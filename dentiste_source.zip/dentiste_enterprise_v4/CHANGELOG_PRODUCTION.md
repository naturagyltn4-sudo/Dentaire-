# CHANGELOG_PRODUCTION — Version "Ready to Go" (9 août 2026)

Cette version a été construite à partir de `dentiste_clinic.zip` et intègre l'intégralité des corrections issues de la certification « Enterprise Production Readiness ». Toutes les validations ont été ré-exécutées sur cette version corrigée avant livraison.

## Corrections de code

| ID | Fichier | Correction | Vérification |
|---|---|---|---|
| FIX-P0 | `api-server/services/patients.py` | Isolation des patients par `clinic_id` : `get_patient`, `list_patients` et `update_patient` filtrent désormais sur la clinique de l'utilisateur authentifié ; tentative de lecture/modification croisée renvoie 404 (pas de fuite d'information) | Régression API exécutée : médecin clinic 2 → 0 patient en liste, GET 404, PATCH refusé ; directrice clinic 1 → accès normal 200 |
| FIX-P3 | `api-server/check_security_config.py` | Suppression de 2 imports inutilisés (`os`, `sys` — F401 ruff) | `ruff check .` : All checks passed |
| FIX-BUILD | `autocommerce-app/.env` | `.env` de test corrigé pour pointer vers le backend local au lieu d'une URL publique morte | Login E2E et build validés |

## Fichiers créés (infrastructure production manquante)

| Fichier | Rôle |
|---|---|
| `infrastructure/nginx/production.conf` | Configuration Nginx production : TLS, HTTP→HTTPS 301, **HSTS** (résout le défaut P2), X-Frame-Options, X-Content-Type-Options, Referrer-Policy, CSP, gzip, cache immutable, proxy /api/ |
| `infrastructure/scripts/backup_restore.sh` | Script officiel de sauvegarde/restoration PostgreSQL (backup/restore/verify) — répond au critère « backup critique vérifié » |
| `api-server/.env.example` | Modèle de configuration production avec instructions de génération des secrets (la configuration refuse de démarrer avec des secrets par défaut) |
| `.github/workflows/ci.yml` | Pipeline CI : backend (PostgreSQL 16 + Redis réels, ruff, compileall, pytest) et frontend (check, test, build) à chaque push/PR |

## Validations ré-exécutées sur cette version

| Validation | Résultat |
|---|---|
| `python3 -m compileall -q` | OK |
| `ruff check` | All checks passed |
| `pytest -q` (backend) | **512 passed, 1 skipped** — identique à la version auditée, aucune régression |
| `pnpm check` (TypeScript) | 0 erreur |
| `pnpm test` (vitest) | 3 fichiers, **16 passed** |
| `pnpm build` (production) | Build réussi en 7,2 s |
| Régression API isolation (P0) | 7 contrôles PASS sur serveur réel |

## Instructions de déploiement

1. Générer les secrets et remplir `api-server/.env` depuis le modèle `.env.example` (`SECRET_KEY`, `FERNET_KEY`, `PHOTO_ENCRYPTION_KEY`, `CORS_ORIGINS` avec le domaine HTTPS réel).
2. Créer la base PostgreSQL et appliquer `alembic upgrade head`, puis exécuter `bootstrap_admin.py`.
3. Démarrer l'API : `cd api-server && python3 main.py`.
4. Construire le frontend : `cd autocommerce-app && pnpm install && pnpm build`, puis servir `dist/public` via Nginx.
5. Installer la configuration Nginx (`infrastructure/nginx/production.conf`) après avoir remplacé `localhost` par le domaine réel et installé un certificat TLS valide (Let's Encrypt recommandé).
6. Programmer le backup quotidien : `0 2 * * * /opt/autocommerce/infrastructure/scripts/backup_restore.sh backup`.
7. Ne pas modifier l'isolation `clinic_id` introduite par FIX-P0 : elle est la condition de conformité RGPD des données patients.
