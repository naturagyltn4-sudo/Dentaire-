const api = (path, options = {}) => fetch(`/api/v1${path}`, {
  credentials: "omit",
  headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  ...options,
});

const byId = (id) => document.getElementById(id);

function showCards(container, items, render) {
  container.innerHTML = items.length ? items.map(render).join("") : "<p class=\"empty\">Aucune information disponible pour le moment.</p>";
}

async function loadPublicContent() {
  const [brandingResponse, practitionersResponse, servicesResponse] = await Promise.all([
    api("/settings/branding"),
    api("/public/praticiens"),
    api("/public/actes"),
  ]);
  if (!brandingResponse.ok || !practitionersResponse.ok || !servicesResponse.ok) {
    throw new Error("Les informations publiques ne sont pas disponibles.");
  }

  const branding = await brandingResponse.json();
  const practitioners = await practitionersResponse.json();
  const services = await servicesResponse.json();

  const clinicName = branding.nom_clinique || "Clinique dentaire";
  byId("clinic-name").textContent = clinicName;
  byId("footer-name").textContent = clinicName;
  const landing = branding.contenu_landing || {};
  byId("clinic-subtitle").textContent = landing.sous_titre || "Découvrez nos praticiens et demandez un créneau en quelques étapes.";
  byId("clinic-address").textContent = landing.adresse || "Informations de la clinique";
  byId("clinic-phone").textContent = landing.telephone || "";
  byId("clinic-hours").textContent = landing.horaires || "";

  showCards(byId("practitioners"), practitioners, (item) => `<article class="card"><span class="avatar">${escapeHtml((item.prenom || "?").slice(0, 1))}</span><h3>${escapeHtml(item.nom_complet || "Praticien")}</h3><p>${escapeHtml(item.specialite || "Pratique dentaire")}</p></article>`);
  showCards(byId("services"), services, (item) => `<article class="card"><h3>${escapeHtml(item.nom || "Acte")}</h3><p>${escapeHtml(item.description || item.categorie || "Soin dentaire")}</p>${item.duree_minutes ? `<small>${item.duree_minutes} minutes</small>` : ""}</article>`);

  byId("praticien-select").insertAdjacentHTML("beforeend", practitioners.map((item) => `<option value="${Number(item.id)}">${escapeHtml(item.nom_complet || "Praticien")}</option>`).join(""));
  byId("acte-select").insertAdjacentHTML("beforeend", services.map((item) => `<option value="${Number(item.id)}">${escapeHtml(item.nom || "Acte")}</option>`).join(""));
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
}

byId("booking-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const formElement = event.currentTarget;
  const status = byId("booking-status");
  const form = new FormData(formElement);
  const payload = Object.fromEntries(form.entries());
  payload.praticien_id = Number(payload.praticien_id);
  payload.acte_id = Number(payload.acte_id);
  payload.date_heure = new Date(payload.date_heure).toISOString();
  status.textContent = "Envoi de votre demande…";
  try {
    const response = await api("/public/reservation", { method: "POST", body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || "La demande n’a pas pu être envoyée.");
    status.textContent = `Demande reçue. Référence ${result.booking_request_id || result.rdv_id || "enregistrée"}.`;
    if (formElement instanceof HTMLFormElement) formElement.reset();
  } catch (error) {
    status.textContent = error instanceof Error ? error.message : "Une erreur est survenue.";
  }
});

loadPublicContent().catch((error) => {
  byId("practitioners").innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`;
  byId("services").innerHTML = "";
});
