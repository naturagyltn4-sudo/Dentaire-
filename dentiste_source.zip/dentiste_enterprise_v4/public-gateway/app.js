const api = (path, options = {}) => fetch(`/api/v1${path}`, {
  credentials: "omit",
  headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  ...options,
});

const byId = (id) => document.getElementById(id);
const practitionerSelect = byId("praticien-select");
const acteSelect = byId("acte-select");
const dateSelect = byId("date-select");
const slotSelect = byId("slot-select");

function showCards(container, items, render) {
  container.innerHTML = items.length ? items.map(render).join("") : "<p class=\"empty\">Aucune information disponible pour le moment.</p>";
}

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[char]));
}

function setSlotPlaceholder(message, disabled = true) {
  slotSelect.innerHTML = `<option value="">${escapeHtml(message)}</option>`;
  slotSelect.disabled = disabled;
}

async function loadPublicContent() {
  const [brandingResponse, practitionersResponse, servicesResponse] = await Promise.all([
    api("/settings/branding"),
    api("/public/praticiens"),
    api("/public/actes"),
  ]);
  if (!brandingResponse.ok || !practitionersResponse.ok || !servicesResponse.ok) {
    throw new Error("Les informations publiques ne sont pas disponibles.");
  }

  const branding = await brandingResponse.json();
  const practitioners = await practitionersResponse.json();
  const services = await servicesResponse.json();
  const clinicName = branding.nom_clinique || "Clinique dentaire";
  const landing = branding.contenu_landing || {};

  byId("clinic-name").textContent = clinicName;
  byId("footer-name").textContent = clinicName;
  byId("clinic-subtitle").textContent = landing.sous_titre || "Découvrez nos praticiens et demandez un créneau en quelques étapes.";
  byId("clinic-address").textContent = landing.adresse || "Informations de la clinique";
  byId("clinic-phone").textContent = landing.telephone || "";
  byId("clinic-hours").textContent = landing.horaires || "";

  showCards(byId("practitioners"), practitioners, (item) => `<article class="card"><span class="avatar">${escapeHtml((item.prenom || "?").slice(0, 1))}</span><h3>${escapeHtml(item.nom_complet || "Praticien")}</h3><p>${escapeHtml(item.specialite || "Pratique dentaire")}</p></article>`);
  showCards(byId("services"), services, (item) => `<article class="card"><h3>${escapeHtml(item.nom || "Acte")}</h3><p>${escapeHtml(item.description || item.categorie || "Soin dentaire")}</p>${item.duree_minutes ? `<small>${item.duree_minutes} minutes</small>` : ""}</article>`);

  practitionerSelect.insertAdjacentHTML("beforeend", practitioners.map((item) => `<option value="${Number(item.id)}">${escapeHtml(item.nom_complet || "Praticien")}</option>`).join(""));
  acteSelect.insertAdjacentHTML("beforeend", services.map((item) => `<option value="${Number(item.id)}">${escapeHtml(item.nom || "Acte")}</option>`).join(""));
}

async function loadAvailableSlots() {
  const practitionerId = Number(practitionerSelect.value);
  const acteId = Number(acteSelect.value);
  const date = dateSelect.value;
  if (!practitionerId || !acteId || !date) {
    setSlotPlaceholder("Choisissez d’abord un praticien, un acte et une date");
    return;
  }

  setSlotPlaceholder("Chargement des créneaux…");
  try {
    const params = new URLSearchParams({ date, acte_id: String(acteId) });
    const response = await api(`/public/disponibilites/${practitionerId}?${params.toString()}`);
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || "Impossible de charger les créneaux.");

    const slots = Array.isArray(result.creneaux) ? result.creneaux : [];
    if (!slots.length) {
      setSlotPlaceholder("Aucun créneau disponible pour cette date");
      return;
    }
    slotSelect.innerHTML = `<option value="">Choisir un créneau</option>${slots.map((slot) => `<option value="${escapeHtml(slot.datetime)}">${escapeHtml(slot.heure || slot.datetime)}</option>`).join("")}`;
    slotSelect.disabled = false;
  } catch (error) {
    setSlotPlaceholder(error instanceof Error ? error.message : "Impossible de charger les créneaux.");
  }
}

[practitionerSelect, acteSelect, dateSelect].forEach((input) => {
  input.addEventListener("change", () => { void loadAvailableSlots(); });
});

byId("booking-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const status = byId("booking-status");
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  const payload = Object.fromEntries(form.entries());
  payload.praticien_id = Number(payload.praticien_id);
  payload.acte_id = Number(payload.acte_id);
  delete payload.date;
  if (!payload.date_heure) {
    status.textContent = "Veuillez choisir un créneau disponible.";
    return;
  }

  status.textContent = "Envoi de votre demande…";
  try {
    const response = await api("/public/reservation", { method: "POST", body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || "La demande n’a pas pu être envoyée.");
    status.textContent = `Demande reçue. Référence ${result.booking_request_id || result.rdv_id || "enregistrée"}. La clinique confirmera le rendez-vous.`;
    if (formElement instanceof HTMLFormElement) {
      formElement.reset();
      setSlotPlaceholder("Choisissez d’abord un praticien, un acte et une date");
    }
  } catch (error) {
    status.textContent = error instanceof Error ? error.message : "Une erreur est survenue.";
  }
});

loadPublicContent().catch((error) => {
  byId("practitioners").innerHTML = `<p class="error">${escapeHtml(error.message)}</p>`;
  byId("services").innerHTML = "";
});
