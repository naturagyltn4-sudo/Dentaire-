# Dentiste RC Enterprise — Installation

## Objet et périmètre

Cette release est conçue selon le modèle **une installation = une clinique**. Chaque déploiement doit être placé sur un VPS ou un hôte dédié à la clinique concernée. L’instance utilise `INSTANCE_CLINIC_ID` comme identité clinique serveur ; cette valeur ne doit jamais être fournie par le navigateur et ne doit pas être modifiée en production sans procédure de migration maîtrisée.

Le présent guide installe la stack complète avec Docker Compose : PostgreSQL 16, Redis 7, l’API FastAPI, les workers Celery, Celery Beat et le frontend Nginx. Le fichier `.env.clinic` est obligatoire, local à l’instance et **ne doit pas être versionné ni transmis dans l’archive client**.

## Prérequis

| Élément | Exigence minimale | Vérification |
|---|---:|---|
| Système | Linux 64 bits récent | `uname -a` |
| Docker Engine | Version supportant Compose v2 | `docker version` |
| Docker Compose | Plugin `docker compose` | `docker compose version` |
| Ressources | 2 vCPU, 4 Go RAM, 40 Go SSD pour un démarrage standard | `free -h`, `df -h` |
| Réseau | DNS et TLS terminés par un reverse proxy ou un load balancer | Vérification avec l’administrateur système |
| Sauvegarde | Stockage hors hôte recommandé | Test de restauration obligatoire |

Les ports applicatifs sont liés à `127.0.0.1` par défaut. Il est recommandé d’exposer uniquement le reverse proxy TLS et de ne jamais publier directement PostgreSQL ou Redis sur Internet.

## Préparation du répertoire

Décompressez l’archive dans un répertoire réservé à l’instance, puis positionnez-vous à sa racine :

```bash
mkdir -p /opt/dentiste-rc
unzip Dentiste-ENTERPRISE-COMMERCIAL-RELEASE.zip -d /opt/dentiste-rc
cd /opt/dentiste-rc/Dentiste-ENTERPRISE-COMMERCIAL-RELEASE
```

Copiez l’exemple d’environnement et protégez immédiatement ses permissions :

```bash
cp .env.example .env.clinic
chmod 600 .env.clinic
```

## Configuration obligatoire

Remplacez toutes les valeurs d’exemple dans `.env.clinic`. Les clés doivent être générées par un gestionnaire de secrets ou par `scripts/generate_secrets.sh`, puis conservées hors Git et hors des tickets de support.

```bash
./scripts/generate_secrets.sh
```

Renseignez au minimum `POSTGRES_PASSWORD`, `REDIS_PASSWORD`, `SECRET_KEY`, `FERNET_KEY`, `PHOTO_ENCRYPTION_KEY`, `BACKUP_ENCRYPTION_KEY`, `DATABASE_URL`, `REDIS_URL`, `CORS_ORIGINS` et `INSTANCE_CLINIC_ID`. En production, `CORS_ORIGINS` doit contenir une liste explicite d’origines HTTPS ; la valeur `*` est interdite avec des credentials.

L’IA est **désactivée par défaut** avec `COPILOTE_IA_ENABLED=false`. Son activation est une décision séparée, soumise à la validation contractuelle et de protection des données de la clinique. Tant que ce drapeau reste faux, les traitements IA dentaire, CRM et scanner de facture ne doivent pas appeler de fournisseur externe.

## Premier démarrage

Validez d’abord la configuration sans démarrer les services :

```bash
docker compose -f docker-compose.production.yml config --quiet
```

Démarrez ensuite la base, Redis, les migrations, l’API et le frontend :

```bash
docker compose -f docker-compose.production.yml up -d postgres redis
docker compose -f docker-compose.production.yml up -d migrate
docker compose -f docker-compose.production.yml up -d api worker beat frontend
```

Les migrations sont exécutées par le service `migrate` et doivent se terminer avec le code 0 avant que l’API soit considérée comme disponible. Vérifiez l’état des services et les healthchecks :

```bash
docker compose -f docker-compose.production.yml ps
curl -fsS http://127.0.0.1:8000/ready
curl -I http://127.0.0.1:8080/
```

## Création du premier administrateur

Utilisez `api-server/bootstrap_admin.py` dans un environnement contrôlé, avec un mot de passe temporaire unique qui sera remplacé à la première connexion. N’inscrivez jamais le mot de passe dans l’historique shell ou dans un fichier de preuve. Après création, activez MFA pour tous les comptes administrateurs et vérifiez que le compte possède le `clinic_id` de l’instance.

## Vérifications de remise

Avant remise au client, l’intégrateur doit confirmer que le reverse proxy force HTTPS, que les cookies de refresh sont `HttpOnly`, `Secure` et `SameSite` selon le mode de déploiement, que PostgreSQL et Redis ne sont pas publiquement accessibles, que les sauvegardes sont chiffrées et qu’une restauration a été testée sur un environnement séparé.

Le contrôle automatisé de la release est exécuté avec :

```bash
./scripts/release_gate.sh
```

Le code de sortie 0 signifie **GO**. Toute autre valeur signifie **NO-GO** et doit être traitée avant livraison.
