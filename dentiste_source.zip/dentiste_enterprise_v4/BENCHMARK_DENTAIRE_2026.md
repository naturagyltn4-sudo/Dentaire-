# Benchmark des logiciels dentaires — constats de conception

## Sources consultées

- Timed, « Logiciel de gestion RH pour les cabinets dentaires » : https://www.timed.fr/logiciel-cabinet-dentaire-rh-plannings/
- Dental Pilote, « Gestion Cabinet Dentaire Moderne » : https://dentalpilote.com/gestion-cabinet-dentaire
- Julie Solutions, « L’agenda 2.0 intégré » : https://www.julie.fr/article_lagenda_2_0_integre/

## Constats retenus

Les solutions dentaires de référence centralisent l'agenda par praticien, lieu, fauteuil et type d'acte. Elles préviennent les conflits, supportent les soins en binôme praticien-assistante, gèrent les urgences et proposent des rappels ainsi qu'une liste d'attente pour compenser les annulations.

La couche RH attendue comprend des fiches adaptées au statut de chaque membre (associé, salarié, collaborateur ou remplaçant), les congés et absences, les remplacements, le suivi des heures et les journées ou demi-journées de présence des praticiens. Les données RH doivent rester distinctes des dossiers médicaux et être contrôlées par l'administration.

La gestion métier dentaire doit conserver l'odontogramme, l'imagerie/radiologie, les prothèses et le suivi orthodontique, tout en reliant les actes, la durée, le fauteuil, le praticien et la facturation. Les workflows utiles incluent la préparation du patient, la stérilisation, les commandes de laboratoire, les relances et le suivi des devis.

## Adaptations appliquées dans cette phase

Le référentiel public accepte maintenant le rôle `orthodontiste`. La disponibilité interne prend l'`acte_id` afin d'utiliser sa durée réelle au lieu d'un créneau fixe de 30 minutes. Les réservations avec fauteuil exigent une salle et vérifient la capacité de la salle. Un verrou transactionnel PostgreSQL sérialise les créations concurrentes sur le même cabinet, jour, praticien et salle afin de réduire les courses de réservation.
