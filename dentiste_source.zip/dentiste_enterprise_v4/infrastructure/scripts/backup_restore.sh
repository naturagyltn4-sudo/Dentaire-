#!/usr/bin/env bash
# Point d’entrée unique pour les opérations de sauvegarde/restauration mono-VPS.
# La logique officielle est maintenue dans api-server/scripts/backup_restore.sh.
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
BACKEND_SCRIPT="$PROJECT_ROOT/api-server/scripts/backup_restore.sh"

[ -x "$BACKEND_SCRIPT" ] || {
    echo "Script backup backend introuvable ou non exécutable : $BACKEND_SCRIPT" >&2
    exit 2
}

exec "$BACKEND_SCRIPT" "$@"
