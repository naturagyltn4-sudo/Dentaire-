#!/usr/bin/env bash
# Provisionnement Nginx/TLS de l'instance clinique.
# Usage: sudo DOMAIN=clinic.example.com EMAIL=ops@example.com ./provision_nginx.sh
set -euo pipefail

DOMAIN="${DOMAIN:?DOMAIN est requis}"
EMAIL="${EMAIL:?EMAIL est requis}"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
TEMPLATE="$PROJECT_ROOT/infrastructure/nginx/production.conf"
TARGET="/etc/nginx/sites-available/dentiste-enterprise"

[[ $EUID -eq 0 ]] || { echo "Exécuter ce script avec sudo" >&2; exit 2; }
[[ "$DOMAIN" =~ ^[A-Za-z0-9][A-Za-z0-9.-]*[A-Za-z0-9]$ && "$DOMAIN" == *.* ]] || {
    echo "Domaine pleinement qualifié invalide" >&2; exit 2;
}
[[ -f "$TEMPLATE" ]] || { echo "Template Nginx introuvable: $TEMPLATE" >&2; exit 2; }
command -v nginx >/dev/null || { echo "nginx est requis" >&2; exit 2; }
command -v certbot >/dev/null || { echo "certbot est requis" >&2; exit 2; }
command -v ss >/dev/null || { echo "iproute2/ss est requis" >&2; exit 2; }

if ss -ltn '( sport = :80 )' | grep -q LISTEN; then
    echo "Le port 80 est déjà occupé. Libérer le port HTTP avant le challenge Certbot standalone." >&2
    exit 3
fi

certbot certonly --standalone --non-interactive --agree-tos --email "$EMAIL" \
    --preferred-challenges http -d "$DOMAIN"

install -d -m 0755 /etc/nginx/sites-available /etc/nginx/sites-enabled
if [[ -f "$TARGET" ]]; then
    cp -a "$TARGET" "$TARGET.bak.$(date -u +%Y%m%dT%H%M%SZ)"
fi
sed \
  -e "s/server_name _;/server_name $DOMAIN;/g" \
  -e "s#/etc/nginx/ssl/server.crt#/etc/letsencrypt/live/$DOMAIN/fullchain.pem#g" \
  -e "s#/etc/nginx/ssl/server.key#/etc/letsencrypt/live/$DOMAIN/privkey.pem#g" \
  "$TEMPLATE" > "$TARGET"
ln -sfn "$TARGET" /etc/nginx/sites-enabled/dentiste-enterprise
nginx -t
systemctl enable nginx >/dev/null
systemctl reload nginx 2>/dev/null || systemctl start nginx
printf 'Nginx provisionné pour %s avec certificat certbot.\n' "$DOMAIN"
