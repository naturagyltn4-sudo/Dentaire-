# Sauvegarde de production

Installer `clinic-backup.service` et `clinic-backup.timer` dans `/etc/systemd/system/`, adapter `WorkingDirectory` au chemin réel de la release, puis exécuter `systemctl daemon-reload`, `systemctl enable --now clinic-backup.timer` et `systemctl start clinic-backup.service` pour un premier test supervisé.

La cadence par défaut est quotidienne à 02:30 avec un décalage aléatoire maximal de 15 minutes. `BACKUP_RETENTION_DAYS` est fixé à 30 jours dans l’exemple d’environnement. La cible opérationnelle proposée est un **RPO de 24 heures** et un **RTO de 4 heures**, à confirmer par un test réel de restauration et par la capacité de l’équipe du cabinet.

`BACKUP_OFFSITE_SCRIPT` doit être configuré avec un script exécutable qui transfère le fichier chiffré vers un stockage externe contrôlé. Sans ce script, la sauvegarde reste locale au VPS et la procédure ne doit pas être certifiée comme protection contre la perte du VPS.
