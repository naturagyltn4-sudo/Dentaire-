#!/usr/bin/env bash
# Génère un fichier .env.clinic local à partir de .env.example.
# Le fichier généré est volontairement hors dépôt et doit rester protégé.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEMPLATE="${1:-$ROOT/.env.example}"
OUTPUT="${2:-$ROOT/.env.clinic}"

[ -f "$TEMPLATE" ] || { echo "Template introuvable : $TEMPLATE" >&2; exit 1; }
if [ -e "$OUTPUT" ] && [ "${FORCE:-0}" != "1" ]; then
    echo "Le fichier existe déjà : $OUTPUT (utiliser FORCE=1 pour le remplacer)" >&2
    exit 2
fi

rand() { openssl rand -base64 64 | tr -dc 'A-Za-z0-9' | head -c 64; }
secret_key="$(rand)"
fernet_key="$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
photo_key="$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
backup_key="$(rand)"
postgres_password="$(rand)"
redis_password="$(rand)"

sed \
    -e "s#^SECRET_KEY=.*#SECRET_KEY=$secret_key#" \
    -e "s#^FERNET_KEY=.*#FERNET_KEY=$fernet_key#" \
    -e "s#^PHOTO_ENCRYPTION_KEY=.*#PHOTO_ENCRYPTION_KEY=$photo_key#" \
    -e "s#^BACKUP_ENCRYPTION_KEY=.*#BACKUP_ENCRYPTION_KEY=$backup_key#" \
    -e "s#^POSTGRES_PASSWORD=.*#POSTGRES_PASSWORD=$postgres_password#" \
    -e "s#^REDIS_PASSWORD=.*#REDIS_PASSWORD=$redis_password#" \
    -e "s#^DATABASE_URL=.*#DATABASE_URL=postgresql+asyncpg://clinic_user:$postgres_password@postgres:5432/clinic_db#" \
    -e "s#^REDIS_URL=.*#REDIS_URL=redis://:$redis_password@redis:6379/0#" \
    "$TEMPLATE" > "$OUTPUT"

chmod 600 "$OUTPUT"
echo "Secrets générés dans $OUTPUT (fichier local, non destiné au dépôt)."
