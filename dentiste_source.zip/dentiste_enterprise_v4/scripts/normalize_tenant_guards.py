from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "api-server" / "services"
FILES = [
    "agenda.py",
    "compte_rendu_dentaire.py",
    "consentement.py",
    "facture_scanner.py",
    "factures.py",
    "fidelite.py",
    "ia_dentaire.py",
    "marketing.py",
    "photos_clinic.py",
    "protheses.py",
    "radiologie.py",
    "reputation.py",
    "simulation_morphing.py",
    "social_crm.py",
]
PATTERN = re.compile(
    r'    if not isinstance\(clinic_id, int\) or clinic_id <= 0:\n'
    r'        raise ValueError\((?P<q>[\"\'])(?P<msg>.*?)(?P=q)\)\n'
    r'(?:    clinic_id = int\(clinic_id\)\n)?'
)

for name in FILES:
    path = ROOT / name
    text = path.read_text()
    original = text
    if "from middleware.clinic_context import require_clinic_id" not in text:
        lines = text.splitlines(keepends=True)
        insert_at = 0
        while insert_at < len(lines) and (lines[insert_at].startswith('"') or lines[insert_at].strip() == ""):
            insert_at += 1
        lines.insert(insert_at, "from middleware.clinic_context import require_clinic_id\n")
        text = "".join(lines)
    def repl(match: re.Match[str]) -> str:
        q = match.group("q")
        msg = match.group("msg")
        purpose = msg.replace("clinic_id explicite requis pour ", "")
        return f"    clinic_id = require_clinic_id(clinic_id, purpose={q}{purpose}{q})\n"
    text, count = PATTERN.subn(repl, text)
    if count == 0:
        print(f"unchanged:{name}")
    elif text != original:
        path.write_text(text)
        print(f"updated:{name}:{count}")

# The omnicanal service has its own public helper; keep that single API and
# delegate to the central policy so non-production compatibility cannot leak
# into production.
omni = ROOT / "omnicanal_service.py"
text = omni.read_text()
text = text.replace(
    "from services.omnicanal.factory import get_connector, get_canal_labels\n",
    "from services.omnicanal.factory import get_connector, get_canal_labels\nfrom middleware.clinic_context import require_clinic_id\n",
)
old = '''def _require_clinic_id(clinic_id: int | None) -> int:\n    if not isinstance(clinic_id, int) or clinic_id <= 0:\n        raise ValueError("clinic_id explicite requis pour l’omnicanal")\n    return clinic_id\n'''
new = '''def _require_clinic_id(clinic_id: int | None) -> int:\n    return require_clinic_id(clinic_id, purpose="l’omnicanal")\n'''
if old not in text:
    raise SystemExit("omnicanal helper pattern not found")
omni.write_text(text.replace(old, new))
print("updated:omnicanal_service:central-helper")
