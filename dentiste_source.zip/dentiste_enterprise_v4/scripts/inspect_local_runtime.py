"""Affiche les comptages métier du runtime SQLite de validation."""

import asyncio
import os

from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine


async def main() -> None:
    engine = create_async_engine(os.environ["DATABASE_URL"])
    async with engine.connect() as connection:
        for table in ("utilisateurs", "actes_medicaux", "salles", "patients", "rendez_vous", "booking_requests"):
            value = await connection.scalar(text(f"SELECT count(*) FROM {table}"))
            print(f"{table}={value}")
        rows = (await connection.execute(text(
            "SELECT id, statut, patient_id, rendez_vous_id FROM booking_requests ORDER BY id DESC LIMIT 3"
        ))).all()
        for row in rows:
            print(f"booking_request={row[0]} statut={row[1]} patient_id={row[2]} rendez_vous_id={row[3]}")
    await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
