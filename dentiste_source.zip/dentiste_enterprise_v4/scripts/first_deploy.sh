#!/usr/bin/env bash
# Première installation mono-VPS du cabinet dentaire.
# À exécuter depuis n’importe quel répertoire; le projet est résolu depuis ce fichier.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

required_files=(
    ".env.example"
    "docker-compose.production.yml"
    "scripts/generate_secrets.sh"
    "infrastructure/scripts/backup_restore.sh"
    "api-server/scripts/backup_restore.sh"
    "api-server/scripts/pre_deploy_security_check.py"
)

for path in "${required_files[@]}"; do
    [ -f "$ROOT/$path" ] || {
        echo "Fichier requis introuvable : $path" >&2
        exit 1
    }
done

# Le mode contrôle ne crée ni ne modifie aucun fichier de secrets.
if [ "${CHECK_ONLY:-0}" = "1" ]; then
    echo "Vérification des chemins réussie depuis : $ROOT"
    exit 0
fi

# Les secrets restent hors du dépôt. Par défaut, le script prépare .env
# depuis le template ; un opérateur peut fournir DEPLOY_ENV_FILE explicitement.
ENV_FILE="${DEPLOY_ENV_FILE:-$ROOT/.env}"
if [ -z "${DEPLOY_ENV_FILE:-}" ] && [ ! -f "$ENV_FILE" ]; then
    "$ROOT/scripts/generate_secrets.sh" "$ROOT/.env.example" "$ENV_FILE"
fi
[ -f "$ENV_FILE" ] || { echo "Fichier env absent : $ENV_FILE" >&2; exit 1; }
chmod 600 "$ENV_FILE"
export DEPLOY_ENV_FILE="$ENV_FILE"

# Aucun démarrage ne doit contourner les contrôles de la release.
"$ROOT/scripts/production_preflight.sh"
NGINX_PRODUCTION_CONF="${NGINX_PRODUCTION_CONF:-/etc/nginx/sites-available/autocommerce}"
[ -f "$NGINX_PRODUCTION_CONF" ] || {
    echo "Configuration Nginx rendue introuvable : $NGINX_PRODUCTION_CONF" >&2
    echo "Exécuter provision_nginx.sh avant le premier démarrage." >&2
    exit 3
}
(
    cd "$ROOT/api-server"
    DEPLOY_ENV_FILE="$ENV_FILE" NGINX_PRODUCTION_CONF="$NGINX_PRODUCTION_CONF" \
      python3 scripts/pre_deploy_security_check.py
)

command -v docker >/dev/null 2>&1 || {
    echo "Docker est requis pour poursuivre le premier déploiement" >&2
    exit 2
}

docker compose --env-file "$ENV_FILE" -f "$ROOT/docker-compose.production.yml" config >/dev/null

echo "Configuration Docker valide. Lancement des services..."
docker compose --env-file "$ENV_FILE" -f "$ROOT/docker-compose.production.yml" up -d --build

echo "Premier déploiement lancé. Vérifier les healthchecks avant toute certification."
