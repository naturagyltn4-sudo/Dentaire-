#!/usr/bin/env bash
set -Eeuo pipefail

PUBLIC_BASE_URL="${PUBLIC_BASE_URL:-http://127.0.0.1:8090}"
PROJECT="${COMPOSE_PROJECT_NAME:-dentiste-audit}"
PRIVATE_API_CONTAINER="${PRIVATE_API_CONTAINER:-${PROJECT}-private_api-1}"
PUBLIC_GATEWAY_CONTAINER="${PUBLIC_GATEWAY_CONTAINER:-${PROJECT}-public_gateway-1}"
PRIVATE_FRONTEND_CONTAINER="${PRIVATE_FRONTEND_CONTAINER:-${PROJECT}-private_frontend-1}"
WORKER_CONTAINER="${WORKER_CONTAINER:-${PROJECT}-worker-1}"
BEAT_CONTAINER="${BEAT_CONTAINER:-${PROJECT}-beat-1}"

if docker info >/dev/null 2>&1; then
  docker_cmd() { docker "$@"; }
elif sudo docker info >/dev/null 2>&1; then
  docker_cmd() { sudo docker "$@"; }
else
  echo "NO-GO: Docker is unavailable" >&2
  exit 2
fi

check_http() {
  local name="$1" expected="$2" url="$3"
  local body_file
  body_file=$(mktemp)
  local code
  code=$(curl --max-time 15 --silent --show-error --output "$body_file" --write-out '%{http_code}' "$url")
  if [[ "$code" != "$expected" ]]; then
    echo "FAIL $name expected=$expected actual=$code url=$url body=$(head -c 180 "$body_file")" >&2
    rm -f "$body_file"
    return 1
  fi
  echo "PASS $name status=$code url=$url"
  rm -f "$body_file"
}

check_http "public-health" 200 "$PUBLIC_BASE_URL/healthz"
check_http "public-landing" 200 "$PUBLIC_BASE_URL/"
check_http "public-branding" 200 "$PUBLIC_BASE_URL/api/v1/settings/branding"
check_http "public-practitioners" 200 "$PUBLIC_BASE_URL/api/v1/public/praticiens"
check_http "public-acts" 200 "$PUBLIC_BASE_URL/api/v1/public/actes"
check_http "private-api-blocked-from-public" 404 "$PUBLIC_BASE_URL/api/v1/patients"
check_http "private-admin-blocked-from-public" 404 "$PUBLIC_BASE_URL/api/v1/admin/users"

private_api_status=$(docker_cmd exec "$PRIVATE_API_CONTAINER" sh -lc 'curl --max-time 10 --silent --show-error --output /dev/null --write-out "%{http_code}" http://localhost:8000/ready')
[[ "$private_api_status" == "200" ]] || { echo "FAIL private-api-ready status=$private_api_status" >&2; exit 1; }
echo "PASS private-api-ready status=$private_api_status"

private_frontend_status=$(docker_cmd exec "$PRIVATE_API_CONTAINER" sh -lc 'curl --max-time 10 --silent --show-error --output /dev/null --write-out "%{http_code}" http://private_frontend/healthz')
[[ "$private_frontend_status" == "200" ]] || { echo "FAIL private-frontend-from-clinical-network status=$private_frontend_status" >&2; exit 1; }
echo "PASS private-frontend-from-clinical-network status=$private_frontend_status"

for container in "$PRIVATE_API_CONTAINER" "$PUBLIC_GATEWAY_CONTAINER" "$PRIVATE_FRONTEND_CONTAINER" "$WORKER_CONTAINER" "$BEAT_CONTAINER"; do
  status=$(docker_cmd inspect -f '{{.State.Status}}' "$container")
  [[ "$status" == "running" ]] || { echo "FAIL container-running name=$container status=$status" >&2; exit 1; }
  echo "PASS container-running name=$container"
done

for container in "$PRIVATE_API_CONTAINER" "$PUBLIC_GATEWAY_CONTAINER" "$PRIVATE_FRONTEND_CONTAINER" "$WORKER_CONTAINER" "$BEAT_CONTAINER"; do
  health=$(docker_cmd inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}no-healthcheck{{end}}' "$container")
  [[ "$health" == "healthy" ]] || { echo "FAIL container-health name=$container health=$health" >&2; exit 1; }
  echo "PASS container-health name=$container"
done

echo "PUBLIC_PRIVATE_BOUNDARY=PASS"
