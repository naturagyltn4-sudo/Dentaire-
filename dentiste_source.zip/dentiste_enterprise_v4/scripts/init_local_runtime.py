"""Initialise une base SQLite isolée pour la validation locale du projet dentaire."""

import asyncio
import os
from decimal import Decimal
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.ext.asyncio import create_async_engine

from middleware.auth import get_password_hash
from models.database import Base, ActeMedical, RoleEnum, Salle, Utilisateur
from models import omnicanal as _omnicanal  # noqa: F401
from models import security as _security  # noqa: F401
from models import workflow_engine as _workflow_engine  # noqa: F401
from models import superadmin as _superadmin  # noqa: F401
from models.superadmin import ClinicSubscription, CliniqueTenant


async def main() -> None:
    database_url = os.environ["DATABASE_URL"]
    engine = create_async_engine(database_url)
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    async with engine.begin() as connection:
        from sqlalchemy.ext.asyncio import async_sessionmaker

        session_factory = async_sessionmaker(engine, expire_on_commit=False)
        async with session_factory() as session:
            accounts = [
                ("directrice@dentiste-validation.tn", "Directrice", "Validation", RoleEnum.DIRECTRICE.value),
                ("dentiste@dentiste-validation.tn", "Dentiste", "Validation", RoleEnum.MEDECIN.value),
                ("assistante@dentiste-validation.tn", "Assistante", "Validation", RoleEnum.ASSISTANTE.value),
                ("admin@dentiste-validation.tn", "Admin", "Validation", RoleEnum.ADMIN.value),
                ("superadmin@dentiste-validation.tn", "Super", "Admin", RoleEnum.SUPERADMIN.value),
            ]
            for email, nom, prenom, role in accounts:
                existing = await session.scalar(select(Utilisateur).where(Utilisateur.email == email))
                if existing is None:
                    session.add(
                        Utilisateur(
                            clinic_id=1,
                            email=email,
                            hashed_password=get_password_hash("Validation-Dentaire-2026!"),
                            nom=nom,
                            prenom=prenom,
                            role=role,
                            is_active=True,
                        )
                    )
            if await session.scalar(select(CliniqueTenant).where(CliniqueTenant.id == 1)) is None:
                session.add(CliniqueTenant(id=1, nom="Cabinet Dentaire de Validation", slug="cabinet-dentaire-validation", statut="active"))
                await session.flush()
            if await session.scalar(select(ClinicSubscription).where(ClinicSubscription.clinic_id == 1)) is None:
                session.add(ClinicSubscription(clinic_id=1, plan="enterprise", statut="active", user_limit=25, storage_limit_gb=100))
            if await session.scalar(select(ActeMedical).where(ActeMedical.clinic_id == 1)) is None:
                session.add(
                    ActeMedical(
                        clinic_id=1,
                        nom="Consultation dentaire",
                        categorie="consultation",
                        duree_minutes=45,
                        prix_base=Decimal("80.000"),
                        description="Consultation de validation runtime",
                        is_active=True,
                    )
                )
            if await session.scalar(select(Salle).where(Salle.clinic_id == 1)) is None:
                session.add(
                    Salle(
                        clinic_id=1,
                        nom="Cabinet dentaire principal",
                        capacite_fauteuils=1,
                    )
                )
            await session.commit()
    await engine.dispose()
    print("LOCAL_RUNTIME_INITIALIZED")


if __name__ == "__main__":
    asyncio.run(main())
