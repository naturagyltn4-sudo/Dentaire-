import secrets
from pathlib import Path
from cryptography.fernet import Fernet

import sys
print("generate_deploy_env.py est un utilitaire de test éphémère. Ne pas utiliser en production.", file=sys.stderr)
sys.exit(1)
vals = {
    'ENV': 'production',
    'INSTANCE_CLINIC_ID': '1',
    'POSTGRES_DB': 'clinic_db',
    'POSTGRES_USER': 'clinic_user',
    'POSTGRES_PASSWORD': secrets.token_urlsafe(32),
    'REDIS_PASSWORD': secrets.token_urlsafe(32),
    'SECRET_KEY': secrets.token_urlsafe(48),
    'FERNET_KEY': Fernet.generate_key().decode(),
    'PHOTO_ENCRYPTION_KEY': Fernet.generate_key().decode(),
    'BACKUP_ENCRYPTION_KEY': Fernet.generate_key().decode(),
    'CORS_ORIGINS': 'http://127.0.0.1:18080,http://localhost:18080',
    'PRIVATE_FRONTEND_BIND': '127.0.0.1',
    'PRIVATE_FRONTEND_PORT': '18080',
    'PUBLIC_GATEWAY_BIND': '127.0.0.1',
    'PUBLIC_GATEWAY_PORT': '18090',
    'COPILOTE_IA_ENABLED': 'false',
    'BACKUP_RETENTION_DAYS': '30',
}
vals['DATABASE_URL'] = f"postgresql+asyncpg://{vals['POSTGRES_USER']}:{vals['POSTGRES_PASSWORD']}@postgres:5432/{vals['POSTGRES_DB']}"
vals['REDIS_URL'] = f"redis://:{vals['REDIS_PASSWORD']}@redis:6379/0"
(root / '.env.clinic').write_text('\n'.join(f'{key}={value}' for key, value in vals.items()) + '\n')
print('wrote .env.clinic with ephemeral validation secrets')
