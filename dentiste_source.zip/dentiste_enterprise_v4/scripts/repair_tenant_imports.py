from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "api-server" / "services"
FILES = [
    "agenda.py", "compte_rendu_dentaire.py", "consentement.py",
    "facture_scanner.py", "factures.py", "fidelite.py", "ia_dentaire.py",
    "marketing.py", "photos_clinic.py", "protheses.py", "radiologie.py",
    "reputation.py", "simulation_morphing.py", "social_crm.py",
    "omnicanal_service.py",
]
IMPORT = "from middleware.clinic_context import require_clinic_id\n"
for name in FILES:
    path = ROOT / name
    text = path.read_text()
    lines = [line for line in text.splitlines(keepends=True) if line.strip() != IMPORT.strip()]
    text = "".join(lines)
    rows = text.splitlines(keepends=True)
    future_index = next((i for i, line in enumerate(rows) if line.startswith("from __future__ import")), None)
    if future_index is not None:
        rows.insert(future_index + 1, IMPORT)
    else:
        first = next((i for i, line in enumerate(rows) if line.strip()), 0)
        if rows[first].lstrip().startswith(('"""', "'''")):
            marker = rows[first].lstrip()[:3]
            if rows[first].count(marker) >= 2:
                insert_at = first + 1
            else:
                insert_at = first + 1
                while insert_at < len(rows) and marker not in rows[insert_at]:
                    insert_at += 1
                insert_at += 1
        else:
            insert_at = first
        rows.insert(insert_at, IMPORT)
    path.write_text("".join(rows))
    print(f"repaired:{name}")
