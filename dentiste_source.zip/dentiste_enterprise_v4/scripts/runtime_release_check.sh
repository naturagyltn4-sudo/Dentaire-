#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT="${COMPOSE_PROJECT_NAME:-dentiste-release-gate-${RUNTIME_RUN_ID:-manual}}"
PUBLIC_PORT="${PUBLIC_GATEWAY_PORT:-18090}"
PUBLIC_URL="${PUBLIC_BASE_URL:-http://127.0.0.1:${PUBLIC_PORT}}"
PRIVATE_E2E_EMAIL="e2e.directrice@validation.example.com"
PRIVATE_E2E_PASSWORD="Validation-Pass-2026!Secure"
PRIVATE_E2E_TOTP_SECRET="JBSWY3DPEHPK3PXP"
PRIVATE_E2E_TLS_PORT="${PRIVATE_E2E_TLS_PORT:-18443}"
PRIVATE_E2E_TLS_PID=""

if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
  DOCKER=(docker)
elif command -v sudo >/dev/null 2>&1 && sudo docker info >/dev/null 2>&1; then
  DOCKER=(sudo env \
    POSTGRES_PASSWORD="${POSTGRES_PASSWORD:-}" \
    REDIS_PASSWORD="${REDIS_PASSWORD:-}" \
    PRIVATE_FRONTEND_BIND="${PRIVATE_FRONTEND_BIND:-127.0.0.1}" \
    PRIVATE_FRONTEND_PORT="${PRIVATE_FRONTEND_PORT:-18080}" \
    PUBLIC_GATEWAY_BIND="${PUBLIC_GATEWAY_BIND:-127.0.0.1}" \
    PUBLIC_GATEWAY_PORT="${PUBLIC_GATEWAY_PORT:-18090}" \
    docker)
else
  echo "Docker daemon unavailable" >&2
  exit 2
fi

compose() {
  "${DOCKER[@]}" compose -p "$PROJECT" -f "$ROOT_DIR/docker-compose.production.yml" "$@"
}

docker_cmd() {
  "${DOCKER[@]}" "$@"
}

cleanup() {
  if [[ -n "$PRIVATE_E2E_TLS_PID" ]]; then
    kill "$PRIVATE_E2E_TLS_PID" >/dev/null 2>&1 || true
  fi
  rm -f "/tmp/dentiste-private-e2e-${RUNTIME_RUN_ID:-manual}.key" "/tmp/dentiste-private-e2e-${RUNTIME_RUN_ID:-manual}.crt"
  compose --profile backup down -v --remove-orphans >/dev/null 2>&1 || true
}
trap cleanup EXIT

export COMPOSE_PROJECT_NAME="$PROJECT"
export PUBLIC_GATEWAY_PORT="$PUBLIC_PORT"
export PUBLIC_GATEWAY_BIND="${PUBLIC_GATEWAY_BIND:-127.0.0.1}"
export PRIVATE_FRONTEND_BIND="${PRIVATE_FRONTEND_BIND:-127.0.0.1}"
export PRIVATE_FRONTEND_PORT="${PRIVATE_FRONTEND_PORT:-18080}"

compose config --quiet
compose build
compose up -d postgres redis

# Le sandbox de validation peut démarrer dockerd sans la table iptables raw.
# Dans ce cas uniquement, autoriser le trafic intra-bridge nécessaire au test;
# aucun transit entre bridges n’est ajouté et aucun réglage VPS client n’est modifié.
allow_sandbox_bridge_traffic() {
  if command -v iptables >/dev/null 2>&1 && ! sudo iptables -t raw -L >/dev/null 2>&1; then
    for bridge in $(ip -o link show | awk -F': ' '$2 ~ /^br-[[:alnum:]]+$/ {print $2}'); do
      sudo iptables -C DOCKER-USER -i "$bridge" -o "$bridge" -j ACCEPT >/dev/null 2>&1 || \
        sudo iptables -I DOCKER-USER -i "$bridge" -o "$bridge" -j ACCEPT
    done
  fi
}

allow_sandbox_bridge_traffic
compose run --rm migrate
compose up -d private_api public_api private_frontend public_gateway worker beat
allow_sandbox_bridge_traffic

for service in private_api public_api private_frontend public_gateway worker beat; do
  container="${PROJECT}-${service}-1"
  ready=0
  for attempt in $(seq 1 20); do
    health=$(docker_cmd inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}no-healthcheck{{end}}' "$container" 2>/dev/null || true)
    if [[ "$health" == "healthy" ]]; then
      ready=1
      break
    fi
    sleep 3
  done
  if [[ "$ready" -ne 1 ]]; then
    echo "Healthcheck timeout: $container" >&2
    docker_cmd inspect -f '{{json .State.Health}}' "$container" >&2 || true
    exit 1
  fi
done

COMPOSE_PROJECT_NAME="$PROJECT" PUBLIC_BASE_URL="$PUBLIC_URL" \
  "$ROOT_DIR/scripts/test_public_private.sh"

(
  cd "$ROOT_DIR/validation-private-frontend"
  E2E_BASE_URL="$PUBLIC_URL" pnpm exec playwright test tests/e2e/public-gateway.spec.ts --project=chromium --reporter=line
)

PRIVATE_API_CONTAINER="${PROJECT}-private_api-1"
PRIVATE_FRONTEND_CONTAINER="${PROJECT}-private_frontend-1"
printf '%s\n' "$PRIVATE_E2E_PASSWORD" | "${DOCKER[@]}" exec -i "$PRIVATE_API_CONTAINER" python bootstrap_admin.py \
  --email "$PRIVATE_E2E_EMAIL" --nom Validation --prenom Directrice --role directrice \
  --clinic-id 1 --force --password-stdin
"${DOCKER[@]}" exec -i "$PRIVATE_API_CONTAINER" python - < "$ROOT_DIR/api-server/scripts/enable_validation_mfa.py"

PRIVATE_FRONTEND_IP="$(docker_cmd inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "$PRIVATE_FRONTEND_CONTAINER")"
TLS_KEY="/tmp/dentiste-private-e2e-${RUNTIME_RUN_ID:-manual}.key"
TLS_CERT="/tmp/dentiste-private-e2e-${RUNTIME_RUN_ID:-manual}.crt"
openssl req -x509 -nodes -newkey rsa:2048 -keyout "$TLS_KEY" -out "$TLS_CERT" \
  -days 1 -subj '/CN=127.0.0.1' >/dev/null 2>&1
socat "OPENSSL-LISTEN:${PRIVATE_E2E_TLS_PORT},cert=${TLS_CERT},key=${TLS_KEY},verify=0,reuseaddr,fork" \
  "TCP:${PRIVATE_FRONTEND_IP}:80" >/tmp/dentiste-private-e2e-socat.log 2>&1 &
PRIVATE_E2E_TLS_PID=$!
sleep 2
if ! kill -0 "$PRIVATE_E2E_TLS_PID" >/dev/null 2>&1; then
  cat /tmp/dentiste-private-e2e-socat.log >&2 || true
  exit 1
fi
(
  cd "$ROOT_DIR/validation-private-frontend"
  E2E_BASE_URL="https://127.0.0.1:${PRIVATE_E2E_TLS_PORT}" \
  E2E_IGNORE_HTTPS_ERRORS=1 \
  E2E_PRIVATE_EMAIL="$PRIVATE_E2E_EMAIL" \
  E2E_PRIVATE_PASSWORD="$PRIVATE_E2E_PASSWORD" \
  E2E_PRIVATE_TOTP_SECRET="$PRIVATE_E2E_TOTP_SECRET" \
  pnpm exec playwright test tests/e2e/private-clinical.spec.ts --project=chromium --reporter=line
)

compose --profile backup run --rm backup
compose --profile backup run --rm backup /bin/bash -lc \
  'set -e; file=$(ls -1t /app/backups/*.dump.gpg | head -1); ./scripts/backup_restore.sh verify "$file"; ./scripts/backup_restore.sh restore "$file"'

echo "PRIVATE_CLINICAL_E2E=PASS"
echo "RUNTIME_RELEASE_CHECK=PASS"
