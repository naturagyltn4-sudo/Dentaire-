#!/usr/bin/env bash
set -uo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/api-server"
FRONTEND_DIR="$ROOT_DIR/validation-private-frontend"
RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)"
PROJECT_ID="release-gate-$(printf '%s' "$RUN_ID" | tr '[:upper:]' '[:lower:]')"
ARTIFACT_DIR="$ROOT_DIR/release-artifacts/release-gate-$RUN_ID"
SUMMARY_FILE="$ARTIFACT_DIR/summary.tsv"
mkdir -p "$ARTIFACT_DIR"
printf 'CHECK\tSTATUS\tLOG\n' > "$SUMMARY_FILE"

OVERALL=0
TEMP_ENV_CREATED=0
OFFSITE_DIR="$ROOT_DIR/.release-offsite"

record() {
  local check="$1" status="$2" log="$3"
  printf '%s\t%s\t%s\n' "$check" "$status" "$log" >> "$SUMMARY_FILE"
  [[ "$status" == "PASS" ]] || OVERALL=1
  printf '[%s] %s — %s\n' "$status" "$check" "$log"
}

safe_log_name() {
  printf '%s' "$1" | tr '[:upper:] /' '[:lower:]__' | tr -cd '[:alnum:]_.-'
}

run_check() {
  local check="$1" cwd="$2" command="$3"
  local log="$ARTIFACT_DIR/$(safe_log_name "$check").log"
  printf '$ (cd %q && %s)\n' "$cwd" "$command" > "$log"
  if (cd "$cwd" && bash -lc "$command") >> "$log" 2>&1; then
    record "$check" "PASS" "$log"
  else
    local status=$?
    printf '\nEXIT_CODE=%s\n' "$status" >> "$log"
    record "$check" "FAIL" "$log"
  fi
}

not_executed() {
  local check="$1" reason="$2"
  local log="$ARTIFACT_DIR/$(safe_log_name "$check").log"
  printf '%s\n' "$reason" > "$log"
  record "$check" "NOT EXECUTED" "$log"
}

cleanup() {
  if [[ "$TEMP_ENV_CREATED" -eq 1 ]]; then
    rm -f "$ROOT_DIR/.env.clinic"
  fi
  rm -rf "$OFFSITE_DIR"
}
trap cleanup EXIT

run_check "release scripts syntax" "$ROOT_DIR" "bash -n scripts/*.sh"
run_check "backend ruff" "$BACKEND_DIR" "ruff check ."
run_check "backend pytest" "$BACKEND_DIR" "pytest -q"
run_check "python pip check" "$BACKEND_DIR" "python3 -m pip check"
run_check "python pip audit" "$BACKEND_DIR" "timeout 120s pip-audit -r requirements.txt"
run_check "alembic single head" "$BACKEND_DIR" "heads=\$(alembic heads | grep -c ' (head)' || true); test \"\$heads\" -eq 1"
run_check "backend compile" "$BACKEND_DIR" "python3 -m compileall -q api core middleware models services"
run_check "api route collisions" "$BACKEND_DIR" "python3 scripts/check_route_collisions.py"

run_check "frontend typescript" "$FRONTEND_DIR" "pnpm check"
run_check "frontend vitest" "$FRONTEND_DIR" "pnpm test -- --run"
run_check "frontend build" "$FRONTEND_DIR" "pnpm build"

SECRET_PATTERN='(BEGIN (RSA|OPENSSH|EC|DSA) PRIVATE KEY|AKIA[0-9A-Z]{16}|sk-[A-Za-z0-9]{20,}|ghp_[A-Za-z0-9]{20,}|JWT_SECRET[[:space:]]*=[[:space:]]*[^[:space:]#]{32,})'
SECRET_SCAN_CMD="if grep -RInE --exclude-dir=node_modules --exclude-dir=dist --exclude-dir=release-artifacts --exclude-dir=.git --exclude='*.log' --exclude='.env' --exclude='.env.clinic' --exclude='.env.example' --exclude='.env.clinic.example' \"$SECRET_PATTERN\" .; then exit 1; else code=\$?; [[ \$code -eq 1 ]]; fi"
run_check "secret scan" "$ROOT_DIR" "$SECRET_SCAN_CMD"

DOCKER_AVAILABLE=0
if command -v docker >/dev/null 2>&1 && docker info >/dev/null 2>&1; then
  DOCKER_AVAILABLE=1
elif command -v sudo >/dev/null 2>&1 && sudo docker info >/dev/null 2>&1; then
  DOCKER_AVAILABLE=1
fi

if [[ "$DOCKER_AVAILABLE" -eq 1 ]]; then
  VALIDATION_FERNET_KEY="$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
  VALIDATION_PHOTO_KEY="$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())')"
  mkdir -p "$OFFSITE_DIR"
  cat > "$OFFSITE_DIR/backup-offsite.sh" <<'EOF_OFFSITE'
#!/usr/bin/env bash
set -euo pipefail
file="${1:?backup path required}"
test -s "$file"
EOF_OFFSITE
  chmod 700 "$OFFSITE_DIR/backup-offsite.sh"
  cat > "$ROOT_DIR/.env.clinic" <<EOF
ENV=production
CLINIC_ID=1
INSTANCE_CLINIC_ID=1
SECRET_KEY=validation-only-secret-key-012345678901234567890123456789
FERNET_KEY=$VALIDATION_FERNET_KEY
PHOTO_ENCRYPTION_KEY=$VALIDATION_PHOTO_KEY
BACKUP_ENCRYPTION_KEY=validation-only-backup-key-012345678901234567890123
POSTGRES_DB=clinic_db
POSTGRES_USER=clinic_user
POSTGRES_PASSWORD=validation-only-postgres-password
REDIS_PASSWORD=validation-only-redis-password
DATABASE_URL=postgresql+asyncpg://clinic_user:validation-only-postgres-password@postgres:5432/clinic_db
REDIS_URL=redis://:validation-only-redis-password@redis:6379/0
DENTAL_DOMAIN=127.0.0.1
CORS_ORIGINS=https://127.0.0.1
BACKUP_OFFSITE_DIR=$OFFSITE_DIR
PRIVATE_FRONTEND_BIND=127.0.0.1
PRIVATE_FRONTEND_PORT=18080
PUBLIC_GATEWAY_BIND=127.0.0.1
PUBLIC_GATEWAY_PORT=18090
DATA_DIR=/app/data
UPLOADS_DIR=/app/data/uploads
PHOTOS_DIR=/app/data/photos
BRANDING_DIR=/app/data/branding
BACKUPS_DIR=/app/backups
COPILOTE_IA_ENABLED=false
LLM_PROVIDER=openai
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4o
EOF
  TEMP_ENV_CREATED=1
  run_check "production preflight" "$ROOT_DIR" "DEPLOY_ENV_FILE=$ROOT_DIR/.env.clinic ./scripts/production_preflight.sh"
  run_check "docker compose config" "$ROOT_DIR" "export POSTGRES_PASSWORD=validation-only-postgres-password REDIS_PASSWORD=validation-only-redis-password PRIVATE_FRONTEND_BIND=127.0.0.1 PRIVATE_FRONTEND_PORT=18080 PUBLIC_GATEWAY_BIND=127.0.0.1 PUBLIC_GATEWAY_PORT=18090; docker compose -p $PROJECT_ID -f docker-compose.production.yml config --quiet"
  run_check "docker runtime public private backup restore private clinical e2e" "$ROOT_DIR" "export POSTGRES_PASSWORD=validation-only-postgres-password REDIS_PASSWORD=validation-only-redis-password PRIVATE_FRONTEND_BIND=127.0.0.1 PRIVATE_FRONTEND_PORT=18080 PUBLIC_GATEWAY_BIND=127.0.0.1 PUBLIC_GATEWAY_PORT=18090 COMPOSE_PROJECT_NAME=$PROJECT_ID RUNTIME_RUN_ID=$RUN_ID PUBLIC_BASE_URL=http://127.0.0.1:18090 PRIVATE_E2E_TLS_PORT=18443; scripts/runtime_release_check.sh"
else
  not_executed "docker compose config" "Docker executable or daemon is unavailable; mandatory Docker validation cannot be inferred."
  not_executed "docker runtime public private backup restore" "Docker executable or daemon is unavailable; mandatory runtime, network and backup/restore validation cannot be inferred."
fi

cp "$SUMMARY_FILE" "$ROOT_DIR/release-artifacts/release-gate-latest.tsv"
printf 'RELEASE_GATE_RUN_ID=%s\n' "$RUN_ID" > "$ROOT_DIR/release-artifacts/release_gate_final_status.txt"
if [[ "$OVERALL" -eq 0 ]]; then
  printf 'RELEASE_GATE_STATUS=GO\n' >> "$ROOT_DIR/release-artifacts/release_gate_final_status.txt"
  printf 'RELEASE_GATE_STATUS=GO\n'
  printf 'GO — all mandatory checks executed and passed.\n'
else
  printf 'RELEASE_GATE_STATUS=NO-GO\n' >> "$ROOT_DIR/release-artifacts/release_gate_final_status.txt"
  printf 'RELEASE_GATE_STATUS=NO-GO\n'
  printf 'NO-GO — at least one mandatory check failed or was not executed.\n'
fi
exit "$OVERALL"
