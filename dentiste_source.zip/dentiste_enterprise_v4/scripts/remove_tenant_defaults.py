from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "api-server"

for path in sorted(ROOT.rglob("*.py")):
    if "tests" in path.parts or "__pycache__" in path.parts:
        continue
    text = path.read_text()
    original = text
    if path.parts[-2] == "models":
        text = text.replace(
            "mapped_column(Integer, default=1, nullable=False)",
            "mapped_column(Integer, nullable=False)",
        )
    text = text.replace("clinic_id: int = 1", "clinic_id: int | None = None")
    text = text.replace('current_user.get("clinic_id", 1)', 'current_user["clinic_id"]')
    text = text.replace("current_user.get('clinic_id', 1)", "current_user['clinic_id']")
    if text != original:
        path.write_text(text)

print("tenant defaults removed from production models/signatures")
