#!/usr/bin/env bash
# Préflight de production mono-VPS.
# Usage: DEPLOY_ENV_FILE=/etc/dentiste/.env ./scripts/production_preflight.sh
set -euo pipefail

ENV_FILE="${DEPLOY_ENV_FILE:-.env}"
[[ -f "$ENV_FILE" ]] || { echo "Fichier d'environnement absent: $ENV_FILE" >&2; exit 2; }
chmod 600 "$ENV_FILE" 2>/dev/null || true

required=(
  POSTGRES_PASSWORD REDIS_PASSWORD DATABASE_URL REDIS_URL CORS_ORIGINS
  SECRET_KEY FERNET_KEY PHOTO_ENCRYPTION_KEY BACKUP_ENCRYPTION_KEY
  INSTANCE_CLINIC_ID DENTAL_DOMAIN
)
for key in "${required[@]}"; do
  value="$(grep -E "^${key}=" "$ENV_FILE" | tail -1 | cut -d= -f2- || true)"
  [[ -n "$value" ]] || { echo "Variable requise absente: $key" >&2; exit 3; }
  case "$value" in
    *CHANGE_ME*|*changeme*|*change-me*|*placeholder*)
      echo "Valeur placeholder interdite pour: $key" >&2; exit 3;;
  esac
done

grep -Eq '^ENV=(production|prod)$' "$ENV_FILE" || { echo "ENV doit valoir production" >&2; exit 3; }
grep -Eq '^DENTAL_DOMAIN=[A-Za-z0-9.-]+$' "$ENV_FILE" || { echo "DENTAL_DOMAIN invalide" >&2; exit 3; }
grep -Eq '^CORS_ORIGINS=https://[^, ]+' "$ENV_FILE" || { echo "CORS_ORIGINS doit commencer par une origine HTTPS réelle" >&2; exit 3; }

read_env() { grep -E "^$1=" "$ENV_FILE" | tail -1 | cut -d= -f2- || true; }
is_true() { case "${1,,}" in true|1|yes|on) return 0 ;; *) return 1 ;; esac; }
require_real_p02_value() {
  local key="$1" value
  value="$(read_env "$key")"
  [[ -n "$value" ]] || { echo "Variable P02 requise absente: $key" >&2; exit 3; }
  case "$value" in *CHANGE_ME*|*changeme*|*change-me*|*placeholder*) echo "Valeur placeholder interdite pour: $key" >&2; exit 3;; esac
}

teleconsultation_enabled="$(read_env TELECONSULTATION_ENABLED)"
practitioner_agent_enabled="$(read_env PRACTITIONER_AGENT_ENABLED)"
daily_required="$(read_env DAILY_REQUIRED_IN_PRODUCTION)"
if is_true "$teleconsultation_enabled"; then
  if is_true "$daily_required"; then require_real_p02_value DAILY_API_KEY; fi
  daily_base="$(read_env DAILY_API_BASE)"
  [[ "$daily_base" == https://* ]] || { echo "DAILY_API_BASE doit être HTTPS" >&2; exit 3; }
fi
if is_true "$(read_env DAILY_ENABLE_RECORDING)"; then
  require_real_p02_value DAILY_API_KEY
fi

practitioner_token="$(read_env WA_BUSINESS_TOKEN_PRATICIEN)"
practitioner_phone="$(read_env WA_PHONE_ID_PRATICIEN)"
practitioner_verify="$(read_env WA_WEBHOOK_VERIFY_TOKEN_PRATICIEN)"
practitioner_count=0
[[ -n "$practitioner_token" ]] && practitioner_count=$((practitioner_count + 1))
[[ -n "$practitioner_phone" ]] && practitioner_count=$((practitioner_count + 1))
[[ -n "$practitioner_verify" ]] && practitioner_count=$((practitioner_count + 1))
if (( practitioner_count > 0 )); then
  require_real_p02_value WA_BUSINESS_TOKEN_PRATICIEN
  require_real_p02_value WA_PHONE_ID_PRATICIEN
  require_real_p02_value WA_WEBHOOK_VERIFY_TOKEN_PRATICIEN
fi
if is_true "$practitioner_agent_enabled"; then
  require_real_p02_value WA_BUSINESS_TOKEN_PRATICIEN
  require_real_p02_value WA_PHONE_ID_PRATICIEN
  require_real_p02_value WA_WEBHOOK_VERIFY_TOKEN_PRATICIEN
  is_true "$teleconsultation_enabled" || { echo "PRACTITIONER_AGENT_ENABLED=true exige TELECONSULTATION_ENABLED=true" >&2; exit 3; }
  require_real_p02_value DAILY_API_KEY
fi

offsite_dir="$(grep '^BACKUP_OFFSITE_DIR=' "$ENV_FILE" | tail -1 | cut -d= -f2-)"
[[ -x "$offsite_dir/backup-offsite.sh" ]] || { echo "Script backup hors VPS absent ou non exécutable: $offsite_dir/backup-offsite.sh" >&2; exit 3; }

secret_key="$(grep '^SECRET_KEY=' "$ENV_FILE" | tail -1 | cut -d= -f2-)"
fernet_key="$(grep '^FERNET_KEY=' "$ENV_FILE" | tail -1 | cut -d= -f2-)"
photo_key="$(grep '^PHOTO_ENCRYPTION_KEY=' "$ENV_FILE" | tail -1 | cut -d= -f2-)"
backup_key="$(grep '^BACKUP_ENCRYPTION_KEY=' "$ENV_FILE" | tail -1 | cut -d= -f2-)"
for pair in "SECRET_KEY:$secret_key" "FERNET_KEY:$fernet_key" "PHOTO_ENCRYPTION_KEY:$photo_key" "BACKUP_ENCRYPTION_KEY:$backup_key"; do
  name="${pair%%:*}"; value="${pair#*:}"
  [[ ${#value} -ge 32 ]] || { echo "$name doit contenir au moins 32 caractères" >&2; exit 3; }
done
[[ "$fernet_key" != "$photo_key" && "$backup_key" != "$secret_key" && "$backup_key" != "$fernet_key" && "$backup_key" != "$photo_key" ]] || { echo "Les clés de chiffrement doivent être indépendantes" >&2; exit 3; }

command -v docker >/dev/null || { echo "docker est requis" >&2; exit 4; }
docker compose --env-file "$ENV_FILE" -f docker-compose.production.yml config >/dev/null

echo "Préflight mono-VPS réussi pour $ENV_FILE."
