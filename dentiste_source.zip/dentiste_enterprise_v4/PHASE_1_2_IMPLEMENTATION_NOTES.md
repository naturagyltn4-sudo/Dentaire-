# Dentiste Enterprise — Phases 1 et 2

## Modifications backend

La table `pointages` a été ajoutée au modèle SQLAlchemy avec `clinic_id`, `utilisateur_id`, `debut`, `fin`, `duree_minutes`, `notes` et les index nécessaires. La migration `20260819_add_pointages_table.py` a été créée, puis une migration de fusion `f657100d5f20_merge_multiple_heads.py` a été générée afin de conserver une tête Alembic unique.

Le module agenda a été renforcé avec un verrou transactionnel PostgreSQL par cabinet/jour/praticien/salle, afin de limiter les courses concurrentes lors de deux réservations simultanées. Les contrôles de conflits utilisent la durée réelle de l'acte, ignorent explicitement les rendez-vous annulés ou no-show, valident l'existence de la salle et la plage de fauteuils, et évitent l'utilisation d'un fauteuil sans salle.

Les endpoints publics et les réservations acceptent désormais les rôles `medecin`, `orthodontiste` et `estheticienne`. L'endpoint de disponibilités accepte `acte_id`, applique `duree_minutes` depuis le catalogue et renvoie cette information au frontend.

L'API Pointage expose :

- `GET /api/v1/pointage/statut` ;
- `POST /api/v1/pointage/entree` ;
- `POST /api/v1/pointage/sortie` ;
- `GET /api/v1/pointage/admin/rapport` pour une période et un membre.

## Modifications frontend

Le formulaire agenda envoie maintenant l'acte sélectionné lors du calcul des créneaux et affiche la durée dans le catalogue. Il vérifie aussi qu'un fauteuil est rattaché à une salle. Les rôles orthodontiste et administrateur peuvent gérer les rendez-vous selon les droits backend.

Le Dashboard inclut un widget de présence avec arrivée, départ et état en cours. La page `/rh/pointage`, réservée à `directrice` et `admin`, permet de choisir un membre, une période et de générer un rapport détaillé avec total d'heures et sessions clôturées.

## Vérifications

- `pytest -q tests/test_agenda.py tests/test_agenda_bloc3.py tests/test_reservation_publique.py` : **21 tests réussis**.
- `python3 -m py_compile` sur les modules backend modifiés : **réussi**.
- `pnpm check` dans `validation-private-frontend` : **réussi**.
- `pnpm build` dans `validation-private-frontend` : **réussi**.

## Point restant avant validation production

La migration doit être exécutée sur une base PostgreSQL de validation ayant des identifiants réels. Le paquet source fournit la migration et le contrôle `alembic heads` retourne une seule tête `f657100d5f20`; aucune base de validation n'était disponible dans l'archive (`.env.clinic.example` uniquement).
