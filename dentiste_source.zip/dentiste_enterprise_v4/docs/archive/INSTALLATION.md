# Installation clinique Dentiste RC Enterprise

## Prérequis

Prévoir un VPS dédié ou un serveur privé avec Docker Engine, Docker Compose, stockage chiffré pour PostgreSQL et les volumes de clinique, accès administrateur contrôlé et un reverse proxy TLS. Le serveur doit pouvoir joindre les registres d’images et les mises à jour de dépendances pendant la préparation, puis fonctionner selon la politique réseau de la clinique.

## Installation

Décompresser l’archive hors d’un répertoire contenant des données patient. Copier `api-server/.env.clinic.example` vers `.env.clinic` à la racine et renseigner les secrets générés par `scripts/generate_secrets.sh` ou un gestionnaire de secrets. Définir `INSTANCE_CLINIC_ID`, `DATABASE_URL`, `REDIS_URL`, `CORS_ORIGINS`, les bindings public/private et les options IA.

Valider puis démarrer :

```bash
docker compose -f docker-compose.production.yml config --quiet
docker compose -f docker-compose.production.yml build --pull
docker compose -f docker-compose.production.yml up -d postgres redis
docker compose -f docker-compose.production.yml run --rm migrate
docker compose -f docker-compose.production.yml up -d private_api public_api private_frontend public_gateway worker beat
docker compose -f docker-compose.production.yml ps
```

## Compte initial et TLS

Créer le premier compte directrice avec `api-server/bootstrap_admin.py` depuis le réseau privé, en injectant le mot de passe par stdin protégé. Ne jamais placer le mot de passe dans l’historique shell. Activer le MFA dès la première connexion et configurer le reverse proxy TLS pour ne publier que `public_gateway`.

Le frontend privé doit être lié à une interface privée/VPN. Le réseau Internet ne doit atteindre ni `private_frontend`, ni `private_api`, ni PostgreSQL, ni Redis.

## Recette d’installation

Depuis Internet, vérifier le gateway public, le branding, les praticiens, les actes et la réservation. Vérifier qu’un appel à `/api/v1/patients` retourne `404` depuis le gateway. Depuis le réseau clinique, vérifier `private_frontend`, login, MFA, refresh et logout, puis exécuter les scénarios de recette avec des données synthétiques.

Le script `scripts/test_public_private.sh` et le scénario `autocommerce-app/tests/e2e/public-gateway.spec.ts` documentent la campagne locale réellement exécutée. Une recette privée complète avec un compte clinique et les données de la clinique reste une étape d’acceptation client.

## Exploitation initiale

Configurer les sauvegardes quotidiennes, le stockage hors VPS, la rotation des secrets, la surveillance des healthchecks et l’astreinte. Lire `DEPLOYMENT.md`, `SECURITY.md`, `BACKUP_RESTORE.md`, `UPGRADE.md` et `ROLLBACK.md` avant toute mise en service.
