# Baseline de ré-audit V2 — 22 août 2026

## Périmètre

La release V2 contient le backend FastAPI, le frontend React/Vite, l’API publique, le gateway Nginx, le Compose mono-VPS, les migrations, les workers Celery/Beat et les scripts de provisioning.

## Constats initiaux

Le précédent cycle a produit une copie V2 avec les ajouts patient 360°, plans de traitement, profils personnel, préflight mono-VPS, readiness PostgreSQL publique, headers supplémentaires et suppression de la route d’équipe dupliquée.

La baseline statique confirme que le Compose limite les ports externes aux frontends liés à `127.0.0.1`, utilise un réseau privé interne pour les services, des healthchecks, `cap_drop: ALL`, `no-new-privileges`, des limites de ressources et des conteneurs applicatifs en lecture seule lorsque possible.

Aucun fichier local `.env`, `.env.clinic`, base SQLite, log applicatif ou secret de test n’est présent dans la copie destinée au packaging. Les occurrences `CHANGE_ME` se trouvent dans les modèles de configuration et la documentation, où elles sont intentionnelles et bloquantes par conception.

La ré-audit doit encore confirmer ou corriger les points suivants avant le packaging final :

| Écart à vérifier | Risque | Action prévue |
|---|---|---|
| Compatibilité migration PostgreSQL réelle | Déploiement bloqué ou schéma incomplet | Vérifier la chaîne de migration et documenter l’essai PostgreSQL live requis. |
| Configuration Nginx template/domain | Faux sentiment de production si le template est utilisé tel quel | Préflight et provisioning doivent exiger le domaine et TLS réels. |
| Surface public/private | Fuite potentielle de routes si le proxy est mal configuré | Cartographier les routes et ajouter des tests de refus public/private. |
| Profil personnel | Données internes visibles au mauvais rôle | Maintenir l’écriture direction/admin et tester la lecture par rôle. |
| Patient 360° | Données médicales agrégées trop largement | Vérifier le filtrage par rôle, clinique et anonymisation. |
| Plans de traitement | Incohérence patient/clinique et progression | Tester contraintes, permissions et liens rendez-vous/devis. |
| Frontend | Accessibilité, états d’erreur et navigation | Repasser typecheck, tests, build et contrôles DOM ciblés. |
| Workers/Beat/backups | Tâches silencieusement non exécutées sur mono-VPS | Vérifier healthchecks, PID, schedule et procédure de restauration. |

## Validation précédente conservée

La V2 précédente avait passé 547 tests backend, 6 tests ignorés, Ruff, compilation Python, 16 tests frontend, TypeScript et build Vite. La ré-audit ne considérera pas ces résultats comme suffisants si une nouvelle modification les invalide ; ils devront être rejoués avant livraison.
