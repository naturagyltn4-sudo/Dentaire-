# Rapport final — Coordination inter-rôles et génération de leads

**Date : 21 août 2026**  
**Périmètre : Clinique Esthétique et Dentiste Enterprise**  
**Auteur : Manus AI**

## Verdict

Les deux projets sont réellement des plateformes de coordination clinique multi-rôles. Ils ne se limitent pas à une landing page : ils contiennent une messagerie interne tenant-scoped, un agenda interne et public, un moteur de workflow, des demandes publiques soumises à approbation, des dossiers patients, des fonctions de facturation et des journaux d’audit. Le flux public reste correctement séparé du cœur clinique : une demande de rendez-vous est enregistrée avant validation par la clinique, puis la directrice, l’assistante ou l’admin peut la traiter selon les permissions prévues.

La version livrée corrige les blocages qui empêchaient toutefois cette architecture d’être exploitable : l’agenda public Dentiste dépend maintenant d’un tenant d’instance explicite dans le runtime de validation, le sélecteur de destinataire de la messagerie ne demande plus d’ID numérique manuel, et chaque landing accepte désormais la réservation, le téléphone, WhatsApp et un formulaire de rappel centralisé.

## Corrections livrées

| Zone | Corrections communes | Esthétique | Dentiste |
|---|---|---|---|
| Branding | Nom, couleurs, titre, sous-titre, adresse, ville, téléphone, WhatsApp, email, Instagram, Facebook, TikTok, description longue et photo hero | Oui | Oui |
| Photo hero | Upload sécurisé côté backend, validation du type et de la taille, URL persistée dans le branding | `/api/public` et `/api/private` | `/api/v1/public` et `/api/v1` |
| Leads | Nouveau modèle tenant-scoped `callback_leads`, statut pending/contacted/closed/rejected, notes et attribution | POST `/api/public/rappel` | POST `/api/v1/public/rappel` |
| File interne | Liste et mise à jour des leads limitée aux rôles directrice/assistante/admin/commercial | Oui | Oui |
| Agenda public | Catalogue praticiens/actes et créneaux accessibles | HTTP 200 vérifié | HTTP 200 vérifié avec `INSTANCE_CLINIC_ID=1` |
| Messagerie | Endpoint `GET /equipe/membres`, sélecteur de membres actifs et exclusion de l’utilisateur courant | Oui | Oui |
| Landing | CTA « Être rappelé », téléphone cliquable, WhatsApp cliquable, photo hero, description, réseaux sociaux et formulaire rappel | Oui | Oui |
| Actes | Catalogue actif réutilisé dans la réservation et les expertises marketing | Oui | Oui |

## Vérifications exécutées

Les vérifications en ligne ont été réalisées sur les runtimes de validation suivants : Esthétique API `8300`, Esthétique frontend `3300`, Dentiste API `8400`, Dentiste frontend `3400`. Les deux landings se chargent dans Chromium sans erreur visible. Les praticiens, actes et formulaires sont présents ; le sélecteur de créneaux est affiché sur les deux applications.

| Test | Résultat |
|---|---:|
| Aesthetic `GET /api/public/content` | 200 |
| Aesthetic `GET /api/public/praticiens` | 200 |
| Aesthetic `GET /api/public/actes` | 200 |
| Aesthetic disponibilité publique avec praticien configuré | 200 |
| Aesthetic demande de rappel | 201 |
| Dentiste `GET /api/v1/settings/branding` | 200 |
| Dentiste `GET /api/v1/public/praticiens` | 200 |
| Dentiste `GET /api/v1/public/actes` | 200 |
| Dentiste disponibilité publique avec praticien configuré | 200 |
| Dentiste demande de rappel | 201 |
| Build et TypeScript Esthétique | PASS |
| Build et TypeScript Dentiste | PASS |
| Pytest complet Esthétique | 542 passed, 1 skipped |
| Pytest complet Dentiste | 542 passed, 6 skipped, 1 warning |
| Head Alembic Esthétique | `20260821_callback_leads_aesthetic` |
| Head Alembic Dentiste | `20260821_callback_leads_dentiste` |

Les tests ciblés des workflows et de la réservation publique ont également passé : 34 tests Esthétique et 21 tests Dentiste. Le seul échec rencontré pendant la livraison concernait le raccordement de la nouvelle migration à un ancien head Alembic ; il a été corrigé, puis les suites complètes ont été relancées avec succès.

## Prérequis de déploiement

La correction respecte les garde-fous multi-tenant existants. En production, l’instance doit fournir explicitement `PUBLIC_CLINIC_ID` et `PUBLIC_ROUTES_ENABLED=true` pour Esthétique, ainsi que `INSTANCE_CLINIC_ID` pour Dentiste. Il faut appliquer la migration Alembic `20260821_add_callback_leads.py` de chaque backend avant d’accepter des leads de rappel. Ces variables ne sont pas remplacées par une valeur implicite en production afin d’éviter de publier le mauvais tenant.

Les bases SQLite de validation ont été complétées pour le test local avec la table `callback_leads`. Cette opération ne remplace pas la migration de production ; elle permet uniquement de valider le parcours en ligne sur les bases de recette existantes.

## Fichiers fonctionnels principaux modifiés

Les changements couvrent les modèles SQLAlchemy, migrations Alembic, services de branding, routes publiques et privées de réglages, routes de messagerie, contrats TypeScript, pages de paramètres, landings publiques et composants de messagerie. Les corrections antérieures du module photo/annotation sont conservées dans les deux arbres source.

## Conclusion d’achat / ready-to-go

**Verdict : version fonctionnelle et livrable pour recette de production, avec les prérequis d’environnement ci-dessus.** Les principaux parcours métier demandés sont cohérents et vérifiés : trafic public → agenda ou rappel → file interne de leads/demandes → traitement par les rôles cliniques → agenda et coordination interne. La version est suffisamment stabilisée pour passer à la configuration d’un environnement de production réel, à condition d’appliquer les migrations et de renseigner les identifiants de tenant propres au client.
