# Validation en ligne des landings — 2026-08-21

## Esthétique
La page `http://127.0.0.1:3300` s’ouvre correctement. Le catalogue actif affiche le praticien « Nadia Ben Salem » et l’acte « Botox front - recette ». Le formulaire de réservation expose les champs patient, praticien, acte, date et créneau ; la page contient également le CTA « Être rappelé », son formulaire nom/téléphone/email/besoin, ainsi que les liens Instagram/Facebook/TikTok. Le hero conserve une mise en page rapide et accepte une photo de présentation via le branding.

## Dentiste
La page `http://127.0.0.1:3400` s’ouvre correctement. L’agenda public est réactivé : le praticien « Validation Dentiste » et l’acte « Consultation dentaire — 45 min » sont chargés, et le sélecteur de créneau est présent. La landing affiche « Être rappelé », le formulaire de rappel et les liens sociaux. L’API publique Dentiste répond avec `200` sur les praticiens, actes et disponibilités lorsque `INSTANCE_CLINIC_ID=1` est configuré.

## Tests HTTP déjà réalisés
Les routes publiques suivantes répondent avec succès :

| Parcours | Esthétique | Dentiste |
|---|---:|---:|
| Catalogue praticiens | 200 | 200 |
| Catalogue actes | 200 | 200 |
| Disponibilités public avec praticien configuré | 200 | 200 |
| POST demande de rappel | 201 | 201 |

La base SQLite de validation a été complétée par la table `callback_leads`; en production, la migration Alembic `20260821_add_callback_leads.py` doit être appliquée.
