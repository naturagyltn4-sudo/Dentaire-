# Constats d’audit en ligne — projet dentaire

## Landing publique

La landing est accessible sur le runtime temporaire et charge correctement les praticiens, les actes et le formulaire de réservation.

Une incohérence UX est immédiatement visible : l’interface mélange le français et l’anglais dans un même parcours. Le bouton et le titre affichent `Book` et `Book an appointment`, tandis que le reste de la page est en français ; les libellés `First Name`, `Last Name`, `Phone`, `Desired Date`, `Available Slot` et `Professional Access` ne sont pas traduits. Le sélecteur de langue annonce Français, mais le contenu courant n’est pas entièrement localisé.

Le praticien `Validation Dentiste` et l’acte `Consultation dentaire — 45 min` sont chargés. Les créneaux sont recalculés après sélection du praticien et de l’acte ; quatre créneaux étaient visibles après le praticien, puis trois après l’acte de 45 minutes.

## Architecture observée

Le backend contient les rôles `directrice`, `medecin`, `orthodontiste`, `estheticienne`, `assistante`, `commercial` et `admin`, mais aucun rôle `superadmin`. La page `/settings` et les routes `/admin/team` sont limitées à une clinique via `clinic_id`. Aucune page ou route globale de pilotage multi-clinique, abonnements, santé technique ou métriques consolidées n’a été trouvée.

Le service de réservation publique crée actuellement immédiatement le patient et le rendez-vous, puis marque la demande `BookingRequest` comme acceptée. Cela contredit un workflow de demande en attente nécessitant une approbation de la clinique. La page Agenda ne présente pas de file de demandes publiques à approuver ou rejeter.

## État initial automatisé

Le backend fourni passe `540 tests`, avec `6 tests ignorés` et `1 avertissement volontaire sur une clé HMAC courte dans un test négatif. Le frontend passe `16 tests`, le contrôle TypeScript et le build production.

## Soumission publique

Les champs de coordonnées acceptent correctement un nom, prénom et téléphone au format international. Un créneau `16:00` a été sélectionné. La soumission est prête à être exécutée pour observer si le système crée une demande en attente ou un rendez-vous interne immédiatement.

## Seconde validation après corrections

Après redémarrage du runtime, la landing se charge en français de manière cohérente : `Accès professionnel`, `Réserver un rendez-vous`, `Prénom`, `Nom`, `Téléphone`, `Praticien`, `Acte`, `Date souhaitée`, `Créneau disponible` et `Réserver` sont alignés. Le message explicatif de demande est visible sous le titre du formulaire.

La sélection du praticien et de l’acte recharge correctement les créneaux ; trois créneaux étaient disponibles pour l’acte de 45 minutes.

## Workflow public corrigé

La soumission en ligne affiche désormais `Demande de rendez-vous reçue — confirmation par la clinique à venir.` ainsi que le bandeau `Demande reçue — référence #1` et `La clinique doit encore confirmer ce créneau.`. Les champs sont réinitialisés, ce qui confirme que la demande a été acceptée par l’API et que le parcours n’annonce plus à tort un rendez-vous confirmé.

## Super Admin en ligne

Le compte `superadmin@dentiste-validation.tn` se connecte correctement après remplacement du domaine réservé `.test` par un domaine syntaxiquement valide. La page `/super-admin` est désormais stable après correction de deux violations d’ordre des hooks React.

La page affiche en ligne : 1 clinique, 5/5 comptes actifs, 0 patient, 0 facture ; API, base de données et Redis sont signalés `ok` ; le tenant `Cabinet Dentaire de Validation`, son abonnement `enterprise` actif, ses limites de 25 comptes et 100 Go, ainsi que les cinq comptes par rôle sont visibles. Les actions de désactivation et la sélection d’abonnement sont présentes.

## Simulation workflow inter-rôles

Le contrôle HTTP runtime a créé une demande publique `pending`, l’a retrouvée dans la file de l’assistante, l’a approuvée avec création du rendez-vous interne, puis a vérifié que le Super Admin consolidait 1 clinique, 5 comptes et 1 rendez-vous. La chaîne public → réception → agenda → gouvernance globale est fonctionnelle.

## Revalidation publique — 2026-08-20

La landing reste en français et le message de demande pending est correct. Le praticien et l’acte se sélectionnent correctement. Le jour courant ne proposait plus de créneau après le rendez-vous de validation déjà approuvé, ce qui est cohérent avec le contrôle anti-surbooking.

Une saisie via l’outil navigateur dans le champ HTML `date` a produit une valeur mal formée (`60821-02-02`) et l’interface a correctement affiché `Date invalide (format YYYY-MM-DD)`. Ce point est à distinguer d’un défaut métier : le champ est un input date natif et la saisie clavier automatisée n’a pas respecté son format interne.

## Nouvelle réservation publique — réaudit

Après passage au 2026-08-21 avec une valeur ISO valide, les créneaux sont correctement recalculés et affichés. La soumission via le navigateur crée la demande `#2`, affiche `Demande de rendez-vous reçue — confirmation par la clinique à venir` et réinitialise les champs. Aucun nouveau défaut fonctionnel n’a été observé sur ce parcours.

## Validation rôle Assistante

La connexion assistante fonctionne. La navigation n’affiche pas le Super Admin ni la gestion d’équipe, tandis que l’Agenda est accessible. La file `Demandes publiques à traiter` affichait la demande #2 avec les actions `Approuver` et `Rejeter`. L’approbation depuis l’interface a affiché `Demande approuvée et rendez-vous créé`, ramené la file à zéro et laissé le rendez-vous interne visible.

La matrice HTTP confirme en parallèle les permissions attendues : Agenda 200, demandes publiques 200, équipe 403, Céphalométrie 403 et Super Admin 403 pour l’assistante.

## Validation rôle Directrice

La Directrice se connecte correctement, voit les modules cliniques attendus, notamment Céphalométrie et Paramètres, et peut ouvrir la gestion d’équipe ainsi que le journal d’audit. Une incohérence UX a été corrigée pendant ce réaudit : le formulaire affichait auparavant le rôle Administrateur alors que le backend refuse sa création par une Directrice. Le formulaire filtre maintenant cette option pour la Directrice ; la vérification en ligne affiche Assistante, Médecin, Orthodontiste, Esthéticienne, Commercial et Directrice, sans Administrateur.

## Validation Super Admin et matrice rôle par rôle

Le compte Super Admin se connecte et ouvre `/super-admin` sans erreur. La page affiche 1 clinique, 5/5 comptes actifs, 2 patients, 2 rendez-vous, 0 facture, un abonnement enterprise actif et les états `ok` de l’API, de la base et de Redis. Le journal global affiche les deux approbations publiques.

La matrice HTTP complète a confirmé 25 contrôles : Directrice, Dentiste, Assistante, Admin et Super Admin s’authentifient correctement ; les accès Agenda, demandes publiques, équipe, Céphalométrie et Super Admin correspondent aux gardes backend. Le correctif Céphalométrie aligne maintenant la route frontend sur `orthodontiste|directrice|admin`, comme le backend.
