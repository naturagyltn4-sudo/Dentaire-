# Rapport d’audit externe — Dentiste Enterprise

**Projet audité :** `dentiste_TOTAL_VERIFIED_FIXED_2026-08-21.zip`  
**Date de l’audit :** 22 août 2026  
**Auditeur :** **Manus AI — Audit externe**  
**Nature de l’audit :** revue statique du code, exécution des contrôles locaux disponibles, compilation, tests automatisés, build frontend et inspection visuelle de la landing page.  
**Périmètre observé :** backend FastAPI/Python, frontend React/Vite/TypeScript, gateway public Nginx, PostgreSQL, Redis, Celery/Beat, fichiers de déploiement Docker, modules métiers et tests.

> **Conclusion exécutive :** le projet présente une base technique ambitieuse et globalement bien structurée, avec une authentification sérieuse, une séparation public/privé recherchée, de nombreux tests backend et des protections de conteneur pertinentes. Il n’est toutefois **pas approuvé pour une mise en production telle que livré** : le contrôle pré-déploiement bloque sur des secrets absents ou par défaut et sur une configuration Nginx non finalisée, tandis que le lint backend échoue sur une redéfinition réelle de route. La landing page est visuellement correcte, mais son état de panne API et son internationalisation partielle dégradent l’expérience utilisateur.

## 1. Statut final

| Statut | Décision | Motif principal |
|---|---|---|
| **À corriger avant mise en production** | **Non approuvé en l’état** | Des blocages de configuration de production sont détectés automatiquement et le contrôle de qualité Ruff échoue. |
| Approbation conditionnelle après corrections | Possible | Les défauts identifiés sont majoritairement remédiables sans refonte complète, sous réserve d’une validation intégrée avec PostgreSQL, Redis, TLS et un environnement de staging. |

Le statut ne signifie pas que le produit est inutilisable. Il signifie que la livraison actuelle ne fournit pas encore les garanties minimales attendues pour une application manipulant des données de santé, des données d’identité, des informations de rendez-vous et des fonctions d’administration.

## 2. Synthèse des notes

La note globale est **7,2/10**. Elle reflète une architecture et un socle de sécurité intéressants, mais elle est plafonnée par la préparation production, la qualité de code non propre et l’absence de validation intégrée complète dans un environnement avec les dépendances réelles.

| Domaine | Note | Appréciation |
|---|---:|---|
| Architecture et séparation des responsabilités | **8,2/10** | Architecture multi-processus cohérente, mais duplication de la surface publique à clarifier. |
| Backend et API | **8,0/10** | FastAPI, validation Pydantic, contrôle tenant et workflow public correctement pensés. |
| Frontend | **7,5/10** | React/Vite typé, routes lazy-loadées et parcours riches ; plusieurs chaînes et états restent perfectibles. |
| Modules fonctionnels | **8,0/10** | Couverture fonctionnelle très large : agenda, patients, dossiers, radiologie, prothèses, stock, facturation, CRM, IA, RH et omnicanal. |
| Sécurité applicative | **7,4/10** | JWT/refresh rotatif, RBAC, garde-fous tenant et headers ; risques résiduels sur configuration, CSP, CSRF et uploads à durcir. |
| Fonctionnement observable | **7,2/10** | Build et tests passent, mais la vérification live complète avec PostgreSQL/Redis n’a pas été possible dans le périmètre livré. |
| Expérience utilisateur | **7,0/10** | Landing claire et responsive, mais gestion de panne API et feedbacks à améliorer. |
| Design et cohérence visuelle | **7,4/10** | Hiérarchie lisible et palette cohérente ; contenu encore partiellement générique et hétérogène. |
| Accessibilité | **6,7/10** | Labels présents sur le formulaire principal ; absence de preuve de test automatisé WCAG et plusieurs éléments restent à compléter. |
| Performance frontend | **7,6/10** | Lazy loading et code splitting présents ; le bundle initial reste significatif. |
| Maintenabilité et qualité | **7,0/10** | Typage strict et tests nombreux, mais duplication de route et couverture de certains services faible. |
| Déploiement et exploitation | **5,8/10** | Contrôles Docker solides, mais configuration TLS/secrets non finalisée et contrôle pré-déploiement en échec. |

## 3. Méthode et limites de l’audit

L’audit a été conduit à partir de l’archive remise. Le code n’a pas été modifié. Les contrôles exécutés sont donc reproductibles à partir du dépôt extrait. Les tests d’intrusion externes, la vérification d’un domaine réel, la validation de certificats TLS, la mesure de charge et la vérification d’un compte clinique réel ne font pas partie de ce périmètre.

Les dépendances ont été installées dans l’environnement isolé sans exécuter les scripts d’installation frontend. Le frontend a ensuite été contrôlé par TypeScript, tests Vitest et build Vite. Le backend a été compilé, testé avec Pytest, analysé avec Ruff et soumis au script de contrôle pré-déploiement fourni par le projet.

## 4. Résultats reproductibles

| Contrôle | Résultat | Interprétation |
|---|---|---|
| `pnpm run check` | **Succès** | Le périmètre TypeScript inclus passe en mode strict. |
| `pnpm run test -- --run` | **Succès — 16 tests dans 3 fichiers** | Les tests frontend présents passent, mais leur volume reste limité par rapport aux nombreux écrans déclarés. |
| `pnpm run build` | **Succès — 2 047 modules transformés** | Le bundle de production est généré correctement. |
| `python3 -m compileall -q .` | **Succès** | Pas d’erreur de syntaxe Python détectée. |
| `pytest -q` | **542 réussis, 6 ignorés, 2 avertissements** | Très bon signal de régression backend sur le périmètre couvert. |
| `pytest --cov=.` | **73 % de couverture totale** | Niveau utile, mais insuffisant pour considérer tous les modules sensibles comme couverts de façon homogène. |
| `ruff check .` | **Échec** | Une redéfinition F811 de `lister_membres_route` est présente dans `api/v1/equipe.py`. |
| Contrôle pré-déploiement | **Échec — 8 blocages** | Secrets de production non définis, `ENV=development`, et placeholders Nginx/TLS présents dans l’environnement audité. |

Le backend démontre donc une maturité de test supérieure à celle de l’interface. Cette asymétrie doit être corrigée par des tests d’intégration et des parcours navigateur sur les flux critiques : connexion, MFA, réservation publique, création de rendez-vous, dossier patient, upload, facturation et permissions par rôle.

## 5. Architecture et fonctionnement

Le projet sépare plusieurs responsabilités : API clinique privée, API publique, frontend privé, gateway public, PostgreSQL, Redis, worker Celery et scheduler Beat. Le fichier Compose applique des mesures de réduction de surface utiles : réseau privé interne, conteneurs applicatifs non-root, système de fichiers en lecture seule pour plusieurs services, `no-new-privileges`, suppression des capabilities Linux, limites CPU/mémoire/PIDs et healthchecks. Cette conception constitue un bon socle d’exploitation [1] [2].

Le point d’entrée privé configure les routes, les headers de sécurité, CORS, le montage des fichiers de branding, un endpoint de santé, une readiness DB/Redis et les métriques Prometheus [3]. Le point d’entrée public ne monte pas les routeurs cliniques privés, ce qui correspond à l’intention de séparation annoncée [4].

Cependant, plusieurs routes publiques — branding, praticiens, actes, disponibilités et réservation — sont également montées dans le routeur v1 utilisé par l’application principale [5]. Cette duplication augmente le risque de divergence entre les deux surfaces, notamment parce que les implémentations ne sont pas parfaitement identiques. Il faut choisir une seule frontière publique effective, ou démontrer explicitement que l’API privée n’est jamais exposée au réseau public.

La readiness privée vérifie bien PostgreSQL et Redis [3]. En revanche, la readiness de `public_main.py` retourne simplement `{"status": "ok"}` sans vérifier la base [4]. Un gateway peut donc considérer l’API publique saine alors que sa dépendance principale est indisponible. Cela doit être harmonisé avec un contrôle DB limité, rapide et sans fuite d’information.

### Évaluation fonctionnelle

Le flux de réservation publique est correctement conçu sur le principe : il valide le téléphone, impose une date future, contrôle le praticien et l’acte dans le tenant courant, vérifie les conflits, limite les doublons sur une fenêtre de quinze minutes et crée d’abord une demande `BookingRequest` avant toute création de patient ou de rendez-vous interne [6]. L’approbation back-office est verrouillée par tenant et par ligne, puis crée le patient et le rendez-vous seulement après validation [6]. C’est un choix métier prudent.

Le risque résiduel est opérationnel : les contrôles de disponibilité et de conflit doivent être confirmés sous concurrence réelle avec PostgreSQL, et non uniquement par tests unitaires. Il faut également tester les fuseaux horaires, les créneaux à la limite du jour, les changements d’heure et les soumissions simultanées.

## 6. Backend, données et modules

Le backend dispose d’une base de dépendances cohérente avec le besoin : FastAPI, SQLAlchemy asynchrone, Alembic, PostgreSQL, Redis, Celery, rate limiting, chiffrement, MFA, génération PDF, traitement d’images, S3 optionnel, Prometheus et Sentry [7]. La surface fonctionnelle est large et couvre les domaines attendus d’un logiciel de clinique : patients et dossiers médicaux, agenda, radiologie, odontogramme, céphalométrie, prothèses, devis, factures, commissions, stock, suivi post-opératoire, recrutement, marketing, CRM social, omnicanal, téléconsultation, workflow et fonctions IA.

Le modèle d’authentification recharge l’utilisateur en base à chaque requête, plutôt que de faire confiance uniquement aux claims de rôle du JWT. Le refresh token est conservé sous forme de hash, associé à un JTI, soumis à rotation et révoqué en cas de réutilisation détectée [8]. Cette stratégie est nettement préférable à un refresh token statique non traçable.

La matrice RBAC distingue les rôles directrice, médecin, esthéticienne, assistante, commercial, admin et superadmin, avec des permissions différentes pour patients, dossiers, photos, agenda, factures, commissions, stock et paramètres [9]. Le contrôle d’accès est également repris dans le routeur frontend par `ProtectedRoute`, ce qui améliore l’expérience, mais ne doit jamais être considéré comme une protection suffisante : la décision serveur reste indispensable.

Le principal défaut qualité concret est la duplication exacte de la route `GET /membres` et de la fonction `lister_membres_route` dans `api/v1/equipe.py` [10]. Ruff la signale en F811. Même si les tests passent, cette duplication rend le comportement d’enregistrement des routes moins explicite et peut créer des régressions lors d’une modification future.

La couverture globale de 73 % est encourageante, mais les écarts sont significatifs dans des services importants. Les résultats observés indiquent notamment une couverture faible pour certains connecteurs omnicanaux, le moteur de workflow, le QR injectable, les rappels, la réputation, la transcription vocale et WhatsApp. Avant production, les modules traitant des données patient, des communications externes ou des tâches asynchrones doivent disposer de tests de chemin nominal, erreur fournisseur, timeout, reprise et idempotence.

## 7. Sécurité

### Points forts

La configuration refuse en production une clé JWT par défaut, des clés de chiffrement absentes, une clé de backup trop courte, la réutilisation de clés sensibles et un CORS wildcard [11]. Les fichiers Docker réduisent les privilèges et isolent les services. Les cookies de refresh sont configurés avec `HttpOnly`, `Secure` en production, `SameSite=lax` et un chemin limité aux routes d’authentification [12]. Le frontend conserve l’access token en mémoire et coordonne les refreshs concurrents avec une promesse partagée [13].

Le traitement des photos applique une taille maximale côté service, et les types MIME autorisés sont restreints dans la configuration [11] [14]. Les données de réservation publique ne créent pas immédiatement d’identité clinique, ce qui réduit l’impact d’un spam ou d’une soumission frauduleuse [6]. Le gateway public supprime les cookies avant proxying et refuse explicitement les chemins `/api/` non autorisés [15].

### Points à corriger

Le contrôle pré-déploiement détecte huit blocages dans l’état livré : clé secrète par défaut ou insuffisante, environnement encore en développement, clé Fernet absente, clé de backup absente, et configuration Nginx laissée avec `server_name _` et certificats TLS placeholders [16]. Une valeur de développement ne doit jamais pouvoir franchir la chaîne de déploiement par défaut. La pipeline doit exiger un fichier d’environnement injecté par secret manager, valider le domaine, vérifier la présence du certificat correspondant et refuser le démarrage si l’environnement de production n’est pas explicite.

La CSP autorise `style-src 'unsafe-inline'` côté frontend [17]. Ce choix peut être acceptable temporairement avec certaines bibliothèques, mais il réduit la défense contre l’injection de contenu. Il faut mesurer les besoins réels, migrer autant que possible vers des styles statiques ou des hashes/nonces, puis déployer d’abord une CSP en mode report-only avant durcissement.

Le projet utilise un cookie de refresh pour des requêtes mutantes d’authentification. `SameSite=lax` apporte une réduction du risque CSRF, mais la présence d’un mécanisme CSRF explicite doit être démontrée pour les opérations sensibles si le produit doit accepter des scénarios cross-site ou des navigateurs ayant un comportement différent. Le frontend envoie également un header `X-CSRF-Token` autorisé par CORS, mais aucun flux complet de génération, injection et vérification n’a été démontré dans les fichiers contrôlés [3] [13].

Plusieurs endpoints lisent le contenu complet d’un `UploadFile` avant traitement [5] [14]. Les limites métier existent, mais une limite Nginx n’est pas appliquée uniformément à tous les endpoints de l’API privée. Il faut ajouter des limites cohérentes côté proxy, vérifier la taille avant de charger tout le contenu en mémoire lorsque c’est possible, contrôler les extensions et signatures de fichier, supprimer les métadonnées non nécessaires et tester les fichiers malformés, polyglottes et compressés de manière abusive.

Enfin, les routes publiques de réservation sont limitées à cinq requêtes par minute et par IP [5] [6]. Ce contrôle est utile, mais il doit être complété par une stratégie anti-abus plus robuste : quotas par empreinte téléphonique, déduplication atomique en base, observabilité des erreurs 429, protection proxy-aware de l’adresse source et éventuellement CAPTCHA ou preuve d’action après détection d’anomalie.

## 8. Frontend, UX et design

Le frontend React/Vite est typé en mode strict et adopte le lazy loading pour les écrans métiers [18]. Le routeur couvre les principaux parcours : login, MFA, tableau de bord, agenda, patients, dossier médical, radiologie, prothèses, devis, stock, factures, commissions, fidélité, téléconsultation, recrutement, social, équipe, RH, paramètres et superadmin [18]. L’usage de `ErrorBoundary`, du contexte de branding, du contexte d’authentification, d’un fournisseur de thème et d’un système de notifications constitue une base saine.

La landing page observée est lisible sur le viewport testé. Elle présente une hiérarchie claire : identité de clinique, accès professionnel, proposition de valeur, prise de rendez-vous, demande de rappel, informations pratiques, praticiens et footer. Les champs disposent de labels et le formulaire explique que la réservation constitue une demande devant encore être confirmée par la clinique [19]. Le code échappe correctement les données injectées dans le mini-gateway public avant insertion HTML [20].

L’expérience est cependant dégradée lorsque l’API n’est pas disponible : la page affiche une erreur de chargement, mais laisse le formulaire avec des listes praticien/acte vides et un bouton de réservation encore visible. Il faudrait présenter un état indisponible explicite, désactiver la réservation tant que les données de référence ne sont pas chargées, proposer un numéro de téléphone ou une demande de rappel comme solution de secours, et éviter de laisser l’utilisateur remplir un parcours voué à échouer.

L’internationalisation est partielle. La page utilise i18next pour certaines chaînes, mais plusieurs textes restent codés en français dans le composant : « Services mis en avant », « Vous préférez être contacté ? », « Adresse », « Téléphone », « Horaires », « Nos praticiens », « Demander un rappel » et les liens sociaux [19]. Le sélecteur de langue donne donc une impression de traduction incomplète. Toutes les chaînes visibles doivent être centralisées, avec une vérification par langue et une stratégie pour les textes administrables provenant du branding.

Le design est professionnel mais encore générique. Les cartes, bordures, espacements, gradient et palette bleue produisent un rendu cohérent. Le hero peut être personnalisé par une image de fond de branding. En revanche, l’écran `Home.tsx` contient encore un contenu de démonstration (« Example Page », spinner, markdown d’exemple et bouton non contextualisé) [21]. Même si la route racine pointe actuellement vers `LandingPage`, ce fichier résiduel doit être supprimé ou remplacé afin d’éviter une régression lors d’un changement de routage.

Sur l’accessibilité, la présence de labels associés aux champs constitue un point positif [19]. La vérification reste incomplète : aucun audit automatisé axe ou test clavier complet n’a été observé dans le périmètre exécuté. Il faut tester les focus visibles, l’ordre de tabulation, les messages d’erreur associés aux champs, les états de chargement annoncés aux technologies d’assistance, le contraste des couleurs administrables et le comportement à 200 % de zoom. Les liens sociaux configurés par défaut vers `#` doivent être masqués lorsqu’ils ne sont pas définis plutôt que de devenir des liens sans destination.

## 9. Performance et exploitation

Le frontend utilise le code splitting par import dynamique et produit plusieurs chunks spécialisés, ce qui est favorable à la navigation initiale [18]. La taille gzip de l’index compilé est néanmoins d’environ 105,68 kB et la feuille CSS d’environ 20,78 kB selon la sortie de build observée. Il faut compléter cette mesure par une analyse Lighthouse sur staging, notamment pour le LCP, le CLS, l’INP, le poids des images de hero et le coût des bibliothèques de graphiques et d’éditeurs.

Le backend est instrumenté pour Prometheus et peut intégrer Sentry [3] [7]. Les healthchecks Docker sont présents pour plusieurs services, mais les checks public et privé ne sont pas homogènes [3] [4]. Les logs doivent être vérifiés pour éviter toute fuite de données médicales, en particulier dans les exceptions, les appels de fournisseurs IA, les webhooks omnicanaux et les uploads.

La configuration réseau et les limites de ressources sont solides pour une première base d’exploitation [2]. La sauvegarde est prévue avec un profil dédié, un répertoire séparé et une clé de chiffrement distincte dans la configuration [11]. Il faut néanmoins exécuter un test réel de restauration, documenter le RPO/RTO, vérifier l’envoi offsite et tester l’expiration des backups, car la seule présence des scripts ne prouve pas la restaurabilité.

## 10. Plan de remédiation priorisé

| Priorité | Action obligatoire | Critère d’acceptation |
|---|---|---|
| **P0 — avant production** | Injecter les secrets réels via un gestionnaire de secrets et refuser toute valeur par défaut en CI/CD. | Le contrôle pré-déploiement passe en environnement de staging avec secrets non exposés dans l’image ou les logs. |
| **P0 — avant production** | Remplacer `server_name _`, les certificats placeholders et finaliser TLS/HSTS avec le domaine réel. | Test Nginx réussi, certificat valide, redirection HTTP→HTTPS et vérification externe des headers. |
| **P0 — avant production** | Supprimer la route dupliquée `GET /membres` et faire passer Ruff. | `ruff check .` retourne zéro erreur. |
| **P0 — avant production** | Décider de la frontière publique unique et retirer ou verrouiller les routes publiques du processus privé. | Test réseau démontrant que le gateway public ne peut atteindre que les endpoints attendus. |
| **P1** | Harmoniser la readiness publique avec un check DB contrôlé. | Une base indisponible rend le service public non-ready. |
| **P1** | Ajouter des tests d’intégration PostgreSQL/Redis et des tests de concurrence sur réservation. | Soumissions simultanées, timezone et conflits produisent un résultat déterministe et idempotent. |
| **P1** | Formaliser CSRF, limites d’upload, validation de contenu et anti-abus. | Tests négatifs automatisés pour CSRF, fichiers malformés, taille, spam et replay. |
| **P1** | Compléter l’internationalisation et les états d’erreur de la landing. | Parcours FR/EN/IT/DE sans chaîne codée en dur et formulaire désactivé si les références sont indisponibles. |
| **P1** | Ajouter des tests navigateur pour les parcours critiques et un audit axe/clavier. | Scénarios login/MFA/réservation/permissions validés sur desktop et mobile. |
| **P2** | Supprimer les écrans et commentaires de scaffold restants, dont `Home.tsx`. | Aucun écran de démonstration accessible ou importé dans le build métier. |
| **P2** | Augmenter et équilibrer la couverture des services asynchrones, omnicanaux, IA et workflow. | Seuil CI défini, avec couverture renforcée sur les modules classés sensibles. |
| **P2** | Mesurer la performance et documenter sauvegarde/restauration. | Rapport Lighthouse staging, test de restauration réussi et RPO/RTO validés. |

## 11. Décision d’audit par domaine

| Domaine | Décision | Condition de clôture |
|---|---|---|
| Backend | **Acceptable sous réserve** | Corriger Ruff et valider les tests intégrés DB/Redis. |
| Frontend | **Acceptable sous réserve** | Corriger les états de panne, les traductions et ajouter les parcours navigateur. |
| Modules métier | **Acceptable sous réserve** | Renforcer les tests des modules à faible couverture et des intégrations externes. |
| Sécurité | **Non acceptable en production en l’état** | Secrets, TLS, frontière publique, CSRF/uploads et anti-abus validés. |
| Fonctionnement | **Partiellement validé** | Rejouer les scénarios critiques sur staging connecté aux dépendances réelles. |
| UX | **Acceptable sous réserve** | Parcours de panne et feedbacks finalisés. |
| Design | **Acceptable** | Supprimer les éléments de scaffold et finaliser la cohérence de contenu. |
| Accessibilité | **Non suffisamment démontrée** | Audit clavier, contraste et axe avec correction des écarts. |
| Exploitation | **Non acceptable en production en l’état** | TLS, monitoring, backups et restauration vérifiés. |

## 12. Conclusion de l’auditeur

Le projet est **techniquement substantiel** et montre un effort réel de durcissement : authentification avec rotation de refresh tokens, RBAC tenant-aware, séparation de processus, chiffrement prévu, contrôles de conteneurs, limitation des endpoints publics et suite backend de 542 tests réussis. Ces éléments justifient une appréciation favorable du potentiel du produit.

La décision reste néanmoins **À corriger avant mise en production**. Les blocages ne sont pas théoriques : ils sont produits par les contrôles livrés avec le projet lui-même. La priorité doit être de rendre la configuration de déploiement non ambiguë, de finaliser TLS et les secrets, de corriger la duplication Ruff, puis d’effectuer une validation intégrée avec les dépendances réelles. Après clôture des points P0 et P1 et production des preuves demandées, une contre-audit pourra raisonnablement viser le statut **Approuvé sous réserves**, puis **Approuvé** si les tests de sécurité, de restauration et d’accessibilité sont concluants.

## Références internes au projet

[1]: ./docker-compose.production.yml "Composition de production"
[2]: ./docker-compose.production.yml#L60-L202 "Services privés, limites et isolation"
[3]: ./api-server/main.py "Point d’entrée API privée"
[4]: ./api-server/public_main.py "Point d’entrée API publique"
[5]: ./api-server/api/v1/settings.py "Routes publiques et branding"
[6]: ./api-server/services/reservation_publique.py "Service de réservation publique"
[7]: ./api-server/requirements.txt "Dépendances backend"
[8]: ./api-server/middleware/auth.py "Authentification JWT et rotation des refresh tokens"
[9]: ./api-server/middleware/clinic_rbac.py "Matrice RBAC"
[10]: ./api-server/api/v1/equipe.py#L89-L132 "Redéfinition de la route membres"
[11]: ./api-server/config.py "Configuration et validations des secrets"
[12]: ./api-server/api/v1/auth.py#L90-L120 "Cookies de refresh"
[13]: ./validation-private-frontend/client/src/lib/api.ts#L215-L280 "Client Axios et rafraîchissement de session"
[14]: ./api-server/services/photos_clinic.py "Validation des photos et limites de taille"
[15]: ./public-gateway/nginx.conf "Gateway public et restrictions de proxy"
[16]: ./api-server/scripts/pre_deploy_security_check.py "Contrôle pré-déploiement"
[17]: ./validation-private-frontend/nginx.conf "Headers et CSP du frontend privé"
[18]: ./validation-private-frontend/client/src/App.tsx "Routage et lazy loading frontend"
[19]: ./validation-private-frontend/client/src/pages/public/LandingPage.tsx "Landing page et formulaire de réservation"
[20]: ./public-gateway/app.js "Échappement HTML du gateway public"
[21]: ./validation-private-frontend/client/src/pages/Home.tsx "Écran de démonstration résiduel"
