# Dentiste Enterprise — validation finale build et packaging Docker

**Date de l’audit :** 21 août 2026  
**Auteur :** Manus AI  
**Périmètre :** installation PNPM verrouillée, tests frontend/backend, TypeScript et build Vite, Dockerfiles multi-stage, Compose production/validation, exécution non-root, healthchecks, migrations et hygiène de l’archive.

## Verdict exécutif

La release Dentiste Enterprise est **prête à être livrée comme release candidate de production** au niveau du code et de la reconstruction Docker. Les dépendances verrouillées sont installables, la suite frontend et la suite backend passent, le graphe Alembic conserve une tête unique et les quatre services runtime validés démarrent avec leurs sondes HTTP en état `healthy`.

Cette validation ne remplace pas la configuration de l’infrastructure finale. Avant le go-live, l’exploitant doit fournir un fichier d’environnement externe, renseigner les secrets de production, appliquer les migrations sur PostgreSQL de production, configurer les domaines/TLS et vérifier les sauvegardes. Aucun secret de production ne doit être ajouté à l’archive.

## Résultats de vérification

| Contrôle | Résultat | Preuve / remarque |
|---|---:|---|
| Installation frontend PNPM verrouillée | **PASS** | Installation avec lockfile et version PNPM du projet. |
| Tests frontend Vitest | **PASS — 16 tests** | Suite frontend complète validée. |
| TypeScript frontend | **PASS** | `tsc --noEmit` sans erreur. |
| Build Vite production | **PASS** | Bundle de production généré. |
| Tests backend pytest | **PASS — 542 passés, 6 ignorés, 1 warning** | Suite backend complète relancée après corrections. |
| Alembic | **PASS — tête unique** | Head : `20260821_callback_leads_dentiste`. |
| Compose production | **PASS** | Configuration validée avec fichier env externe via `DEPLOY_ENV_FILE`. |
| Compose validation-local | **PASS** | Healthcheck `public_api` aligné sur le port 8001. |
| API privée | **PASS** | `/health` répond HTTP 200. |
| API publique / gateway | **PASS** | `/ready` et `/healthz` répondent HTTP 200 selon le service. |
| Frontend privé | **PASS** | Page et `/healthz` répondent HTTP 200. |
| Gateway public | **PASS** | Page et `/healthz` répondent HTTP 200. |
| Runtime non-root | **PASS** | Images API et Nginx exécutées avec utilisateurs dédiés. |
| Secrets dans l’archive | **PASS** | Le contrat repose sur un env externe ; aucun secret réel n’est requis dans le ZIP. |

## Corrections Docker appliquées

Le Dockerfile du frontend privé expose désormais le port interne non-root `18080`, crée les droits nécessaires pour `/run`, et utilise un healthcheck sur `http://127.0.0.1:18080/healthz`. Le gateway public suit le même contrat sur le port `18090`. Cette correction évite le démarrage Nginx avec un bind privilégié sur le port 80.

Les deux configurations Nginx résolvent maintenant les noms Docker à la demande avec le resolver interne `127.0.0.11` et une variable d’upstream. Le conteneur peut donc démarrer avant que le service API soit résolu, sans figer une résolution DNS prématurée au chargement de la configuration.

Le Dockerfile API utilise des chemins de stockage sous `/app`, notamment `DATA_DIR`, `PHOTOS_DIR`, `UPLOADS_DIR`, `BRANDING_DIR` et `BACKUPS_DIR`. Les répertoires sont créés et attribués à l’utilisateur applicatif avant le passage en non-root. Le montage des volumes Compose reste ainsi cohérent avec le runtime et ne dépend d’aucun chemin absolu de la sandbox.

## Corrections Compose et scripts

Les fichiers Compose production et validation-local utilisent `env_file: ${DEPLOY_ENV_FILE:-.env}`. Le déployeur peut ainsi conserver les secrets en dehors du dépôt et du ZIP, tout en bénéficiant d’un défaut local explicite. Les ports publics et privés, les healthchecks et les dépendances `service_healthy` sont alignés avec les ports réellement écoutés par les conteneurs.

Les scripts `start.sh` et `scripts/first_deploy.sh` ne recherchent plus un fichier secret imposé sous `api-server/`. Ils acceptent `DEPLOY_ENV_FILE`, vérifient la présence du fichier fourni, valident la configuration Compose, exécutent les migrations et les contrôles de sécurité, puis lancent les smoke tests. Le fichier `.env.example` documente le contrat sans embarquer de valeurs sensibles.

## Points fonctionnels conservés dans la release

Les corrections applicatives livrées précédemment sont conservées dans l’archive, notamment le workflow multi-tenant, la coordination entre rôles, la landing page de collecte de leads, l’agenda public, les réglages de branding et le module photo/annotation. Les migrations liées aux callback leads sont présentes et raccordées à l’historique Alembic unique.

## Contrat de déploiement final

| Élément | Contrat attendu |
|---|---|
| Fichier de secrets | Fourni par l’opérateur via `DEPLOY_ENV_FILE=/chemin/absolu/.env` |
| Build | `docker compose --env-file "$DEPLOY_ENV_FILE" -f docker-compose.production.yml build` |
| Migration | `docker compose ... run --rm private_api alembic upgrade head` |
| Démarrage | `DEPLOY_ENV_FILE=/chemin/.env ./start.sh` |
| Vérification | `/health`, `/ready`, `/healthz` selon le service |
| Production | PostgreSQL, Redis, TLS, domaine et sauvegardes externes configurés par l’opérateur |

> **Conclusion :** la release est techniquement reconstructible et cohérente pour une livraison Docker contrôlée. Le statut « production » dépend encore de l’injection des secrets réels et de la validation de l’infrastructure cible, volontairement absents du ZIP.

## Fichiers de référence

Les fichiers corrigés les plus importants sont `api-server/Dockerfile`, `validation-private-frontend/Dockerfile`, `public-gateway/Dockerfile`, `docker-compose.production.yml`, `docker-compose.validation-local.yml`, `start.sh`, `scripts/first_deploy.sh` et `.env.example`.

Le ZIP final exclut les dépendances installées, les bundles de build temporaires, les caches de tests, les fichiers Python compilés, les fichiers `.env` réels et les données runtime. Il conserve les lockfiles, les sources, les migrations, les Dockerfiles, les Compose, les scripts, les templates env et les rapports nécessaires à la reconstruction.
