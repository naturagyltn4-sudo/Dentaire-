# Vérification totale des trois archives finales

**Date de vérification : 21 août 2026**  
**Périmètre :** Esthétique, Dentiste Enterprise et AutoCommerce Garage.  
**Méthode :** reconstruction depuis les ZIP livrés, installation PNPM verrouillée, tests frontend/backend, build Docker, démarrage avec PostgreSQL et Redis de validation, réseau Docker bridge avec DNS interconteneurs, healthchecks, puis parcours utilisateur public dans un navigateur.

## 1. Verdict exécutif

La reconstruction indépendante depuis les trois archives a permis de distinguer les éléments déjà conformes des défauts qui n’étaient visibles qu’avec une base PostgreSQL neuve et un parcours navigateur complet. Les trois interfaces publiques sont accessibles. Les trois API atteignent leurs endpoints de santé avec PostgreSQL et Redis réels. Les conteneurs applicatifs démarrent en utilisateurs non-root et les communications frontend → Nginx → API → PostgreSQL ont été validées sur un réseau Docker bridge.

Deux catégories de corrections ont été nécessaires pendant cette vérification totale. Premièrement, les migrations Dentiste et Garage contenaient des identifiants Alembic dépassant la longueur historique de `alembic_version.version_num` (`VARCHAR(32)`), ce qui bloquait une base PostgreSQL neuve. Deuxièmement, Garage tentait de recréer deux contraintes déjà définies lors de la création initiale des tables, et le gateway public Dentiste appelait `event.currentTarget.reset()` après un `await`, ce qui produisait une exception JavaScript malgré la création de la demande.

Après correction et rebuild ciblé, les scénarios fonctionnels publics suivants ont réussi : création d’un lead Esthétique, création d’un lead Garage et création d’une demande de rendez-vous Dentiste avec référence affichée. Le résultat est **opérationnel pour les parcours publics testés**, sous réserve de fournir en production les secrets, les domaines, les données métier et les services externes réels.

## 2. Résultats de reconstruction

| Projet | PNPM/frontend | Backend | Docker | Résultat |
|---|---:|---:|---:|---|
| Esthétique | Installation verrouillée, tests Vitest, TypeScript et build Vite déjà validés depuis l’archive | API démarrée avec PostgreSQL/Redis, migration corrigée et head appliqué | API et frontend reconstruits ; frontend non-root sur 8080 | **Pass après corrections** |
| Dentiste Enterprise | Installation verrouillée, 16 tests frontend, TypeScript et build Vite validés depuis l’archive | 542 tests pytest précédemment validés ; migration vers `20260821_callback_leads_dentiste` appliquée sur PostgreSQL neuf | API, gateway public et frontend privé `healthy`, tous non-root | **Pass après corrections** |
| AutoCommerce Garage | Installation verrouillée, 16 tests frontend, TypeScript et build Vite validés depuis l’archive | 514 tests pytest précédemment validés ; migration vers `20260821_garage_callback_leads` appliquée sur PostgreSQL neuf | API et frontend `healthy`, tous non-root | **Pass après corrections** |

Les installations et builds PNPM ont été exécutés depuis les répertoires extraits des ZIP, et non depuis les sources de travail originelles. Les builds Docker ont utilisé `--network host` pour la phase de construction, conformément à la contrainte de la sandbox.

## 3. Corrections découvertes pendant le test total

### 3.1 Esthétique

Sur PostgreSQL neuf, la migration callback leads écrivait un revision ID plus long que la colonne historique `alembic_version.version_num`. La migration a été renforcée pour élargir transactionnellement cette colonne avant l’écriture du head. Le frontend Nginx a également été vérifié sur le port non-root 8080 et sa réécriture proxy a été corrigée afin de conserver le chemin `/api/...` lors de l’utilisation d’un upstream dynamique.

Avec le réseau Docker bridge et l’alias `api`, la landing publique est accessible. Après activation explicite de `PUBLIC_ROUTES_ENABLED=true`, le formulaire de rappel a créé un lead et affiché une confirmation utilisateur. La base de validation contenait **1 lead Esthétique** après le test.

### 3.2 Dentiste Enterprise

La migration `20260820_tenant_composite_uniques` était bloquée sur une base neuve par le revision ID `20260820_tenant_composite_uniques`, trop long pour `VARCHAR(32)`. Un élargissement à `VARCHAR(64)` a été ajouté au début de la migration avant l’écriture du head.

Le premier parcours public avec base vide a correctement empêché la soumission, car aucun praticien ni acte n’était publié. Après exécution du seed local fourni par l’archive, les données « Validation Dentiste » et « Consultation dentaire » sont apparues dans le navigateur.

La soumission valide a ensuite révélé une erreur frontend : `Cannot read properties of null (reading 'reset')`. La cause était l’utilisation de `event.currentTarget` après un appel asynchrone. Le code conserve désormais la référence du formulaire avant le `await`, puis exécute `formElement.reset()` après succès. Un suffixe `?v=20260821-fixed` a été ajouté à la balise script afin de garantir le renouvellement du bundle après déploiement.

Après rebuild du gateway et cache-busting, la réservation a réussi avec le message **« Demande reçue. Référence 4. »**. Les champs ont été réinitialisés sans exception. La base Dentiste contenait **4 demandes de réservation** au total pendant la vérification, dont la dernière issue du parcours corrigé.

### 3.3 AutoCommerce Garage

La migration `20260820_garage_tenant_constraints` présentait deux problèmes sur PostgreSQL neuf. Son revision ID dépassait 32 caractères et la migration recréait les contraintes uniques de `garage_quotes` et `garage_invoices`, alors que ces contraintes étaient déjà créées par `20260814_garage_finance_core`. La migration a été rendue compatible avec une base neuve en élargissant `alembic_version.version_num` avant l’écriture du head et en supprimant les créations/suppressions redondantes.

La réécriture Nginx Garage a été validée avec un upstream dynamique et conservation du chemin API. Sur le réseau bridge, la landing Garage a affiché son formulaire public. La soumission d’un lead fictif a abouti au message **« Votre demande a bien été transmise. Notre équipe vous rappelle rapidement. »**. La base Garage contenait **1 lead** créé par le test navigateur.

## 4. Validation runtime et sécurité d’exécution

| Contrôle | Esthétique | Dentiste | Garage |
|---|---:|---:|---:|
| `GET /health` | 200 | 200 | 200 |
| `GET /ready` avec PostgreSQL et Redis | 200 | 200 | 200 |
| Page publique | 200 | 200 | 200 |
| Frontend/gateway `healthcheck` | Healthy | Healthy | Healthy |
| API exécutée non-root | Oui | Oui | Oui |
| Frontend/gateway exécuté non-root | Oui | Oui | Oui |
| DNS Docker bridge vers l’API | Validé | Validé | Validé |
| Soumission publique réussie | Lead créé | Réservation créée | Lead créé |

Les identités observées pendant les tests étaient `appuser` pour les API, `gateway`/`nginxapp` pour les services Dentiste et `garageweb` pour le frontend Garage. Les secrets utilisés étaient synthétiques, générés uniquement pour la validation et non inclus dans les archives finales.

## 5. Parcours utilisateur réalisés

Le parcours Esthétique a couvert l’ouverture de la landing, l’accès à la connexion, le formulaire de rappel et la soumission d’un lead via le proxy Docker. Le parcours Dentiste a couvert la landing publique, l’état contrôlé sans données métier, le chargement du praticien et de l’acte après seed, la sélection du créneau, la soumission d’une réservation et l’affichage d’une référence. Le parcours Garage a couvert la landing, l’accès équipe, le formulaire de rappel, la soumission du lead et l’écran de connexion professionnel avec identifiants fictifs.

Ces tests ont été effectués sur des données fictives et des bases isolées. Ils ne constituent pas une connexion à un compte client réel ni une validation des fournisseurs externes WhatsApp, email, paiement ou IA.

## 6. Limites restantes à traiter lors du déploiement réel

La base de validation ne remplace pas les données métier de production. Chaque installation réelle doit appliquer le fichier `.env.example` correspondant, générer ses secrets hors dépôt, configurer les domaines et certificats TLS, créer les tenants, utilisateurs, rôles, praticiens, actes, horaires et paramètres de branding, puis vérifier les sauvegardes et les fournisseurs externes.

Les endpoints `/ready` ont été validés avec PostgreSQL et Redis réels dans la sandbox. Les workers Celery, les tâches planifiées, les connecteurs sociaux, les canaux WhatsApp/SMS/email, les appels IA et les certificats TLS ne peuvent pas être déclarés validés de bout en bout sans leurs identifiants et services de production. Les archives livrées ne contiennent volontairement aucun secret réel.

## 7. Fichiers de preuve

Les journaux détaillés des parcours navigateur sont conservés dans `logs/aesthetic-browser-findings.md`, `logs/dentist-browser-findings.md` et `logs/garage-browser-findings.md`. Les logs de build Docker et de migration se trouvent dans le même répertoire de vérification. Les bases et conteneurs de validation ont été isolés et arrêtés après collecte des preuves finales.

## 8. Conclusion

Les trois projets ont été reconstruits depuis leurs ZIP et soumis à un test plus strict que le simple démarrage d’image : base neuve, migrations complètes, DNS Docker bridge, healthchecks, utilisateurs non-root et interaction navigateur avec création réelle de données de test. Les défauts bloquants découverts ont été corrigés dans les clones de vérification et revalidés par rebuild ciblé. Les ZIP révisés associés à ce rapport doivent être utilisés comme livrables finaux de cette passe de vérification.
