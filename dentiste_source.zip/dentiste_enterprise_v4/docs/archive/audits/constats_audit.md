# Constats intermédiaires — audit externe

## Périmètre
- Archive auditée : `dentiste_TOTAL_VERIFIED_FIXED_2026-08-21.zip`
- Répertoire de travail : `/home/ubuntu/audit_dentiste`
- Architecture repérée : backend FastAPI/Python, frontend React/Vite/TypeScript, gateway public Nginx, PostgreSQL, Redis, Celery/Beat, services d’intégration et modules cliniques.

## Contrôles reproductibles
- Frontend `pnpm run check` : succès.
- Frontend `pnpm run test -- --run` : succès, 3 fichiers / 16 tests.
- Frontend `pnpm run build` : succès ; 2047 modules transformés.
- Backend `python3 -m compileall -q .` : succès.
- Backend `pytest -q` : succès ; 91 % environ de progression affichée, 5 tests ignorés, avertissement Starlette/httpx.
- Backend `ruff check .` : échec, erreur F811 dans `api/v1/equipe.py:113`, redéfinition de `lister_membres_route`.
- Contrôle pré-déploiement sécurité : échec en environnement local avec 8 blocages, notamment secrets de production absents/par défaut, ENV development et configuration Nginx avec `server_name _` et certificats TLS placeholder.

## Observations visuelles / UX
- Landing compilée accessible sous `http://127.0.0.1:4173/`.
- Rendu initial propre et responsive sur viewport observé : en-tête, hero, formulaire de réservation, formulaire de rappel, footer.
- Sans API disponible, la page affiche une erreur de chargement mais conserve le formulaire avec listes praticien/acte vides ; cela mérite un état de panne plus explicite et une prévention de soumission inutilisable.
- Présence de textes français et de chaînes non traduites ou codées en dur dans `LandingPage.tsx` (`Services mis en avant`, `Vous préférez être contacté ?`, `Instagram`, etc.) malgré i18next.
- `Home.tsx` est un écran d’exemple (« Example Page ») mais la racine de `App.tsx` pointe vers `LandingPage`; le fichier paraît mort ou résiduel.

## Sécurité / architecture déjà observées
- `main.py` monte le routeur API v1 privé et expose aussi plusieurs routes publiques via `api/v1/settings.py`.
- `public_main.py` existe comme point d’entrée public séparé ; duplication de la surface publique entre API principale et process public à clarifier/réduire.
- Authentification : JWT access court, refresh en cookie HttpOnly côté client selon la stratégie documentée, rotation et détection de réutilisation du refresh token en base.
- CORS et secrets sont validés en production par `config.py`, mais les valeurs par défaut restent permissives en développement ; un déploiement mal paramétré peut être dangereux si `ENV` n’est pas forcé.
- En-têtes présents : nosniff, X-Frame-Options, Referrer-Policy, Permissions-Policy et CSP côté Nginx/frontend ; la CSP autorise toutefois `unsafe-inline` pour les styles et la configuration Nginx utilise `server_name _` comme valeur par défaut.
- Compose production applique des contrôles utiles : réseaux privés, conteneurs non-root pour les services applicatifs, read-only, no-new-privileges, cap_drop, limites CPU/mémoire/PIDs.
