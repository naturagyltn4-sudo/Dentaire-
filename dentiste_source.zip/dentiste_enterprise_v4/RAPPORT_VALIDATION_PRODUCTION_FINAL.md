# Dentiste Enterprise — Livraison corrigée

Cette archive contient le projet corrigé, les tests, les configurations Docker, les sources frontend/backend et les fichiers de validation. Les secrets de validation, les dépendances `node_modules`, les caches Python et les fichiers temporaires ne sont pas inclus.

## Corrections principales

- Consentement optionnel pour les actes courants et obligatoire pour les actes chirurgicaux ou à risque.
- Refus propre lorsqu’un acte inconnu est vérifié, sans erreur HTTP 500.
- Création de workflow depuis un modèle et normalisation des actions.
- Scanner de stock avec résultats persistants et messages d’erreur explicites.
- Gateway public corrigé pour l’exécution Docker en réseau host.
- PID Nginx rendu compatible avec l’utilisateur non root.
- Configuration `INSTANCE_CLINIC_ID` corrigée.
- Favicon ajouté.

## Validation

- Tests backend ciblés : **39 réussis sur 39**.
- API privée : PostgreSQL et Redis opérationnels, `/ready` validé.
- Gateway public : `/healthz` validé.
- Portail public : praticiens, actes, disponibilités et réservation testés.
- Scénario réservation publique → approbation secrétaire → rendez-vous → facture → paiement validé.

Avant déploiement, copier `.env.example` vers l’environnement de production, renseigner de nouveaux secrets, charger les praticiens et actes réels, puis exécuter la suite complète de tests CI.
