# Release Manifest — Dentiste Enterprise V4 — Build complet

**Version :** V4 requalifiée avec build Docker et E2E  
**Cible :** mono-VPS Docker Compose avec Nginx, PostgreSQL, Redis, Celery/Beat et deux surfaces frontend  
**Statut :** **build local complet validé après corrections**  
**Verdict production :** passage vers staging autorisé ; ouverture publique encore conditionnée aux gates fournisseur, TLS, restauration et exploitation.

## Corrections de cette passe

| Domaine | Correction |
|---|---|
| Proxy frontend privé | Remplacement de la résolution `private_api` par `127.0.0.1:8000`, nécessaire avec `network_mode: host`. Le 502 reproduit a disparu ; l’API protégée renvoie maintenant 401 sans session. |
| Réservation publique | Conservation de la référence du formulaire avant `await`, supprimant l’erreur `event.currentTarget` nul après succès. |
| Tests E2E privés | Email patient unique et sélection de ligne déterministe, rendant le scénario répétable. |
| Client OpenAI | `OPENAI_API_BASE` configurable avec défaut officiel et `max_completion_tokens` pour GPT-5. |
| QA frontend | Ajout d’une matrice de routes privées et d’un test de réservation publique de bout en bout. |

## Build et runtime validés

| Contrôle | Résultat |
|---|---|
| Installation dépendances Python | Réussie selon `requirements.txt`. |
| Installation dépendances frontend | Réussie avec lockfile gelé. |
| Docker Engine / Compose | Docker 29.1.3 et Compose 2.40.3 opérationnels. |
| Build Compose | Réussi pour toutes les images applicatives. |
| PostgreSQL | Conteneur PostgreSQL 16 healthy. |
| Redis | Conteneur Redis 7 healthy. |
| Alembic | Migration `20260822_p02_release_final` terminée avec code 0. |
| API privée/publique | Healthy avec `db=ok`, et `redis=ok` côté API privée. |
| Worker / Beat | Healthy. |
| Frontend privé / gateway public | Healthy sur 18080 / 18090 dans le compose local. |

## Tests et résultats

| Test | Résultat |
|---|---|
| Backend unitaire en mode test | **558 passed, 6 skipped, 2 warnings**. |
| Compilation Python / Ruff | Réussis. |
| Collisions routes / tête Alembic | 249 routes, 0 collision ; tête unique `20260822_p02_release_final`. |
| `pip check` / `pip-audit` | Aucun requirement cassé ; aucune vulnérabilité connue signalée. |
| TypeScript / Vitest / build Vite | Réussis ; 16 tests frontend unitaires. |
| E2E privé Docker | Matrice de toutes les routes : 1 passe ; parcours MFA/patient/modules/logout : 2 répétitions réussies. |
| E2E public Docker | Gateway/restrictions : 2 passes ; réservation publique : 1 passe. |
| OpenAI compatible | Appel minimal, client backend et chemin production avec budget PostgreSQL : réponses `OK` obtenues avec `gpt-5-nano`. |

## Limites restantes

Le test OpenAI utilise un endpoint compatible configuré dans le sandbox et un prompt sans donnée personnelle ou clinique. Il ne constitue pas une preuve d’offre gratuite, de SLA, de conformité réglementaire ou d’autorisation d’envoyer des données de santé.

Le build local ne valide pas un domaine Internet, un certificat TLS réel, l’approbation Meta/WhatsApp, les credentials Daily.co, la conformité contractuelle du fournisseur vidéo, une restauration hors VPS, la charge, la supervision ou une procédure d’incident. Ces points restent des gates avant production publique.

## Fichiers principaux

| Fichier | Rôle |
|---|---|
| `FULL_BUILD_VALIDATION_REPORT_V4.md` | Rapport détaillé et verdict complet. |
| `DEPLOYMENT_PRODUCTION_MONOVPS_V4.md` | Guide mono-VPS. |
| `P02_LIVE_REQUALIFICATION_RUNBOOK.md` | Runbook P02. |
| `.env.example` | Modèle sans secrets. |
| `docker-compose.validation-local.yml` | Compose de validation locale. |
| `scripts/v4_llm_production_smoke.py` | Smoke test LLM avec budget PostgreSQL. |
