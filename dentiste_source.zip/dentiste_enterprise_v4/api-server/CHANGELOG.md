# CHANGELOG — AutoCommerce Clinic

## [1.3.0] — 2026-08-20

### Fixed
- **REAUDIT-01** — La garde frontend `/cephalometries` est maintenant alignée sur le backend : `orthodontiste`, `directrice` et `admin`. Le rôle `medecin` généraliste ne voit plus un module auquel l’API lui refusait l’accès.
- **REAUDIT-02** — Le formulaire de gestion d’équipe masque le rôle `Administrateur` pour une Directrice, conformément au contrôle backend qui interdit à une Directrice de créer ou d’attribuer ce rôle.

### Validation en ligne
- Landing publique, changement de date ISO, créneaux et réservation `pending` vérifiés.
- Assistante connectée : file publique visible, approbation réussie et rendez-vous interne créé.
- Directrice connectée : Agenda, Céphalométrie, Paramètres, équipe et journal d’audit vérifiés.
- Super Admin connecté : KPI, tenant, abonnement, comptes, audit et santé API/base/Redis vérifiés.
- Matrice HTTP : 25 contrôles de permissions passés pour les cinq rôles.

### Non-régression
- **pytest backend** : 542 passed, 6 skipped, 0 failed.
- **Vitest frontend** : 16 passed, 0 failed.
- **TypeScript** : aucune erreur.
- **Ruff F/E9** : aucune erreur.
- **Build frontend production** : réussi en 4,38 s.

## [1.2.0] — 2026-08-20

### Fixed
- **NC-D01** — Les réservations publiques créent désormais une `BookingRequest` en statut `pending` ; le patient et le rendez-vous interne ne sont créés qu’après approbation par la clinique.
- **NC-D02** — Ajout du contrôle de conflit entre demandes publiques concurrentes sur un même créneau.
- **NC-D03** — Les orthodontistes sont inclus dans les praticiens et disponibilités publics.
- **NC-D04** — Le domaine de validation `.test`, rejeté par `EmailStr`, a été remplacé par un domaine de seed syntaxiquement valide.
- **NC-D05** — Correction de l’ordre des hooks React dans `ProtectedRoute` et `SuperAdminDashboard`.
- **NC-D06** — La landing est française par défaut et explique le statut de demande à confirmer.

### Added
- **Super Admin global** : overview consolidé, santé API/base/Redis, tenants, abonnements, comptes, activation/désactivation, réinitialisation de mot de passe et journal d’audit.
- **File des demandes publiques** dans l’Agenda avec approbation/rejet et journalisation.
- Registre `cliniques` et table `clinic_subscriptions`, avec migration Alembic à tête unique.
- Seed runtime avec compte Super Admin, tenant dentaire et abonnement enterprise.

### Validation
- **pytest backend** : 542 passed, 6 skipped, 0 failed.
- **Vitest frontend** : suite complète réussie.
- **TypeScript** : aucune erreur.
- **Ruff F/E9** : aucune erreur.
- **Build frontend production** : réussi.
- **Runtime en ligne** : landing, réservation pending, approbation réception, Super Admin et santé technique validés.

## [1.1.0] — 2026-07-30

### Fixed
- **NC-M01** — `services/factures.py`: `marquer_payee()` lève désormais `ValueError` si la facture est déjà marquée payée (double paiement interdit).
- **NC-R01** — `config.py`: ajout d'une validation en production qui refuse `CORS_ORIGINS = ["*"]` (secrets exposure).
- **NC-R02** — `services/clinic_settings.py`: ajout d'un cache LRU en mémoire (max 128 entrées, TTL 300 s) pour les paramètres cliniques, reduisant les appels DB récurrents.
- **NC-R03** — `models/omnicanal.py`, `services/omnicanal/__init__.py`: import `Utilisateur` ajouté, re-export explicite `ChannelAdapter as ChannelAdapter`. `ruff check . --select F,E9` passe désormais sans erreur.

### Added (Tests)
- **NC-M02** — `tests/test_copilote_crm_coverage.py` : 16 tests nouveaux, couverture `copilote_crm` portée à **98 %** (seuil ≥ 60 %).
- **NC-M03** — `tests/test_dashboard_ia_coverage.py` : 24 tests nouveaux, couverture `dashboard_ia` portée à **98 %** (seuil ≥ 55 %).
- **NC-M04** — `tests/test_business_intelligence_coverage.py` : 14 tests nouveaux, couverture `business_intelligence` portée à **100 %** (seuil ≥ 55 %).
- **NC-M05** — `tests/test_workflow_engine_coverage.py` : 12 tests nouveaux, couverture `workflow_engine` portée à **57 %** (seuil ≥ 55 %).
- **NC-M06** — `client/src/__tests__/shared-const.test.ts`, `auth-context.test.ts`, `utils.test.ts` : 16 tests vitest frontend, tous verts.

### Updated
- `tests/test_factures.py`: test `marquer_payee_twice` corrigé pour attendre `ValueError`.
- `tests/test_config_security.py`: fixture `_settings` mise à jour avec `cors_origins`.

### Results
- **pytest** : 466 passed, 1 skipped, 0 failed
- **vitest** : 16 passed, 0 failed
- **ruff** : 0 erreur F/E9
