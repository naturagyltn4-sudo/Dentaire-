"""
AutoCommerce Clinic — Configuration centralisée
Règles absolues : jamais de secret en dur, jamais de Float pour montants
"""

from functools import lru_cache
from pathlib import Path

from cryptography.fernet import Fernet
from pydantic_settings import BaseSettings
from pydantic import ConfigDict


class Settings(BaseSettings):
    """Configuration chargée depuis les variables d'environnement."""

    # ── Identité clinique ────────────────────────────────────
    clinic_id: int | None = None
    instance_clinic_id: int | None = None
    env: str = "development"

    # ── API / réseau ─────────────────────────────────────────
    # Domaine(s) du frontend autorisé(s) en CORS, séparés par virgule.
    # À restreindre au domaine réel du client en production.
    cors_origins: str = ""
    dental_domain: str = ""
    api_port: int = 8000
    frontend_port: int = 8080

    # ── Base de données ──────────────────────────────────────
    database_url: str = (
        "sqlite+aiosqlite:///./autocommerce_clinic.db"
    )
    postgres_db: str = "clinic_db"
    postgres_user: str = "clinic_user"
    postgres_password: str = ""

    # ── Redis ────────────────────────────────────────────────
    redis_url: str = "redis://localhost:6379/0"
    redis_password: str = ""

    # ── Sécurité ─────────────────────────────────────────────
    secret_key: str = "change-me-in-production-64-chars-minimum-for-jwt-signing"
    fernet_key: str = ""
    # Clé séparée pour le chiffrement AES des photos : ne doit jamais
    # partager la clé du dossier médical (compromission de l'une ne doit
    # pas exposer l'autre).
    photo_encryption_key: str = ""
    algorithm: str = "HS256"
    access_token_expire_minutes: int = (
        15  # durée courte; la rotation du refresh token renouvelle la session
    )
    refresh_token_expire_days: int = 7

    # ── Compte de recette Railway ─────────────────────────────
    # Le provisionnement est inactif par défaut. Il est limité au compte
    # explicitement configuré et ne doit jamais être activé en production clinique.
    test_admin_bootstrap_enabled: bool = False
    test_admin_reset_existing: bool = False
    test_admin_email: str = ""
    test_admin_nom: str = ""
    test_admin_prenom: str = ""
    test_admin_password: str = ""

    # ── WhatsApp Business API ────────────────────────────────
    wa_business_token: str = ""
    wa_phone_id: str = ""
    wa_webhook_verify_token: str = ""
    wa_api_version: str = "v18.0"
    wa_base_url: str = "https://graph.facebook.com"
    # Correction B6 (AUDIT) : opt-in explicite pour le mode dev WhatsApp.
    # JAMAIS `true` en production : sécurise le connecteur contre l'envoi
    # silencieux de messages non livrés (cf. services/omnicanal/whatsapp_connector.py).
    wa_allow_dev_mode: bool = False

    # ── WhatsApp Business API — ligne praticien (P02-a) ──────────
    # Un Phone Number ID distinct est obligatoire (Meta impose 1 bot / numéro).
    wa_business_token_praticien: str = ""
    wa_phone_id_praticien: str = ""
    wa_webhook_verify_token_praticien: str = ""
    practitioner_agent_enabled: bool = False

    # ── Daily.co (téléconsultation esthétique) ─────────────────
    # Fournisseur vidéo externe optionnel. Les engagements RGPD/HDS doivent être
    # vérifiés et contractés par l’opérateur avant tout usage de données de santé.
    # En production, l’absence de fournisseur configuré bloque la téléconsultation
    # lorsqu’elle est activée ; aucun fallback vidéo public n’est autorisé.
    daily_api_key: str = ""
    daily_api_base: str = "https://api.daily.co/v1"
    daily_default_expires_min: int = 60
    daily_enable_recording: bool = False
    teleconsultation_enabled: bool = False
    daily_required_in_production: bool = True

    # ── Resend (Email) ───────────────────────────────────────
    resend_api_key: str = ""

    # ── Twilio (SMS) ─────────────────────────────────────────
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_from: str = ""

    # ── Feature Flags Omnicanal ──────────────────────────────
    # Double opt-in requis avant toute émission réelle depuis Social CRM.
    # Désactivé par défaut, y compris lorsque des identifiants fournisseurs existent.
    social_external_delivery_enabled: bool = False
    tiktok_enabled: bool = False
    instagram_enabled: bool = False
    facebook_enabled: bool = False

    # ── Webhooks réseaux sociaux (signature) ─────────────────
    # Secret partagé pour vérifier la signature HMAC-SHA256 des webhooks
    # entrants (header X-Signature). En prod, chaque plateforme a son
    # propre schéma (Meta : X-Hub-Signature-256, TikTok : sa propre
    # convention) — ce secret sert de base commune tant qu'un seul
    # webhook générique est utilisé ; à spécialiser par plateforme si
    # plusieurs comptes développeur réels sont branchés.
    social_webhook_secret: str = (
        ""  # Meta uniquement (WhatsApp/Instagram/Facebook — un seul App Secret)
    )
    tiktok_webhook_secret: str = (
        ""  # TikTok a son propre secret, distinct de Meta — jamais le même
    )

    # ── LLM multi-provider (v1.1.0 patch IA) ───────────────────
    # Sélection du provider LLM principal pour les assistants et le runtime
    # agent. Valeurs supportées : openai | openrouter | anthropic |
    # gemini | mistral.
    # Le copilote IA (CRM + analyse dentaire) envoie des données patient
    # (texte pseudonymisé ou images de radiographies) à un LLM tiers.
    # Désactivé par défaut, indépendamment de la présence d'une clé API —
    # l'activation doit être un choix explicite du client.
    copilote_ia_enabled: bool = False
    llm_provider: str = "openai"
    openai_api_key: str = ""
    # Endpoint configurable uniquement pour les environnements de test ou
    # d’exploitation approuvés ; le défaut reste l’API OpenAI officielle.
    openai_api_base: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4o"
    openrouter_api_key: str = ""
    openrouter_model: str = "openai/gpt-4o"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-3-5-sonnet-latest"
    gemini_api_key: str = ""
    gemini_model: str = "gemini-1.5-flash"
    mistral_api_key: str = ""
    mistral_model: str = "mistral-large-latest"
    # Modèle d'édition d'image pour les simulations IA médicales.
    # gpt-image-1 permet un vrai flux d'édition à partir d'une photo source.
    openai_image_model: str = "gpt-image-1"
    # Budget IA tenant-scoped, appliqué avant tout appel fournisseur.
    ai_monthly_request_limit: int = 5_000
    ai_monthly_token_limit: int = 500_000

    # ── Stockage fichiers ────────────────────────────────────
    data_dir: Path = Path("/home/ubuntu/autocommerce-clinic/data")
    photos_dir: Path = Path("/home/ubuntu/autocommerce-clinic/data/photos")
    uploads_dir: Path = Path("/home/ubuntu/autocommerce-clinic/data/uploads")
    branding_dir: Path = Path("/home/ubuntu/autocommerce-clinic/data/branding")
    backups_dir: Path = Path("/home/ubuntu/autocommerce-clinic/backups")
    # Clé indépendante utilisée pour chiffrer les sauvegardes PostgreSQL.
    # Elle doit être fournie hors du dépôt en production.
    backup_encryption_key: str = ""
    backup_retention_days: int = 30
    backup_offsite_dir: str = ""
    backup_offsite_script: str = ""
    max_photo_size_mb: int = 20

    # ── AWS S3 (optionnel) ───────────────────────────────────
    aws_access_key_id: str = ""
    aws_secret_access_key: str = ""
    aws_s3_bucket: str = ""
    aws_region: str = "eu-west-1"

    # ── Email (optionnel) ────────────────────────────────────
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = "noreply@clinic.local"

    # ── Monitoring ───────────────────────────────────────────
    sentry_dsn: str = ""

    # ── RGPD ─────────────────────────────────────────────────
    rgpd_retention_years: int = 10
    points_expiry_months: int = 12
    consent_validity_months: int = 12

    model_config = ConfigDict(
        env_file=".env.clinic",
        env_file_encoding="utf-8",
        case_sensitive=False,
        # Une variable mal orthographiée doit être rejetée, pas ignorée.
        extra="forbid",
    )


DEFAULT_SECRET_KEY = "change-me-in-production-64-chars-minimum-for-jwt-signing"


def _validate_production_secrets(settings: "Settings") -> None:
    """Refuse de démarrer en production avec des secrets par défaut ou
    absents — un oubli de configuration ne doit jamais passer inaperçu.
    Ne s'applique pas en dev/test pour ne pas gêner le développement local."""
    if settings.env != "production":
        return

    erreurs = []
    if settings.secret_key == DEFAULT_SECRET_KEY or len(settings.secret_key) < 32:
        erreurs.append(
            "SECRET_KEY doit être définie et faire au moins 32 caractères en production"
        )
    if not settings.fernet_key:
        erreurs.append(
            "FERNET_KEY doit être définie en production (chiffrement des données médicales)"
        )
    if not settings.photo_encryption_key:
        erreurs.append(
            "PHOTO_ENCRYPTION_KEY doit être définie en production (chiffrement des photos)"
        )
    for field_name, field_label in (
        ("fernet_key", "FERNET_KEY"),
        ("photo_encryption_key", "PHOTO_ENCRYPTION_KEY"),
    ):
        key_value = getattr(settings, field_name)
        if key_value:
            try:
                Fernet(key_value)
            except (TypeError, ValueError):
                erreurs.append(f"{field_label} doit être une clé Fernet valide")
    if not settings.backup_encryption_key or len(settings.backup_encryption_key) < 32:
        erreurs.append(
            "BACKUP_ENCRYPTION_KEY doit être définie et faire au moins 32 caractères en production"
        )
    if (
        settings.photo_encryption_key
        and settings.photo_encryption_key == settings.fernet_key
    ):
        erreurs.append("PHOTO_ENCRYPTION_KEY doit être différente de FERNET_KEY")
    if settings.backup_encryption_key and settings.backup_encryption_key in {
        settings.secret_key,
        settings.fernet_key,
        settings.photo_encryption_key,
    }:
        erreurs.append(
            "BACKUP_ENCRYPTION_KEY doit être indépendante des autres clés de sécurité"
        )
    if settings.database_url.startswith("postgresql+asyncpg://clinic_admin:changeme@"):
        erreurs.append("DATABASE_URL utilise encore les identifiants par défaut")
    if settings.cors_origins == "*":
        erreurs.append("CORS_ORIGINS ne doit pas valoir '*' en production")
    if not settings.dental_domain or "." not in settings.dental_domain:
        erreurs.append("DENTAL_DOMAIN doit être défini avec le domaine de production")
    if not settings.cors_origins.startswith("https://"):
        erreurs.append("CORS_ORIGINS doit commencer par une origine HTTPS en production")
    # P02 : les fonctionnalités sont opt-in et leurs secrets ne sont exigés
    # que lorsqu'elles sont effectivement activées.
    practitioner_wa_fields = (
        ("wa_business_token_praticien", "WA_BUSINESS_TOKEN_PRATICIEN"),
        ("wa_phone_id_praticien", "WA_PHONE_ID_PRATICIEN"),
        ("wa_webhook_verify_token_praticien", "WA_WEBHOOK_VERIFY_TOKEN_PRATICIEN"),
    )
    practitioner_wa_present = [bool(getattr(settings, name)) for name, _ in practitioner_wa_fields]
    if any(practitioner_wa_present) and not all(practitioner_wa_present):
        erreurs.append("La ligne WhatsApp praticien doit fournir ses trois variables ensemble")
    if settings.practitioner_agent_enabled:
        if not all(practitioner_wa_present):
            erreurs.append("PRACTITIONER_AGENT_ENABLED=true exige les trois identifiants WhatsApp praticien")
        if not settings.teleconsultation_enabled:
            erreurs.append("PRACTITIONER_AGENT_ENABLED=true exige TELECONSULTATION_ENABLED=true")
        if not settings.daily_api_key:
            erreurs.append("PRACTITIONER_AGENT_ENABLED=true exige DAILY_API_KEY")
    if settings.teleconsultation_enabled and settings.daily_required_in_production:
        if not settings.daily_api_key:
            erreurs.append("TELECONSULTATION_ENABLED=true exige DAILY_API_KEY quand DAILY_REQUIRED_IN_PRODUCTION=true")
        if not settings.daily_api_base.startswith("https://"):
            erreurs.append("DAILY_API_BASE doit être une URL HTTPS en production")
    if settings.daily_enable_recording and not settings.daily_api_key:
        erreurs.append("DAILY_ENABLE_RECORDING=true exige DAILY_API_KEY")
    if not 5 <= settings.daily_default_expires_min <= 1440:
        erreurs.append("DAILY_DEFAULT_EXPIRES_MIN doit être compris entre 5 et 1440 minutes")

    if erreurs:
        raise RuntimeError(
            "Configuration de production invalide :\n- " + "\n- ".join(erreurs)
        )


@lru_cache()
def get_settings() -> Settings:
    """Retourne une instance singleton des settings. Échoue au démarrage
    (pas au premier appel isolé) si ENV=production et que des secrets
    critiques sont absents ou laissés à leur valeur par défaut."""
    settings = Settings()
    _validate_production_secrets(settings)
    return settings


# ── Constantes métier ──────────────────────────────────────

POINTS_PER_DT: int = 1
FIDELITE_SEUILS = {
    "bronze": 0,
    "silver": 500,
    "gold": 1500,
    "vip": 3000,
}

COMMISSION_VALIDATION_SEUIL: float = 500.0  # Numeric, pas Float

STOCK_ALERT_DAYS_EXPIRING: int = 30
STOCK_WARNING_DAYS_EXPIRING: int = 60

PHOTO_ALLOWED_MIMETYPES = {"image/jpeg", "image/png", "image/webp"}
PHOTO_MAX_DIMENSION = 4096
PHOTO_THUMBNAIL_SIZE = 200

LABEL_FORMATS = {
    "a4": {"width": 210, "height": 297, "cols": 2, "rows": 2},
    "50x30": {"width": 50, "height": 30, "cols": 1, "rows": 1},
    "40x25": {"width": 40, "height": 25, "cols": 1, "rows": 1},
    "60x40": {"width": 60, "height": 40, "cols": 1, "rows": 1},
}

WA_TEMPLATES = {
    "rdv_confirmation": "Votre rendez-vous est confirmé pour le {date} à {heure} avec {praticien}. À bientôt !",
    "rdv_rappel_j1": "Rappel : votre rendez-vous demain à {heure}h avec {praticien}. Confirmer : répondez OUI. Pour annuler : répondez NON.",
    "rdv_rappel_h2": "⏰ Dans 2h : votre rendez-vous à {clinique} 📍 {adresse}",
    "suivi_post_acte": "Comment vous sentez-vous après votre {acte} ? 1️⃣ Très satisfaite 2️⃣ Satisfaite 3️⃣ Questions 4️⃣ Problème",
    "fidelite_gain": "Vous avez gagné {points} points 🌟 Votre solde : {solde} points ({niveau})",
    "fidelite_niveau": "Félicitations {prenom} ! Vous êtes maintenant {niveau} 👑",
    "anniversaire": "Joyeux anniversaire {prenom} ! 🎂 Nous vous offrons 100 points fidélité. À très vite !",
    "relance_inactive": "Bonjour {prenom}, nous vous manquons ! Profitez de -15% sur votre prochain soin. Répondez RDV pour prendre rendez-vous.",
    "stock_alerte": "🏥 Rapport stock — {date}\n🔴 URGENT :\n{urgent}\n🟠 ATTENTION :\n{attention}",
    "backup_ok": "✅ Backup quotidien effectué avec succès. Base + photos chiffrées. {date}",
    "candidature_recu": "Nouvelle candidature reçue : {poste} — {nom}",
    "candidature_statut": "Votre candidature pour {poste} : statut mis à jour → {statut}",
    "injection_rappel": "Bonjour {prenom}, votre injection de {produit} arrive à échéance le {date}. Souhaitez-vous planifier votre prochaine séance ?",
}
