"""
AutoCommerce Clinic — Authentification JWT
PyJWT 2.10.1 (jamais python-jose)
"""

from datetime import datetime, timedelta
from typing import Optional
import hashlib
import uuid

import jwt
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from config import get_settings
from models.database import Utilisateur
from models.security import RefreshTokenSession


settings = get_settings()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
security = HTTPBearer(auto_error=False)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=settings.access_token_expire_minutes)
    )
    to_encode.update({"exp": expire})
    encoded = jwt.encode(to_encode, settings.secret_key, algorithm=settings.algorithm)
    return encoded


def create_mfa_challenge_token(user_id: int) -> str:
    return create_access_token(
        {"sub": str(user_id), "type": "mfa_challenge"},
        expires_delta=timedelta(minutes=5),
    )


def decode_token(token: str) -> dict:
    try:
        payload = jwt.decode(
            token, settings.secret_key, algorithms=[settings.algorithm]
        )
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expiré")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Token invalide")


async def get_db_user(user_id: int, db: AsyncSession) -> Optional[Utilisateur]:
    result = await db.execute(select(Utilisateur).where(Utilisateur.id == user_id))
    return result.scalar_one_or_none()


async def get_auth_db(request: Request):
    # Import différé pour éviter le cycle middleware.auth -> api.deps -> middleware.auth.
    from api.deps import get_db
    dependency = request.app.dependency_overrides.get(get_db, get_db)
    async for session in dependency():
        yield session


async def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    db: AsyncSession = Depends(get_auth_db),
) -> Optional[dict]:
    """Valide le JWT puis recharge le rôle, la clinique et l'état actif en DB."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentification requise",
            headers={"WWW-Authenticate": "Bearer"},
        )

    payload = decode_token(credentials.credentials)

    if payload.get("type") != "access":
        raise HTTPException(status_code=401, detail="Type de token invalide")

    user_id = payload.get("sub")
    if not user_id:
        raise HTTPException(
            status_code=401, detail="Token sans identifiant utilisateur"
        )

    user = await get_db_user(int(user_id), db)
    if not user:
        raise HTTPException(status_code=401, detail="Utilisateur introuvable")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Compte inactif")

    return {
        "id": user.id,
        "role": user.role,
        "clinic_id": user.clinic_id,
        "email": user.email,
        "nom": user.nom,
        "prenom": user.prenom,
        "is_active": user.is_active,
    }


async def get_current_active_user(
    user: Optional[dict] = Depends(get_current_user),
) -> dict:
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentification requise",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.get("is_active"):
        raise HTTPException(status_code=403, detail="Compte inactif")
    return user


async def authenticate_user(
    email: str, password: str, db: AsyncSession
) -> Optional[Utilisateur]:
    result = await db.execute(select(Utilisateur).where(Utilisateur.email == email))
    user = result.scalar_one_or_none()
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user


def _hash_refresh_token(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_refresh_token(user: Utilisateur, jti: Optional[str] = None) -> tuple[str, str]:
    token_jti = jti or uuid.uuid4().hex
    token = create_access_token(
        {"sub": str(user.id), "clinic_id": user.clinic_id, "jti": token_jti, "type": "refresh"},
        expires_delta=timedelta(days=settings.refresh_token_expire_days),
    )
    return token, token_jti


async def create_tokens_for_user(user: Utilisateur, db: Optional[AsyncSession] = None) -> dict:
    access_payload = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role,
        "clinic_id": user.clinic_id,
        "nom": user.nom,
        "prenom": user.prenom,
        "is_active": user.is_active,
        "type": "access",
    }
    refresh_token, jti = create_refresh_token(user)
    if db is not None:
        db.add(
            RefreshTokenSession(
                user_id=user.id,
                clinic_id=user.clinic_id,
                jti=jti,
                token_hash=_hash_refresh_token(refresh_token),
                expires_at=datetime.utcnow() + timedelta(days=settings.refresh_token_expire_days),
            )
        )
        await db.flush()
    return {
        "access_token": create_access_token(access_payload),
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": settings.access_token_expire_minutes * 60,
    }


async def rotate_refresh_token(raw_token: str, db: AsyncSession) -> dict:
    payload = decode_token(raw_token)
    if payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Ce n'est pas un refresh token")
    jti = payload.get("jti")
    user_id = payload.get("sub")
    if not jti or not user_id:
        raise HTTPException(status_code=401, detail="Refresh token sans identifiant")
    result = await db.execute(
        select(RefreshTokenSession).where(RefreshTokenSession.jti == str(jti)).with_for_update()
    )
    session = result.scalar_one_or_none()
    now = datetime.utcnow()
    if not session or session.token_hash != _hash_refresh_token(raw_token):
        raise HTTPException(status_code=401, detail="Refresh token invalide")
    if session.revoked_at is not None:
        if session.replaced_by_jti:
            await db.execute(
                RefreshTokenSession.__table__.update()
                .where(RefreshTokenSession.user_id == session.user_id)
                .where(RefreshTokenSession.revoked_at.is_(None))
                .values(revoked_at=now)
            )
        raise HTTPException(status_code=401, detail="Refresh token réutilisé ou révoqué")
    if session.expires_at <= now:
        session.revoked_at = now
        await db.flush()
        raise HTTPException(status_code=401, detail="Refresh token expiré")
    user = await get_db_user(int(user_id), db)
    if not user or not user.is_active or user.clinic_id != session.clinic_id:
        session.revoked_at = now
        await db.flush()
        raise HTTPException(status_code=401, detail="Utilisateur introuvable ou désactivé")
    new_token, new_jti = create_refresh_token(user)
    session.revoked_at = now
    session.replaced_by_jti = new_jti
    db.add(
        RefreshTokenSession(
            user_id=user.id,
            clinic_id=user.clinic_id,
            jti=new_jti,
            token_hash=_hash_refresh_token(new_token),
            expires_at=now + timedelta(days=settings.refresh_token_expire_days),
        )
    )
    await db.flush()
    access_payload = {
        "sub": str(user.id), "email": user.email, "role": user.role,
        "clinic_id": user.clinic_id, "nom": user.nom, "prenom": user.prenom,
        "is_active": user.is_active, "type": "access",
    }
    return {
        "access_token": create_access_token(access_payload),
        "refresh_token": new_token,
        "token_type": "bearer",
        "expires_in": settings.access_token_expire_minutes * 60,
    }


async def revoke_refresh_token(raw_token: str, db: AsyncSession) -> None:
    payload = decode_token(raw_token)
    jti = payload.get("jti")
    if not jti or payload.get("type") != "refresh":
        return
    result = await db.execute(select(RefreshTokenSession).where(RefreshTokenSession.jti == str(jti)))
    session = result.scalar_one_or_none()
    if session and session.revoked_at is None:
        session.revoked_at = datetime.utcnow()
        await db.flush()
