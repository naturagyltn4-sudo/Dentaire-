"""
AutoCommerce Clinic — Middleware Webhook Omnicanal (Bloc 1)

CORRECTION du webhook auth existant :
  - Supporte les signatures multi-canal (X-Hub-Signature-256, X-Tiktok-Signature)
  - Détecte automatiquement le canal à partir du payload
  - Dispatche vers le bon connecteur pour validation
  - Rétrocompatible avec l'ancien X-Signature (transition progressive)
"""

import json
import hashlib
import hmac
import logging
from datetime import datetime
from typing import Optional

from fastapi import Request

logger = logging.getLogger(__name__)

# En-têtes de signature par canal
SIGNATURE_HEADERS = {
    "whatsapp": "X-Hub-Signature-256",
    "instagram": "X-Hub-Signature-256",
    "facebook": "X-Hub-Signature-256",
    "tiktok": "X-Tiktok-Signature",
    "email": None,  # Email n'a pas de webhook
    "sms": "X-Twilio-Signature",
}


async def get_channel_from_request(
    request: Request, path_canal: Optional[str] = None
) -> Optional[str]:
    """Détecte le canal à partir du payload ou des headers.

    Utilise en priorité le path param (ex: /webhook/whatsapp) si le payload
    ne permet pas d'identifier le canal de manière fiable.
    """
    # Essayer de parser le body pour identifier le canal
    try:
        body = await request.body()
        data = json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        data = {}

    # WhatsApp Meta
    if data.get("object") == "whatsapp_business_account":
        return "whatsapp"
    # Instagram Meta
    if data.get("object") == "instagram":
        return "instagram"
    # Facebook Meta
    if data.get("object") == "page":
        # Peut être Instagram ou Facebook — vérifier les champs
        entries = data.get("entry", [{}])
        if entries and "messaging" in entries[0]:
            # Facebook Messenger utilise 'messaging'
            return "facebook"
        return "instagram"  # Fallback
    # TikTok
    if "X-Tiktok-Signature" in request.headers:
        return "tiktok"
    # Twilio SMS
    if "X-Twilio-Signature" in request.headers:
        return "sms"
    # Header explicite
    canal_header = request.headers.get("X-Channel")
    if canal_header:
        return canal_header

    # Fallback : utiliser le path param si fourni
    if path_canal and path_canal in (
        "whatsapp",
        "instagram",
        "facebook",
        "tiktok",
        "sms",
        "email",
    ):
        return path_canal

    return None


async def verify_webhook_signature(
    request: Request, channel: str, secret: Optional[str]
) -> bool:
    """Vérifie la signature du webhook pour un canal donné.

    `secret` doit déjà être le bon secret pour ce canal (Meta pour
    whatsapp/instagram/facebook, TikTok pour tiktok) — voir
    process_incoming_webhook, qui sélectionne le bon avant d'appeler
    cette fonction. Ne jamais réutiliser le secret Meta pour TikTok."""
    if not secret:
        return False

    raw_body = await request.body()
    header_name = SIGNATURE_HEADERS.get(channel, "X-Signature")

    signature = request.headers.get(header_name) or request.headers.get("X-Signature")
    if not signature:
        return False

    hex_hash = signature
    if signature.startswith("sha256="):
        hex_hash = signature[len("sha256=") :]

    expected = hmac.new(
        secret.encode(),
        raw_body,
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(hex_hash, expected)


async def process_incoming_webhook(
    request: Request, db, clinic_id: int | None = None, path_canal: Optional[str] = None
) -> dict:
    """Traite un webhook entrant multi-canal."""
    from config import get_settings
    from middleware.clinic_context import require_clinic_id
    from services.omnicanal_service import receive_message
    from services.omnicanal.factory import OmnicanalFactory
    from middleware.assistant_whitelist import (
        resolve_user_from_whitelist,
        normalize_numero,
        WhitelistRejection,
    )
    from services.clinic_agent import handle_agent_message
    from services.voice_transcription import transcribe_whatsapp_voice

    settings = get_settings()
    clinic_id = require_clinic_id(
        clinic_id or settings.instance_clinic_id,
        purpose="le webhook omnicanal mono-VPS",
    )

    # Détecter le canal d'abord : le secret dépend du canal (Meta et
    # TikTok ont chacun leur propre secret, jamais partagé entre les deux).
    channel = await get_channel_from_request(request, path_canal=path_canal)
    if not channel:
        logger.warning("Could not identify channel from webhook payload")
        return {"error": "Canal non identifiable", "success": False}

    channel_secrets = {
        "whatsapp": settings.social_webhook_secret,
        "instagram": settings.social_webhook_secret,
        "facebook": settings.social_webhook_secret,
        "tiktok": settings.tiktok_webhook_secret,
    }
    secret = channel_secrets.get(channel)

    if not secret:
        logger.error(f"Webhook secret missing for channel={channel}")
        return {"error": f"Webhook non configuré pour {channel}", "success": False}

    # Vérification des feature flags
    disabled = False
    if channel == "tiktok" and not settings.tiktok_enabled:
        disabled = True
    elif channel == "instagram" and not settings.instagram_enabled:
        disabled = True
    elif channel == "facebook" and not settings.facebook_enabled:
        disabled = True

    if disabled:
        logger.warning(f"Webhook received for disabled channel: {channel}")
        return {"error": f"Canal {channel} désactivé", "success": False}

    # Récupérer le connecteur pour la vérification de signature
    factory = OmnicanalFactory()
    connector = factory.get_connector(channel)
    raw_body = await request.body()

    header_name = SIGNATURE_HEADERS.get(channel) or "X-Signature"
    sig = request.headers.get(header_name) or request.headers.get("X-Signature")

    if connector:
        if sig:
            if not connector.verify_signature(raw_body, sig):
                return {"error": "Signature invalide", "success": False}
        else:
            if not await verify_webhook_signature(request, channel, secret):
                return {"error": "Signature manquante ou invalide", "success": False}
    else:
        if not await verify_webhook_signature(request, channel, secret):
            return {"error": "Signature manquante ou invalide", "success": False}

    # Parser le payload
    if connector:
        messages_data = connector.parse_webhook_payload(raw_body)
    else:
        messages_data = []

    # Enregistrer chaque message
    results = []
    for msg_data in messages_data:
        # Transcrire avant persistance afin que l'inbox et l'agent IA reçoivent
        # le contenu réel tout en conservant l'ID média Meta original.
        processed_content = msg_data.get("content", "")
        transcription_failed = False
        if channel == "whatsapp" and msg_data.get("type_message") == "audio" and msg_data.get("media_url"):
            transcribed = await transcribe_whatsapp_voice(
                msg_data["media_url"], db=db, clinic_id=clinic_id
            )
            if transcribed:
                processed_content = transcribed
            else:
                transcription_failed = True

        # La ligne praticien est séparée de la whitelist cabinet. Elle ne peut
        # interroger l’agent médecin qu’avec une téléconsultation consentie.
        if channel == "whatsapp" and (
            settings.env not in {"production", "prod"}
            or getattr(settings, "practitioner_agent_enabled", False)
        ):
            from models.database import RendezVous, Teleconsultation, Utilisateur
            from models.security import AssistantMedecinWhitelist
            from sqlalchemy import select

            numero_norm = await normalize_numero(msg_data["contact_id"])
            practitioner_row = (
                await db.execute(
                    select(AssistantMedecinWhitelist).where(
                        AssistantMedecinWhitelist.numero == numero_norm,
                        AssistantMedecinWhitelist.clinic_id == clinic_id,
                        AssistantMedecinWhitelist.statut == "active",
                        AssistantMedecinWhitelist.revoked_at.is_(None),
                        (AssistantMedecinWhitelist.expires_at.is_(None))
                        | (AssistantMedecinWhitelist.expires_at > datetime.utcnow()),
                    )
                )
            ).scalar_one_or_none()
            if practitioner_row:
                staff_user = await db.scalar(
                    select(Utilisateur).where(
                        Utilisateur.id == practitioner_row.utilisateur_id,
                        Utilisateur.clinic_id == clinic_id,
                        Utilisateur.is_active,
                    )
                )
                question = None if transcription_failed else processed_content
                teleconsultation = None
                if staff_user and question:
                    teleconsultation = await db.scalar(
                        select(Teleconsultation)
                        .join(RendezVous, RendezVous.id == Teleconsultation.rdv_id)
                        .where(
                            Teleconsultation.clinic_id == clinic_id,
                            Teleconsultation.consent_url.is_not(None),
                            Teleconsultation.consent_url != "",
                            Teleconsultation.statut.in_(["planifiee", "en_cours"]),
                            RendezVous.clinic_id == clinic_id,
                            RendezVous.praticien_id == staff_user.id,
                        )
                        .order_by(Teleconsultation.id.desc())
                        .limit(1)
                    )
                if not staff_user or not teleconsultation:
                    agent_result = {
                        "ok": False,
                        "error": "Aucune téléconsultation active avec consentement pour ce praticien",
                    }
                elif question:
                    from services.agent_medecin import handle_agent_medecin_message

                    agent_result = await handle_agent_medecin_message(
                        numero_norm,
                        question,
                        {
                            "id": staff_user.id,
                            "role": staff_user.role,
                            "clinic_id": clinic_id,
                        },
                        db,
                        teleconsultation_id=teleconsultation.id,
                    )
                else:
                    agent_result = {
                        "ok": False,
                        "error": "Message vocal non transcrit",
                    }
                results.append({"canal": "whatsapp", "agent_medecin": True, **agent_result})
                continue

            # Un numéro WhatsApp whitelisté cabinet reste traité par l’agent
            # général avec ses confirmations et permissions historiques.
            try:
                _, staff_user = await resolve_user_from_whitelist(
                    msg_data["contact_id"], db, clinic_id=clinic_id
                )
                current_user = {
                    "id": staff_user.id,
                    "role": staff_user.role,
                    "nom": staff_user.nom,
                    "prenom": staff_user.prenom,
                    "email": staff_user.email,
                    "clinic_id": clinic_id,
                }

                question = None if transcription_failed else processed_content
                if question:
                    agent_result = await handle_agent_message(
                        msg_data["contact_id"], question, current_user, db
                    )
                else:
                    agent_result = {
                        "reponse": "Je n'ai pas pu comprendre ce message vocal, pouvez-vous réessayer ou l'écrire ?",
                        "statut": "transcription_echouee",
                    }
                results.append({"canal": "whatsapp", "agent": True, **agent_result})
                continue
            except WhitelistRejection:
                pass  # pas un numéro staff → traitement patient normal ci-dessous

        result = await receive_message(
            canal=channel,
            contact_external_id=msg_data["contact_id"],
            content=processed_content,
            type_message=msg_data.get("type_message", "texte"),
            media_url=msg_data.get("media_url"),
            external_message_id=msg_data.get("external_message_id"),
            clinic_id=clinic_id,
            db=db,
        )
        results.append(result)

    logger.info(f"Webhook {channel} processed: {len(results)} messages persisted")
    return {
        "canal": channel,
        "messages_count": len(results),
        "success": True,
        "results": results,
    }
