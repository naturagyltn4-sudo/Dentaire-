"""
AutoCommerce Clinic — Contexte clinique (multi-clinique préparation)
Contexte clinique déterminé côté serveur par instance_clinic_id
"""

from contextvars import ContextVar
from typing import Optional

from config import get_settings

clinic_id_var: ContextVar[Optional[int]] = ContextVar("clinic_id", default=None)


def get_current_clinic_id() -> int:
    """Retourne le contexte interne de l’instance.

    Cette fonction est réservée aux tâches système et aux flux publics liés à
    une instance. Les routes authentifiées doivent préférer
    :func:`require_clinic_id` avec le tenant issu du JWT.
    """
    return clinic_id_var.get() or get_settings().instance_clinic_id


def require_clinic_id(clinic_id: int | None, *, purpose: str = "opération") -> int:
    """Valide le tenant serveur avec un mode compatibilité non-production.

    En production, l’absence de tenant explicite est toujours refusée. En
    test/dev uniquement, l’ancien contexte d’instance peut être utilisé pour
    les jobs historiques qui ne traitent pas de requête authentifiée ; cette
    compatibilité n’est donc jamais une voie d’accès inter-clinique en
    production.
    """
    if isinstance(clinic_id, int) and clinic_id > 0:
        return clinic_id
    settings = get_settings()
    if settings.env not in {"production", "prod"}:
        fallback = get_current_clinic_id()
        if isinstance(fallback, int) and fallback > 0:
            return fallback
    raise ValueError(f"clinic_id explicite requis pour {purpose}")


def set_clinic_id(clinic_id: int):
    """Définit un contexte interne ; en production, il doit rester celui de l’instance."""
    settings = get_settings()
    if settings.env == "production" and clinic_id != settings.instance_clinic_id:
        raise ValueError("Une instance clinique ne peut pas changer de clinique en production")
    clinic_id_var.set(clinic_id)
