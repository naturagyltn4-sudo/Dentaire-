from __future__ import annotations

import re
from typing import Any

_SENSITIVE_KEYS = {
    "nom",
    "prenom",
    "name",
    "patient_name",
    "email",
    "telephone",
    "phone",
    "patient_phone",
    "whatsapp_phone",
    "adresse",
    "address",
    "ville",
    "notes",
    "note_interne",
}
_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I)
_PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d[\d .()/-]{7,}\d)(?!\d)")


def pseudonymiser_prompt_payload(payload: Any, patient_ref: str = "PATIENT-ANONYME") -> Any:
    """Retourne une copie récursive sans PII directe pour un prompt LLM."""
    if isinstance(payload, dict):
        sanitized = {}
        for key, value in payload.items():
            key_lower = str(key).lower()
            if key_lower in _SENSITIVE_KEYS:
                sanitized[key] = (
                    patient_ref
                    if key_lower in {"name", "patient_name", "nom", "prenom"}
                    else "[REDACTED]"
                )
            elif key_lower in {"id", "patient_id"}:
                sanitized[key] = patient_ref
            else:
                sanitized[key] = pseudonymiser_prompt_payload(value, patient_ref)
        return sanitized
    if isinstance(payload, list):
        return [pseudonymiser_prompt_payload(item, patient_ref) for item in payload]
    if isinstance(payload, tuple):
        return tuple(pseudonymiser_prompt_payload(item, patient_ref) for item in payload)
    return payload


def _redact_free_text(value: str) -> str:
    value = _EMAIL_RE.sub("[REDACTED_EMAIL]", value)
    return _PHONE_RE.sub("[REDACTED_PHONE]", value)


def sanitize_llm_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize structured message payloads at the provider boundary.

    Structured PII keys are pseudonymised recursively; free text receives a
    conservative email/phone redaction. Clinical content remains available,
    but the caller must still minimize it before this final defense-in-depth
    layer.
    """
    sanitized = pseudonymiser_prompt_payload(messages)

    def walk(value: Any) -> Any:
        if isinstance(value, str):
            return _redact_free_text(value)
        if isinstance(value, list):
            return [walk(item) for item in value]
        if isinstance(value, dict):
            return {key: walk(item) for key, item in value.items()}
        return value

    return walk(sanitized)
