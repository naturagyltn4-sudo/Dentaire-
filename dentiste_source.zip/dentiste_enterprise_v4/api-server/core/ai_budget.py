"""Tenant-scoped AI budget enforcement.

The budget is deliberately enforced before any external provider call. A
reservation is conservative (input estimate + requested max output tokens),
so retries and parallel requests cannot silently bypass a clinic's quota.
"""

from __future__ import annotations

from datetime import date
from typing import Any

from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.ext.asyncio import AsyncSession

from models.database import AIUsage


class AIBudgetExceeded(PermissionError):
    """Raised when the authenticated clinic has exhausted its AI budget."""


def _month_start() -> date:
    today = date.today()
    return today.replace(day=1)


def _positive_int(value: Any, name: str) -> int:
    if not isinstance(value, int) or value <= 0:
        raise ValueError(f"{name} doit être un entier positif")
    return value


async def reserve_ai_budget(
    session: AsyncSession,
    clinic_id: int,
    *,
    estimated_input_tokens: int,
    requested_output_tokens: int,
    request_limit: int,
    token_limit: int,
) -> AIUsage:
    """Reserve one request and its worst-case token cost for one clinic.

    PostgreSQL uses an upsert to close the first-request race, then locks the
    single clinic/month row before checking and incrementing both counters.
    """
    clinic_id = _positive_int(clinic_id, "clinic_id")
    estimated_input_tokens = _positive_int(estimated_input_tokens, "estimated_input_tokens")
    requested_output_tokens = _positive_int(requested_output_tokens, "requested_output_tokens")
    request_limit = _positive_int(request_limit, "request_limit")
    token_limit = _positive_int(token_limit, "token_limit")
    period_start = _month_start()
    reservation = estimated_input_tokens + requested_output_tokens

    bind = session.get_bind()
    dialect = getattr(getattr(bind, "dialect", None), "name", "")
    if dialect == "postgresql":
        stmt = pg_insert(AIUsage).values(
            clinic_id=clinic_id,
            period_start=period_start,
            requests_count=0,
            reserved_tokens=0,
            request_limit=request_limit,
            token_limit=token_limit,
        ).on_conflict_do_nothing(
            index_elements=["clinic_id", "period_start"]
        )
        await session.execute(stmt)
    else:
        row = (
            await session.execute(
                select(AIUsage).where(
                    AIUsage.clinic_id == clinic_id,
                    AIUsage.period_start == period_start,
                )
            )
        ).scalar_one_or_none()
        if row is None:
            session.add(
                AIUsage(
                    clinic_id=clinic_id,
                    period_start=period_start,
                    request_limit=request_limit,
                    token_limit=token_limit,
                )
            )
            await session.flush()

    row = (
        await session.execute(
            select(AIUsage)
            .where(
                AIUsage.clinic_id == clinic_id,
                AIUsage.period_start == period_start,
            )
            .with_for_update()
        )
    ).scalar_one()

    if row.request_limit != request_limit:
        row.request_limit = request_limit
    if row.token_limit != token_limit:
        row.token_limit = token_limit

    if row.requests_count + 1 > row.request_limit:
        raise AIBudgetExceeded("Quota mensuel de requêtes IA dépassé pour cette clinique")
    if row.reserved_tokens + reservation > row.token_limit:
        raise AIBudgetExceeded("Quota mensuel de tokens IA dépassé pour cette clinique")

    row.requests_count += 1
    row.reserved_tokens += reservation
    await session.flush()
    return row
