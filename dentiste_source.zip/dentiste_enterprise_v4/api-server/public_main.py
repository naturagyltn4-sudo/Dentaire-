"""Public Gateway API.

Ce processus ne monte aucun routeur clinique privé. Il expose seulement la
surface publique nécessaire à la landing page et au booking, tandis que le
processus `main:app` reste le Private Clinical Core.
"""

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query, Request, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, limiter
from config import get_settings
from models.database import ActeMedical, RoleEnum, Utilisateur
from services.agenda import get_disponibilites
from services.branding import get_branding
from services.reservation_publique import hash_source_ip, reserver_creneau_public

settings = get_settings()
app = FastAPI(title="Dentiste Public Gateway", version="1.1.0")

origins = [origin.strip() for origin in settings.cors_origins.split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins and origins != ["*"] else ["*"],
    allow_credentials=False,
    allow_methods=["GET", "HEAD", "OPTIONS", "POST"],
    allow_headers=["Content-Type", "Accept", "Origin"],
)

public_router = APIRouter(prefix="/api/v1", tags=["public-gateway"])


class PublicReservation(BaseModel):
    nom: str
    prenom: str
    telephone: str
    praticien_id: Optional[int] = None
    specialite: Optional[str] = None
    acte_id: int
    date_heure: datetime


@public_router.get("/settings/branding")
async def public_branding(db: AsyncSession = Depends(get_db)):
    return await get_branding(db)


@public_router.get("/public/praticiens")
async def public_praticiens(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Utilisateur)
        .where(Utilisateur.clinic_id == settings.instance_clinic_id)
        .where(Utilisateur.is_active)
        .where(
            Utilisateur.role.in_([
                RoleEnum.MEDECIN.value,
                RoleEnum.ORTHODONTISTE.value,
                RoleEnum.ESTHETICIENNE.value,
            ])
        )
        .order_by(Utilisateur.prenom, Utilisateur.nom)
    )
    return [
        {
            "id": user.id,
            "nom": user.nom,
            "prenom": user.prenom,
            "nom_complet": f"{user.prenom} {user.nom}",
            "specialite": user.specialite,
            "agenda_color": user.agenda_color,
        }
        for user in result.scalars().all()
    ]


@public_router.get("/public/actes")
async def public_actes(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(ActeMedical)
        .where(ActeMedical.clinic_id == settings.instance_clinic_id)
        .where(ActeMedical.is_active)
        .order_by(ActeMedical.nom)
    )
    return [
        {
            "id": acte.id,
            "nom": acte.nom,
            "categorie": acte.categorie,
            "duree_minutes": acte.duree_minutes,
            "description": acte.description,
            "prix_base": float(acte.prix_base) if acte.prix_base is not None else None,
        }
        for acte in result.scalars().all()
    ]


@public_router.get("/public/disponibilites/{praticien_id}")
async def public_disponibilites(
    praticien_id: int,
    date: Optional[str] = Query(None, description="YYYY-MM-DD"),
    acte_id: Optional[int] = Query(None),
    duree: Optional[int] = Query(None, ge=15, le=240),
    db: AsyncSession = Depends(get_db),
):
    practitioner = (
        await db.execute(
            select(Utilisateur).where(
                Utilisateur.id == praticien_id,
                Utilisateur.clinic_id == settings.instance_clinic_id,
                Utilisateur.is_active,
                Utilisateur.role.in_([
                    RoleEnum.MEDECIN.value,
                    RoleEnum.ORTHODONTISTE.value,
                    RoleEnum.ESTHETICIENNE.value,
                ]),
            )
        )
    ).scalar_one_or_none()
    if not practitioner:
        raise HTTPException(status_code=404, detail="Praticien non trouvé")

    if date:
        try:
            date_jour = datetime.strptime(date, "%Y-%m-%d").date()
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Date invalide") from exc
    else:
        date_jour = datetime.utcnow().date()

    duration = duree or 30
    if acte_id is not None:
        acte = (
            await db.execute(
                select(ActeMedical).where(
                    ActeMedical.id == acte_id,
                    ActeMedical.clinic_id == settings.instance_clinic_id,
                    ActeMedical.is_active,
                )
            )
        ).scalar_one_or_none()
        if not acte:
            raise HTTPException(status_code=404, detail="Acte non trouvé")
        duration = acte.duree_minutes

    slots = await get_disponibilites(
        praticien_id,
        date_jour,
        duration,
        db,
        clinic_id=settings.instance_clinic_id,
    )
    if date_jour == datetime.utcnow().date():
        now = datetime.utcnow()
        slots = [
            slot
            for slot in slots
            if datetime.fromisoformat(slot["datetime"]) >= now
        ]
    return {
        "praticien_id": praticien_id,
        "date": date_jour.isoformat(),
        "duree_minutes": duration,
        "creneaux": slots,
    }


@public_router.post("/public/reservation", status_code=status.HTTP_201_CREATED)
@limiter.limit("5/minute")
async def public_reservation(
    request: Request,
    payload: PublicReservation,
    db: AsyncSession = Depends(get_db),
):
    try:
        return await reserver_creneau_public(
            payload.model_dump(),
            db,
            clinic_id=settings.instance_clinic_id,
            source_ip_hash=hash_source_ip(
                request.client.host if request.client else None
            ),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


app.include_router(public_router)


@app.get("/ready")
async def ready(db: AsyncSession = Depends(get_db)):
    """Readiness publique réelle : la base doit répondre sans divulguer l’erreur."""
    try:
        await db.execute(select(1))
        return {"status": "ready", "surface": "public-gateway", "db": "ok"}
    except Exception as exc:
        import logging
        logging.getLogger(__name__).exception("Public readiness check failed")
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Service temporairement indisponible") from exc
