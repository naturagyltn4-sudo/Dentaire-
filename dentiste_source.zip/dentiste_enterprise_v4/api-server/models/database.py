"""
AutoCommerce Clinic — Modèles SQLAlchemy 2.0
Style modern mapped_column. Tous les montants en Numeric(10,3).
Données médicales chiffrées suffixe _enc.
Clinic_id=1 partout (préparation multi-clinique).
"""

import enum
from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional

from sqlalchemy import (
    JSON,
    Boolean,
    CheckConstraint,
    Date,
    DateTime,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import (
    DeclarativeBase,
    Mapped,
    mapped_column,
    relationship,
)
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker


# ═══════════════════════════════════════════════════════════
# Base & Engine
# ═══════════════════════════════════════════════════════════


class Base(DeclarativeBase):
    pass


# ═══════════════════════════════════════════════════════════
# ENUMS
# ═══════════════════════════════════════════════════════════


class RoleEnum(str, enum.Enum):
    DIRECTRICE = "directrice"
    MEDECIN = "medecin"
    ORTHODONTISTE = "orthodontiste"
    ESTHETICIENNE = "estheticienne"
    ASSISTANTE = "assistante"
    COMMERCIAL = "commercial"
    ADMIN = "admin"
    SUPERADMIN = "superadmin"


class StatutRDV(str, enum.Enum):
    PLANIFIE = "planifie"
    CONFIRME = "confirme"
    EN_COURS = "en_cours"
    TERMINE = "termine"
    ANNULE = "annule"
    NO_SHOW = "no_show"


class TypePhoto(str, enum.Enum):
    AVANT = "avant"
    APRES = "apres"
    PROGRESSION = "progression"
    COMPLICATION = "complication"
    AUTRE = "autre"


class StatutLot(str, enum.Enum):
    DISPONIBLE = "disponible"
    QUARANTAINE = "quarantaine"
    EPUISE = "epuise"
    EXPIRE = "expire"
    RETIRE = "retire"


class StatutFacture(str, enum.Enum):
    BROUILLON = "brouillon"
    ENVOYEE = "envoyee"
    PAYEE = "payee"
    PARTIELLEMENT_PAYEE = "partiellement_payee"
    ANNULEE = "annulee"


class StatutDevis(str, enum.Enum):
    BROUILLON = "brouillon"
    ENVOYE = "envoye"
    ACCEPTE = "accepte"
    REFUSE = "refuse"
    EXPIRE = "expire"


class StatutPriseEnCharge(str, enum.Enum):
    EN_ATTENTE = "en_attente"
    ACCEPTE = "accepte"
    REFUSE = "refuse"
    PARTIEL = "partiel"


class StatutCommission(str, enum.Enum):
    EN_ATTENTE = "en_attente"
    VALIDATION_PARTIELLE = (
        "validation_partielle"  # >500 DT, 1 seul validateur pour l'instant
    )
    VALIDEE = "validee"
    PAYEE = "payee"


class NiveauFidelite(str, enum.Enum):
    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"
    VIP = "vip"


class StatutDepense(str, enum.Enum):
    EN_ATTENTE = "en_attente"
    TRAITEE_IA = "traitee_ia"
    IA_DESACTIVEE = "ia_desactivee"
    VALIDEE = "validee"
    REJETEE = "rejetee"


class StatutCandidature(str, enum.Enum):
    RECU = "recu"
    EN_ETUDE = "en_etude"
    ENTRETIEN = "entretien"
    ACCEPTE = "accepte"
    REFUSE = "refuse"


class StatutSuiviPostOp(str, enum.Enum):
    PLANIFIE = "planifie"
    EFFECTUE = "effectue"
    MANQUE = "manque"


class PhaseOrtho(str, enum.Enum):
    AVANT = "avant"
    PENDANT = "pendant"
    APRES = "apres"


class AppareilOrtho(str, enum.Enum):
    BAGUES = "bagues"
    ALIGNEURS = "aligneurs"
    AUTRE = "autre"


# ═══════════════════════════════════════════════════════════
# MODÈLES (dans l'ordre des dépendances FK)
# ═══════════════════════════════════════════════════════════


class Utilisateur(Base):
    __tablename__ = "utilisateurs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    email: Mapped[str] = mapped_column(
        String(255), unique=True, index=True, nullable=False
    )
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    nom: Mapped[str] = mapped_column(String(100), nullable=False)
    prenom: Mapped[str] = mapped_column(String(100), nullable=False)
    role: Mapped[RoleEnum] = mapped_column(String(20), nullable=False)
    telephone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    photo_profil_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    taux_commission: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), default=Decimal("0.00")
    )
    agenda_color: Mapped[Optional[str]] = mapped_column(String(7), nullable=True)
    specialite: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    # ── MFA / 2FA ───────────────────────────────────────────
    mfa_secret: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    mfa_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    mfa_backup_codes: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )  # JSON de codes hachés
    mfa_setup_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    mfa_failed_attempts: Mapped[int] = mapped_column(Integer, default=0)
    mfa_locked_until: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (Index("ix_utilisateurs_clinic_email", "clinic_id", "email"),)

    # Relations
    patients_commercial: Mapped[List["Patient"]] = relationship(
        "Patient", foreign_keys="Patient.commercial_id", back_populates="commercial"
    )
    rdvs_praticien: Mapped[List["RendezVous"]] = relationship(
        "RendezVous", foreign_keys="RendezVous.praticien_id", back_populates="praticien"
    )
    rdvs_created: Mapped[List["RendezVous"]] = relationship(
        "RendezVous", foreign_keys="RendezVous.created_by", back_populates="createur"
    )
    dossiers_praticien: Mapped[List["DossierMedical"]] = relationship(
        "DossierMedical",
        foreign_keys="DossierMedical.praticien_id",
        back_populates="praticien",
    )
    commissions: Mapped[List["Commission"]] = relationship(
        "Commission",
        foreign_keys="Commission.commercial_id",
        back_populates="commercial",
    )
    commissions_validees: Mapped[List["Commission"]] = relationship(
        "Commission",
        foreign_keys="Commission.validee_par_id",
        back_populates="validateur",
    )
    photos_prise_par: Mapped[List["PhotoClinic"]] = relationship(
        "PhotoClinic",
        foreign_keys="PhotoClinic.prise_par_id",
        back_populates="prise_par",
    )
    utilisations_lot: Mapped[List["UtilisationLot"]] = relationship(
        "UtilisationLot",
        foreign_keys="UtilisationLot.praticien_id",
        back_populates="praticien",
    )
    mouvements_consommables: Mapped[List["MouvementConsommable"]] = relationship(
        "MouvementConsommable", back_populates="utilisateur"
    )
    factures_created: Mapped[List["Facture"]] = relationship(
        "Facture", foreign_keys="Facture.created_by", back_populates="createur"
    )
    depenses_validees: Mapped[List["Depense"]] = relationship(
        "Depense", foreign_keys="Depense.valide_par_id", back_populates="validateur"
    )
    depenses_created: Mapped[List["Depense"]] = relationship(
        "Depense", foreign_keys="Depense.created_by", back_populates="createur_depense"
    )
    candidatures_evaluees: Mapped[List["Candidature"]] = relationship(
        "Candidature",
        foreign_keys="Candidature.evaluateur_id",
        back_populates="evaluateur",
    )
    campagnes_created: Mapped[List["CampagneMarketing"]] = relationship(
        "CampagneMarketing",
        foreign_keys="CampagneMarketing.created_by",
        back_populates="createur_campagne",
    )
    etats_dentaires_modifies: Mapped[List["EtatDentaire"]] = relationship(
        "EtatDentaire",
        foreign_keys="EtatDentaire.praticien_id",
        back_populates="praticien",
    )
    historiques_dentaires_crees: Mapped[List["HistoriqueDentaire"]] = relationship(
        "HistoriqueDentaire",
        foreign_keys="HistoriqueDentaire.praticien_id",
        back_populates="praticien",
    )


class Patient(Base):
    __tablename__ = "patients"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    prenom: Mapped[str] = mapped_column(String(100), index=True, nullable=False)
    date_naissance: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    genre: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    telephone: Mapped[str] = mapped_column(
        String(20), index=True, nullable=False
    )
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    adresse: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    ville: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    groupe_sanguin: Mapped[Optional[str]] = mapped_column(String(5), nullable=True)
    allergies_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    antecedents_medicaux_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    contre_indications_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    note_interne_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    photo_profil_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    source_acquisition: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    commercial_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    statut: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    whatsapp_phone: Mapped[Optional[str]] = mapped_column(
        String(20), index=True, nullable=True
    )
    opted_out: Mapped[bool] = mapped_column(Boolean, default=False)
    last_message_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    points_fidelite: Mapped[int] = mapped_column(Integer, default=0)
    niveau_fidelite: Mapped[NiveauFidelite] = mapped_column(
        String(10), default=NiveauFidelite.BRONZE.value
    )
    derniere_visite: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    consentement_rgpd_signe_le: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    consentement_marketing: Mapped[bool] = mapped_column(Boolean, default=False)
    anonymized_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        UniqueConstraint("clinic_id", "telephone", name="uq_patients_clinic_telephone"),
        Index("ix_patients_clinic_nom", "clinic_id", "nom"),
        Index("ix_patients_clinic_telephone", "clinic_id", "telephone"),
        Index("ix_patients_clinic_niveau", "clinic_id", "niveau_fidelite"),
    )

    # Relations
    commercial: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur",
        foreign_keys=[commercial_id],
        back_populates="patients_commercial",
    )
    rdvs: Mapped[List["RendezVous"]] = relationship(
        "RendezVous", back_populates="patient"
    )
    dossiers: Mapped[List["DossierMedical"]] = relationship(
        "DossierMedical", back_populates="patient"
    )
    series_photos: Mapped[List["SeriePhotos"]] = relationship(
        "SeriePhotos", back_populates="patient"
    )
    photos: Mapped[List["PhotoClinic"]] = relationship(
        "PhotoClinic", back_populates="patient"
    )
    consentements: Mapped[List["Consentement"]] = relationship(
        "Consentement", back_populates="patient"
    )
    utilisations_lot: Mapped[List["UtilisationLot"]] = relationship(
        "UtilisationLot", back_populates="patient"
    )
    factures: Mapped[List["Facture"]] = relationship(
        "Facture", back_populates="patient"
    )
    commissions: Mapped[List["Commission"]] = relationship(
        "Commission", back_populates="patient"
    )
    fidelite_transactions: Mapped[List["FideliteTransaction"]] = relationship(
        "FideliteTransaction", back_populates="patient"
    )
    devis: Mapped[List["DevisTraitement"]] = relationship(
        "DevisTraitement", back_populates="patient"
    )
    radios: Mapped[List["ImagerieRadio"]] = relationship(
        "ImagerieRadio", back_populates="patient"
    )
    parrainages_parrain: Mapped[List["Parrainage"]] = relationship(
        "Parrainage",
        foreign_keys="Parrainage.parrain_patient_id",
        back_populates="parrain",
    )
    parrainages_filleul: Mapped[List["Parrainage"]] = relationship(
        "Parrainage",
        foreign_keys="Parrainage.filleul_patient_id",
        back_populates="filleul",
    )
    etats_dentaires: Mapped[List["EtatDentaire"]] = relationship(
        "EtatDentaire", back_populates="patient"
    )
    historiques_dentaires: Mapped[List["HistoriqueDentaire"]] = relationship(
        "HistoriqueDentaire", back_populates="patient"
    )
    commandes_protheses: Mapped[List["CommandeProthese"]] = relationship(
        "CommandeProthese", back_populates="patient"
    )
    suivis_post_op: Mapped[List["SuiviPostOperatoire"]] = relationship(
        "SuiviPostOperatoire", back_populates="patient"
    )
    suivis_ortho: Mapped[List["SuiviOrthodontique"]] = relationship(
        "SuiviOrthodontique", back_populates="patient"
    )


class ActeMedical(Base):
    __tablename__ = "actes_medicaux"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(200), nullable=False)
    categorie: Mapped[str] = mapped_column(String(50), nullable=False)
    duree_minutes: Mapped[int] = mapped_column(Integer, default=30)
    prix_base: Mapped[Decimal] = mapped_column(Numeric(10, 3), default=Decimal("0.000"))
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    protocole: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_chirurgical: Mapped[bool] = mapped_column(Boolean, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    rdvs: Mapped[List["RendezVous"]] = relationship("RendezVous", back_populates="acte")
    dossiers: Mapped[List["DossierMedical"]] = relationship(
        "DossierMedical", back_populates="acte"
    )
    consentements: Mapped[List["Consentement"]] = relationship(
        "Consentement", back_populates="acte"
    )
    series_photos: Mapped[List["SeriePhotos"]] = relationship(
        "SeriePhotos", back_populates="acte"
    )
    suivis_post_op: Mapped[List["SuiviPostOperatoire"]] = relationship(
        "SuiviPostOperatoire", back_populates="acte"
    )


class SuiviPostOperatoire(Base):
    __tablename__ = "suivis_post_operatoires"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    acte_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="CASCADE"), nullable=False
    )
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False
    )
    date_controle_prevue: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    date_controle_reelle: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    statut: Mapped[StatutSuiviPostOp] = mapped_column(
        String(20), default=StatutSuiviPostOp.PLANIFIE.value
    )
    observations: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    complication: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relations
    acte: Mapped["ActeMedical"] = relationship(
        "ActeMedical", back_populates="suivis_post_op"
    )
    patient: Mapped["Patient"] = relationship(
        "Patient", back_populates="suivis_post_op"
    )
    praticien: Mapped["Utilisateur"] = relationship("Utilisateur")


class SuiviOrthodontique(Base):
    __tablename__ = "suivis_orthodontiques"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False
    )
    photo_reelle_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("photos_clinic.id", ondelete="CASCADE"), nullable=False
    )
    date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    phase: Mapped[PhaseOrtho] = mapped_column(String(20), nullable=False)
    type_appareil: Mapped[AppareilOrtho] = mapped_column(String(20), nullable=False)
    observations: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="suivis_ortho")
    photo_reelle: Mapped["PhotoClinic"] = relationship("PhotoClinic")


class Salle(Base):
    __tablename__ = "salles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(100), nullable=False)
    capacite_fauteuils: Mapped[int] = mapped_column(Integer, default=1)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    rdvs: Mapped[List["RendezVous"]] = relationship(
        "RendezVous", back_populates="salle_rel"
    )


class RendezVous(Base):
    __tablename__ = "rendez_vous"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="RESTRICT"), nullable=False
    )
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    acte_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    date_heure_debut: Mapped[datetime] = mapped_column(
        DateTime, index=True, nullable=False
    )
    date_heure_fin: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    salle: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    salle_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("salles.id", ondelete="SET NULL"), nullable=True
    )
    fauteuil_numero: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    statut: Mapped[StatutRDV] = mapped_column(
        String(20), default=StatutRDV.PLANIFIE.value
    )
    notes_pre_acte: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    notes_post_acte: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    rappel_j1_envoye: Mapped[bool] = mapped_column(Boolean, default=False)
    rappel_h2_envoye: Mapped[bool] = mapped_column(Boolean, default=False)
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        Index("ix_rdv_praticien_date", "praticien_id", "date_heure_debut"),
        Index("ix_rdv_patient_date", "patient_id", "date_heure_debut"),
        Index("ix_rdv_clinic_date", "clinic_id", "date_heure_debut"),
    )

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="rdvs")
    praticien: Mapped["Utilisateur"] = relationship(
        "Utilisateur", foreign_keys=[praticien_id], back_populates="rdvs_praticien"
    )
    acte: Mapped[Optional["ActeMedical"]] = relationship(
        "ActeMedical", back_populates="rdvs"
    )
    createur: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur", foreign_keys=[created_by], back_populates="rdvs_created"
    )
    dossier: Mapped[Optional["DossierMedical"]] = relationship(
        "DossierMedical", back_populates="rdv"
    )
    facture: Mapped[Optional["Facture"]] = relationship("Facture", back_populates="rdv")
    teleconsultation: Mapped[Optional["Teleconsultation"]] = relationship(
        "Teleconsultation", back_populates="rdv"
    )
    salle_rel: Mapped[Optional["Salle"]] = relationship("Salle", back_populates="rdvs")


class DossierMedical(Base):
    __tablename__ = "dossiers_medicaux"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    rdv_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("rendez_vous.id", ondelete="SET NULL"), nullable=True
    )
    acte_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    date_acte: Mapped[datetime] = mapped_column(DateTime, index=True, nullable=False)
    zones_traitees: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    produits_utilises: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    observations_enc: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    effets_secondaires: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    satisfaction_patient: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    suivi_requis: Mapped[bool] = mapped_column(Boolean, default=False)
    date_suivi_recommandee: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (Index("ix_dossier_patient_date", "patient_id", "date_acte"),)

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="dossiers")
    praticien: Mapped["Utilisateur"] = relationship(
        "Utilisateur", foreign_keys=[praticien_id], back_populates="dossiers_praticien"
    )
    rdv: Mapped[Optional["RendezVous"]] = relationship(
        "RendezVous", back_populates="dossier"
    )
    acte: Mapped[Optional["ActeMedical"]] = relationship(
        "ActeMedical", back_populates="dossiers"
    )
    photos: Mapped[List["PhotoClinic"]] = relationship(
        "PhotoClinic", back_populates="dossier"
    )
    utilisations_lot: Mapped[List["UtilisationLot"]] = relationship(
        "UtilisationLot", back_populates="dossier"
    )


class SeriePhotos(Base):
    __tablename__ = "series_photos"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    nom_serie: Mapped[str] = mapped_column(String(200), nullable=False)
    zone_anatomique: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    acte_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    date_debut: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    date_fin: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    is_public: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="series_photos")
    acte: Mapped[Optional["ActeMedical"]] = relationship(
        "ActeMedical", back_populates="series_photos"
    )
    photos: Mapped[List["PhotoClinic"]] = relationship(
        "PhotoClinic", back_populates="serie"
    )


class PhotoClinic(Base):
    __tablename__ = "photos_clinic"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    dossier_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("dossiers_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    serie_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("series_photos.id", ondelete="SET NULL"), nullable=True
    )
    type: Mapped[TypePhoto] = mapped_column(String(20), nullable=False)
    date_prise: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    zone_anatomique: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    angle_prise: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    url_stockage: Mapped[str] = mapped_column(String(500), nullable=False)
    url_thumbnail: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    hash_fichier: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    taille_octets: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    visible_patient: Mapped[bool] = mapped_column(Boolean, default=False)
    visible_marketing: Mapped[bool] = mapped_column(Boolean, default=False)
    filigrane_applique: Mapped[bool] = mapped_column(Boolean, default=False)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    prise_par_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    deleted_by: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    raison_suppression: Mapped[Optional[str]] = mapped_column(
        String(200), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_photo_patient_type", "patient_id", "type"),
        Index("ix_photo_patient_zone", "patient_id", "zone_anatomique"),
    )

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="photos")
    dossier: Mapped[Optional["DossierMedical"]] = relationship(
        "DossierMedical", back_populates="photos"
    )
    serie: Mapped[Optional["SeriePhotos"]] = relationship(
        "SeriePhotos", back_populates="photos"
    )
    prise_par: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur", foreign_keys=[prise_par_id], back_populates="photos_prise_par"
    )


class Consentement(Base):
    __tablename__ = "consentements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    acte_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    type_consentement: Mapped[str] = mapped_column(String(50), nullable=False)
    contenu_signe: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    signe_le: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    methode_signature: Mapped[str] = mapped_column(String(50), nullable=False)
    signature_base64: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    est_valide: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="consentements")
    acte: Mapped[Optional["ActeMedical"]] = relationship(
        "ActeMedical", back_populates="consentements"
    )


class ProduitInjectable(Base):
    __tablename__ = "produits_injectables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(200), index=True, nullable=False)
    fabricant: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    categorie: Mapped[str] = mapped_column(String(50), nullable=False)
    reference_fabricant: Mapped[Optional[str]] = mapped_column(
        String(100), nullable=True
    )
    unite: Mapped[str] = mapped_column(String(20), nullable=False)
    prix_achat: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    prix_vente: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    stock_actuel: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), default=Decimal("0.00")
    )
    stock_minimum: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), default=Decimal("0.00")
    )
    stock_alerte: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), default=Decimal("0.00")
    )
    temperature_conservation: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True
    )
    conditions_stockage: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    duree_effet_jours: Mapped[int] = mapped_column(Integer, nullable=False, default=90)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    lots: Mapped[List["LotInjectable"]] = relationship(
        "LotInjectable", back_populates="produit"
    )


class LotInjectable(Base):
    __tablename__ = "lots_injectables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    produit_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("produits_injectables.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    numero_lot: Mapped[str] = mapped_column(
        String(100), index=True, nullable=False
    )
    date_fabrication: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    date_expiration: Mapped[date] = mapped_column(Date, index=True, nullable=False)
    quantite_initiale: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    quantite_restante: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    fournisseur: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    date_reception: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    prix_achat_lot: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    certificat_conformite_url: Mapped[Optional[str]] = mapped_column(
        String(500), nullable=True
    )
    qr_code_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    barcode_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    label_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    statut: Mapped[StatutLot] = mapped_column(
        String(20), default=StatutLot.DISPONIBLE.value
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("clinic_id", "numero_lot", name="uq_lots_clinic_numero"),
        Index("ix_lot_expiration_statut", "date_expiration", "statut"),
    )

    # Relations
    produit: Mapped["ProduitInjectable"] = relationship(
        "ProduitInjectable", back_populates="lots"
    )
    utilisations: Mapped[List["UtilisationLot"]] = relationship(
        "UtilisationLot", back_populates="lot"
    )
    depenses: Mapped[List["Depense"]] = relationship(
        "Depense", back_populates="lot_injectable"
    )


class UtilisationLot(Base):
    __tablename__ = "utilisations_lot"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    lot_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("lots_injectables.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    dossier_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("dossiers_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    date_utilisation: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    quantite_utilisee: Mapped[Decimal] = mapped_column(Numeric(10, 3), nullable=False)
    unite: Mapped[str] = mapped_column(String(20), nullable=False)
    type_injection: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    prochaine_injection_date: Mapped[Optional[date]] = mapped_column(
        Date, nullable=True
    )
    prochaine_injection_envoyee: Mapped[bool] = mapped_column(Boolean, default=False)

    # Relations
    lot: Mapped["LotInjectable"] = relationship(
        "LotInjectable", back_populates="utilisations"
    )
    dossier: Mapped[Optional["DossierMedical"]] = relationship(
        "DossierMedical", back_populates="utilisations_lot"
    )
    patient: Mapped["Patient"] = relationship(
        "Patient", back_populates="utilisations_lot"
    )
    praticien: Mapped["Utilisateur"] = relationship(
        "Utilisateur", foreign_keys=[praticien_id], back_populates="utilisations_lot"
    )


class Facture(Base):
    __tablename__ = "factures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    rdv_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("rendez_vous.id", ondelete="SET NULL"), nullable=True
    )
    numero_facture: Mapped[str] = mapped_column(
        String(50), index=True, nullable=False
    )
    date_emission: Mapped[date] = mapped_column(
        Date, nullable=False, default=date.today
    )
    date_echeance: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    actes: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    produits: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    sous_total: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    taux_tva: Mapped[Decimal] = mapped_column(Numeric(5, 3), default=Decimal("0.190"))
    montant_tva: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    total_ttc: Mapped[Decimal] = mapped_column(Numeric(10, 3), default=Decimal("0.000"))
    remise_globale_pct: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), default=Decimal("0.00")
    )
    statut: Mapped[StatutFacture] = mapped_column(
        String(20), default=StatutFacture.BROUILLON.value
    )
    mode_paiement: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("clinic_id", "numero_facture", name="uq_factures_clinic_numero"),
        Index("ix_facture_clinic_date", "clinic_id", "date_emission"),
        Index("ix_facture_clinic_statut", "clinic_id", "statut"),
    )

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="factures")
    rdv: Mapped[Optional["RendezVous"]] = relationship(
        "RendezVous", back_populates="facture"
    )
    createur: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur", foreign_keys=[created_by], back_populates="factures_created"
    )
    commissions: Mapped[List["Commission"]] = relationship(
        "Commission", back_populates="facture"
    )
    prises_en_charge: Mapped[List["PriseEnChargeMutuelle"]] = relationship(
        "PriseEnChargeMutuelle", back_populates="facture"
    )


class DevisTraitement(Base):
    __tablename__ = "devis_traitements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    acte_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="SET NULL"), nullable=True
    )
    dent: Mapped[Optional[str]] = mapped_column(String(2), nullable=True)

    lignes: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    prix: Mapped[Decimal] = mapped_column(Numeric(10, 3), default=Decimal("0.000"))

    date_validite: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    statut: Mapped[StatutDevis] = mapped_column(
        String(20), default=StatutDevis.BROUILLON.value
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="devis")
    acte: Mapped[Optional["ActeMedical"]] = relationship("ActeMedical")
    prises_en_charge: Mapped[List["PriseEnChargeMutuelle"]] = relationship(
        "PriseEnChargeMutuelle", back_populates="devis"
    )


class PriseEnChargeMutuelle(Base):
    __tablename__ = "prises_en_charge_mutuelle"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    devis_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("devis_traitements.id", ondelete="SET NULL"), nullable=True
    )
    facture_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("factures.id", ondelete="SET NULL"), nullable=True
    )
    organisme: Mapped[str] = mapped_column(String(200), nullable=False)
    numero_dossier: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    montant_pris_en_charge: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    statut: Mapped[StatutPriseEnCharge] = mapped_column(
        String(20), default=StatutPriseEnCharge.EN_ATTENTE.value
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    devis: Mapped[Optional["DevisTraitement"]] = relationship(
        "DevisTraitement", back_populates="prises_en_charge"
    )
    facture: Mapped[Optional["Facture"]] = relationship(
        "Facture", back_populates="prises_en_charge"
    )


class ImagerieRadio(Base):
    __tablename__ = "imagerie_radios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    type_radio: Mapped[str] = mapped_column(
        String(50), nullable=False
    )  # panoramique, CBCT, retro-alveolaire
    dent_associee: Mapped[Optional[str]] = mapped_column(String(2), nullable=True)

    # Fichier chiffré
    url_stockage: Mapped[str] = mapped_column(String(500), nullable=False)
    hash_fichier: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    taille_octets: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    # Métadonnées DICOM extraites (JSON)
    dicom_metadata: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    date_prise: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    patient: Mapped["Patient"] = relationship("Patient", back_populates="radios")
    praticien: Mapped["Utilisateur"] = relationship("Utilisateur")


class AnalyseCaries(Base):
    """Résultat IA d'aide à la lecture, sans effet sur le dossier clinique."""

    __tablename__ = "analyses_caries"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    radio_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("imagerie_radios.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    resultat: Mapped[dict] = mapped_column(JSON, nullable=False)
    valide_par_praticien_id: Mapped[int | None] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=True
    )
    valide_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )


class PlanTraitementIA(Base):
    """Proposition LLM nécessitant une validation explicite avant envoi."""

    __tablename__ = "plans_traitement_ia"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )
    cree_par_praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    proposition: Mapped[dict] = mapped_column(JSON, nullable=False)
    valide_par_praticien_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    valide_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    envoye_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )


class EstimationCoutPlan(Base):
    """Estimation déterministe, calculée exclusivement depuis les actes tarifés."""

    __tablename__ = "estimations_cout_plan"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    plan_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("plans_traitement_ia.id", ondelete="CASCADE"),
        nullable=False,
        unique=True,
    )
    total: Mapped[Decimal] = mapped_column(Numeric(12, 3), nullable=False)
    details: Mapped[dict] = mapped_column(JSON, nullable=False)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )


class Commission(Base):
    __tablename__ = "commissions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    commercial_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("utilisateurs.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="RESTRICT"), nullable=False
    )
    facture_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("factures.id", ondelete="RESTRICT"), nullable=False
    )
    montant_ca: Mapped[Decimal] = mapped_column(Numeric(10, 3), nullable=False)
    taux_commission: Mapped[Decimal] = mapped_column(Numeric(5, 2), nullable=False)
    montant_commission: Mapped[Decimal] = mapped_column(Numeric(10, 3), nullable=False)
    statut: Mapped[StatutCommission] = mapped_column(
        String(20), default=StatutCommission.EN_ATTENTE.value
    )
    periode_mois: Mapped[date] = mapped_column(Date, index=True, nullable=False)
    validee_par_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    # Deuxième validateur, requis uniquement au-delà de COMMISSION_VALIDATION_SEUIL
    # (500 DT) — doit être une personne différente du premier validateur.
    validee_par_id_2: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    validated_at_2: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    date_paiement: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    commercial: Mapped["Utilisateur"] = relationship(
        "Utilisateur", foreign_keys=[commercial_id], back_populates="commissions"
    )
    patient: Mapped["Patient"] = relationship("Patient", back_populates="commissions")
    facture: Mapped["Facture"] = relationship("Facture", back_populates="commissions")
    validateur: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur",
        foreign_keys=[validee_par_id],
        back_populates="commissions_validees",
    )


class FideliteTransaction(Base):
    __tablename__ = "fidelite_transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    type: Mapped[str] = mapped_column(
        String(20), nullable=False
    )  # gain | depense | expiration
    points: Mapped[int] = mapped_column(Integer, nullable=False)
    solde_apres: Mapped[int] = mapped_column(Integer, nullable=False)
    motif: Mapped[str] = mapped_column(String(100), nullable=False)
    reference_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    reference_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    patient: Mapped["Patient"] = relationship(
        "Patient", back_populates="fidelite_transactions"
    )


class CategorieDepense(Base):
    __tablename__ = "categories_depenses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(100), nullable=False)
    code: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    icone: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    couleur: Mapped[Optional[str]] = mapped_column(String(7), nullable=True)
    type: Mapped[str] = mapped_column(String(30), nullable=False)
    budget_mensuel: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(10, 3), nullable=True
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    # Relations
    depenses: Mapped[List["Depense"]] = relationship(
        "Depense", back_populates="categorie"
    )


class Depense(Base):
    __tablename__ = "depenses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    categorie_id: Mapped[Optional[int]] = mapped_column(
        Integer,
        ForeignKey("categories_depenses.id", ondelete="SET NULL"),
        nullable=True,
    )
    fournisseur: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    titre: Mapped[str] = mapped_column(String(300), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    montant_ht: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    taux_tva: Mapped[Decimal] = mapped_column(Numeric(5, 3), default=Decimal("0.190"))
    montant_tva: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    montant_ttc: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    date_depense: Mapped[date] = mapped_column(Date, index=True, nullable=False)
    periode_comptable: Mapped[date] = mapped_column(Date, index=True, nullable=False)
    mode_paiement: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    reference_paiement: Mapped[Optional[str]] = mapped_column(
        String(100), nullable=True
    )
    facture_scan_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    facture_scan_statut: Mapped[StatutDepense] = mapped_column(
        String(20), default=StatutDepense.EN_ATTENTE.value
    )
    extraction_ia: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    lot_injectable_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("lots_injectables.id", ondelete="SET NULL"), nullable=True
    )
    valide_par_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    categorie: Mapped[Optional["CategorieDepense"]] = relationship(
        "CategorieDepense", back_populates="depenses"
    )
    lot_injectable: Mapped[Optional["LotInjectable"]] = relationship(
        "LotInjectable", back_populates="depenses"
    )
    validateur: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur", foreign_keys=[valide_par_id], back_populates="depenses_validees"
    )
    createur_depense: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur", foreign_keys=[created_by], back_populates="depenses_created"
    )


class Candidature(Base):
    __tablename__ = "candidatures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    poste: Mapped[str] = mapped_column(String(200), nullable=False)
    nom_candidat: Mapped[str] = mapped_column(String(200), nullable=False)
    email: Mapped[str] = mapped_column(String(255), nullable=False)
    telephone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    cv_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    lettre_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    statut: Mapped[StatutCandidature] = mapped_column(
        String(20), default=StatutCandidature.RECU.value
    )
    notes_rh: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    date_entretien: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    evaluateur_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    evaluateur: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur",
        foreign_keys=[evaluateur_id],
        back_populates="candidatures_evaluees",
    )


class Consommable(Base):
    __tablename__ = "consommables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(200), index=True, nullable=False)
    categorie: Mapped[str] = mapped_column(String(100), nullable=False)
    unite: Mapped[str] = mapped_column(
        String(50), nullable=False
    )  # piece, boite, paquet
    stock_actuel: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), default=Decimal("0.00")
    )
    seuil_alerte: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), default=Decimal("0.00")
    )
    stock_minimum: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), default=Decimal("0.00")
    )
    prix_unitaire: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000")
    )
    fournisseur_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    # Relations
    mouvements: Mapped[List["MouvementConsommable"]] = relationship(
        "MouvementConsommable", back_populates="consommable"
    )


class MouvementConsommable(Base):
    __tablename__ = "mouvements_consommables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    consommable_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("consommables.id", ondelete="CASCADE"), nullable=False
    )
    type: Mapped[str] = mapped_column(String(20), nullable=False)  # entree, sortie
    quantite: Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    date_mouvement: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    utilisateur_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    motif: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    reference: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)

    # Relations
    consommable: Mapped["Consommable"] = relationship(
        "Consommable", back_populates="mouvements"
    )
    utilisateur: Mapped["Utilisateur"] = relationship(
        "Utilisateur", back_populates="mouvements_consommables"
    )


class Teleconsultation(Base):
    __tablename__ = "teleconsultations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    rdv_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("rendez_vous.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    lien_visio: Mapped[str] = mapped_column(String(500), nullable=False)
    statut: Mapped[str] = mapped_column(
        String(20), default="planifiee"
    )  # planifiee, en_cours, terminee
    duree_reelle: Mapped[Optional[int]] = mapped_column(
        Integer, nullable=True
    )  # en minutes
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    # P02-b
    provider: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    consent_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    recording_url: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    rdv: Mapped["RendezVous"] = relationship(
        "RendezVous", back_populates="teleconsultation"
    )


class Parrainage(Base):
    __tablename__ = "parrainages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    parrain_patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False
    )
    filleul_patient_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="SET NULL"), nullable=True
    )
    code_parrain: Mapped[str] = mapped_column(String(20), index=True, nullable=False)
    statut: Mapped[str] = mapped_column(String(20), default="actif")  # actif, utilise
    date_parrainage: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    recompense_attribuee: Mapped[bool] = mapped_column(Boolean, default=False)
    recompense_utilisee: Mapped[bool] = mapped_column(Boolean, default=False)

    # Relations
    parrain: Mapped["Patient"] = relationship(
        "Patient",
        foreign_keys=[parrain_patient_id],
        back_populates="parrainages_parrain",
    )
    filleul: Mapped[Optional["Patient"]] = relationship(
        "Patient",
        foreign_keys=[filleul_patient_id],
        back_populates="parrainages_filleul",
    )


class AuditLogMedical(Base):
    __tablename__ = "audit_logs_medicaux"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    utilisateur_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)
    patient_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(50), nullable=False)
    resource_id: Mapped[int] = mapped_column(Integer, nullable=False)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    __table_args__ = (
        Index("ix_audit_patient_date", "patient_id", "created_at"),
        Index("ix_audit_user_date", "utilisateur_id", "created_at"),
    )


class JournalAudit(Base):
    """Journal transversal des actions applicatives et administratives.

    Les entrées sont append-only : aucune route applicative ne doit les mettre
    à jour ou les supprimer. patient_id est optionnel pour les actions de
    gestion d’équipe, mais obligatoire dans les événements liés à un dossier.
    """

    __tablename__ = "journal_audit"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    utilisateur_id: Mapped[int] = mapped_column(Integer, index=True, nullable=False)
    patient_id: Mapped[Optional[int]] = mapped_column(Integer, index=True, nullable=True)
    action: Mapped[str] = mapped_column(String(100), nullable=False)
    resource_type: Mapped[str] = mapped_column(String(60), nullable=False)
    resource_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    details: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(45), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_journal_audit_clinic_date", "clinic_id", "created_at"),
        Index("ix_journal_audit_patient_date", "patient_id", "created_at"),
        Index("ix_journal_audit_user_date", "utilisateur_id", "created_at"),
    )



# ═══════════════════════════════════════════════════════════
# ODONTOGRAMME — BLOC 1
# ═══════════════════════════════════════════════════════════


class StatutDent(str, enum.Enum):
    """Statuts possibles d'une dent."""

    SAIN = "sain"
    CARIE = "carie"
    OBTURE = "obture"
    COURONNE = "couronne"
    BRIDGE = "bridge"
    IMPLANT = "implant"
    ABSENTE = "absente"
    DEVITALISEE = "devitalisee"
    A_EXTRAIRE = "a_extraire"
    EN_TRAITEMENT = "en_traitement"


class EtatDentaire(Base):
    """État actuel d'une dent pour un patient."""

    __tablename__ = "etats_dentaires"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    numero_dent: Mapped[str] = mapped_column(
        String(2), nullable=False
    )  # FDI notation (11-48)
    statut: Mapped[StatutDent] = mapped_column(
        String(20), default=StatutDent.SAIN.value, nullable=False
    )
    face: Mapped[Optional[str]] = mapped_column(
        String(50), nullable=True
    )  # Réservé pour V2
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    date_modification: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        UniqueConstraint("clinic_id", "patient_id", "numero_dent", name="uq_etats_dentaires_clinic_patient_dent"),
        Index("ix_etat_dentaire_patient_dent", "patient_id", "numero_dent"),
        Index("ix_etat_dentaire_patient_date", "patient_id", "date_modification"),
    )

    # Relations
    patient: Mapped["Patient"] = relationship(
        "Patient", back_populates="etats_dentaires"
    )
    praticien: Mapped["Utilisateur"] = relationship(
        "Utilisateur",
        foreign_keys=[praticien_id],
        back_populates="etats_dentaires_modifies",
    )
    historique: Mapped[List["HistoriqueDentaire"]] = relationship(
        "HistoriqueDentaire", back_populates="etat_dentaire"
    )


class HistoriqueDentaire(Base):
    """Historique append-only des modifications d'état dentaire."""

    __tablename__ = "historiques_dentaires"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    etat_dentaire_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("etats_dentaires.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    numero_dent: Mapped[str] = mapped_column(String(2), nullable=False)  # FDI notation
    statut_ancien: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    statut_nouveau: Mapped[str] = mapped_column(String(20), nullable=False)
    face_ancien: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    face_nouveau: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, index=True
    )

    __table_args__ = (
        Index("ix_historique_dentaire_patient_date", "patient_id", "created_at"),
        Index("ix_historique_dentaire_etat_date", "etat_dentaire_id", "created_at"),
    )

    # Relations
    etat_dentaire: Mapped["EtatDentaire"] = relationship(
        "EtatDentaire", back_populates="historique"
    )
    patient: Mapped["Patient"] = relationship(
        "Patient", back_populates="historiques_dentaires"
    )
    praticien: Mapped["Utilisateur"] = relationship(
        "Utilisateur",
        foreign_keys=[praticien_id],
        back_populates="historiques_dentaires_crees",
    )


class AIUsage(Base):
    __tablename__ = "ai_usage"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    requests_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    reserved_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    request_limit: Mapped[int] = mapped_column(Integer, nullable=False)
    token_limit: Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        Index("uq_ai_usage_clinic_period", "clinic_id", "period_start", unique=True),
        Index("ix_ai_usage_clinic", "clinic_id"),
    )


class ClinicSetting(Base):
    __tablename__ = "clinic_settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    key: Mapped[str] = mapped_column(
        String(100), index=True, nullable=False
    )
    value: Mapped[dict] = mapped_column(JSON, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        UniqueConstraint("clinic_id", "key", name="uq_clinic_settings_clinic_key"),
        Index("ix_clinic_settings_clinic_key", "clinic_id", "key"),
    )


class SocialMessage(Base):
    """Message entrant/sortant sur un canal social (inbox unifié).
    plateforme : whatsapp | instagram | facebook | tiktok"""

    __tablename__ = "social_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    plateforme: Mapped[str] = mapped_column(String(20), nullable=False)
    contact_id: Mapped[str] = mapped_column(String(255), index=True, nullable=False)
    contact_nom: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    direction: Mapped[str] = mapped_column(
        String(10), nullable=False
    )  # entrant | sortant
    contenu: Mapped[str] = mapped_column(Text, nullable=False)
    statut: Mapped[str] = mapped_column(
        String(20), default="nouveau"
    )  # nouveau|traite|repondu
    reponse_auto_envoyee: Mapped[bool] = mapped_column(Boolean, default=False)
    patient_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_social_messages_clinic_plateforme", "clinic_id", "plateforme"),
        Index("ix_social_messages_clinic_statut", "clinic_id", "statut"),
    )


# ═══════════════════════════════════════════════════════════
# BLOC 6 — PROTHÈSES ET LABORATOIRE
# ═══════════════════════════════════════════════════════════


class TypeProthese(str, enum.Enum):
    COURONNE = "couronne"
    BRIDGE = "bridge"
    PROTHESE_AMOVIBLE = "prothèse amovible"
    IMPLANT = "implant"


class StatutProthese(str, enum.Enum):
    COMMANDE = "commande"
    EN_FABRICATION = "en_fabrication"
    RECU = "recu"
    POSE = "pose"
    RETOUR_LABO = "retour_labo"


class CommandeProthese(Base):
    __tablename__ = "commandes_protheses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="RESTRICT"),
        index=True,
        nullable=False,
    )
    dent: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    dents: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    type: Mapped[str] = mapped_column(String(50), nullable=False)
    laboratoire: Mapped[str] = mapped_column(String(200), nullable=False)
    date_commande: Mapped[date] = mapped_column(
        Date, nullable=False, default=date.today
    )
    date_reception_prevue: Mapped[date] = mapped_column(Date, nullable=False)
    date_reception_reelle: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    statut: Mapped[str] = mapped_column(
        String(30), default=StatutProthese.COMMANDE.value, nullable=False
    )
    cout: Mapped[Decimal] = mapped_column(
        Numeric(10, 3), default=Decimal("0.000"), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        Index("ix_commandes_protheses_patient", "clinic_id", "patient_id"),
        Index("ix_commandes_protheses_statut", "clinic_id", "statut"),
    )

    # Relations
    patient: Mapped["Patient"] = relationship(
        "Patient", back_populates="commandes_protheses"
    )


class SocialPost(Base):
    """Post planifié/publié sur un canal social, avec métriques d'engagement."""

    __tablename__ = "social_posts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    plateforme: Mapped[str] = mapped_column(String(20), nullable=False)
    contenu: Mapped[str] = mapped_column(Text, nullable=False)
    media_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    date_publication_prevue: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    date_publication_reelle: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    statut: Mapped[str] = mapped_column(
        String(20), default="brouillon"
    )  # brouillon|planifie|publie|echec
    erreur: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    plateforme_post_id: Mapped[Optional[str]] = mapped_column(
        String(255), nullable=True
    )
    likes: Mapped[int] = mapped_column(Integer, default=0)
    commentaires: Mapped[int] = mapped_column(Integer, default=0)
    partages: Mapped[int] = mapped_column(Integer, default=0)
    impressions: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_social_posts_clinic_plateforme", "clinic_id", "plateforme"),
        Index("ix_social_posts_clinic_statut", "clinic_id", "statut"),
    )


class CampagneMarketing(Base):
    __tablename__ = "campagnes_marketing"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(200), nullable=False)
    type: Mapped[str] = mapped_column(String(20), nullable=False)
    segment_cible: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    message_template: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    date_envoi_planifiee: Mapped[Optional[datetime]] = mapped_column(
        DateTime, nullable=True
    )
    statut: Mapped[str] = mapped_column(String(20), default="brouillon")
    nb_envoyes: Mapped[int] = mapped_column(Integer, default=0)
    nb_ouverts: Mapped[int] = mapped_column(Integer, default=0)
    created_by: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    createur_campagne: Mapped[Optional["Utilisateur"]] = relationship(
        "Utilisateur", foreign_keys=[created_by], back_populates="campagnes_created"
    )


class EquipeMessage(Base):
    """Messagerie interne entre membres de l'équipe clinique."""

    __tablename__ = "equipe_messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    expediteur_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False
    )
    destinataire_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False
    )
    sujet: Mapped[str] = mapped_column(String(200), nullable=False)
    contenu: Mapped[str] = mapped_column(Text, nullable=False)
    lu: Mapped[bool] = mapped_column(Boolean, default=False)
    lu_a: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    cree_a: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_equipe_messages_clinic_expediteur", "clinic_id", "expediteur_id"),
        Index("ix_equipe_messages_clinic_destinataire", "clinic_id", "destinataire_id"),
        Index("ix_equipe_messages_destinataire_lu", "destinataire_id", "lu"),
    )

    # Relations
    expediteur: Mapped["Utilisateur"] = relationship(
        "Utilisateur", foreign_keys=[expediteur_id], backref="messages_envoyes"
    )
    destinataire: Mapped["Utilisateur"] = relationship(
        "Utilisateur", foreign_keys=[destinataire_id], backref="messages_recus"
    )


# ═══════════════════════════════════════════════════════════
# Helpers moteurs
# ═══════════════════════════════════════════════════════════


def get_async_engine(database_url: str):
    """Retourne le moteur async SQLAlchemy."""
    return create_async_engine(database_url, echo=False, future=True)


def get_async_sessionmaker(engine):
    """Retourne la factory de sessions async."""
    return async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)


class PlateformeAvis(str, enum.Enum):
    """Plateformes d'avis supportées (correctif Bug #8 audit).

    Enum côté Python pour valider les valeurs en API + CHECK constraint
    côté SQL pour rejeter toute insertion hors-énumération. Le rapport
    d'audit soulignait que ``String(20)`` acceptait n'importe quelle
    chaîne (ex: ``FACEBOOK`` au lieu de ``facebook``), cassant les
    filtres et l'auto-reply IA. On conserve la valeur technique en
    minuscule pour cohérence avec le reste de la base.
    """

    GOOGLE = "google"
    INSTAGRAM = "instagram"
    FACEBOOK = "facebook"


class AvisClient(Base):
    """Avis clients récoltés (Google, Instagram, Facebook)."""

    __tablename__ = "avis_clients"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    # Bug #8 (audit) : la plateforme reste en String(20) pour rester
    # compatible avec les INSERT legacy, mais est désormais validée par
    # un CheckConstraint côté SQL + par PlateformeAvis côté Python. Les
    # futurs inserts passeront par la couche PydanticAvisClientIn qui
    # valide la valeur côté routeur (cf. api/v1/social.py).
    plateforme: Mapped[str] = mapped_column(String(20), nullable=False)
    note: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    texte: Mapped[str] = mapped_column(Text, nullable=False)
    auteur_nom: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    reponse_suggeree_ia: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    reponse_publiee: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    statut: Mapped[str] = mapped_column(
        String(20), default="nouveau"
    )  # nouveau|suggere|valide|publie
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        Index("ix_avis_clinic_plateforme", "clinic_id", "plateforme"),
        Index("ix_avis_clinic_statut", "clinic_id", "statut"),
        CheckConstraint(
            "plateforme IN ('google', 'instagram', 'facebook')",
            name="ck_avis_plateforme_enum",
        ),
    )


class SimulationIA(Base):
    """Simulations de résultats générées par IA."""

    __tablename__ = "simulations_ia"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    photo_source_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("photos_clinic.id", ondelete="CASCADE"), nullable=False
    )
    patient_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("patients.id", ondelete="CASCADE"),
        index=True,
        nullable=False,
    )
    zone_anatomique: Mapped[str] = mapped_column(String(50), nullable=False)
    url_resultat: Mapped[str] = mapped_column(String(500), nullable=False)
    url_masque: Mapped[str | None] = mapped_column(String(500), nullable=True)
    instructions: Mapped[str | None] = mapped_column(Text, nullable=True)
    consentement_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("consentements.id", ondelete="RESTRICT"), nullable=False
    )
    genere_par_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relations
    photo_source: Mapped["PhotoClinic"] = relationship("PhotoClinic")
    patient: Mapped["Patient"] = relationship("Patient")
    consentement: Mapped["Consentement"] = relationship("Consentement")
    createur: Mapped["Utilisateur"] = relationship("Utilisateur")


class StatutCompteRenduDentaire(str, enum.Enum):
    PROPOSITION = "proposition"
    VALIDE = "valide"


class CompteRenduDentaire(Base):
    """Compte rendu dentaire généré comme proposition puis validé par un praticien."""

    __tablename__ = "comptes_rendus_dentaires"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False, index=True
    )
    plan_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("plans_traitement_ia.id", ondelete="SET NULL"), nullable=True
    )
    contenu: Mapped[str] = mapped_column(Text, nullable=False)
    statut: Mapped[str] = mapped_column(
        String(20), default=StatutCompteRenduDentaire.PROPOSITION.value, nullable=False
    )
    cree_par_praticien_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    valide_par_praticien_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    cree_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    modifie_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )
    valide_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class RappelDentaire(Base):
    """Événement de rappel dédupliqué, livré par le moteur omnicanal existant."""

    __tablename__ = "rappels_dentaires"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False, index=True
    )
    source_type: Mapped[str] = mapped_column(String(50), nullable=False)
    source_id: Mapped[int] = mapped_column(Integer, nullable=False)
    date_prevue: Mapped[datetime] = mapped_column(DateTime, nullable=False, index=True)
    canal: Mapped[str] = mapped_column(String(20), nullable=False)
    destinataire: Mapped[str] = mapped_column(String(255), nullable=False)
    contenu: Mapped[str] = mapped_column(Text, nullable=False)
    envoye_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index(
            "uq_rappel_dentaire_source",
            "clinic_id",
            "source_type",
            "source_id",
            unique=True,
        ),
    )


# Ré-export explicite pour les modules qui importent les modèles dentaires.
CompteRenduDentaire.__module__ = __name__
RappelDentaire.__module__ = __name__



# ═══════════════════════════════════════════════════════════
# MODULES AJOUTÉS : DÉLÉGUÉS & CÉPHALOMÉTRIE
# ═══════════════════════════════════════════════════════════

class Delegue(Base):
    __tablename__ = "delegues"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    nom: Mapped[str] = mapped_column(String(100), nullable=False)
    prenom: Mapped[str] = mapped_column(String(100), nullable=False)
    laboratoire_ou_societe: Mapped[str] = mapped_column(String(150), nullable=False)
    telephone: Mapped[str] = mapped_column(String(20), nullable=False)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    specialite_produits: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Cephalometrie(Base):
    __tablename__ = "cephalometries"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False)
    praticien_id: Mapped[int] = mapped_column(Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True)
    titre: Mapped[str] = mapped_column(String(200), nullable=False)
    image_url: Mapped[str] = mapped_column(String(500), nullable=False)
    mime_type: Mapped[str] = mapped_column(String(100), default="image/jpeg", nullable=False)
    analyse_data: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    conclusions: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    patient: Mapped["Patient"] = relationship("Patient", backref="cephalometries")
    praticien: Mapped[Optional["Utilisateur"]] = relationship("Utilisateur", foreign_keys=[praticien_id])


class Pointage(Base):
    __tablename__ = "pointages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    utilisateur_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False, index=True
    )
    debut: Mapped[datetime] = mapped_column(DateTime, nullable=False, default=datetime.utcnow)
    fin: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    duree_minutes: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        Index("ix_pointages_clinic_user", "clinic_id", "utilisateur_id"),
        Index("ix_pointages_clinic_debut", "clinic_id", "debut"),
    )

    utilisateur: Mapped["Utilisateur"] = relationship("Utilisateur", backref="pointages")


class CallbackLead(Base):
    """Lead public de rappel, séparé d'une demande de rendez-vous."""

    __tablename__ = "callback_leads"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    nom: Mapped[str] = mapped_column(String(100), nullable=False)
    telephone: Mapped[str] = mapped_column(String(30), nullable=False, index=True)
    email: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    source: Mapped[str] = mapped_column(String(30), nullable=False, default="landing")
    statut: Mapped[str] = mapped_column(String(20), nullable=False, default="pending", index=True)
    assigned_to_id: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    contacted_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)


class BookingRequest(Base):
    """Demande publique isolée avant validation et création du rendez-vous interne."""

    __tablename__ = "booking_requests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False, index=True)
    nom: Mapped[str] = mapped_column(String(100), nullable=False)
    prenom: Mapped[str] = mapped_column(String(100), nullable=False)
    telephone: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    praticien_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    acte_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("actes_medicaux.id", ondelete="RESTRICT"), nullable=False
    )
    date_heure: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    specialite: Mapped[Optional[str]] = mapped_column(String(120), nullable=True)
    statut: Mapped[str] = mapped_column(String(20), nullable=False, default="pending")
    patient_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="SET NULL"), nullable=True
    )
    rendez_vous_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("rendez_vous.id", ondelete="SET NULL"), nullable=True
    )
    source_ip_hash: Mapped[Optional[str]] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    validated_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    rejected_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)

    __table_args__ = (
        Index(
            "ix_booking_requests_dedupe",
            "clinic_id",
            "telephone",
            "date_heure",
            "acte_id",
        ),
    )


# ═══════════════════════════════════════════════════════════
# MODULE : PLANS DE TRAITEMENT OPÉRATIONNELS
# ═══════════════════════════════════════════════════════════


class StatutPlanTraitement(str, enum.Enum):
    BROUILLON = "brouillon"
    EN_COURS = "en_cours"
    TERMINE = "termine"
    ANNULE = "annule"


class StatutEtapeTraitement(str, enum.Enum):
    A_FAIRE = "a_faire"
    PLANIFIEE = "planifiee"
    EN_COURS = "en_cours"
    TERMINEE = "terminee"
    BLOQUEE = "bloquee"
    ANNULEE = "annulee"


class PlanTraitement(Base):
    """Plan opérationnel validé par l'équipe, distinct d'une proposition IA."""

    __tablename__ = "plans_traitement"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False
    )
    praticien_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="SET NULL"), nullable=True
    )
    titre: Mapped[str] = mapped_column(String(200), nullable=False)
    objectif: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    statut: Mapped[str] = mapped_column(
        String(20), default=StatutPlanTraitement.BROUILLON.value, nullable=False
    )
    date_debut: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    date_cible: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    cree_par_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False
    )
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    __table_args__ = (
        Index("ix_plans_traitement_clinic_patient", "clinic_id", "patient_id"),
        Index("ix_plans_traitement_clinic_statut", "clinic_id", "statut"),
    )


class EtapePlanTraitement(Base):
    """Étape ordonnée d'un plan, reliée aux objets opérationnels existants."""

    __tablename__ = "etapes_plans_traitement"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    plan_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("plans_traitement.id", ondelete="CASCADE"), nullable=False
    )
    patient_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("patients.id", ondelete="CASCADE"), nullable=False
    )
    ordre: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    titre: Mapped[str] = mapped_column(String(200), nullable=False)
    type_etape: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    statut: Mapped[str] = mapped_column(
        String(20), default=StatutEtapeTraitement.A_FAIRE.value, nullable=False
    )
    date_prevue: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    date_realisation: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    rendez_vous_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("rendez_vous.id", ondelete="SET NULL"), nullable=True
    )
    devis_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("devis_traitements.id", ondelete="SET NULL"), nullable=True
    )
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    __table_args__ = (
        Index("ix_etapes_plan_clinic_plan", "clinic_id", "plan_id", "ordre"),
        Index("ix_etapes_plan_clinic_patient", "clinic_id", "patient_id"),
        UniqueConstraint("plan_id", "ordre", name="uq_etapes_plan_ordre"),
    )


class PersonnelProfile(Base):
    """Informations professionnelles légères, séparées des credentials."""

    __tablename__ = "profils_personnel"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False
    )
    adresse: Mapped[Optional[str]] = mapped_column(String(300), nullable=True)
    fonction: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    date_embauche: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    diplomes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    specialisations: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    certifications: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    documents: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    notes_internes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("clinic_id", "user_id", name="uq_profils_personnel_clinic_user"),
        Index("ix_profils_personnel_clinic", "clinic_id"),
    )
