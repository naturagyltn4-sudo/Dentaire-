"""Modèles de pilotage global du Super Admin.

Les données de ce module décrivent les tenants et leur abonnement ; elles ne
contiennent aucun contenu médical patient.
"""

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, Index, Integer, JSON, String, Text, UniqueConstraint
from sqlalchemy.orm import Mapped, mapped_column

from models.database import Base


class CliniqueTenant(Base):
    __tablename__ = "cliniques"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    nom: Mapped[str] = mapped_column(String(200), nullable=False)
    slug: Mapped[str] = mapped_column(String(120), nullable=False, unique=True)
    statut: Mapped[str] = mapped_column(String(20), nullable=False, default="active")
    email_contact: Mapped[Optional[str]] = mapped_column(String(255), nullable=True)
    telephone_contact: Mapped[Optional[str]] = mapped_column(String(30), nullable=True)
    fuseau_horaire: Mapped[str] = mapped_column(String(60), nullable=False, default="Africa/Tunis")
    metadata_json: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    __table_args__ = (
        Index("ix_cliniques_statut", "statut"),
    )


class ClinicSubscription(Base):
    __tablename__ = "clinic_subscriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    clinic_id: Mapped[int] = mapped_column(Integer, nullable=False)
    plan: Mapped[str] = mapped_column(String(40), nullable=False, default="enterprise")
    statut: Mapped[str] = mapped_column(String(20), nullable=False, default="trial")
    started_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    expires_at: Mapped[Optional[datetime]] = mapped_column(DateTime, nullable=True)
    user_limit: Mapped[int] = mapped_column(Integer, nullable=False, default=25)
    storage_limit_gb: Mapped[int] = mapped_column(Integer, nullable=False, default=100)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    metadata_json: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    __table_args__ = (
        UniqueConstraint("clinic_id", name="uq_clinic_subscription_clinic"),
        Index("ix_clinic_subscription_status", "statut"),
    )
