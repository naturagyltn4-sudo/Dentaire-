"""
AutoCommerce Clinic — Constantes dentaires
Notation FDI (Fédération Dentaire Internationale)
32 dents numérotées de 11 à 48
"""

import enum


class NotationDentaire(str, enum.Enum):
    """
    Notation FDI pour les 32 dents permanentes.
    Format : XY où X = quadrant (1-4), Y = position (1-8)

    Quadrants :
    - 1 : Maxillaire droit (dents 11-18)
    - 2 : Maxillaire gauche (dents 21-28)
    - 3 : Mandibulaire gauche (dents 31-38)
    - 4 : Mandibulaire droit (dents 41-48)
    """

    # Quadrant 1 : Maxillaire droit
    DENT_11 = "11"  # Incisive centrale supérieure droite
    DENT_12 = "12"  # Incisive latérale supérieure droite
    DENT_13 = "13"  # Canine supérieure droite
    DENT_14 = "14"  # Première prémolaire supérieure droite
    DENT_15 = "15"  # Deuxième prémolaire supérieure droite
    DENT_16 = "16"  # Première molaire supérieure droite
    DENT_17 = "17"  # Deuxième molaire supérieure droite
    DENT_18 = "18"  # Troisième molaire supérieure droite (sagesse)

    # Quadrant 2 : Maxillaire gauche
    DENT_21 = "21"  # Incisive centrale supérieure gauche
    DENT_22 = "22"  # Incisive latérale supérieure gauche
    DENT_23 = "23"  # Canine supérieure gauche
    DENT_24 = "24"  # Première prémolaire supérieure gauche
    DENT_25 = "25"  # Deuxième prémolaire supérieure gauche
    DENT_26 = "26"  # Première molaire supérieure gauche
    DENT_27 = "27"  # Deuxième molaire supérieure gauche
    DENT_28 = "28"  # Troisième molaire supérieure gauche (sagesse)

    # Quadrant 3 : Mandibulaire gauche
    DENT_31 = "31"  # Incisive centrale inférieure gauche
    DENT_32 = "32"  # Incisive latérale inférieure gauche
    DENT_33 = "33"  # Canine inférieure gauche
    DENT_34 = "34"  # Première prémolaire inférieure gauche
    DENT_35 = "35"  # Deuxième prémolaire inférieure gauche
    DENT_36 = "36"  # Première molaire inférieure gauche
    DENT_37 = "37"  # Deuxième molaire inférieure gauche
    DENT_38 = "38"  # Troisième molaire inférieure gauche (sagesse)

    # Quadrant 4 : Mandibulaire droit
    DENT_41 = "41"  # Incisive centrale inférieure droite
    DENT_42 = "42"  # Incisive latérale inférieure droite
    DENT_43 = "43"  # Canine inférieure droite
    DENT_44 = "44"  # Première prémolaire inférieure droite
    DENT_45 = "45"  # Deuxième prémolaire inférieure droite
    DENT_46 = "46"  # Première molaire inférieure droite
    DENT_47 = "47"  # Deuxième molaire inférieure droite
    DENT_48 = "48"  # Troisième molaire inférieure droite (sagesse)

    @classmethod
    def get_all_fdi_numbers(cls) -> list[str]:
        """Retourne la liste de tous les numéros FDI."""
        return [member.value for member in cls]

    @classmethod
    def get_quadrant(cls, numero_fdi: str) -> int:
        """Retourne le quadrant (1-4) pour un numéro FDI."""
        if numero_fdi.startswith(("11", "12", "13", "14", "15", "16", "17", "18")):
            return 1
        elif numero_fdi.startswith(("21", "22", "23", "24", "25", "26", "27", "28")):
            return 2
        elif numero_fdi.startswith(("31", "32", "33", "34", "35", "36", "37", "38")):
            return 3
        elif numero_fdi.startswith(("41", "42", "43", "44", "45", "46", "47", "48")):
            return 4
        else:
            raise ValueError(f"Numéro FDI invalide : {numero_fdi}")

    @classmethod
    def get_position_in_quadrant(cls, numero_fdi: str) -> int:
        """Retourne la position (1-8) dans le quadrant."""
        if numero_fdi not in [member.value for member in cls]:
            raise ValueError(f"Numéro FDI invalide : {numero_fdi}")
        return int(numero_fdi[1])


__all__ = ["NotationDentaire"]
