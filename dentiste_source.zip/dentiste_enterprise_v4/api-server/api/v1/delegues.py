"""
API Délégués Médicaux — Gestion des contacts laboratoires et pharmaceutiques.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from models.database import Delegue, RoleEnum
from api.deps import get_db
from middleware.clinic_rbac import require_role

router = APIRouter(prefix="/delegues", tags=["delegues"])


class DelegueCreate(BaseModel):
    nom: str
    prenom: str
    laboratoire_ou_societe: str
    telephone: str
    email: Optional[str] = None
    specialite_produits: Optional[str] = None
    notes: Optional[str] = None


class DelegueUpdate(BaseModel):
    nom: Optional[str] = None
    prenom: Optional[str] = None
    laboratoire_ou_societe: Optional[str] = None
    telephone: Optional[str] = None
    email: Optional[str] = None
    specialite_produits: Optional[str] = None
    notes: Optional[str] = None
    is_active: Optional[bool] = None


@router.get("", response_model=List[dict])
async def list_delegues(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)),
):
    """Liste tous les délégués médicaux."""
    result = await db.execute(
        select(Delegue)
        .where(Delegue.clinic_id == current_user["clinic_id"])
        .order_by(Delegue.nom.asc())
    )
    delegues = result.scalars().all()
    return [
        {
            "id": d.id,
            "nom": d.nom,
            "prenom": d.prenom,
            "laboratoire_ou_societe": d.laboratoire_ou_societe,
            "telephone": d.telephone,
            "email": d.email,
            "specialite_produits": d.specialite_produits,
            "notes": d.notes,
            "is_active": d.is_active,
            "created_at": d.created_at.isoformat(),
        }
        for d in delegues
    ]


@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_delegue(
    data: DelegueCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    """Crée un nouveau délégué médical."""
    delegue = Delegue(
        clinic_id=current_user["clinic_id"],
        nom=data.nom,
        prenom=data.prenom,
        laboratoire_ou_societe=data.laboratoire_ou_societe,
        telephone=data.telephone,
        email=data.email,
        specialite_produits=data.specialite_produits,
        notes=data.notes,
    )
    db.add(delegue)
    await db.commit()
    await db.refresh(delegue)
    return {"id": delegue.id, "message": "Délégué créé avec succès"}


@router.patch("/{delegue_id}", response_model=dict)
async def update_delegue(
    delegue_id: int,
    data: DelegueUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    """Met à jour un délégué."""
    delegue = await db.scalar(
        select(Delegue).where(
            Delegue.id == delegue_id,
            Delegue.clinic_id == current_user["clinic_id"],
        )
    )
    if not delegue:
        raise HTTPException(status_code=404, detail="Délégué non trouvé")

    for field, value in data.dict(exclude_unset=True).items():
        setattr(delegue, field, value)

    await db.commit()
    return {"message": "Délégué mis à jour avec succès"}


@router.delete("/{delegue_id}", response_model=dict)
async def delete_delegue(
    delegue_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    """Supprime un délégué."""
    delegue = await db.scalar(
        select(Delegue).where(
            Delegue.id == delegue_id,
            Delegue.clinic_id == current_user["clinic_id"],
        )
    )
    if not delegue:
        raise HTTPException(status_code=404, detail="Délégué non trouvé")

    await db.delete(delegue)
    await db.commit()
    return {"message": "Délégué supprimé"}
