"""API de gestion des clichés et analyses céphalométriques."""

from datetime import datetime
import os
from typing import List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import Cephalometrie, Patient, RoleEnum
from services.audit_medical import log_access
from services.photos_clinic import _decrypt_file, _encrypt_file
from config import get_settings

router = APIRouter(prefix="/cephalometries", tags=["cephalometries"])
settings = get_settings()
ALLOWED_MIME_TYPES = {"image/jpeg", "image/png", "image/webp", "application/dicom", "application/octet-stream"}
MAX_FILE_SIZE = 25 * 1024 * 1024


class CephalometrieUpdate(BaseModel):
    conclusions: Optional[str] = None
    analyse_data: Optional[dict] = None


async def _get_patient(db: AsyncSession, patient_id: int, clinic_id: int) -> Patient:
    result = await db.execute(select(Patient).where(Patient.id == patient_id, Patient.clinic_id == clinic_id))
    patient = result.scalar_one_or_none()
    if patient is None:
        raise HTTPException(status_code=404, detail="Patient non trouvé")
    return patient


def _serialize(item: Cephalometrie) -> dict:
    return {
        "id": item.id,
        "patient_id": item.patient_id,
        "praticien_id": item.praticien_id,
        "titre": item.titre,
        "image_url": f"/api/v1/cephalometries/{item.id}/image",
        "mime_type": item.mime_type,
        "analyse_data": item.analyse_data,
        "conclusions": item.conclusions,
        "created_at": item.created_at.isoformat(),
    }


@router.get("", response_model=List[dict])
async def list_cephalometries(
    patient_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.ORTHODONTISTE, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    clinic_id = current_user["clinic_id"]
    query = select(Cephalometrie).where(Cephalometrie.clinic_id == clinic_id)
    if patient_id is not None:
        query = query.where(Cephalometrie.patient_id == patient_id)
    result = await db.execute(query.order_by(Cephalometrie.created_at.desc()))
    return [_serialize(item) for item in result.scalars().all()]


@router.post("", response_model=dict, status_code=status.HTTP_201_CREATED)
async def upload_cephalometrie(
    request: Request,
    patient_id: int = Form(...),
    titre: str = Form(..., min_length=2, max_length=200),
    conclusions: Optional[str] = Form(None),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.ORTHODONTISTE, RoleEnum.ADMIN)),
):
    clinic_id = current_user["clinic_id"]
    await _get_patient(db, patient_id, clinic_id)
    mime_type = file.content_type or "application/octet-stream"
    if mime_type not in ALLOWED_MIME_TYPES:
        raise HTTPException(status_code=415, detail="Format de fichier non autorisé")
    file_bytes = await file.read()
    if not file_bytes:
        raise HTTPException(status_code=400, detail="Le fichier est vide")
    if len(file_bytes) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="Le fichier dépasse 25 Mo")

    nonce, ciphertext = _encrypt_file(file_bytes)
    storage_dir = os.path.join(str(settings.photos_dir), datetime.utcnow().strftime("%Y/%m/cephalometries"))
    os.makedirs(storage_dir, exist_ok=True)
    filename = f"ceph_{clinic_id}_{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S_%f')}.enc"
    storage_path = os.path.join(storage_dir, filename)
    with open(storage_path, "wb") as stored_file:
        stored_file.write(nonce + ciphertext)

    item = Cephalometrie(
        clinic_id=clinic_id,
        patient_id=patient_id,
        praticien_id=current_user.get("id"),
        titre=titre.strip(),
        image_url=storage_path,
        mime_type=mime_type,
        conclusions=conclusions,
        analyse_data=None,
    )
    db.add(item)
    await db.flush()
    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="UPLOAD_CEPHALOMETRIE",
        resource_type="cephalometrie",
        resource_id=item.id,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
        clinic_id=clinic_id,
    )
    await db.commit()
    await db.refresh(item)
    return {"id": item.id, "message": "Céphalométrie enregistrée avec succès", "image_url": f"/api/v1/cephalometries/{item.id}/image"}


@router.get("/{cephalometrie_id}/image")
async def view_cephalometrie_image(
    cephalometrie_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.ORTHODONTISTE, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    clinic_id = current_user["clinic_id"]
    result = await db.execute(select(Cephalometrie).where(Cephalometrie.id == cephalometrie_id, Cephalometrie.clinic_id == clinic_id))
    item = result.scalar_one_or_none()
    if item is None or not os.path.exists(item.image_url):
        raise HTTPException(status_code=404, detail="Cliché céphalométrique introuvable")
    with open(item.image_url, "rb") as stored_file:
        encrypted = stored_file.read()
    if len(encrypted) < 13:
        raise HTTPException(status_code=500, detail="Fichier céphalométrique invalide")
    content = _decrypt_file(encrypted[:12], encrypted[12:])
    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=item.patient_id,
        action="VIEW_CEPHALOMETRIE",
        resource_type="cephalometrie",
        resource_id=item.id,
        ip_address=request.client.host if request.client else None,
        clinic_id=clinic_id,
    )
    await db.commit()
    return Response(content=content, media_type=item.mime_type, headers={"Cache-Control": "private, no-store"})


@router.patch("/{cephalometrie_id}", response_model=dict)
async def update_cephalometrie(
    cephalometrie_id: int,
    data: CephalometrieUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.ORTHODONTISTE, RoleEnum.ADMIN)),
):
    result = await db.execute(select(Cephalometrie).where(Cephalometrie.id == cephalometrie_id, Cephalometrie.clinic_id == current_user["clinic_id"]))
    item = result.scalar_one_or_none()
    if item is None:
        raise HTTPException(status_code=404, detail="Analyse céphalométrique introuvable")
    if data.conclusions is not None:
        item.conclusions = data.conclusions
    if data.analyse_data is not None:
        item.analyse_data = data.analyse_data
    await db.commit()
    return _serialize(item)
