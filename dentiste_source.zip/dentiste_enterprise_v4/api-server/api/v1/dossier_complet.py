"""
AutoCommerce Clinic — API Dossier Complet (BLOC 2)
Intègre odontogramme + dossier médical + photos + actes
Source de vérité : EtatDentaire + HistoriqueDentaire
DossierMedical.zones_traitees reste un résumé dénormalisé
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from models.database import (
    Patient,
    DossierMedical,
    EtatDentaire,
    PhotoClinic,
    ActeMedical,
    Utilisateur,
    RoleEnum,
)
from api.deps import get_db
from middleware.clinic_rbac import require_role
from services.audit_medical import log_access
from services.audit_journal import log_event
from services.dossier_medical import decrypt_field

router = APIRouter(prefix="/patients", tags=["dossier-complet"])


# ── Schémas ────────────────────────────────────────────────


class EtatDentaireSimple(BaseModel):
    """État dentaire simplifié."""

    numero_dent: str
    statut: str
    notes: Optional[str] = None
    date_modification: datetime

    class Config:
        from_attributes = True


class OdontogrammeResume(BaseModel):
    """Résumé de l'odontogramme."""

    total_dents: int = 32
    dents_saines: int = 0
    dents_avec_problemes: int = 0
    etats: List[EtatDentaireSimple]
    date_derniere_modification: Optional[datetime] = None

    class Config:
        from_attributes = True


class DossierMedicalResume(BaseModel):
    """Résumé du dossier médical."""

    id: int
    date_acte: datetime
    acte_nom: Optional[str] = None
    praticien_nom: str
    observations: Optional[str] = None
    satisfaction_patient: Optional[int] = None
    suivi_requis: bool
    date_suivi_recommandee: Optional[str] = None

    class Config:
        from_attributes = True


class PhotoResume(BaseModel):
    """Résumé d'une photo."""

    id: int
    type: str
    zone_anatomique: Optional[str] = None
    date_prise: datetime
    url_thumbnail: Optional[str] = None
    visible_patient: bool

    class Config:
        from_attributes = True


class DossierCompletResponse(BaseModel):
    """Réponse complète du dossier patient."""

    patient_id: int
    patient_nom: str
    patient_prenom: str
    patient_telephone: str
    patient_date_naissance: Optional[str] = None

    # Odontogramme
    odontogramme: OdontogrammeResume

    # Dossiers médicaux (derniers)
    dossiers_recents: List[DossierMedicalResume]

    # Photos (dernières)
    photos_recentes: List[PhotoResume]

    # Metadata
    date_derniere_modification: Optional[datetime] = None

    class Config:
        from_attributes = True


# ── Endpoints ────────────────────────────────────────────


@router.get("/{patient_id}/dossier-complet", response_model=DossierCompletResponse)
async def get_dossier_complet(
    patient_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.ASSISTANTE,
            RoleEnum.DIRECTRICE,
        )
    ),
):
    """
    Récupère le dossier complet d'un patient en un seul appel.

    Retourne :
    - Informations patient
    - Odontogramme courant (32 dents)
    - Derniers dossiers médicaux (5 derniers)
    - Dernières photos (5 dernières)

    Permissions :
    - MEDECIN, ESTHETICIENNE, ASSISTANTE, DIRECTRICE

    Source de vérité :
    - Odontogramme : EtatDentaire + HistoriqueDentaire
    - Dossier médical : DossierMedical (zones_traitees est un résumé)
    """
    # Vérifier que le patient existe
    clinic_id = current_user.get("clinic_id") if isinstance(current_user, dict) else getattr(current_user, "clinic_id", None)
    if not isinstance(clinic_id, int) or clinic_id <= 0:
        raise HTTPException(status_code=403, detail="Contexte clinique absent")
    stmt = select(Patient).where(
        Patient.id == patient_id,
        Patient.clinic_id == clinic_id,
    )
    patient = await db.scalar(stmt)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Patient non trouvé",
        )

    # Récupérer l'odontogramme (32 dents)
    stmt = select(EtatDentaire).where(
        EtatDentaire.patient_id == patient_id,
        EtatDentaire.clinic_id == clinic_id,
    )
    etats_dentaires = await db.scalars(stmt)
    etats_list = list(etats_dentaires)

    # Calculer les statistiques odontogramme
    dents_saines = sum(1 for e in etats_list if e.statut == "sain")
    dents_avec_problemes = len(etats_list) - dents_saines
    date_derniere_modif_odonto = (
        max(e.date_modification for e in etats_list) if etats_list else None
    )

    odontogramme = OdontogrammeResume(
        total_dents=32,
        dents_saines=dents_saines,
        dents_avec_problemes=dents_avec_problemes,
        etats=[
            EtatDentaireSimple(
                numero_dent=e.numero_dent,
                statut=e.statut,
                notes=e.notes,
                date_modification=e.date_modification,
            )
            for e in etats_list
        ],
        date_derniere_modification=date_derniere_modif_odonto,
    )

    # Récupérer les derniers dossiers médicaux (5 derniers)
    stmt = (
        select(DossierMedical)
        .where(
            DossierMedical.patient_id == patient_id,
            DossierMedical.clinic_id == clinic_id,
        )
        .order_by(desc(DossierMedical.date_acte))
        .limit(5)
    )
    dossiers = await db.scalars(stmt)
    dossiers_list = list(dossiers)

    dossiers_recents = []
    for dossier in dossiers_list:
        # Récupérer le nom de l'acte si disponible
        acte_nom = None
        if dossier.acte_id:
            stmt = select(ActeMedical).where(
                ActeMedical.id == dossier.acte_id,
                ActeMedical.clinic_id == clinic_id,
            )
            acte = await db.scalar(stmt)
            acte_nom = acte.nom if acte else None

        # Récupérer le nom du praticien
        stmt = select(Utilisateur).where(
            Utilisateur.id == dossier.praticien_id,
            Utilisateur.clinic_id == clinic_id,
        )
        praticien = await db.scalar(stmt)
        praticien_nom = (
            f"{praticien.prenom} {praticien.nom}" if praticien else "Inconnu"
        )

        dossiers_recents.append(
            DossierMedicalResume(
                id=dossier.id,
                date_acte=dossier.date_acte,
                acte_nom=acte_nom,
                praticien_nom=praticien_nom,
                observations=(
                decrypt_field(dossier.observations_enc)
                if dossier.observations_enc
                else None
            ),
                satisfaction_patient=dossier.satisfaction_patient,
                suivi_requis=dossier.suivi_requis,
                date_suivi_recommandee=(
                    dossier.date_suivi_recommandee.isoformat()
                    if dossier.date_suivi_recommandee
                    else None
                ),
            )
        )

    # Récupérer les dernières photos (5 dernières)
    stmt = (
        select(PhotoClinic)
        .where(
            PhotoClinic.patient_id == patient_id,
            PhotoClinic.clinic_id == clinic_id,
        )
        .where(~PhotoClinic.is_deleted)
        .order_by(desc(PhotoClinic.date_prise))
        .limit(5)
    )
    photos = await db.scalars(stmt)
    photos_list = list(photos)

    photos_recentes = [
        PhotoResume(
            id=p.id,
            type=p.type,
            zone_anatomique=p.zone_anatomique,
            date_prise=p.date_prise,
            url_thumbnail=p.url_thumbnail,
            visible_patient=p.visible_patient,
        )
        for p in photos_list
    ]

    # Déterminer la date de dernière modification globale
    dates = [
        date_derniere_modif_odonto,
        max(d.date_acte for d in dossiers_list) if dossiers_list else None,
        max(p.date_prise for p in photos_list) if photos_list else None,
    ]
    date_derniere_modification = max((d for d in dates if d is not None), default=None)

    # Enregistrer l'accès dans l'audit
    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="READ_DOSSIER_COMPLET",
        resource_type="dossier_complet",
        resource_id=patient_id,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
        clinic_id=clinic_id,
    )
    await log_event(
        db,
        utilisateur_id=current_user["id"],
        clinic_id=clinic_id,
        action="READ_DOSSIER_COMPLET",
        resource_type="dossier_complet",
        resource_id=patient_id,
        patient_id=patient_id,
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )

    return DossierCompletResponse(
        patient_id=patient_id,
        patient_nom=patient.nom,
        patient_prenom=patient.prenom,
        patient_telephone=patient.telephone,
        patient_date_naissance=(
            patient.date_naissance.isoformat() if patient.date_naissance else None
        ),
        odontogramme=odontogramme,
        dossiers_recents=dossiers_recents,
        photos_recentes=photos_recentes,
        date_derniere_modification=date_derniere_modification,
    )
