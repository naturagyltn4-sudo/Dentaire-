"""
AutoCommerce Clinic — API Agenda
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, field_validator
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from models.database import (
    RendezVous,
    Patient,
    Utilisateur,
    ActeMedical,
    StatutRDV,
    Salle,
)
from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum

from services.agenda import get_disponibilites, creer_rdv, annuler_rdv
from services.datetime_utils import to_utc_naive
from services.suivi_post_op import trigger_suivi_post_op

router = APIRouter(prefix="/agenda", tags=["agenda"])


# ── Schémas ────────────────────────────────────────────────


class RDVCreate(BaseModel):
    patient_id: int
    praticien_id: int
    acte_id: int
    date_heure: str  # ISO datetime
    salle: Optional[str] = Field(None, max_length=50)
    salle_id: Optional[int] = None
    fauteuil_numero: Optional[int] = None


class RDVUpdate(BaseModel):
    statut: Optional[str] = None
    notes_pre_acte: Optional[str] = None
    notes_post_acte: Optional[str] = None

    @field_validator("statut")
    @classmethod
    def statut_doit_etre_valide(cls, v):
        if v is not None:
            valeurs = [s.value for s in StatutRDV]
            if v not in valeurs:
                raise ValueError(
                    f"statut invalide, doit être l'un de : {', '.join(valeurs)}"
                )
        return v


class RDVOut(BaseModel):
    id: int
    patient_id: int
    patient_nom: str
    praticien_id: int
    praticien_nom: str
    acte_id: Optional[int]
    acte_nom: Optional[str]
    date_heure_debut: str
    date_heure_fin: Optional[str]
    salle: Optional[str]
    salle_id: Optional[int]
    fauteuil_numero: Optional[int]
    statut: str
    consentement_manquant: bool = False

    class Config:
        from_attributes = True


class SalleCreate(BaseModel):
    nom: str
    capacite_fauteuils: int = 1


class SalleOut(BaseModel):
    id: int
    nom: str
    capacite_fauteuils: int

    class Config:
        from_attributes = True


# ── Routes ─────────────────────────────────────────────────


@router.get("", response_model=List[RDVOut])
async def list_agenda(
    praticien_id: Optional[int] = Query(None),
    salle_id: Optional[int] = Query(None),
    date_debut: Optional[str] = Query(None),
    date_fin: Optional[str] = Query(None),
    vue: str = Query("semaine", pattern="^(semaine|jour)$"),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.MEDECIN,
            RoleEnum.ORTHODONTISTE,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.ASSISTANTE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Liste les RDV (vue semaine ou jour)."""
    query = (
        select(RendezVous, Patient, Utilisateur, ActeMedical)
        .join(
            Patient,
            (RendezVous.patient_id == Patient.id)
            & (Patient.clinic_id == current_user["clinic_id"]),
        )
        .join(
            Utilisateur,
            (RendezVous.praticien_id == Utilisateur.id)
            & (Utilisateur.clinic_id == current_user["clinic_id"]),
        )
        .outerjoin(
            ActeMedical,
            (RendezVous.acte_id == ActeMedical.id)
            & (ActeMedical.clinic_id == current_user["clinic_id"]),
        )
        .where(RendezVous.clinic_id == current_user["clinic_id"])
    )

    if praticien_id:
        query = query.where(RendezVous.praticien_id == praticien_id)

    if salle_id:
        query = query.where(RendezVous.salle_id == salle_id)

    if date_debut:
        dt_debut = datetime.fromisoformat(date_debut)
        query = query.where(RendezVous.date_heure_debut >= dt_debut)

    if date_fin:
        dt_fin = datetime.fromisoformat(date_fin)
        query = query.where(RendezVous.date_heure_debut <= dt_fin)

    query = query.order_by(RendezVous.date_heure_debut)
    result = await db.execute(query)

    rdvs = []
    for rdv, patient, praticien, acte in result.all():
        from services.consentement import verify_consent

        consent_missing = not await verify_consent(
            rdv.patient_id,
            rdv.acte_id,
            db,
            clinic_id=current_user["clinic_id"],
        )

        rdvs.append(
            RDVOut(
                id=rdv.id,
                patient_id=rdv.patient_id,
                patient_nom=f"{patient.prenom} {patient.nom}",
                praticien_id=rdv.praticien_id,
                praticien_nom=f"{praticien.prenom} {praticien.nom}",
                acte_id=rdv.acte_id,
                acte_nom=acte.nom if acte else None,
                date_heure_debut=rdv.date_heure_debut.isoformat(),
                date_heure_fin=rdv.date_heure_fin.isoformat()
                if rdv.date_heure_fin
                else None,
                salle=rdv.salle,
                salle_id=rdv.salle_id,
                fauteuil_numero=rdv.fauteuil_numero,
                statut=rdv.statut,
                consentement_manquant=consent_missing,
            )
        )

    return rdvs


@router.post("/rdv", response_model=RDVOut)
async def create_rdv(
    data: RDVCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.ASSISTANTE,
            RoleEnum.MEDECIN,
            RoleEnum.ORTHODONTISTE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Crée un rendez-vous."""
    try:
        date_heure = to_utc_naive(datetime.fromisoformat(data.date_heure))
        rdv, consent_missing = await creer_rdv(
            patient_id=data.patient_id,
            praticien_id=data.praticien_id,
            acte_id=data.acte_id,
            date_heure=date_heure,
            salle=data.salle,
            salle_id=data.salle_id,
            fauteuil_numero=data.fauteuil_numero,
            db=db,
            created_by=current_user["id"],
            clinic_id=current_user["clinic_id"],
        )

        # Récupérer noms
        patient_r = await db.execute(
            select(Patient).where(
                Patient.id == data.patient_id,
                Patient.clinic_id == current_user["clinic_id"],
            )
        )
        patient = patient_r.scalar_one()
        praticien_r = await db.execute(
            select(Utilisateur).where(
                Utilisateur.id == data.praticien_id,
                Utilisateur.clinic_id == current_user["clinic_id"],
            )
        )
        praticien = praticien_r.scalar_one()
        acte_r = await db.execute(
            select(ActeMedical).where(
                ActeMedical.id == data.acte_id,
                ActeMedical.clinic_id == current_user["clinic_id"],
            )
        )
        acte = acte_r.scalar_one()

        return RDVOut(
            id=rdv.id,
            patient_id=rdv.patient_id,
            patient_nom=f"{patient.prenom} {patient.nom}",
            praticien_id=rdv.praticien_id,
            praticien_nom=f"{praticien.prenom} {praticien.nom}",
            acte_id=rdv.acte_id,
            acte_nom=acte.nom,
            date_heure_debut=rdv.date_heure_debut.isoformat(),
            date_heure_fin=rdv.date_heure_fin.isoformat()
            if rdv.date_heure_fin
            else None,
            salle=rdv.salle,
            salle_id=rdv.salle_id,
            fauteuil_numero=rdv.fauteuil_numero,
            statut=rdv.statut,
            consentement_manquant=consent_missing,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.patch("/rdv/{rdv_id}/statut")
@router.put("/rdv/{rdv_id}/statut")
async def update_rdv_statut(
    rdv_id: int,
    data: RDVUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.ASSISTANTE,
            RoleEnum.MEDECIN,
            RoleEnum.ORTHODONTISTE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Met à jour le statut d'un RDV."""
    result = await db.execute(
        select(RendezVous).where(
            RendezVous.id == rdv_id,
            RendezVous.clinic_id == current_user["clinic_id"],
        )
    )
    rdv = result.scalar_one_or_none()
    if not rdv:
        raise HTTPException(status_code=404, detail="RDV non trouvé")

    old_statut = rdv.statut
    if data.statut:
        rdv.statut = data.statut
    if data.notes_pre_acte is not None:
        rdv.notes_pre_acte = data.notes_pre_acte
    if data.notes_post_acte is not None:
        rdv.notes_post_acte = data.notes_post_acte

    await db.flush()

    # Hook : Création automatique du suivi post-op si TERMINE
    if data.statut == StatutRDV.TERMINE.value and old_statut != StatutRDV.TERMINE.value:
        # Durée configurable : on pourrait la tirer des settings de la clinique
        # Ici on utilise 7 jours par défaut comme demandé.
        await trigger_suivi_post_op(rdv.id, db, delay_days=7)

    return {"message": "RDV mis à jour"}


@router.delete("/rdv/{rdv_id}")
async def cancel_rdv_route(
    rdv_id: int,
    raison: Optional[str] = Query(None, min_length=3),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    """Annule un RDV."""
    if raison is None:
        raison = "Annulation sans raison spécifiée (via API DELETE)"
    """Annule un RDV."""
    try:
        rdv = await annuler_rdv(
            rdv_id,
            raison,
            db,
            clinic_id=current_user["clinic_id"],
        )
        return {"message": "RDV annulé", "rdv_id": rdv.id}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/disponibilites/{praticien_id}")
async def get_dispos(
    praticien_id: int,
    date: str = Query(..., description="YYYY-MM-DD"),
    duree: int = Query(30, ge=15, le=240),
    acte_id: Optional[int] = Query(None),
    salle_id: Optional[int] = Query(None),
    fauteuil_numero: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.ASSISTANTE,
            RoleEnum.MEDECIN,
            RoleEnum.ORTHODONTISTE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Créneaux libres d'un praticien pour une date et un acte précis."""
    try:
        date_jour = datetime.strptime(date, "%Y-%m-%d").date()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Date invalide, format attendu YYYY-MM-DD") from exc

    if fauteuil_numero is not None and salle_id is None:
        raise HTTPException(status_code=400, detail="Un fauteuil doit être rattaché à une salle")

    if acte_id is not None:
        acte_result = await db.execute(
            select(ActeMedical).where(
                ActeMedical.id == acte_id,
                ActeMedical.clinic_id == current_user["clinic_id"],
                ActeMedical.is_active,
            )
        )
        acte = acte_result.scalar_one_or_none()
        if acte is None:
            raise HTTPException(status_code=404, detail="Acte non trouvé")
        duree = acte.duree_minutes

    creneaux = await get_disponibilites(
        praticien_id,
        date_jour,
        duree,
        db,
        salle_id,
        fauteuil_numero,
        clinic_id=current_user["clinic_id"],
    )
    return {
        "praticien_id": praticien_id,
        "date": date,
        "acte_id": acte_id,
        "duree_minutes": duree,
        "creneaux": creneaux,
    }


# ── Salles ──────────────────────────────────────────────────


@router.get("/salles", response_model=List[SalleOut])
async def list_salles(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.ASSISTANTE,
            RoleEnum.MEDECIN,
            RoleEnum.ORTHODONTISTE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Liste les salles de la clinique."""
    result = await db.execute(
        select(Salle).where(Salle.clinic_id == current_user["clinic_id"])
    )
    return result.scalars().all()


@router.post("/salles", response_model=SalleOut)
async def create_salle(
    data: SalleCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    """Crée une nouvelle salle."""
    salle = Salle(
        clinic_id=current_user["clinic_id"],
        nom=data.nom,
        capacite_fauteuils=data.capacite_fauteuils,
    )
    db.add(salle)
    await db.flush()
    return salle
