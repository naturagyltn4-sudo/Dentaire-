"""API des plans de traitement opérationnels."""
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum
from services.plans_traitement import (
    add_step,
    create_plan,
    list_plans,
    update_step,
)

router = APIRouter(prefix="/plans-traitement", tags=["plans-traitement"])

READ_ROLES = (
    RoleEnum.DIRECTRICE,
    RoleEnum.MEDECIN,
    RoleEnum.ORTHODONTISTE,
    RoleEnum.ESTHETICIENNE,
    RoleEnum.ASSISTANTE,
    RoleEnum.ADMIN,
)
WRITE_ROLES = (
    RoleEnum.DIRECTRICE,
    RoleEnum.MEDECIN,
    RoleEnum.ORTHODONTISTE,
    RoleEnum.ADMIN,
)


class PlanCreate(BaseModel):
    titre: str = Field(min_length=2, max_length=200)
    objectif: Optional[str] = Field(default=None, max_length=4000)
    praticien_id: Optional[int] = Field(default=None, gt=0)
    statut: Optional[str] = None
    date_debut: Optional[date] = None
    date_cible: Optional[date] = None


class EtapeCreate(BaseModel):
    titre: str = Field(min_length=2, max_length=200)
    type_etape: Optional[str] = Field(default=None, max_length=50)
    statut: Optional[str] = None
    ordre: Optional[int] = Field(default=None, ge=1, le=1000)
    date_prevue: Optional[date] = None
    date_realisation: Optional[date] = None
    rendez_vous_id: Optional[int] = Field(default=None, gt=0)
    devis_id: Optional[int] = Field(default=None, gt=0)
    notes: Optional[str] = Field(default=None, max_length=4000)


class EtapeUpdate(BaseModel):
    titre: Optional[str] = Field(default=None, min_length=2, max_length=200)
    type_etape: Optional[str] = Field(default=None, max_length=50)
    statut: Optional[str] = None
    ordre: Optional[int] = Field(default=None, ge=1, le=1000)
    date_prevue: Optional[date] = None
    date_realisation: Optional[date] = None
    rendez_vous_id: Optional[int] = Field(default=None, gt=0)
    devis_id: Optional[int] = Field(default=None, gt=0)
    notes: Optional[str] = Field(default=None, max_length=4000)


@router.get("/patients/{patient_id}")
async def list_patient_plans(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*READ_ROLES)),
):
    try:
        return await list_plans(patient_id, current_user, db)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.post("/patients/{patient_id}", status_code=status.HTTP_201_CREATED)
async def create_patient_plan(
    patient_id: int,
    payload: PlanCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*WRITE_ROLES)),
):
    try:
        return await create_plan(patient_id, payload.model_dump(exclude_none=True), current_user, db)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.post("/{plan_id}/etapes", status_code=status.HTTP_201_CREATED)
async def create_plan_step(
    plan_id: int,
    payload: EtapeCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*WRITE_ROLES)),
):
    try:
        return await add_step(plan_id, payload.model_dump(exclude_none=True), current_user, db)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.patch("/etapes/{step_id}")
async def patch_plan_step(
    step_id: int,
    payload: EtapeUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*WRITE_ROLES)),
):
    try:
        return await update_step(step_id, payload.model_dump(exclude_none=True), current_user, db)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
