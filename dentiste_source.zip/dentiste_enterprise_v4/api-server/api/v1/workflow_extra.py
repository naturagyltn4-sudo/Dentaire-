"""Routes Workflow Engine supplémentaires : preview, decide, approve."""

from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, get_current_user
from services.workflow_engine import WorkflowEngineService
from models.database import RoleEnum
router = APIRouter()


def _require_user_clinic(current_user: dict) -> int:
    clinic_id = current_user.get("clinic_id") if isinstance(current_user, dict) else None
    if not isinstance(clinic_id, int) or clinic_id <= 0:
        raise HTTPException(status_code=403, detail="Contexte clinique absent")
    return clinic_id


class DecidePayload(BaseModel):
    event_type: str
    event_data: Dict[str, Any] = Field(default_factory=dict)
    clinic_id: int | None = None


class ApprovePayload(BaseModel):
    action_id: int
    workflow_id: int


@router.post("/decide")
async def decide(
    payload: DecidePayload,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    clinic_id = _require_user_clinic(current_user)
    workflows = await WorkflowEngineService.get_active_workflows(
        db, clinic_id=clinic_id
    )
    user_context = current_user
    decision = await WorkflowEngineService.decide_next_branch(
        db,
        event_type=payload.event_type,
        event_data=payload.event_data,
        available_workflows=list(workflows),
        settings=user_context,
    )
    return decision


@router.post("/executions/{execution_id}/approve-action")
async def approve(
    execution_id: int,
    payload: ApprovePayload,
    current_user=Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Approuve un brouillon d'action (humain-dans-la-boucle requis)."""
    approval = current_user.get("role") if isinstance(current_user, dict) else None
    allowed_roles = {RoleEnum.ADMIN.value, RoleEnum.DIRECTRICE.value, RoleEnum.MEDECIN.value}
    if approval not in allowed_roles:
        raise HTTPException(
            status_code=403,
            detail="Seuls admin, directrice ou médecin peuvent approuver un envoi.",
        )
    clinic_id = _require_user_clinic(current_user)
    action = await WorkflowEngineService.approve_drafted_action(
        db,
        execution_id=execution_id,
        action_id=payload.action_id,
        clinic_id=clinic_id,
        workflow_id=payload.workflow_id,
    )
    return {
        "id": action.id,
        "action_type": action.action_type,
        "status": action.status,
        "result": action.result,
    }
