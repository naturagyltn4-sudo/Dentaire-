"""
AutoCommerce Clinic — API Suivi Post-Opératoire (Bloc 8)
La création du suivi est déclenchée automatiquement par le hook
`trigger_suivi_post_op` dans agenda_clinic.update_rdv_statut (transition du
RDV vers TERMINE pour un acte chirurgical). Ce routeur expose la consultation,
la liste et la clôture (effectuée / manquée) des suivis post-opératoires.
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models.database import (
    Patient,
    RoleEnum,
    StatutSuiviPostOp,
    SuiviPostOperatoire,
)
from api.deps import get_db
from middleware.clinic_rbac import require_role
from services.audit_medical import log_access

router = APIRouter(tags=["suivi_post_op"])


# ── Schémas Pydantic ───────────────────────────────────────


class SuiviPostOpUpdate(BaseModel):
    observations: Optional[str] = Field(
        None, description="Observations du praticien après le contrôle"
    )
    complication: Optional[str] = Field(
        None, description="Complication éventuelle signalée"
    )


class SuiviPostOpCloture(BaseModel):
    statut: str = Field(
        ..., description="Statut de clôture du contrôle : effectue ou manque"
    )


class SuiviPostOpResponse(BaseModel):
    id: int
    clinic_id: int
    acte_id: int
    patient_id: int
    date_controle_prevue: datetime
    date_controle_reelle: Optional[datetime] = None
    statut: str
    observations: Optional[str] = None
    complication: Optional[str] = None
    praticien_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ── Endpoints ──────────────────────────────────────────────


@router.get(
    "/patients/{patient_id}/suivi-post-op",
    response_model=List[SuiviPostOpResponse],
)
async def lister_suivis_patient(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.ASSISTANTE
        )
    ),
):
    """Lister tous les suivis post-opératoires d'un patient."""
    patient = await db.scalar(
        select(Patient).where(
            Patient.id == patient_id,
            Patient.clinic_id == current_user["clinic_id"],
        )
    )
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Patient non trouvé"
        )

    result = await db.execute(
        select(SuiviPostOperatoire)
        .where(
            SuiviPostOperatoire.patient_id == patient_id,
            SuiviPostOperatoire.clinic_id == current_user["clinic_id"],
        )
        .order_by(SuiviPostOperatoire.date_controle_prevue.desc())
    )
    suivis = list(result.scalars().all())

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="READ_SUIVIS_POST_OP",
        resource_type="suivi_post_op",
        resource_id=0,
    )

    return suivis


@router.get(
    "/suivis-post-op/{suivi_id}", response_model=SuiviPostOpResponse
)
async def get_suivi_post_op(
    suivi_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.ASSISTANTE
        )
    ),
):
    """Obtenir les détails d'un suivi post-opératoire."""
    suivi = await db.scalar(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.id == suivi_id,
            SuiviPostOperatoire.clinic_id == current_user["clinic_id"],
        )
    )
    if not suivi:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Suivi post-opératoire non trouvé",
        )

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=suivi.patient_id,
        action="READ_SUIVI_POST_OP",
        resource_type="suivi_post_op",
        resource_id=suivi.id,
    )

    return suivi


@router.patch(
    "/suivis-post-op/{suivi_id}", response_model=SuiviPostOpResponse
)
async def mettre_a_jour_suivi_post_op(
    suivi_id: int,
    data: SuiviPostOpUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)
    ),
):
    """Mettre à jour les observations et complications d'un suivi post-opératoire."""
    suivi = await db.scalar(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.id == suivi_id,
            SuiviPostOperatoire.clinic_id == current_user["clinic_id"],
        )
    )
    if not suivi:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Suivi post-opératoire non trouvé",
        )

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(suivi, field, value)

    suivi.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(suivi)

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=suivi.patient_id,
        action="UPDATE_SUIVI_POST_OP",
        resource_type="suivi_post_op",
        resource_id=suivi.id,
    )

    return suivi


@router.post(
    "/suivis-post-op/{suivi_id}/cloturer", response_model=SuiviPostOpResponse
)
async def cloturer_suivi_post_op(
    suivi_id: int,
    request: Request,
    data: SuiviPostOpCloture,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE)),
):
    """Marquer le contrôle post-opératoire comme effectué ou manqué."""
    suivi = await db.scalar(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.id == suivi_id,
            SuiviPostOperatoire.clinic_id == current_user["clinic_id"],
        )
    )
    if not suivi:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Suivi post-opératoire non trouvé",
        )

    if data.statut not in (
        StatutSuiviPostOp.EFFECTUE.value,
        StatutSuiviPostOp.MANQUE.value,
    ):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Statut invalide : attendue '{StatutSuiviPostOp.EFFECTUE.value}' "
            f"ou '{StatutSuiviPostOp.MANQUE.value}'",
        )

    suivi.statut = data.statut
    suivi.date_controle_reelle = datetime.utcnow()
    suivi.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(suivi)

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=suivi.patient_id,
        action="VALIDATE_SUIVI_POST_OP",
        resource_type="suivi_post_op",
        resource_id=suivi.id,
        ip_address=request.client.host if request.client else None,
        details={"nouveau_statut": data.statut},
    )

    return suivi
