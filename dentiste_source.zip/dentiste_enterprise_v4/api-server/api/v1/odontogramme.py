"""
AutoCommerce Clinic — API Odontogramme (BLOC 1)
Gestion de l'état dentaire et historique des modifications.
"""

from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from models.database import (
    EtatDentaire,
    HistoriqueDentaire,
    StatutDent,
    Patient,
    Utilisateur,
    AuditLogMedical,
    RoleEnum,
)
from models.dental_constants import NotationDentaire
from api.deps import get_db
from middleware.clinic_rbac import require_role
from services.audit_medical import log_access
from services.audit_journal import log_event

router = APIRouter(prefix="/patients", tags=["odontogramme"])


# ── Schémas ────────────────────────────────────────────────


class EtatDentaireResponse(BaseModel):
    """Réponse pour un état dentaire."""

    id: int
    patient_id: int
    numero_dent: str
    statut: str
    face: Optional[str] = None
    praticien_id: int
    notes: Optional[str] = None
    date_modification: datetime
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class EtatDentaireUpdate(BaseModel):
    """Mise à jour d'un état dentaire."""

    statut: str = Field(..., description="Nouveau statut (sain, carie, obture, etc.)")
    face: Optional[str] = Field(None, description="Face dentaire (réservé pour V2)")
    notes: Optional[str] = Field(None, description="Notes du praticien")


class HistoriqueDentaireResponse(BaseModel):
    """Réponse pour un événement d'historique."""

    id: int
    patient_id: int
    numero_dent: str
    statut_ancien: Optional[str] = None
    statut_nouveau: str
    face_ancien: Optional[str] = None
    face_nouveau: Optional[str] = None
    praticien_id: int
    notes: Optional[str] = None
    created_at: datetime

    class Config:
        from_attributes = True


class OdontogrammeResponse(BaseModel):
    """Réponse pour l'odontogramme complet."""

    patient_id: int
    dents: List[EtatDentaireResponse]
    date_derniere_modification: Optional[datetime] = None

    class Config:
        from_attributes = True


# ── Endpoints ────────────────────────────────────────────


@router.get("/{patient_id}/odontogramme", response_model=OdontogrammeResponse)
async def get_odontogramme(
    patient_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.MEDECIN, RoleEnum.ESTHETICIENNE, RoleEnum.ASSISTANTE)
    ),
):
    """
    Récupère l'odontogramme complet d'un patient (32 dents).

    Permissions :
    - MEDECIN, ESTHETICIENNE, ASSISTANTE

    Audit :
    - Enregistre l'accès au dossier dentaire
    """
    # Vérifier que le patient existe
    stmt = select(Patient).where(
        Patient.id == patient_id,
        Patient.clinic_id == current_user["clinic_id"],
    )
    patient = await db.scalar(stmt)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Patient non trouvé"
        )

    # Récupérer les états dentaires uniquement dans le tenant courant
    stmt = select(EtatDentaire).where(
        EtatDentaire.patient_id == patient_id,
        EtatDentaire.clinic_id == current_user["clinic_id"],
    )
    etats = await db.scalars(stmt)
    etats_list = list(etats)

    # Enregistrer l'accès dans l'audit
    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="READ_ODONTOGRAMME",
        resource_type="odontogramme",
        resource_id=patient_id,
        clinic_id=current_user["clinic_id"],
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )

    # Déterminer la dernière modification
    date_derniere_modification = None
    if etats_list:
        date_derniere_modification = max(e.date_modification for e in etats_list)

    return OdontogrammeResponse(
        patient_id=patient_id,
        dents=[EtatDentaireResponse.from_orm(e) for e in etats_list],
        date_derniere_modification=date_derniere_modification,
    )


@router.patch(
    "/{patient_id}/odontogramme/{numero_dent}", response_model=EtatDentaireResponse
)
async def update_etat_dentaire(
    patient_id: int,
    numero_dent: str,
    data: EtatDentaireUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.MEDECIN, RoleEnum.ESTHETICIENNE)),
):
    """
    Met à jour l'état d'une dent.

    Permissions :
    - MEDECIN, ESTHETICIENNE

    Opérations atomiques :
    1. Valider le numéro FDI
    2. Valider le statut
    3. Récupérer ou créer EtatDentaire
    4. Créer l'événement HistoriqueDentaire
    5. Enregistrer l'audit
    6. Tout dans une seule transaction

    Audit :
    - Enregistre la modification dans AuditLogMedical
    """
    # Valider le numéro FDI
    try:
        NotationDentaire[f"DENT_{numero_dent}"]
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Numéro FDI invalide : {numero_dent}. Doit être entre 11 et 48.",
        )

    # Valider le statut
    statuts_valides = [s.value for s in StatutDent]
    if data.statut not in statuts_valides:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Statut invalide : {data.statut}. Statuts valides : {', '.join(statuts_valides)}",
        )

    # Vérifier que le patient existe
    stmt = select(Patient).where(
        Patient.id == patient_id,
        Patient.clinic_id == current_user["clinic_id"],
    )
    patient = await db.scalar(stmt)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Patient non trouvé"
        )

    # Vérifier que le praticien existe (doit être le praticien courant)
    stmt = select(Utilisateur).where(
        Utilisateur.id == current_user["id"],
        Utilisateur.clinic_id == current_user["clinic_id"],
    )
    praticien = await db.scalar(stmt)
    if not praticien:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Praticien non trouvé"
        )

    try:
        # Récupérer ou créer l'état dentaire
        stmt = select(EtatDentaire).where(
            and_(
                EtatDentaire.patient_id == patient_id,
                EtatDentaire.clinic_id == current_user["clinic_id"],
                EtatDentaire.numero_dent == numero_dent,
            )
        )
        etat_dentaire = await db.scalar(stmt)

        if not etat_dentaire:
            # Créer un nouvel état dentaire
            etat_dentaire = EtatDentaire(
                clinic_id=current_user["clinic_id"],
                patient_id=patient_id,
                numero_dent=numero_dent,
                statut=data.statut,
                face=data.face,
                praticien_id=current_user["id"],
                notes=data.notes,
                date_modification=datetime.utcnow(),
            )
            db.add(etat_dentaire)
            await db.flush()

            # Créer l'événement historique (première création)
            historique = HistoriqueDentaire(
                clinic_id=current_user["clinic_id"],
                etat_dentaire_id=etat_dentaire.id,
                patient_id=patient_id,
                numero_dent=numero_dent,
                statut_ancien=None,
                statut_nouveau=data.statut,
                face_ancien=None,
                face_nouveau=data.face,
                praticien_id=current_user["id"],
                notes=data.notes,
            )
            db.add(historique)
        else:
            # Mettre à jour l'état dentaire existant
            statut_ancien = etat_dentaire.statut
            face_ancien = etat_dentaire.face

            etat_dentaire.statut = data.statut
            etat_dentaire.face = data.face
            etat_dentaire.notes = data.notes
            etat_dentaire.praticien_id = current_user["id"]
            etat_dentaire.date_modification = datetime.utcnow()
            etat_dentaire.updated_at = datetime.utcnow()

            # Créer l'événement historique
            historique = HistoriqueDentaire(
                clinic_id=current_user["clinic_id"],
                etat_dentaire_id=etat_dentaire.id,
                patient_id=patient_id,
                numero_dent=numero_dent,
                statut_ancien=statut_ancien,
                statut_nouveau=data.statut,
                face_ancien=face_ancien,
                face_nouveau=data.face,
                praticien_id=current_user["id"],
                notes=data.notes,
            )
            db.add(historique)

        # Enregistrer dans l'audit médical
        audit_log = AuditLogMedical(
            clinic_id=current_user["clinic_id"],
            utilisateur_id=current_user["id"],
            patient_id=patient_id,
            action="UPDATE_DENT",
            resource_type="etat_dentaire",
            resource_id=etat_dentaire.id,
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
            details={
                "numero_dent": numero_dent,
                "statut_ancien": etat_dentaire.statut if etat_dentaire else None,
                "statut_nouveau": data.statut,
                "face": data.face,
            },
        )
        db.add(audit_log)
        await log_event(
            db,
            utilisateur_id=current_user["id"],
            clinic_id=current_user["clinic_id"],
            action="UPDATE_DENT",
            resource_type="etat_dentaire",
            resource_id=etat_dentaire.id,
            patient_id=patient_id,
            details={
                "numero_dent": numero_dent,
                "statut_nouveau": data.statut,
                "face": data.face,
            },
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )

        # Commit de la transaction
        await db.commit()
        await db.refresh(etat_dentaire)

        return EtatDentaireResponse.from_orm(etat_dentaire)

    except Exception as e:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erreur lors de la mise à jour de l'état dentaire : {str(e)}",
        )


@router.get(
    "/{patient_id}/odontogramme/{numero_dent}/historique",
    response_model=List[HistoriqueDentaireResponse],
)
async def get_historique_dent(
    patient_id: int,
    numero_dent: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.MEDECIN, RoleEnum.ESTHETICIENNE, RoleEnum.ASSISTANTE)
    ),
):
    """
    Récupère l'historique complet des modifications d'une dent.

    Permissions :
    - MEDECIN, ESTHETICIENNE, ASSISTANTE

    Audit :
    - Enregistre l'accès à l'historique
    """
    # Valider le numéro FDI
    try:
        NotationDentaire[f"DENT_{numero_dent}"]
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Numéro FDI invalide : {numero_dent}",
        )

    # Vérifier que le patient existe
    stmt = select(Patient).where(
        Patient.id == patient_id,
        Patient.clinic_id == current_user["clinic_id"],
    )
    patient = await db.scalar(stmt)
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Patient non trouvé"
        )

    # Récupérer l'historique (append-only, trié par date)
    stmt = (
        select(HistoriqueDentaire)
        .where(
            and_(
                HistoriqueDentaire.patient_id == patient_id,
                HistoriqueDentaire.clinic_id == current_user["clinic_id"],
                HistoriqueDentaire.numero_dent == numero_dent,
            )
        )
        .order_by(HistoriqueDentaire.created_at.asc())
    )
    historique = await db.scalars(stmt)
    historique_list = list(historique)

    # Enregistrer l'accès dans l'audit
    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="READ_HISTORIQUE_DENT",
        resource_type="historique_dentaire",
        resource_id=patient_id,
        clinic_id=current_user["clinic_id"],
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )

    return [HistoriqueDentaireResponse.from_orm(h) for h in historique_list]
