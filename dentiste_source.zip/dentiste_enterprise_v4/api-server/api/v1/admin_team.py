"""Gestion des membres d'équipe et journal d'audit administratif."""

from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.auth import get_password_hash
from middleware.clinic_rbac import require_role
from models.database import RoleEnum, Utilisateur
from services.audit_journal import list_events, log_event

router = APIRouter(prefix="/admin", tags=["administration"])
ADMIN_ROLES = (RoleEnum.DIRECTRICE, RoleEnum.ADMIN)


class TeamMemberCreate(BaseModel):
    email: EmailStr
    nom: str = Field(min_length=1, max_length=100)
    prenom: str = Field(min_length=1, max_length=100)
    role: RoleEnum
    mot_de_passe: str = Field(min_length=12, max_length=128)
    telephone: Optional[str] = Field(default=None, max_length=20)
    specialite: Optional[str] = Field(default=None, max_length=100)
    agenda_color: Optional[str] = Field(default=None, pattern=r"^#[0-9A-Fa-f]{6}$")
    taux_commission: Decimal = Field(default=Decimal("0.00"), ge=0, le=100)


class TeamMemberUpdate(BaseModel):
    nom: Optional[str] = Field(default=None, min_length=1, max_length=100)
    prenom: Optional[str] = Field(default=None, min_length=1, max_length=100)
    role: Optional[RoleEnum] = None
    telephone: Optional[str] = Field(default=None, max_length=20)
    specialite: Optional[str] = Field(default=None, max_length=100)
    agenda_color: Optional[str] = Field(default=None, pattern=r"^#[0-9A-Fa-f]{6}$")
    taux_commission: Optional[Decimal] = Field(default=None, ge=0, le=100)
    is_active: Optional[bool] = None


class PasswordReset(BaseModel):
    mot_de_passe: str = Field(min_length=12, max_length=128)


def _serialize_member(user: Utilisateur) -> dict:
    return {
        "id": user.id,
        "email": user.email,
        "nom": user.nom,
        "prenom": user.prenom,
        "role": getattr(user.role, "value", user.role),
        "telephone": user.telephone,
        "specialite": user.specialite,
        "agenda_color": user.agenda_color,
        "taux_commission": str(user.taux_commission or Decimal("0.00")),
        "is_active": user.is_active,
        "mfa_enabled": user.mfa_enabled,
        "created_at": user.created_at.isoformat() if user.created_at else None,
        "last_login": user.last_login.isoformat() if user.last_login else None,
    }


def _ensure_role_allowed(actor: dict, role: RoleEnum) -> None:
    if role == RoleEnum.ADMIN and actor.get("role") != RoleEnum.ADMIN.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Seul un administrateur peut créer ou attribuer le rôle admin.",
        )


@router.get("/team", response_model=list[dict])
async def list_team(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*ADMIN_ROLES)),
):
    result = await db.execute(
        select(Utilisateur)
        .where(Utilisateur.clinic_id == current_user["clinic_id"])
        .order_by(Utilisateur.nom, Utilisateur.prenom)
    )
    return [_serialize_member(user) for user in result.scalars().all()]


@router.post("/team", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_team_member(
    payload: TeamMemberCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*ADMIN_ROLES)),
):
    _ensure_role_allowed(current_user, payload.role)
    email = payload.email.lower()
    existing = await db.execute(select(Utilisateur).where(Utilisateur.email == email))
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Cette adresse email possède déjà un compte.")

    user = Utilisateur(
        clinic_id=current_user["clinic_id"],
        email=email,
        hashed_password=get_password_hash(payload.mot_de_passe),
        nom=payload.nom.strip(),
        prenom=payload.prenom.strip(),
        role=payload.role.value,
        telephone=payload.telephone,
        specialite=payload.specialite,
        agenda_color=payload.agenda_color,
        taux_commission=payload.taux_commission,
        is_active=True,
    )
    db.add(user)
    await db.flush()
    await log_event(
        db,
        utilisateur_id=current_user["id"],
        clinic_id=current_user["clinic_id"],
        action="CREATE_TEAM_MEMBER",
        resource_type="utilisateur",
        resource_id=user.id,
        details={"email": user.email, "role": user.role},
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    return _serialize_member(user)


@router.patch("/team/{user_id}", response_model=dict)
async def update_team_member(
    user_id: int,
    payload: TeamMemberUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*ADMIN_ROLES)),
):
    result = await db.execute(
        select(Utilisateur).where(
            Utilisateur.id == user_id,
            Utilisateur.clinic_id == current_user["clinic_id"],
        )
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Membre introuvable.")
    data = payload.model_dump(exclude_unset=True)
    if data.get("role") is not None:
        _ensure_role_allowed(current_user, data["role"])
        data["role"] = data["role"].value
    changed = {}
    for field, value in data.items():
        if field == "role" or value is not None:
            setattr(user, field, value)
            if field != "is_active":
                changed[field] = value
            else:
                changed[field] = bool(value)
    await db.flush()
    await log_event(
        db,
        utilisateur_id=current_user["id"],
        clinic_id=current_user["clinic_id"],
        action="UPDATE_TEAM_MEMBER",
        resource_type="utilisateur",
        resource_id=user.id,
        details={"changed_fields": sorted(changed)},
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    return _serialize_member(user)


@router.post("/team/{user_id}/reset-password", response_model=dict)
async def reset_team_member_password(
    user_id: int,
    payload: PasswordReset,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*ADMIN_ROLES)),
):
    result = await db.execute(
        select(Utilisateur).where(
            Utilisateur.id == user_id,
            Utilisateur.clinic_id == current_user["clinic_id"],
        )
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Membre introuvable.")
    user.hashed_password = get_password_hash(payload.mot_de_passe)
    await db.flush()
    await log_event(
        db,
        utilisateur_id=current_user["id"],
        clinic_id=current_user["clinic_id"],
        action="RESET_TEAM_MEMBER_PASSWORD",
        resource_type="utilisateur",
        resource_id=user.id,
        details={"target_email": user.email},
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    return {"status": "ok", "message": "Mot de passe réinitialisé."}


@router.get("/audit", response_model=list[dict])
async def get_audit_log(
    patient_id: Optional[int] = Query(None, ge=1),
    utilisateur_id: Optional[int] = Query(None, ge=1),
    resource_type: Optional[str] = Query(None, max_length=60),
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*ADMIN_ROLES)),
):
    return await list_events(
        db,
        clinic_id=current_user["clinic_id"],
        patient_id=patient_id,
        utilisateur_id=utilisateur_id,
        resource_type=resource_type,
        limit=limit,
    )


@router.get("/audit/patients/{patient_id}", response_model=list[dict])
async def get_patient_audit(
    patient_id: int,
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*ADMIN_ROLES)),
):
    return await list_events(
        db,
        clinic_id=current_user["clinic_id"],
        patient_id=patient_id,
        limit=limit,
    )
