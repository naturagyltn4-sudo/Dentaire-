"""
AutoCommerce Clinic — API Prothèses et Laboratoire (BLOC 6)
"""

from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from models.database import (
    CommandeProthese,
    Patient,
    RoleEnum,
)
from api.deps import get_db
from middleware.clinic_rbac import require_role
from services.protheses import (
    create_commande_prothese,
    poser_prothese,
)
from services.audit_medical import log_access

router = APIRouter(prefix="/protheses", tags=["protheses"])


# ── Schémas Pydantic ───────────────────────────────────────


class CommandeProtheseCreate(BaseModel):
    dent: Optional[str] = Field(None, description="Numéro FDI de la dent (ex: 16)")
    dents: Optional[str] = Field(None, description="Numéros FDI des dents (ex: 16,17)")
    type: str = Field(..., description="couronne, bridge, prothèse amovible, implant")
    laboratoire: str = Field(..., description="Nom du laboratoire")
    date_commande: Optional[date] = Field(None, description="Date de commande")
    date_reception_prevue: date = Field(..., description="Date de réception prévue")
    cout: Decimal = Field(..., description="Coût de la prothèse")


class CommandeProtheseUpdate(BaseModel):
    dent: Optional[str] = None
    dents: Optional[str] = None
    type: Optional[str] = None
    laboratoire: Optional[str] = None
    date_reception_prevue: Optional[date] = None
    date_reception_reelle: Optional[date] = None
    statut: Optional[str] = None
    cout: Optional[Decimal] = None


class CommandeProtheseResponse(BaseModel):
    id: int
    clinic_id: int
    patient_id: int
    dent: Optional[str] = None
    dents: Optional[str] = None
    type: str
    laboratoire: str
    date_commande: date
    date_reception_prevue: date
    date_reception_reelle: Optional[date] = None
    statut: str
    cout: Decimal
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ── Endpoints ────────────────────────────────────────────


@router.post(
    "/patient/{patient_id}",
    response_model=CommandeProtheseResponse,
    status_code=status.HTTP_201_CREATED,
)
async def creer_commande_prothese(
    patient_id: int,
    data: CommandeProtheseCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.ASSISTANTE
        )
    ),
):
    """Créer une commande de prothèse pour un patient."""
    try:
        commande = await create_commande_prothese(
            db=db,
            patient_id=patient_id,
            type_prothese=data.type,
            praticien_id=current_user["id"],
            laboratoire=data.laboratoire,
            date_reception_prevue=data.date_reception_prevue,
            cout=data.cout,
            dent=data.dent,
            dents=data.dents,
            date_commande=data.date_commande,
            clinic_id=current_user["clinic_id"],
        )
        await db.commit()
        await db.refresh(commande)
        return commande
    except ValueError as e:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get(
    "/patient/{patient_id}", response_model=List[CommandeProtheseResponse]
)
async def lister_protheses_patient(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.ASSISTANTE
        )
    ),
):
    """Lister toutes les commandes de prothèses d'un patient."""
    patient = await db.scalar(
        select(Patient).where(
            Patient.id == patient_id,
            Patient.clinic_id == current_user["clinic_id"],
        )
    )
    if not patient:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Patient non trouvé"
        )

    result = await db.execute(
        select(CommandeProthese)
        .where(
            CommandeProthese.patient_id == patient_id,
            CommandeProthese.clinic_id == current_user["clinic_id"],
        )
        .order_by(CommandeProthese.created_at.desc())
    )
    commandes = list(result.scalars().all())

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="READ_COMMANDES_PROTHESES_PATIENT",
        resource_type="commande_prothese",
        resource_id=0,
    )

    return commandes


@router.get("/", response_model=List[CommandeProtheseResponse])
async def lister_toutes_protheses(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.ASSISTANTE
        )
    ),
):
    """Lister toutes les commandes de prothèses de la clinique."""
    result = await db.execute(
        select(CommandeProthese)
        .where(CommandeProthese.clinic_id == current_user["clinic_id"])
        .order_by(CommandeProthese.created_at.desc())
    )
    commandes = list(result.scalars().all())
    return commandes


@router.get("/{prothese_id}", response_model=CommandeProtheseResponse)
async def get_prothese(
    prothese_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN, RoleEnum.ASSISTANTE
        )
    ),
):
    """Obtenir les détails d'une commande de prothèse."""
    commande = await db.scalar(
        select(CommandeProthese).where(
            CommandeProthese.id == prothese_id,
            CommandeProthese.clinic_id == current_user["clinic_id"],
        )
    )
    if not commande:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Prothèse non trouvée"
        )

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=commande.patient_id,
        action="READ_COMMANDE_PROTHESE",
        resource_type="commande_prothese",
        resource_id=commande.id,
    )

    return commande


@router.patch("/{prothese_id}", response_model=CommandeProtheseResponse)
async def modifier_prothese(
    prothese_id: int,
    data: CommandeProtheseUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)
    ),
):
    """Modifier une commande de prothèse."""
    commande = await db.scalar(
        select(CommandeProthese).where(
            CommandeProthese.id == prothese_id,
            CommandeProthese.clinic_id == current_user["clinic_id"],
        )
    )
    if not commande:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Prothèse non trouvée"
        )

    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(commande, field, value)

    commande.updated_at = datetime.utcnow()
    await db.commit()
    await db.refresh(commande)

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=commande.patient_id,
        action="UPDATE_COMMANDE_PROTHESE",
        resource_type="commande_prothese",
        resource_id=commande.id,
    )

    return commande


@router.post("/{prothese_id}/poser", response_model=CommandeProtheseResponse)
async def poser_commande_prothese(
    prothese_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.MEDECIN)),
):
    """
    Poser une prothèse :
    - Met à jour le statut de la prothèse à 'pose'
    - Met à jour l'EtatDentaire de la/les dents concernées
    - Crée un HistoriqueDentaire
    - Tout de manière atomique (transaction unique)
    """
    try:
        commande = await poser_prothese(
            db=db,
                prothese_id=prothese_id,
                praticien_id=current_user["id"],
                clinic_id=current_user["clinic_id"],
            )
        return commande
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.delete("/{prothese_id}", status_code=status.HTTP_204_NO_CONTENT)
async def supprimer_prothese(
    prothese_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    """Supprimer une commande de prothèse."""
    commande = await db.scalar(
        select(CommandeProthese).where(
            CommandeProthese.id == prothese_id,
            CommandeProthese.clinic_id == current_user["clinic_id"],
        )
    )
    if not commande:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Prothèse non trouvée"
        )

    await db.delete(commande)
    await db.commit()
    return None
