"""
AutoCommerce Clinic — API Simulation IA
Génération de simulations avant/après.
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum, SimulationIA
from services.simulation_morphing import generer_simulation_ia, get_decrypted_simulation
from services.consentement import sign_consent

router = APIRouter(prefix="/simulation-ia", tags=["simulation-ia"])


class SimulationRequest(BaseModel):
    zone_anatomique: str = Field(..., min_length=2)
    intensite: int = Field(default=20, ge=0, le=100)
    instructions: Optional[str] = None
    masque_base64: Optional[str] = None


class SimulationIAConsentRequest(BaseModel):
    signature_base64: str
    methode_signature: str = "tactile"


async def _sign_simulation_ia_consent(
    patient_id: int,
    data: SimulationIAConsentRequest,
    request: Request,
    db: AsyncSession,
) -> dict:
    """Point commun de signature du consentement simulation IA.

    Correctif Bug #10 : expose explicitement un flux backend dédié à la
    signature tactile du consentement ``simulation_ia``.
    """
    try:
        consent = await sign_consent(
            patient_id=patient_id,
            acte_id=None,
            signature_b64=data.signature_base64,
            method=data.methode_signature,
            ip_address=request.client.host if request.client else None,
            db=db,
            type_consentement="simulation_ia",
        )
        return {
            "consentement_id": consent.id,
            "type_consentement": consent.type_consentement,
            "est_valide": consent.est_valide,
            "signe_le": consent.signe_le.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/patients/{patient_id}/consentement", response_model=dict)
async def create_simulation_ia_consent(
    patient_id: int,
    data: SimulationIAConsentRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.DIRECTRICE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Compatibilité historique : signe le consentement simulation IA."""
    return await _sign_simulation_ia_consent(patient_id, data, request, db)


@router.post("/patients/{patient_id}/consents/simulation-ia", response_model=dict)
async def create_simulation_ia_consent_explicit(
    patient_id: int,
    data: SimulationIAConsentRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.DIRECTRICE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Route explicite recommandée par l'audit pour le consentement simulation IA."""
    return await _sign_simulation_ia_consent(patient_id, data, request, db)


@router.post("/patients/{patient_id}/photos/{photo_id}/simuler", response_model=dict)
async def post_simulation(
    patient_id: int,
    photo_id: int,
    data: SimulationRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)
    ),
):
    """Génère une simulation IA pour une photo donnée."""
    try:
        simulation = await generer_simulation_ia(
            patient_id=patient_id,
            photo_source_id=photo_id,
            zone=data.zone_anatomique,
            intensite=data.intensite,
            instructions=data.instructions,
            masque_base64=data.masque_base64,
            genere_par_id=current_user["id"],
            db=db,
            clinic_id=current_user["clinic_id"],
        )
        return {
            "simulation_id": simulation.id,
            "url_resultat": f"/api/v1/simulation-ia/patients/{patient_id}/simulations/{simulation.id}/view",
            "created_at": simulation.created_at.isoformat(),
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/patients/{patient_id}/simulations", response_model=List[dict])
async def list_simulations(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN
        )
    ),
):
    """Liste les simulations IA d'un patient."""
    result = await db.execute(
        select(SimulationIA).where(
            SimulationIA.patient_id == patient_id,
            SimulationIA.clinic_id == current_user["clinic_id"],
        )
    )
    simulations = result.scalars().all()
    return [
        {
            "id": s.id,
            "photo_source_id": s.photo_source_id,
            "zone_anatomique": s.zone_anatomique,
            "url_resultat": f"/api/v1/simulation-ia/patients/{patient_id}/simulations/{s.id}/view",
            "created_at": s.created_at.isoformat(),
        }
        for s in simulations
    ]


@router.get("/patients/{patient_id}/simulations/{simulation_id}/view")
async def view_simulation(
    patient_id: int,
    simulation_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN
        )
    ),
):
    """Affiche l'image déchiffrée de la simulation."""
    try:
        img_bytes, filename = await get_decrypted_simulation(
            simulation_id=simulation_id,
            patient_id=patient_id,
            db=db,
            utilisateur_id=current_user["id"],
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
            clinic_id=current_user["clinic_id"],
        )
        return Response(
            content=img_bytes,
            media_type="image/jpeg",
            headers={"Content-Disposition": f"inline; filename={filename}"},
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
