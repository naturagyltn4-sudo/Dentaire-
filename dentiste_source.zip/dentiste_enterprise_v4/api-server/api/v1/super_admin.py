"""Pilotage global réservé au rôle superadmin.

Cette surface ne retourne pas de contenu médical ; elle expose uniquement des
métriques agrégées, la gestion des tenants, des abonnements et des comptes.
"""

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.auth import get_password_hash
from middleware.clinic_rbac import require_role
from models.database import (
    Facture,
    JournalAudit,
    Patient,
    RendezVous,
    RoleEnum,
    Utilisateur,
)
from models.security import AlerteSecurite
from models.superadmin import ClinicSubscription, CliniqueTenant
from services.audit_journal import log_event

router = APIRouter(prefix="/super-admin", tags=["super admin"])


class ClinicCreate(BaseModel):
    nom: str = Field(min_length=2, max_length=200)
    slug: str = Field(min_length=2, max_length=120, pattern=r"^[a-z0-9][a-z0-9-]+[a-z0-9]$")
    email_contact: Optional[str] = Field(default=None, max_length=255)
    telephone_contact: Optional[str] = Field(default=None, max_length=30)
    plan: str = Field(default="enterprise", max_length=40)
    statut_abonnement: str = Field(default="trial", max_length=20)


class ClinicUpdate(BaseModel):
    nom: Optional[str] = Field(default=None, min_length=2, max_length=200)
    statut: Optional[str] = Field(default=None, pattern=r"^(active|suspended|archived)$")
    email_contact: Optional[str] = Field(default=None, max_length=255)
    telephone_contact: Optional[str] = Field(default=None, max_length=30)
    fuseau_horaire: Optional[str] = Field(default=None, max_length=60)


class SubscriptionUpdate(BaseModel):
    plan: Optional[str] = Field(default=None, max_length=40)
    statut: Optional[str] = Field(default=None, pattern=r"^(trial|active|past_due|cancelled|suspended)$")
    expires_at: Optional[datetime] = None
    user_limit: Optional[int] = Field(default=None, ge=1, le=100000)
    storage_limit_gb: Optional[int] = Field(default=None, ge=1, le=100000)
    notes: Optional[str] = Field(default=None, max_length=2000)


class UserGlobalUpdate(BaseModel):
    is_active: Optional[bool] = None
    role: Optional[RoleEnum] = None


class PasswordReset(BaseModel):
    mot_de_passe: str = Field(min_length=12, max_length=128)


async def _count(db: AsyncSession, model, clinic_id: Optional[int] = None) -> int:
    query = select(func.count()).select_from(model)
    if clinic_id is not None and hasattr(model, "clinic_id"):
        query = query.where(model.clinic_id == clinic_id)
    return int(await db.scalar(query) or 0)


async def _clinic_ids(db: AsyncSession) -> list[int]:
    ids: set[int] = set()
    for model in (Utilisateur, Patient, CliniqueTenant, ClinicSubscription):
        result = await db.execute(select(model.id if model is CliniqueTenant else model.clinic_id).distinct())
        ids.update(int(value) for value in result.scalars().all() if value and int(value) > 0)
    return sorted(ids)


def _subscription_dict(subscription: Optional[ClinicSubscription]) -> dict:
    if not subscription:
        return {"plan": "non_configure", "statut": "non_configure", "user_limit": None, "storage_limit_gb": None}
    return {
        "id": subscription.id,
        "plan": subscription.plan,
        "statut": subscription.statut,
        "started_at": subscription.started_at.isoformat() if subscription.started_at else None,
        "expires_at": subscription.expires_at.isoformat() if subscription.expires_at else None,
        "user_limit": subscription.user_limit,
        "storage_limit_gb": subscription.storage_limit_gb,
        "notes": subscription.notes,
    }


async def _clinic_payload(db: AsyncSession, clinic: CliniqueTenant, subscription: Optional[ClinicSubscription]) -> dict:
    users = await _count(db, Utilisateur, clinic.id)
    active_users = await db.scalar(
        select(func.count()).select_from(Utilisateur).where(
            Utilisateur.clinic_id == clinic.id,
            Utilisateur.is_active,
        )
    )
    return {
        "id": clinic.id,
        "nom": clinic.nom,
        "slug": clinic.slug,
        "statut": clinic.statut,
        "email_contact": clinic.email_contact,
        "telephone_contact": clinic.telephone_contact,
        "fuseau_horaire": clinic.fuseau_horaire,
        "created_at": clinic.created_at.isoformat() if clinic.created_at else None,
        "users_count": users,
        "active_users_count": int(active_users or 0),
        "patients_count": await _count(db, Patient, clinic.id),
        "appointments_count": await _count(db, RendezVous, clinic.id),
        "invoices_count": await _count(db, Facture, clinic.id),
        "subscription": _subscription_dict(subscription),
    }


@router.get("/overview", response_model=dict)
async def overview(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    clinic_ids = await _clinic_ids(db)
    revenue = await db.scalar(select(func.coalesce(func.sum(Facture.total_ttc), 0)))
    security_alerts = await db.scalar(
        select(func.count()).select_from(AlerteSecurite).where(AlerteSecurite.statut != "resolue")
    )
    registry_ids = set((await db.execute(select(CliniqueTenant.id))).scalars().all())
    tenants_without_registry = sum(1 for clinic_id in clinic_ids if clinic_id not in registry_ids)
    return {
        "generated_at": datetime.utcnow().isoformat(),
        "clinics_count": len(clinic_ids),
        "users_count": await _count(db, Utilisateur),
        "active_users_count": int(await db.scalar(select(func.count()).select_from(Utilisateur).where(Utilisateur.is_active)) or 0),
        "patients_count": await _count(db, Patient),
        "appointments_count": await _count(db, RendezVous),
        "invoices_count": await _count(db, Facture),
        "revenue_total": str(revenue),
        "security_alerts_open": int(security_alerts or 0),
        "tenants_without_registry": tenants_without_registry,
    }


@router.get("/clinics", response_model=list[dict])
async def list_clinics(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    registry = {clinic.id: clinic for clinic in (await db.execute(select(CliniqueTenant).order_by(CliniqueTenant.nom))).scalars().all()}
    subscriptions = {subscription.clinic_id: subscription for subscription in (await db.execute(select(ClinicSubscription))).scalars().all()}
    for clinic_id in await _clinic_ids(db):
        if clinic_id not in registry:
            registry[clinic_id] = CliniqueTenant(id=clinic_id, nom=f"Clinique {clinic_id}", slug=f"clinic-{clinic_id}", statut="active")
    return [await _clinic_payload(db, registry[clinic_id], subscriptions.get(clinic_id)) for clinic_id in sorted(registry)]


@router.post("/clinics", response_model=dict, status_code=status.HTTP_201_CREATED)
async def create_clinic(
    payload: ClinicCreate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    if await db.scalar(select(CliniqueTenant.id).where(CliniqueTenant.slug == payload.slug)):
        raise HTTPException(status_code=409, detail="Ce slug clinique existe déjà")
    clinic = CliniqueTenant(
        nom=payload.nom.strip(), slug=payload.slug, email_contact=payload.email_contact,
        telephone_contact=payload.telephone_contact, statut="active",
    )
    db.add(clinic)
    await db.flush()
    subscription = ClinicSubscription(clinic_id=clinic.id, plan=payload.plan, statut=payload.statut_abonnement)
    db.add(subscription)
    await db.flush()
    await log_event(db, utilisateur_id=current_user["id"], clinic_id=clinic.id, action="SUPERADMIN_CREATE_CLINIC", resource_type="clinic", resource_id=clinic.id, details={"slug": clinic.slug}, ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    return await _clinic_payload(db, clinic, subscription)


@router.patch("/clinics/{clinic_id}", response_model=dict)
async def update_clinic(
    clinic_id: int,
    payload: ClinicUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    clinic = await db.scalar(select(CliniqueTenant).where(CliniqueTenant.id == clinic_id))
    if not clinic:
        raise HTTPException(status_code=404, detail="Clinique non enregistrée")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(clinic, field, value)
    await db.flush()
    await log_event(db, utilisateur_id=current_user["id"], clinic_id=clinic_id, action="SUPERADMIN_UPDATE_CLINIC", resource_type="clinic", resource_id=clinic_id, details=payload.model_dump(exclude_unset=True), ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    subscription = await db.scalar(select(ClinicSubscription).where(ClinicSubscription.clinic_id == clinic_id))
    return await _clinic_payload(db, clinic, subscription)


@router.patch("/clinics/{clinic_id}/subscription", response_model=dict)
async def update_subscription(
    clinic_id: int,
    payload: SubscriptionUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    if not await db.scalar(select(CliniqueTenant.id).where(CliniqueTenant.id == clinic_id)):
        raise HTTPException(status_code=404, detail="Clinique non enregistrée")
    subscription = await db.scalar(select(ClinicSubscription).where(ClinicSubscription.clinic_id == clinic_id))
    if not subscription:
        subscription = ClinicSubscription(clinic_id=clinic_id)
        db.add(subscription)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(subscription, field, value)
    await db.flush()
    await log_event(db, utilisateur_id=current_user["id"], clinic_id=clinic_id, action="SUPERADMIN_UPDATE_SUBSCRIPTION", resource_type="clinic_subscription", resource_id=subscription.id, details=payload.model_dump(exclude_unset=True), ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    return _subscription_dict(subscription)


@router.get("/users", response_model=list[dict])
async def list_global_users(
    clinic_id: Optional[int] = None,
    limit: int = 500,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    query = select(Utilisateur).order_by(Utilisateur.clinic_id, Utilisateur.nom, Utilisateur.prenom).limit(min(max(limit, 1), 1000))
    if clinic_id is not None:
        query = query.where(Utilisateur.clinic_id == clinic_id)
    users = (await db.execute(query)).scalars().all()
    return [{"id": user.id, "clinic_id": user.clinic_id, "email": user.email, "nom": user.nom, "prenom": user.prenom, "role": user.role, "is_active": user.is_active, "mfa_enabled": user.mfa_enabled, "last_login": user.last_login.isoformat() if user.last_login else None} for user in users]


@router.patch("/users/{user_id}", response_model=dict)
async def update_global_user(
    user_id: int,
    payload: UserGlobalUpdate,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    if user_id == current_user["id"] and payload.is_active is False:
        raise HTTPException(status_code=409, detail="Le Super Admin courant ne peut pas désactiver sa propre session")
    user = await db.scalar(select(Utilisateur).where(Utilisateur.id == user_id))
    if not user:
        raise HTTPException(status_code=404, detail="Compte introuvable")
    data = payload.model_dump(exclude_unset=True)
    if data.get("role") is not None:
        data["role"] = data["role"].value
    for field, value in data.items():
        setattr(user, field, value)
    await db.flush()
    await log_event(db, utilisateur_id=current_user["id"], clinic_id=user.clinic_id, action="SUPERADMIN_UPDATE_USER", resource_type="utilisateur", resource_id=user.id, details={"changed": sorted(data)}, ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    return {"id": user.id, "clinic_id": user.clinic_id, "email": user.email, "nom": user.nom, "prenom": user.prenom, "role": user.role, "is_active": user.is_active, "mfa_enabled": user.mfa_enabled}


@router.post("/users/{user_id}/reset-password", response_model=dict)
async def reset_global_user_password(
    user_id: int,
    payload: PasswordReset,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    user = await db.scalar(select(Utilisateur).where(Utilisateur.id == user_id))
    if not user:
        raise HTTPException(status_code=404, detail="Compte introuvable")
    user.hashed_password = get_password_hash(payload.mot_de_passe)
    await db.flush()
    await log_event(db, utilisateur_id=current_user["id"], clinic_id=user.clinic_id, action="SUPERADMIN_RESET_PASSWORD", resource_type="utilisateur", resource_id=user.id, details={"target_email": user.email}, ip_address=request.client.host if request.client else None, user_agent=request.headers.get("user-agent"))
    return {"status": "ok", "message": "Mot de passe réinitialisé"}


@router.get("/audit", response_model=list[dict])
async def global_audit(
    limit: int = 200,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    rows = (await db.execute(select(JournalAudit, Utilisateur).outerjoin(Utilisateur, Utilisateur.id == JournalAudit.utilisateur_id).order_by(JournalAudit.created_at.desc()).limit(min(max(limit, 1), 500)))).all()
    return [{"id": event.id, "clinic_id": event.clinic_id, "created_at": event.created_at.isoformat() if event.created_at else None, "action": event.action, "resource_type": event.resource_type, "resource_id": event.resource_id, "utilisateur_id": event.utilisateur_id, "utilisateur_nom": f"{actor.prenom} {actor.nom}" if actor else "Système", "details": event.details or {}} for event, actor in rows]


@router.get("/health", response_model=dict)
async def global_health(
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(RoleEnum.SUPERADMIN)),
):
    checks = {"api": "ok", "database": "unknown", "redis": "unknown"}
    try:
        await db.execute(select(1))
        checks["database"] = "ok"
    except Exception:
        checks["database"] = "error"
    try:
        import redis.asyncio as redis
        from config import get_settings
        client = redis.from_url(get_settings().redis_url, socket_connect_timeout=1, socket_timeout=1)
        await client.ping()
        checks["redis"] = "ok"
        await client.aclose()
    except Exception:
        checks["redis"] = "degraded"
    return {"generated_at": datetime.utcnow().isoformat(), "environment": __import__("config").get_settings().env, "checks": checks, "status": "ok" if checks["database"] == "ok" else "degraded"}
