"""Dentiste Enterprise — API Pointage & RH
Gestion du temps de présence des praticiens et du personnel.
"""

from datetime import datetime, date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, get_current_user
from middleware.clinic_rbac import require_role
from models.database import RoleEnum, Pointage, Utilisateur

router = APIRouter(prefix="/pointage", tags=["pointage"])

class PointageOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    debut: datetime
    fin: Optional[datetime] = None
    duree_minutes: Optional[int] = None
    notes: Optional[str] = None

class PointageStatus(BaseModel):
    is_clocked_in: bool
    current_pointage: Optional[PointageOut] = None

class PointageReportItem(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    date: date
    debut: datetime
    fin: Optional[datetime]
    duree_minutes: int

class UserReport(BaseModel):
    utilisateur_id: int
    nom_complet: str
    total_minutes: int
    details: List[PointageReportItem]

@router.get("/statut", response_model=PointageStatus)
async def get_pointage_status(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Vérifie si l'utilisateur est actuellement pointé (en cours)."""
    result = await db.execute(
        select(Pointage)
        .where(
            Pointage.utilisateur_id == current_user["id"],
            Pointage.fin.is_(None)
        )
        .order_by(Pointage.debut.desc())
    )
    current = result.scalar_one_or_none()
    
    return {
        "is_clocked_in": current is not None,
        "current_pointage": current
    }

@router.post("/entree", response_model=PointageOut)
async def clock_in(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Marque l'arrivée du praticien/membre."""
    check = await db.execute(
        select(Pointage).where(Pointage.utilisateur_id == current_user["id"], Pointage.fin.is_(None))
    )
    if check.scalar_one_or_none():
        raise HTTPException(400, "Vous êtes déjà pointé à l'arrivée.")

    new_p = Pointage(
        clinic_id=current_user["clinic_id"],
        utilisateur_id=current_user["id"],
        debut=datetime.utcnow()
    )
    db.add(new_p)
    await db.commit()
    await db.refresh(new_p)
    return new_p

@router.post("/sortie", response_model=PointageOut)
async def clock_out(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Marque le départ du praticien/membre."""
    result = await db.execute(
        select(Pointage)
        .where(Pointage.utilisateur_id == current_user["id"], Pointage.fin.is_(None))
        .order_by(Pointage.debut.desc())
    )
    current = result.scalar_one_or_none()
    
    if not current:
        raise HTTPException(400, "Aucun pointage en cours trouvé.")

    current.fin = datetime.utcnow()
    delta = current.fin - current.debut
    current.duree_minutes = int(delta.total_seconds() / 60)
    
    await db.commit()
    await db.refresh(current)
    return current

@router.get("/admin/rapport", response_model=UserReport)
async def get_admin_report(
    utilisateur_id: int,
    date_debut: date,
    date_fin: date,
    current_user: dict = Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
    db: AsyncSession = Depends(get_db)
):
    """Génère le rapport de présence pour un employé sur une période donnée."""
    user_res = await db.execute(
        select(Utilisateur).where(Utilisateur.id == utilisateur_id, Utilisateur.clinic_id == current_user["clinic_id"])
    )
    target_user = user_res.scalar_one_or_none()
    if not target_user:
        raise HTTPException(404, "Utilisateur non trouvé dans votre cabinet.")

    pointages_res = await db.execute(
        select(Pointage)
        .where(
            Pointage.utilisateur_id == utilisateur_id,
            Pointage.debut >= datetime.combine(date_debut, datetime.min.time()),
            Pointage.debut <= datetime.combine(date_fin, datetime.max.time()),
            Pointage.fin.is_not(None)
        )
        .order_by(Pointage.debut.asc())
    )
    pointages = pointages_res.scalars().all()
    
    total_min = sum((p.duree_minutes or 0) for p in pointages)
    
    details = [
        PointageReportItem(
            date=p.debut.date(),
            debut=p.debut,
            fin=p.fin,
            duree_minutes=p.duree_minutes or 0
        ) for p in pointages
    ]
    
    return UserReport(
        utilisateur_id=target_user.id,
        nom_complet=f"{target_user.prenom} {target_user.nom}",
        total_minutes=total_min,
        details=details
    )
