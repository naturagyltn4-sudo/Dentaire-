"""AutoCommerce Clinic — API Factures"""

from datetime import date
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum
from services.factures import (
    create_facture,
    marquer_payee,
    annuler_facture,
    list_factures,
    accepter_devis,
)
from services.pdf_generator import generate_invoice_pdf
from sqlalchemy import select
from models.database import (
    Facture,
    Patient,
    DevisTraitement,
    PriseEnChargeMutuelle,
    StatutDevis,
    StatutPriseEnCharge,
)

router = APIRouter(prefix="/factures", tags=["factures"])


class LigneFacture(BaseModel):
    description: str
    prix: Decimal
    quantite: int = 1


class FactureCreate(BaseModel):
    patient_id: int
    rdv_id: Optional[int] = None
    actes: list[LigneFacture] = []
    produits: list[LigneFacture] = []
    taux_tva: Decimal = Decimal("0.190")
    remise_globale_pct: Decimal = Decimal("0.00")
    date_echeance: Optional[date] = None
    notes: Optional[str] = None


class PaiementRequest(BaseModel):
    mode_paiement: str


class AnnulationRequest(BaseModel):
    motif: str


class FactureOut(BaseModel):
    id: int
    numero_facture: str
    patient_id: int
    total_ttc: Decimal
    statut: str
    date_emission: date

    class Config:
        from_attributes = True


class DevisCreate(BaseModel):
    patient_id: int
    acte_id: Optional[int] = None
    dent: Optional[str] = None
    prix: Decimal
    date_validite: Optional[date] = None
    lignes: Optional[list[dict]] = None


class DevisOut(BaseModel):
    id: int
    patient_id: int
    acte_id: Optional[int]
    dent: Optional[str]
    prix: Decimal
    statut: str
    date_validite: Optional[date]

    class Config:
        from_attributes = True


class PECMutuelleCreate(BaseModel):
    organisme: str
    numero_dossier: Optional[str] = None
    montant_pris_en_charge: Decimal


class PECMutuelleOut(BaseModel):
    id: int
    organisme: str
    numero_dossier: Optional[str]
    montant_pris_en_charge: Decimal
    statut: str

    class Config:
        from_attributes = True


@router.post("", response_model=FactureOut, status_code=status.HTTP_201_CREATED)
async def create_facture_route(
    payload: FactureCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    data = payload.model_dump()
    data["actes"] = [a for a in data["actes"]]
    data["produits"] = [p for p in data["produits"]]
    try:
        facture = await create_facture(
            data,
            created_by=current_user["id"],
            db=db,
            clinic_id=current_user["clinic_id"],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    return facture


@router.get("", response_model=list[FactureOut])
async def list_factures_route(
    response: Response,
    patient_id: Optional[int] = Query(None),
    statut: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=200),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.MEDECIN,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.ASSISTANTE,
            RoleEnum.ADMIN,
        )
    ),
):
    factures, total = await list_factures(
        db,
        patient_id=patient_id,
        statut=statut,
        skip=skip,
        limit=limit,
        clinic_id=current_user["clinic_id"],
    )
    response.headers["X-Total-Count"] = str(total)
    return factures


@router.post("/{facture_id}/payer")
async def payer_facture_route(
    facture_id: int,
    payload: PaiementRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    try:
        result = await marquer_payee(
            facture_id,
            payload.mode_paiement,
            db,
            clinic_id=current_user["clinic_id"],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    return {
        "statut": result["facture"].statut,
        "commission_generee": result["commission"] is not None,
        "points_gagnes": result["points_gagnes"],
    }


@router.post("/{facture_id}/annuler", response_model=FactureOut)
async def annuler_facture_route(
    facture_id: int,
    payload: AnnulationRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    try:
        facture = await annuler_facture(
            facture_id,
            payload.motif,
            db,
            clinic_id=current_user["clinic_id"],
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    return facture


# ── Devis ──────────────────────────────────────────────────


@router.get("/devis", response_model=list[DevisOut])
async def list_devis_route(
    patient_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.MEDECIN,
            RoleEnum.ASSISTANTE,
            RoleEnum.ADMIN,
        )
    ),
):
    """Lister tous les devis de la clinique."""
    query = select(DevisTraitement).where(
        DevisTraitement.clinic_id == current_user["clinic_id"]
    )
    if patient_id is not None:
        query = query.where(DevisTraitement.patient_id == patient_id)
    result = await db.execute(query.order_by(DevisTraitement.created_at.desc()))
    devis = list(result.scalars().all())
    return devis


@router.post("/devis", response_model=DevisOut, status_code=status.HTTP_201_CREATED)
async def create_devis(
    payload: DevisCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.MEDECIN, RoleEnum.ADMIN
        )
    ),
):
    devis = DevisTraitement(
        clinic_id=current_user["clinic_id"],
        patient_id=payload.patient_id,
        acte_id=payload.acte_id,
        dent=payload.dent,
        prix=payload.prix,
        date_validite=payload.date_validite,
        lignes=payload.lignes,
        statut=StatutDevis.BROUILLON.value,
    )
    db.add(devis)
    await db.flush()
    return devis


@router.post("/devis/{devis_id}/accepter", response_model=FactureOut)
async def accepter_devis_route(
    devis_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    try:
        facture = await accepter_devis(
            devis_id,
            created_by=current_user["id"],
            db=db,
            clinic_id=current_user["clinic_id"],
        )
        return facture
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


# ── Mutuelle ───────────────────────────────────────────────


@router.post("/{facture_id}/mutuelle", response_model=PECMutuelleOut)
async def add_pec_mutuelle(
    facture_id: int,
    payload: PECMutuelleCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    facture_result = await db.execute(
        select(Facture).where(
            Facture.id == facture_id,
            Facture.clinic_id == current_user["clinic_id"],
        )
    )
    if facture_result.scalar_one_or_none() is None:
        raise HTTPException(status_code=404, detail="Facture non trouvée")

    pec = PriseEnChargeMutuelle(
        clinic_id=current_user["clinic_id"],
        facture_id=facture_id,
        organisme=payload.organisme,
        numero_dossier=payload.numero_dossier,
        montant_pris_en_charge=payload.montant_pris_en_charge,
        statut=StatutPriseEnCharge.ACCEPTE.value,
    )
    db.add(pec)
    await db.flush()
    return pec


@router.get("/{facture_id}/reste-patient")
async def get_reste_patient(
    facture_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.MEDECIN,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.ASSISTANTE,
            RoleEnum.ADMIN,
        )
    ),
):
    res = await db.execute(
        select(Facture).where(
            Facture.id == facture_id,
            Facture.clinic_id == current_user["clinic_id"],
        )
    )
    facture = res.scalar_one_or_none()
    if not facture:
        raise HTTPException(status_code=404, detail="Facture non trouvée")

    res_pec = await db.execute(
        select(PriseEnChargeMutuelle).where(
            PriseEnChargeMutuelle.facture_id == facture_id,
            PriseEnChargeMutuelle.clinic_id == current_user["clinic_id"],
        )
    )
    pecs = res_pec.scalars().all()

    total_mutuelle = sum((p.montant_pris_en_charge for p in pecs), Decimal("0.000"))
    reste = facture.total_ttc - total_mutuelle

    return {
        "total_ttc": facture.total_ttc,
        "prise_en_charge_mutuelle": total_mutuelle,
        "reste_patient": reste.quantize(Decimal("0.001")),
    }


@router.get("/{facture_id}/pdf")
async def get_facture_pdf(
    facture_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    """Génère et retourne le PDF d'une facture."""
    result = await db.execute(
        select(Facture).where(
            Facture.id == facture_id,
            Facture.clinic_id == current_user["clinic_id"],
        )
    )
    facture = result.scalar_one_or_none()
    if not facture:
        raise HTTPException(status_code=404, detail="Facture non trouvée")

    patient_res = await db.execute(
        select(Patient).where(
            Patient.id == facture.patient_id,
            Patient.clinic_id == current_user["clinic_id"],
        )
    )
    patient = patient_res.scalar_one()

    from services.branding import get_branding_context

    branding = await get_branding_context(db, current_user["clinic_id"])

    pdf_bytes = await generate_invoice_pdf(facture, patient, branding)

    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": f'attachment; filename="facture_{facture.numero_facture}.pdf"'
        },
    )


@router.get("/devis/{facture_id}/pdf")
async def get_devis_pdf(
    facture_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)
    ),
):
    """Génère et retourne le PDF d'un devis (même logique que facture)."""
    return await get_facture_pdf(facture_id, db, current_user)
