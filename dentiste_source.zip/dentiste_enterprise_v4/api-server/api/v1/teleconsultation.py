from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, require_role
from models.database import RoleEnum
from services.teleconsultation import TeleconsultationService
from config import get_settings

router = APIRouter(prefix="/teleconsultation", tags=["teleconsultation"])


class TeleconsultationCreate(BaseModel):
    rdv_id: int
    consent_url: str = Field(min_length=12, max_length=500)


class TeleconsultationComplete(BaseModel):
    duree: Optional[int] = Field(default=None, ge=1, le=24 * 60)
    notes: Optional[str] = Field(default=None, max_length=5000)


READ_ROLES = [RoleEnum.ADMIN, RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ASSISTANTE]
WRITE_ROLES = [RoleEnum.ADMIN, RoleEnum.DIRECTRICE, RoleEnum.MEDECIN]


def _validate_consent_url(value: str) -> str:
    if not value.lower().startswith("https://"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Le lien de consentement doit utiliser HTTPS",
        )
    return value


@router.post("/creer")
async def creer_teleconsultation(
    data: TeleconsultationCreate,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(READ_ROLES)),
):
    consent_url = _validate_consent_url(data.consent_url)
    try:
        tc = await TeleconsultationService.creer_pour_rdv(
            db,
            data.rdv_id,
            clinic_id=current_user["clinic_id"],
            consent_url=consent_url,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not tc:
        raise HTTPException(status_code=404, detail="Rendez-vous non trouvé")
    settings = get_settings()
    return {
        "id": tc.id,
        "rdv_id": tc.rdv_id,
        "lien_visio": tc.lien_visio,
        "statut": tc.statut,
        "provider": tc.provider,
        "provider_daily": tc.provider == "daily",
        "expires_in_min": settings.daily_default_expires_min if tc.provider == "daily" else None,
        "consent_url": tc.consent_url,
    }


@router.get("/{rdv_id}/lien")
async def get_lien_visio(
    rdv_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(READ_ROLES)),
):
    tc = await TeleconsultationService.get_by_rdv(
        db, rdv_id, clinic_id=current_user["clinic_id"]
    )
    if not tc:
        raise HTTPException(
            status_code=404, detail="Téléconsultation non trouvée pour ce RDV"
        )
    settings = get_settings()
    return {
        "id": tc.id,
        "rdv_id": tc.rdv_id,
        "lien_visio": tc.lien_visio,
        "statut": tc.statut,
        "provider": tc.provider,
        "provider_daily": tc.provider == "daily",
        "expires_in_min": settings.daily_default_expires_min if tc.provider == "daily" else None,
        "consent_url": tc.consent_url,
    }


@router.post("/{tc_id}/terminer")
async def terminer_teleconsultation(
    tc_id: int,
    data: TeleconsultationComplete,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(WRITE_ROLES)),
):
    success = await TeleconsultationService.marquer_terminee(
        db,
        tc_id,
        data.duree,
        data.notes,
        clinic_id=current_user["clinic_id"],
    )
    if not success:
        raise HTTPException(status_code=404, detail="Téléconsultation non trouvée")
    return {"status": "success"}
