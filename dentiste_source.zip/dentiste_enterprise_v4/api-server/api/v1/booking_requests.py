"""File de traitement des demandes de réservation publique."""

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import ActeMedical, BookingRequest, RoleEnum, Utilisateur
from services.audit_journal import log_event
from services.reservation_publique import approuver_demande_public, rejeter_demande_public

router = APIRouter(prefix="/booking-requests", tags=["demandes publiques"])
PROCESSING_ROLES = (RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)


class RejectBookingRequest(BaseModel):
    motif: Optional[str] = Field(default=None, max_length=500)


def _serialize(request: BookingRequest, practitioner: Optional[Utilisateur], acte: Optional[ActeMedical]) -> dict:
    return {
        "id": request.id,
        "clinic_id": request.clinic_id,
        "nom": request.nom,
        "prenom": request.prenom,
        "telephone": request.telephone,
        "praticien_id": request.praticien_id,
        "praticien_nom": (
            f"{practitioner.prenom} {practitioner.nom}" if practitioner else "Praticien non disponible"
        ),
        "acte_id": request.acte_id,
        "acte_nom": acte.nom if acte else "Acte non disponible",
        "date_heure": request.date_heure.isoformat(),
        "statut": request.statut,
        "patient_id": request.patient_id,
        "rendez_vous_id": request.rendez_vous_id,
        "created_at": request.created_at.isoformat() if request.created_at else None,
        "validated_at": request.validated_at.isoformat() if request.validated_at else None,
        "rejected_at": request.rejected_at.isoformat() if request.rejected_at else None,
    }


async def _get_request_rows(db: AsyncSession, clinic_id: int, statut: Optional[str], limit: int):
    query = (
        select(BookingRequest, Utilisateur, ActeMedical)
        .outerjoin(Utilisateur, Utilisateur.id == BookingRequest.praticien_id)
        .outerjoin(ActeMedical, ActeMedical.id == BookingRequest.acte_id)
        .where(BookingRequest.clinic_id == clinic_id)
        .order_by(BookingRequest.created_at.desc())
        .limit(limit)
    )
    if statut:
        query = query.where(BookingRequest.statut == statut)
    return (await db.execute(query)).all()


@router.get("", response_model=list[dict])
async def list_booking_requests(
    statut: Optional[str] = Query("pending", pattern="^(pending|accepted|rejected)$"),
    limit: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*PROCESSING_ROLES)),
):
    rows = await _get_request_rows(db, current_user["clinic_id"], statut, limit)
    return [_serialize(request, practitioner, acte) for request, practitioner, acte in rows]


@router.post("/{booking_request_id}/approve", response_model=dict)
async def approve_booking_request(
    booking_request_id: int,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*PROCESSING_ROLES)),
):
    try:
        result = await approuver_demande_public(
            booking_request_id,
            db,
            clinic_id=current_user["clinic_id"],
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    await log_event(
        db,
        utilisateur_id=current_user["id"],
        clinic_id=current_user["clinic_id"],
        action="APPROVE_PUBLIC_BOOKING_REQUEST",
        resource_type="booking_request",
        resource_id=booking_request_id,
        details={"rdv_id": result["rdv_id"], "patient_id": result["patient_id"]},
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    return result


@router.post("/{booking_request_id}/reject", response_model=dict)
async def reject_booking_request(
    booking_request_id: int,
    payload: RejectBookingRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    current_user: dict = Depends(require_role(*PROCESSING_ROLES)),
):
    try:
        result = await rejeter_demande_public(
            booking_request_id,
            db,
            clinic_id=current_user["clinic_id"],
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    await log_event(
        db,
        utilisateur_id=current_user["id"],
        clinic_id=current_user["clinic_id"],
        action="REJECT_PUBLIC_BOOKING_REQUEST",
        resource_type="booking_request",
        resource_id=booking_request_id,
        details={"motif": payload.motif},
        ip_address=request.client.host if request.client else None,
        user_agent=request.headers.get("user-agent"),
    )
    return result
