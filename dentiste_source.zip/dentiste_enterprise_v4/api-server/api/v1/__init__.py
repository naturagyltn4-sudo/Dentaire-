"""
AutoCommerce Clinic — API v1 routers (v1.1.0 patch LLM)

Inclut 3 routers supplémentaires vs v1.1.0 de base :
- ``assistant_ia`` : routes conversationnelles + agent ReAct ;
- ``bi_insights``   : insights LLM du Bloc 8 ;
- ``workflow_extra``: décision LLM + approbation humaine des brouillons.
"""

from fastapi import APIRouter

from api.v1 import (
    agenda_clinic,
    assistant,
    auth,
    business_intelligence,
    commissions,
    copilote_crm,
    dashboard_ia,
    depenses_clinic,
    dossiers_medicaux,
    equipe,
    factures,
    fidelite,
    mfa,
    omnicanal,
    patients,
    recrutement,
    settings as settings_router,
    social,
    stock_injectable,
    workflow_engine,
    consommables,
    teleconsultation,
    parrainage,
    simulation_ia,
    odontogramme,
    dossier_complet,
    assistant_ia,
    bi_insights,
    workflow_extra,
    radiologie,
    protheses,
    orthodontie,
    ia_dentaire,
    suivi_post_op,
    delegues,
    cephalometrie_module,
    admin_team,
    pointage,
    plans_traitement,
    personnel,
    booking_requests,
    super_admin,
)

api_router = APIRouter(prefix="/api/v1")

api_router.include_router(auth.router)
api_router.include_router(assistant.router)
api_router.include_router(patients.router)
api_router.include_router(factures.router)
api_router.include_router(commissions.router)
api_router.include_router(fidelite.router)
api_router.include_router(recrutement.router)
api_router.include_router(social.router)
api_router.include_router(settings_router.router)
api_router.include_router(agenda_clinic.router)
api_router.include_router(depenses_clinic.router)
api_router.include_router(dossiers_medicaux.router)
api_router.include_router(odontogramme.router)
api_router.include_router(dossier_complet.router)
api_router.include_router(stock_injectable.router)
api_router.include_router(consommables.router)
api_router.include_router(teleconsultation.router)
api_router.include_router(parrainage.router)
api_router.include_router(mfa.router)
api_router.include_router(omnicanal.router)
api_router.include_router(dashboard_ia.router)
api_router.include_router(workflow_engine.router)
api_router.include_router(copilote_crm.router)
api_router.include_router(business_intelligence.router)
api_router.include_router(equipe.router)
api_router.include_router(simulation_ia.router)
api_router.include_router(radiologie.router)
api_router.include_router(protheses.router)
api_router.include_router(orthodontie.router)
api_router.include_router(ia_dentaire.router)
api_router.include_router(suivi_post_op.router)
api_router.include_router(delegues.router)
api_router.include_router(cephalometrie_module.router)
api_router.include_router(admin_team.router)
api_router.include_router(pointage.router)
api_router.include_router(plans_traitement.router)
api_router.include_router(personnel.router)
api_router.include_router(booking_requests.router)
api_router.include_router(super_admin.router)

# v1.1.0 — patch LLM
api_router.include_router(assistant_ia.router)
api_router.include_router(bi_insights.router)
api_router.include_router(workflow_extra.router)
