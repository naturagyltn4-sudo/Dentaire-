"""
AutoCommerce Clinic — API Authentification

N'existait pas : middleware/auth.py savait créer/décoder un JWT mais
aucune route n'exposait de moyen de se connecter. Ce fichier ajoute
login / refresh / me.
"""

from datetime import datetime
from typing import Union

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, EmailStr
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, limiter
from middleware.auth import (
    authenticate_user,
    create_tokens_for_user,
    rotate_refresh_token,
    revoke_refresh_token,
    create_mfa_challenge_token,
    get_current_active_user,
    get_db_user,
)
from config import get_settings

router = APIRouter(prefix="/auth", tags=["auth"])
settings = get_settings()


# ── Schémas ────────────────────────────────────────────────


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Réponse publique : le refresh token reste exclusivement dans le cookie."""

    access_token: str
    token_type: str
    expires_in: int


class MfaRequiredResponse(BaseModel):
    mfa_required: bool = True
    challenge_token: str


class UserOut(BaseModel):
    id: int
    email: str
    nom: str
    prenom: str
    role: str
    telephone: str | None = None
    specialite: str | None = None


# ── Routes ─────────────────────────────────────────────────


@router.post("/login", response_model=Union[TokenResponse, MfaRequiredResponse])
@limiter.limit("5/minute")
async def login(
    request: Request, response: Response, payload: LoginRequest, db: AsyncSession = Depends(get_db)
):
    user = await authenticate_user(payload.email, payload.password, db)
    if not user:
        # Message générique volontaire : ne pas révéler si l'email existe.
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Email ou mot de passe incorrect",
        )
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Compte désactivé"
        )

    # Si le MFA est activé, ne pas émettre les tokens tout de suite.
    # Le frontend doit appeler /auth/mfa/verify avec ce challenge_token +
    # l'OTP. Le token est signé et n'expose pas le user_id en clair côté
    # client (contrairement à l'ancien flux "MFA_REQUIRED" + lookup public
    # par email), et expire en 5 minutes.
    if user.mfa_enabled and user.mfa_secret:
        return MfaRequiredResponse(challenge_token=create_mfa_challenge_token(user.id))

    user.last_login = datetime.utcnow()
    await db.flush()

    tokens = await create_tokens_for_user(user, db)
    response.set_cookie(
        "refresh_token", tokens["refresh_token"], httponly=True, secure=settings.env == "production",
        samesite="lax", max_age=settings.refresh_token_expire_days * 86400, path="/api/v1/auth",
    )
    return TokenResponse(
        access_token=tokens["access_token"],
        token_type=tokens["token_type"],
        expires_in=tokens["expires_in"],
    )


@router.post("/refresh", response_model=TokenResponse)
@limiter.limit("10/minute")
async def refresh(
    request: Request, response: Response, db: AsyncSession = Depends(get_db)
):
    raw_token = request.cookies.get("refresh_token")
    if not raw_token:
        raise HTTPException(status_code=401, detail="Refresh token manquant")
    tokens = await rotate_refresh_token(raw_token, db)
    response.set_cookie(
        "refresh_token", tokens["refresh_token"], httponly=True, secure=settings.env == "production",
        samesite="lax", max_age=settings.refresh_token_expire_days * 86400, path="/api/v1/auth",
    )
    return TokenResponse(
        access_token=tokens["access_token"],
        token_type=tokens["token_type"],
        expires_in=tokens["expires_in"],
    )


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    raw_token = request.cookies.get("refresh_token", "")
    if raw_token:
        await revoke_refresh_token(raw_token, db)
    response.delete_cookie("refresh_token", path="/api/v1/auth")
    return None


@router.get("/me", response_model=UserOut)
async def me(
    current_user: dict = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    user = await get_db_user(current_user["id"], db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Utilisateur introuvable"
        )
    return UserOut(
        id=user.id,
        email=user.email,
        nom=user.nom,
        prenom=user.prenom,
        role=user.role,
        telephone=user.telephone,
        specialite=user.specialite,
    )
