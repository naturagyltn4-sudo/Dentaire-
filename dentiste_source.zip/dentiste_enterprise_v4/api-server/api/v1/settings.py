"""AutoCommerce Clinic — API Settings (branding) & réservation publique"""

from datetime import datetime
from typing import Optional

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Request,
    UploadFile,
    File,
    status,
    Query,
)
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, limiter
from middleware.clinic_rbac import require_role
from models.database import RoleEnum, Utilisateur, ActeMedical
from services.agenda import get_disponibilites
from services.branding import get_branding, update_branding, save_logo, save_hero
from services.reservation_publique import hash_source_ip, reserver_creneau_public
from config import get_settings
from middleware.clinic_context import require_clinic_id

router = APIRouter(tags=["settings"])
settings = get_settings()


def _instance_clinic_id() -> int:
    return require_clinic_id(
        settings.instance_clinic_id,
        purpose="la configuration d’instance publique",
    )


class ContenuLanding(BaseModel):
    titre: Optional[str] = None
    sous_titre: Optional[str] = None
    services_mis_en_avant: Optional[list[str]] = None
    adresse: Optional[str] = None
    ville: Optional[str] = None
    telephone: Optional[str] = None
    whatsapp: Optional[str] = None
    email: Optional[str] = None
    instagram: Optional[str] = None
    facebook: Optional[str] = None
    tiktok: Optional[str] = None
    photo_hero_url: Optional[str] = None
    description_longue: Optional[str] = None
    horaires: Optional[str] = None


class BrandingUpdate(BaseModel):
    nom_clinique: Optional[str] = None
    couleur_primaire: Optional[str] = None
    couleur_secondaire: Optional[str] = None
    contenu_landing: Optional[ContenuLanding] = None


class ReservationPublique(BaseModel):
    nom: str
    prenom: str
    telephone: str
    praticien_id: Optional[int] = None
    specialite: Optional[str] = None
    acte_id: int
    date_heure: datetime


# ── Branding ───────────────────────────────────────────────


@router.get("/settings/branding")
async def get_branding_route(db: AsyncSession = Depends(get_db)):
    """Public — lu par la landing page, aucune authentification requise."""
    return await get_branding(db, clinic_id=_instance_clinic_id())


@router.patch("/settings/branding")
async def update_branding_route(
    payload: BrandingUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    data = payload.model_dump(exclude_none=True)
    return await update_branding(data, db, clinic_id=current_user["clinic_id"])


@router.post("/settings/branding/logo")
async def upload_logo_route(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    file_bytes = await file.read()
    try:
        logo_url = save_logo(file_bytes, file.content_type)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    updated = await update_branding({"logo_url": logo_url}, db, clinic_id=current_user["clinic_id"])
    return {"logo_url": updated["logo_url"]}


@router.post("/settings/branding/hero")
async def upload_hero_route(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ADMIN)),
):
    file_bytes = await file.read()
    try:
        hero_url = save_hero(file_bytes, file.content_type, clinic_id=current_user["clinic_id"])
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    updated = await update_branding({"contenu_landing": {"photo_hero_url": hero_url}}, db, clinic_id=current_user["clinic_id"])
    return {"photo_hero_url": updated["contenu_landing"]["photo_hero_url"]}


class CallbackLeadCreate(BaseModel):
    nom: str
    telephone: str
    email: Optional[str] = None
    message: Optional[str] = None


@router.post("/public/rappel", status_code=status.HTTP_201_CREATED)
@limiter.limit("5/minute")
async def callback_lead_route(request: Request, payload: CallbackLeadCreate, db: AsyncSession = Depends(get_db)):
    from models.database import CallbackLead
    nom = payload.nom.strip()
    telephone = payload.telephone.strip()
    if len(nom) < 2 or len(telephone) < 8:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Nom et téléphone requis")
    lead = CallbackLead(clinic_id=_instance_clinic_id(), nom=nom[:100], telephone=telephone[:30], email=(payload.email or None), message=(payload.message or None))
    db.add(lead)
    await db.flush()
    return {"lead_id": lead.id, "statut": lead.statut, "message": "Votre demande de rappel a bien été reçue."}


@router.get("/callback-leads")
async def list_callback_leads_route(
    statut: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN, RoleEnum.COMMERCIAL)),
):
    from models.database import CallbackLead
    query = select(CallbackLead).where(CallbackLead.clinic_id == current_user["clinic_id"])
    if statut:
        query = query.where(CallbackLead.statut == statut)
    query = query.order_by(CallbackLead.created_at.desc()).limit(100)
    result = await db.execute(query)
    return result.scalars().all()


@router.patch("/callback-leads/{lead_id}")
async def update_callback_lead_route(
    lead_id: int,
    payload: dict,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN, RoleEnum.COMMERCIAL)),
):
    from models.database import CallbackLead
    lead = await db.scalar(select(CallbackLead).where(CallbackLead.id == lead_id, CallbackLead.clinic_id == current_user["clinic_id"]))
    if not lead:
        raise HTTPException(status_code=404, detail="Lead introuvable")
    if payload.get("statut") in {"pending", "contacted", "closed", "rejected"}:
        lead.statut = payload["statut"]
        if lead.statut == "contacted":
            lead.contacted_at = datetime.utcnow()
    if "notes" in payload:
        lead.notes = str(payload["notes"] or "")[:2000] or None
    await db.flush()
    return lead


# ── Réservation publique ───────────────────────────────────


@router.get("/public/praticiens")
async def public_praticiens_route(db: AsyncSession = Depends(get_db)):
    """Liste publique des praticiens réservable depuis la landing page."""
    result = await db.execute(
        select(Utilisateur)
        .where(Utilisateur.clinic_id == _instance_clinic_id())
        .where(Utilisateur.is_active)
        .where(
            Utilisateur.role.in_([RoleEnum.MEDECIN.value, RoleEnum.ORTHODONTISTE.value, RoleEnum.ESTHETICIENNE.value])
        )
        .order_by(Utilisateur.prenom, Utilisateur.nom)
    )
    praticiens = result.scalars().all()
    seen_emails: set[str] = set()
    response: list[dict] = []
    for praticien in praticiens:
        identity = (praticien.email or f"user:{praticien.id}").lower()
        if identity in seen_emails:
            continue
        seen_emails.add(identity)
        response.append(
            {
                "id": praticien.id,
                "nom": praticien.nom,
                "prenom": praticien.prenom,
                "nom_complet": f"{praticien.prenom} {praticien.nom}",
                "specialite": praticien.specialite,
                "agenda_color": praticien.agenda_color,
            }
        )
    return response


@router.get("/public/actes")
async def public_actes_route(db: AsyncSession = Depends(get_db)):
    """Catalogue public des actes activés."""
    result = await db.execute(
        select(ActeMedical)
        .where(ActeMedical.clinic_id == _instance_clinic_id())
        .where(ActeMedical.is_active)
        .order_by(ActeMedical.nom)
    )
    actes = result.scalars().all()
    return [
        {
            "id": acte.id,
            "nom": acte.nom,
            "categorie": acte.categorie,
            "duree_minutes": acte.duree_minutes,
            "description": acte.description,
            "prix_base": float(acte.prix_base) if acte.prix_base is not None else None,
        }
        for acte in actes
    ]


@router.get("/public/disponibilites/{praticien_id}")
async def public_disponibilites_route(
    praticien_id: int,
    date: Optional[str] = Query(None, description="YYYY-MM-DD"),
    acte_id: Optional[int] = Query(None),
    duree: Optional[int] = Query(None, ge=15, le=240),
    db: AsyncSession = Depends(get_db),
):
    """Créneaux libres publics d'un praticien pour un jour donné."""
    praticien_result = await db.execute(
        select(Utilisateur)
        .where(Utilisateur.id == praticien_id)
        .where(Utilisateur.clinic_id == _instance_clinic_id())
        .where(Utilisateur.is_active)
        .where(
            Utilisateur.role.in_([RoleEnum.MEDECIN.value, RoleEnum.ORTHODONTISTE.value, RoleEnum.ESTHETICIENNE.value])
        )
    )
    praticien = praticien_result.scalar_one_or_none()
    if not praticien:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Praticien non trouvé"
        )

    if date:
        try:
            date_jour = datetime.strptime(date, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Date invalide (format YYYY-MM-DD)",
            )
    else:
        date_jour = datetime.utcnow().date()

    duree_minutes = duree or 30
    if acte_id is not None:
        acte_result = await db.execute(
            select(ActeMedical)
            .where(ActeMedical.id == acte_id)
            .where(ActeMedical.clinic_id == _instance_clinic_id())
            .where(ActeMedical.is_active)
        )
        acte = acte_result.scalar_one_or_none()
        if not acte:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Acte non trouvé"
            )
        duree_minutes = acte.duree_minutes

    creneaux = await get_disponibilites(
        praticien_id,
        date_jour,
        duree_minutes,
        db,
        clinic_id=_instance_clinic_id(),
    )

    if date_jour == datetime.utcnow().date():
        now = datetime.utcnow()
        creneaux = [
            creneau
            for creneau in creneaux
            if datetime.fromisoformat(creneau["datetime"]) >= now
        ]

    return {
        "praticien_id": praticien_id,
        "date": date_jour.isoformat(),
        "duree_minutes": duree_minutes,
        "creneaux": creneaux,
    }


@router.post("/public/reservation", status_code=status.HTTP_201_CREATED)
@limiter.limit("5/minute")
async def reservation_publique_route(
    request: Request,
    payload: ReservationPublique,
    db: AsyncSession = Depends(get_db),
):
    """Public — prise de RDV depuis la landing page, sans authentification.
    Rate-limité (5/min/IP) pour éviter le spam de faux RDV."""
    try:
        result = await reserver_creneau_public(
            payload.model_dump(),
            db,
            clinic_id=_instance_clinic_id(),
            source_ip_hash=hash_source_ip(request.client.host if request.client else None),
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    return result
