"""
AutoCommerce Clinic — Assistant conversationnel + Agent runtime (Bloc Conversation IA)

Routes nouvelles (en plus de l'existant `/assistant/*` historique) :

- POST /assistant/ask         : 1 LLM-call avec tools, mode conversation
- POST /assistant/agent/run    : vrai runtime agent (ReAct + tools)
- GET  /assistant/capabilities : introspection des tools exposésoodle
- POST /assistant/cache/clear  : admin only (reset cache LLM)

Toutes les routes respectent la dépendance d'authentification
préexistante (``Depends(get_current_user)``) et le contexte clinique.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db, get_current_user
from middleware.clinic_rbac import require_role
from middleware.clinic_context import require_clinic_id
from models.database import RoleEnum
from config import get_settings
from core.llm_client import (
    LLMUnavailable,
    get_llm_if_enabled,
    cache_clear as llm_cache_clear,
)
from core.llm_privacy import pseudonymiser_prompt_payload
from core.agent_runtime import (
    AgentRuntime,
    ToolRegistry,
    build_default_registry,
)
from services import copilote_crm as copilote

logger = logging.getLogger("assistant_ia")

router = APIRouter(prefix="/assistant-ia", tags=["assistant-ia"])


# ── Schemas ──────────────────────────────────────────────────────────────


class AskPayload(BaseModel):
    question: str = Field(..., min_length=1, max_length=2_000)
    context: Optional[Dict[str, Any]] = None
    provider: Optional[str] = None
    model: Optional[str] = None


class AskResponse(BaseModel):
    answer: str
    provider: Optional[str] = None
    model: Optional[str] = None
    latency_ms: int = 0
    cached: bool = False
    error: Optional[str] = None


class AgentRunPayload(BaseModel):
    request: str = Field(..., min_length=1, max_length=4_000)
    context: Optional[Dict[str, Any]] = None
    use_real_search: bool = True
    max_steps: int = Field(default=6, ge=1, le=6)


class AgentStepOut(BaseModel):
    index: int
    thought: str
    action: Optional[str] = None
    args: Optional[Dict[str, Any]] = None
    observation: Optional[str] = None


class AgentRunResponse(BaseModel):
    run_id: str
    success: bool
    final_answer: str
    used_llm: bool
    provider: Optional[str] = None
    error: Optional[str] = None
    steps: List[AgentStepOut] = Field(default_factory=list)


class CapabilitiesResponse(BaseModel):
    llm_provider: Optional[str]
    model: Optional[str]
    tools: List[str]
    cache_ttl_seconds: int


# ── Helpers ──────────────────────────────────────────────────────────────


def _server_clinic_id(current_user: dict) -> int:
    try:
        return require_clinic_id(
            current_user.get("clinic_id") if isinstance(current_user, dict) else None,
            purpose="les routes assistant IA",
        )
    except ValueError as exc:
        raise PermissionError("Contexte clinique serveur absent ou invalide") from exc


async def _search_patient(
    session: AsyncSession, query: str, current_user: Optional[dict] = None
):
    """Tool callable : cherche patient par nom ou téléphone.

    Applique les mêmes règles que services/patients.py::list_patients —
    ce tool interrogeait la table sans aucune restriction (ni exclusion
    des patients anonymisés RGPD, ni périmètre commercial), ce qui
    donnait à n'importe quel rôle authentifié un accès complet aux
    patients via l'agent, en contournant le RBAC appliqué partout
    ailleurs dans l'app."""
    from sqlalchemy import select, or_
    from models.database import Patient

    q = (query or "").strip()
    if not q:
        return []
    clinic_id = _server_clinic_id(current_user or {})
    stmt = select(Patient).where(
        Patient.clinic_id == clinic_id,
        Patient.anonymized_at.is_(None),
        or_(
            Patient.prenom.ilike(f"%{q}%"),
            Patient.nom.ilike(f"%{q}%"),
            Patient.telephone == q,
        ),
    )
    if current_user and current_user.get("role") == "commercial":
        stmt = stmt.where(Patient.commercial_id == current_user.get("id"))
    stmt = stmt.limit(10)
    rows = (await session.execute(stmt)).scalars().all()
    return [
        {
            "patient_ref": f"PATIENT-{p.id}",
            "name": "[REDACTED]",
            "phone": "[REDACTED]",
        }
        for p in rows
    ]


async def _revenue_30d(
    session: AsyncSession, clinic_id: int, current_user: Optional[dict] = None
):
    if current_user and current_user.get("role") not in ("directrice", "admin"):
        return {"error": "Accès refusé : chiffre d'affaires réservé à la direction."}
    from services.business_intelligence import BusinessIntelligenceService

    rev = await BusinessIntelligenceService.get_revenue_summary(session, clinic_id, 30)
    return rev


async def _draft_whatsapp(
    session: AsyncSession,
    patient_id: int,
    message_type: str,
    current_user: dict,
):
    from sqlalchemy import select
    from models.database import Patient

    clinic_id = _server_clinic_id(current_user)
    patient = (
        await session.execute(
            select(Patient).where(
                Patient.id == patient_id,
                Patient.clinic_id == clinic_id,
                Patient.anonymized_at.is_(None),
            )
        )
    ).scalar_one_or_none()
    if patient is None:
        raise ValueError("Patient introuvable dans la clinique courante")
    if current_user.get("role") == "commercial" and patient.commercial_id != current_user.get("id"):
        raise PermissionError("Patient hors périmètre commercial")

    draft = await copilote.CopiloteCRMService.generate_whatsapp_draft(
        session,
        patient_id=patient_id,
        message_type=message_type,
        clinic_id=clinic_id,
    )
    return pseudonymiser_prompt_payload(draft, patient_ref=f"PATIENT-{patient_id}")


async def _at_risk_patients(session: AsyncSession, current_user: Optional[dict] = None):
    if current_user and current_user.get("role") not in (
        "directrice",
        "medecin",
        "assistante",
        "admin",
    ):
        return {"error": "Accès refusé à cette information."}
    clinic_id = _server_clinic_id(current_user or {})
    result = await copilote.CopiloteCRMService.detect_at_risk_patients(session, clinic_id)
    return pseudonymiser_prompt_payload(result, patient_ref="PATIENT-ANONYME")


# ── Routes ───────────────────────────────────────────────────────────────


@router.post("/ask", response_model=AskResponse)
async def ask_llm(
    payload: AskPayload,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Une question au LLM. Contexte utilisateur facultatif."""
    settings = get_settings()
    llm = get_llm_if_enabled(settings)
    if llm is None:
        return AskResponse(
            answer="Le copilote IA est désactivé par la configuration de la clinique.",
            error="COPILOTE_IA_DISABLED",
        )
    msgs = []
    if payload.context:
        safe_context = pseudonymiser_prompt_payload(payload.context)
        msgs.append(
            {"role": "system", "content": f"Contexte utilisateur : {safe_context!r}"}
        )
    msgs.append({"role": "user", "content": payload.question})
    # Le provider et le modèle sont exclusivement déterminés par la configuration serveur.
    out = await llm.chat(
        msgs,
        model=settings.openai_model,
        provider_override=settings.llm_provider,
        use_cache=True,
        max_tokens=800,
        cache_context={
            "clinic_id": current_user["clinic_id"],
            "user_id": current_user["id"],
            "data_classification": "medical",
        },
        budget_session=db,
        clinic_id=_server_clinic_id(current_user),
    )
    if isinstance(out, LLMUnavailable):
        return AskResponse(
            answer=f"(LLM indisponible) {out.reason}",
            provider=out.provider,
            error=out.reason,
        )
    return AskResponse(
        answer=out.text,
        provider=out.provider,
        model=out.model,
        latency_ms=out.latency_ms,
        cached=out.cached,
    )


@router.post("/agent/run", response_model=AgentRunResponse)
async def run_agent(
    payload: AgentRunPayload,
    current_user: dict = Depends(
        require_role(
            RoleEnum.DIRECTRICE,
            RoleEnum.MEDECIN,
            RoleEnum.ESTHETICIENNE,
            RoleEnum.ASSISTANTE,
            RoleEnum.COMMERCIAL,
            RoleEnum.ADMIN,
        )
    ),
    db: AsyncSession = Depends(get_db),
):
    """Lance l'agent ReAct multi-tool sur une demande en français.

    Tous les rôles authentifiés peuvent appeler cette route, mais chaque
    tool applique son propre périmètre (ex. search_patient restreint un
    commercial à ses patients) — la restriction se fait au niveau du
    tool, pas juste à l'entrée de la route.
    """
    settings = get_settings()
    llm = get_llm_if_enabled(settings)
    if llm is None:
        return AgentRunResponse(
            run_id="disabled",
            success=False,
            final_answer="Le copilote IA est désactivé par la configuration de la clinique.",
            used_llm=False,
            error="COPILOTE_IA_DISABLED",
        )

    registry: ToolRegistry = build_default_registry(
        search_patient=(lambda query: _search_patient(db, query, current_user)),
        revenue_30d=(
            lambda: _revenue_30d(db, _server_clinic_id(current_user), current_user)
        ),
        draft_whatsapp=(
            lambda patient_id, message_type="appointment_reminder": _draft_whatsapp(
                db, patient_id, message_type, current_user
            )
        ),
        at_risk_patients=(lambda: _at_risk_patients(db, current_user)),
    )
    runtime = AgentRuntime(llm, registry, max_steps=payload.max_steps)
    agent_context = {
        "user_id": current_user["id"],
        "role": current_user["role"],
        "clinic_id": current_user["clinic_id"],
        "confirmed_actions": [],
    }
    result = await runtime.run(
        payload.request,
        user_context=agent_context,
        budget_session=db,
        clinic_id=_server_clinic_id(current_user),
    )
    return AgentRunResponse(
        run_id=result.run_id,
        success=result.success,
        final_answer=result.final_answer,
        used_llm=result.used_llm,
        provider=result.provider,
        error=result.error,
        steps=[
            AgentStepOut(
                index=s.index,
                thought=s.thought,
                action=s.action_name,
                args=s.action_args,
                observation=s.observation,
            )
            for s in result.steps
        ],
    )


@router.get("/capabilities", response_model=CapabilitiesResponse)
async def capabilities(current_user: dict = Depends(get_current_user)):
    s = get_settings()
    return CapabilitiesResponse(
        llm_provider=getattr(s, "llm_provider", "openai"),
        model=getattr(s, "openai_model", "gpt-4o"),
        tools=[
            "search_patient",
            "get_patient",
            "list_rdv_patient",
            "last_invoices",
            "at_risk_patients",
            "draft_whatsapp",
            "draft_email",
            "revenue_30d",
            "top_treatments",
            "schedule_task",
            "add_loyalty_points",
            "get_alerts_stock",
        ],
        cache_ttl_seconds=300,
    )


@router.post("/cache/clear")
async def clear_cache(
    current_user=Depends(require_role(RoleEnum.ADMIN, RoleEnum.DIRECTRICE)),
):
    """Vide le cache LLM in-memory (utile en debug). Restreint admin en prod."""
    llm_cache_clear()
    return {"status": "cleared"}
