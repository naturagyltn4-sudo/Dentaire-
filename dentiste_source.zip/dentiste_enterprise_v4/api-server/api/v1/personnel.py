"""API de fiche personnel légère."""
from datetime import date
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum
from services.personnel import get_or_create_profile, list_profiles, update_profile

router = APIRouter(prefix="/personnel", tags=["personnel"])

READ_ROLES = (
    RoleEnum.DIRECTRICE,
    RoleEnum.MEDECIN,
    RoleEnum.ORTHODONTISTE,
    RoleEnum.ESTHETICIENNE,
    RoleEnum.ASSISTANTE,
    RoleEnum.ADMIN,
)
WRITE_ROLES = (RoleEnum.DIRECTRICE, RoleEnum.ADMIN)


class PersonnelUpdate(BaseModel):
    adresse: Optional[str] = Field(default=None, max_length=300)
    fonction: Optional[str] = Field(default=None, max_length=100)
    date_embauche: Optional[date] = None
    diplomes: Optional[str] = Field(default=None, max_length=4000)
    specialisations: Optional[str] = Field(default=None, max_length=4000)
    certifications: Optional[str] = Field(default=None, max_length=4000)
    documents: Optional[list[dict]] = None
    notes_internes: Optional[str] = Field(default=None, max_length=4000)


@router.get("")
async def list_personnel(
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*READ_ROLES)),
):
    return await list_profiles(current_user, db)


@router.get("/{user_id}")
async def get_personnel(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*READ_ROLES)),
):
    try:
        return await get_or_create_profile(user_id, current_user, db)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.put("/{user_id}")
@router.patch("/{user_id}")
async def patch_personnel(
    user_id: int,
    payload: PersonnelUpdate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(*WRITE_ROLES)),
):
    try:
        return await update_profile(user_id, payload.model_dump(exclude_unset=True), current_user, db)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
