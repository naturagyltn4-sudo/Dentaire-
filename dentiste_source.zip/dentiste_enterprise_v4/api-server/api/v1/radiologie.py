"""
AutoCommerce Clinic — API Radiologie
"""

from typing import List, Optional
from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    UploadFile,
    File,
    Form,
    Response,
    status,
)
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum
from services.radiologie import upload_radio, get_decrypted_radio, list_radios
from services.audit_medical import log_access

router = APIRouter(prefix="/radiologie", tags=["radiologie"])


class RadioOut(BaseModel):
    id: int
    patient_id: int
    praticien_id: int
    type_radio: str
    dent_associee: Optional[str]
    date_prise: datetime
    dicom_metadata: Optional[dict]
    notes: Optional[str]
    taille_octets: int

    class Config:
        from_attributes = True


@router.post("/upload", response_model=RadioOut, status_code=status.HTTP_201_CREATED)
async def upload_radio_route(
    patient_id: int = Form(...),
    type_radio: str = Form(...),
    dent_associee: Optional[str] = Form(None),
    notes: Optional[str] = Form(None),
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    """Upload une radio (DICOM ou autre). Réservé au personnel médical."""
    file_bytes = await file.read()
    try:
        radio = await upload_radio(
            patient_id=patient_id,
            praticien_id=current_user["id"],
            type_radio=type_radio,
            file_bytes=file_bytes,
            dent_associee=dent_associee,
            notes=notes,
            db=db,
            clinic_id=current_user["clinic_id"],
        )
        return radio
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/patient/{patient_id}", response_model=List[RadioOut])
async def get_patient_radios(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN
        )
    ),
):
    """Liste les radios d'un patient."""
    radios = await list_radios(patient_id, db, clinic_id=current_user["clinic_id"])

    await log_access(
        db=db,
        utilisateur_id=current_user["id"],
        patient_id=patient_id,
        action="READ_RADIOS_PATIENT",
        resource_type="radio",
        resource_id=0,
    )

    return radios


@router.get("/{radio_id}/view")
async def view_radio(
    radio_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    """Consulte une radio (déchiffrement à la volée)."""
    try:
        decrypted_bytes, radio = await get_decrypted_radio(
            radio_id, current_user["id"], db, clinic_id=current_user["clinic_id"]
        )

        # Déterminer le media type
        media_type = (
            "application/dicom"
            if radio.dicom_metadata and "error" not in radio.dicom_metadata
            else "image/jpeg"
        )

        return Response(
            content=decrypted_bytes,
            media_type=media_type,
            headers={"Content-Disposition": f'inline; filename="radio_{radio.id}"'},
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Erreur lors du déchiffrement")


@router.get("/{radio_id}/download")
async def download_radio(
    radio_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    """Téléchargement sécurisé d'une radio."""
    try:
        decrypted_bytes, radio = await get_decrypted_radio(
            radio_id, current_user["id"], db, clinic_id=current_user["clinic_id"]
        )

        filename = f"radio_{radio.patient_id}_{radio.id}.dcm"
        if radio.dicom_metadata and "error" in radio.dicom_metadata:
            filename = f"radio_{radio.patient_id}_{radio.id}.jpg"

        return Response(
            content=decrypted_bytes,
            media_type="application/octet-stream",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
