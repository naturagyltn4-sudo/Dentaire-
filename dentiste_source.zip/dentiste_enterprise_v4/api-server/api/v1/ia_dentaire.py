from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum
from services.ia_dentaire import (
    detecter_caries,
    proposer_plan_traitement,
    valider_plan,
    valider_analyse_caries,
    envoyer_plan_patient,
)
from services.cout_plan import estimer_cout_plan
from services.audit_medical import log_access

router = APIRouter(prefix="/ia-dentaire", tags=["ia-dentaire"])


class AnalyseRequest(BaseModel):
    radio_id: int


class PlanRequest(BaseModel):
    patient_id: int


class ValidationRequest(BaseModel):
    praticien_id: int


@router.post("/caries/analyser")
async def analyser_caries(
    body: AnalyseRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    try:
        result = await detecter_caries(
            db,
            body.radio_id,
            current_user["id"],
            clinic_id=current_user["clinic_id"],
        )

        await log_access(
            db=db,
            utilisateur_id=current_user["id"],
            patient_id=result.get("patient_id"),
            action="READ_IA_CARIES_ANALYSIS",
            resource_type="analyse_caries",
            resource_id=result.get("id") or 0,
        )

        return result
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/caries/{analyse_id}/valider")
async def valider_analyse_caries_route(
    analyse_id: int,
    body: ValidationRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    if body.praticien_id != current_user["id"]:
        raise HTTPException(
            status_code=403,
            detail="Le praticien validateur doit être l'utilisateur connecté",
        )
    try:
        analyse = await valider_analyse_caries(db, analyse_id, body.praticien_id)
        return {
            "id": analyse.id,
            "valide_par_praticien_id": analyse.valide_par_praticien_id,
            "valide_at": analyse.valide_at,
        }
    except ValueError as exc:
        status_code = 404 if "non trouvée" in str(exc) else 409
        raise HTTPException(status_code=status_code, detail=str(exc))


@router.post("/plans/{plan_id}/estimer-cout")
async def estimer_cout_route(
    plan_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    try:
        return await estimer_cout_plan(db, plan_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/plans/proposer")
async def proposer_plan(
    body: PlanRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    try:
        return await proposer_plan_traitement(
            db,
            body.patient_id,
            current_user["id"],
            clinic_id=current_user["clinic_id"],
        )
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/plans/{plan_id}/valider")
async def valider_plan_route(
    plan_id: int,
    body: ValidationRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    if body.praticien_id != current_user["id"]:
        raise HTTPException(
            status_code=403,
            detail="Le praticien validateur doit être l'utilisateur connecté",
        )
    try:
        plan = await valider_plan(db, plan_id, body.praticien_id)

        return {
            "id": plan.id,
            "valide_par_praticien_id": plan.valide_par_praticien_id,
            "valide_at": plan.valide_at,
        }
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


@router.post("/plans/{plan_id}/envoyer")
async def envoyer_plan_route(
    plan_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)
    ),
):
    try:
        result = await envoyer_plan_patient(db, plan_id, current_user["id"])

        return result
    except PermissionError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


class CompteRenduRequest(BaseModel):
    patient_id: int
    plan_id: int | None = None


class CompteRenduModificationRequest(BaseModel):
    contenu: str


from services.compte_rendu_dentaire import (  # noqa: E402
    generer_compte_rendu,
    modifier_compte_rendu,
    valider_compte_rendu,
)
from services.rappels_dentaires import generer_rappel_suivi  # noqa: E402


@router.post("/comptes-rendus")
async def creer_compte_rendu(
    body: CompteRenduRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)),
):
    try:
        result = await generer_compte_rendu(
            db,
            body.patient_id,
            current_user["id"],
            body.plan_id,
            clinic_id=current_user["clinic_id"],
        )
        return {"id": result.id, "contenu": result.contenu, "statut": result.statut}
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.patch("/comptes-rendus/{compte_rendu_id}")
async def modifier_compte_rendu_route(
    compte_rendu_id: int,
    body: CompteRenduModificationRequest,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)),
):
    try:
        result = await modifier_compte_rendu(
            db,
            compte_rendu_id,
            current_user["id"],
            body.contenu,
            clinic_id=current_user["clinic_id"],
        )
        return {"id": result.id, "contenu": result.contenu, "statut": result.statut}
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/comptes-rendus/{compte_rendu_id}/valider")
async def valider_compte_rendu_route(
    compte_rendu_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ADMIN)),
):
    try:
        result = await valider_compte_rendu(
            db,
            compte_rendu_id,
            current_user["id"],
            clinic_id=current_user["clinic_id"],
        )
        return {"id": result.id, "statut": result.statut, "valide_par_praticien_id": result.valide_par_praticien_id}
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/rappels/{suivi_id}")
async def creer_rappel_dentaire(
    suivi_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(require_role(RoleEnum.DIRECTRICE, RoleEnum.MEDECIN, RoleEnum.ASSISTANTE, RoleEnum.ADMIN)),
):
    try:
        result = await generer_rappel_suivi(db, suivi_id)
        return {"id": result.id, "patient_id": result.patient_id, "date_prevue": result.date_prevue, "canal": result.canal, "destinataire": result.destinataire}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
