"""
AutoCommerce Clinic — API Orthodontie (Bloc 9)
"""

from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from api.deps import get_db
from middleware.clinic_rbac import require_role
from models.database import RoleEnum, SuiviOrthodontique, Patient, PhotoClinic
from pydantic import BaseModel

router = APIRouter(prefix="/orthodontie", tags=["orthodontie"])


class SuiviOrthoCreate(BaseModel):
    photo_reelle_id: int
    phase: str
    type_appareil: str
    observations: str = None


class SuiviOrthoCreateOut(BaseModel):
    id: int
    message: str


class SuiviOrthoOut(BaseModel):
    id: int
    photo_reelle_id: int
    date: str
    phase: str
    type_appareil: str
    observations: str | None = None


@router.post("/patients/{patient_id}/suivi", response_model=SuiviOrthoCreateOut)
async def create_suivi_ortho(
    patient_id: int,
    data: SuiviOrthoCreate,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ADMIN)
    ),
):
    """Crée un suivi orthodontique réel (sans IA)."""
    # Vérifier patient
    patient = await db.scalar(
        select(Patient).where(
            Patient.id == patient_id,
            Patient.clinic_id == current_user["clinic_id"],
        )
    )
    if not patient:
        raise HTTPException(status_code=404, detail="Patient non trouvé")

    # Vérifier photo
    photo = await db.scalar(
        select(PhotoClinic).where(
            PhotoClinic.id == data.photo_reelle_id,
            PhotoClinic.patient_id == patient_id,
            PhotoClinic.clinic_id == current_user["clinic_id"],
            ~PhotoClinic.is_deleted,
        )
    )
    if not photo:
        raise HTTPException(status_code=400, detail="Photo non trouvée ou invalide")

    suivi = SuiviOrthodontique(
        clinic_id=current_user["clinic_id"],
        patient_id=patient_id,
        photo_reelle_id=data.photo_reelle_id,
        phase=data.phase,
        type_appareil=data.type_appareil,
        observations=data.observations,
    )
    db.add(suivi)
    await db.flush()

    return SuiviOrthoCreateOut(id=suivi.id, message="Suivi orthodontique créé")


@router.get("/patients/{patient_id}/suivis", response_model=List[SuiviOrthoOut])
async def list_suivis_ortho(
    patient_id: int,
    db: AsyncSession = Depends(get_db),
    current_user=Depends(
        require_role(
            RoleEnum.MEDECIN, RoleEnum.DIRECTRICE, RoleEnum.ASSISTANTE, RoleEnum.ADMIN
        )
    ),
):
    """Liste les suivis orthodontiques réels."""
    result = await db.execute(
        select(SuiviOrthodontique).where(
            SuiviOrthodontique.patient_id == patient_id,
            SuiviOrthodontique.clinic_id == current_user["clinic_id"],
        )
    )
    suivis = result.scalars().all()
    return [
        SuiviOrthoOut(
            id=s.id,
            photo_reelle_id=s.photo_reelle_id,
            date=s.date.isoformat(),
            phase=s.phase,
            type_appareil=s.type_appareil,
            observations=s.observations,
        )
        for s in suivis
    ]
