"""Compare les tables déclarées dans models/database.py avec celles créées
dans les migrations Alembic pour identifier les écarts."""
import re
from pathlib import Path

API = Path(__file__).resolve().parent.parent

models_file = API / "models" / "database.py"
tables_models = set(re.findall(r'__tablename__ = "([^"]+)"', models_file.read_text()))

created = set()
for f in (API / "alembic" / "versions").glob("*.py"):
    created.update(re.findall(r'create_table\(\s*["\']([^"\']+)["\']', f.read_text()))

missing = sorted(tables_models - created - {"utilisateurs", "patients", "actes_medicaux"})
print("Tables dans les modèles mais absentes des migrations create_table :")
for t in missing:
    print(" -", t)
