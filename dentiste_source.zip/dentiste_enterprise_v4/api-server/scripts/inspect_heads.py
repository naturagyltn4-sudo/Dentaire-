"""Inspecte les révisions Alembic pour reconstruire le graphe de dépendances."""
import re
from pathlib import Path

versions = Path(__file__).resolve().parent.parent / "alembic" / "versions"
graph = {}
for f in sorted(versions.glob("*.py")):
    txt = f.read_text()
    rev_m = re.search(r"revision\s*(?::\s*[^=]+?)?\s*=\s*\"([^\"]+)\"", txt)
    down_m = re.search(r"down_revision\s*(?::\s*[^=]+?)?\s*=\s*(.+)$", txt, re.M)
    if not rev_m or not down_m:
        print(f"! SKIP {f.name}")
        continue
    rev = rev_m.group(1)
    raw = down_m.group(1).strip()
    if raw == "None":
        downs = [None]
    else:
        tuple_m = re.search(r"\(([^)]+)\)", raw)
        if tuple_m:
            downs = re.findall(r'"([^"]+)"', tuple_m.group(1))
        else:
            m = re.search(r'"([^"]+)"', raw)
            downs = [m.group(1)] if m else ["???"]
    graph[rev] = downs
    print(f"{f.name:<55} rev={rev:<30} down={downs}")

heads = [r for r, d in graph.items() if r not in {x for ds in graph.values() for x in ds if x is not None}]
print("\nHEADS:", heads)
