import os
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

os.environ.setdefault("ENV", "test")
os.environ.setdefault("DATABASE_URL", "sqlite+aiosqlite://")
os.environ.setdefault("INSTANCE_CLINIC_ID", "1")
os.environ.setdefault("FERNET_KEY", "test-fernet-key")
os.environ.setdefault("PHOTO_ENCRYPTION_KEY", "test-photo-key")
os.environ.setdefault("SECRET_KEY", "test-secret-key")

from api.v1 import api_router  # noqa: E402


def iter_routes(routes, prefix=""):
    for route in routes:
        if type(route).__name__ == "_IncludedRouter":
            context = getattr(route, "include_context", None)
            nested_prefix = getattr(context, "prefix", "") if context else ""
            original = getattr(route, "original_router", None)
            if original is not None:
                yield from iter_routes(original.routes, prefix + nested_prefix)
            continue
        methods = getattr(route, "methods", set())
        if methods and hasattr(route, "path"):
            yield route, prefix


collisions = defaultdict(list)
for route, prefix in iter_routes(api_router.routes, prefix=api_router.prefix):
    for method in route.methods - {"HEAD"}:
        collisions[(method, prefix + route.path)].append(getattr(route, "name", "<anonymous>"))

bad = {key: value for key, value in collisions.items() if len(value) > 1}
if bad:
    for (method, path), names in sorted(bad.items()):
        print(f"{method} {path}: {', '.join(names)}")
    raise SystemExit(1)

print(f"ROUTE_COLLISIONS=0 ROUTES={len(collisions)} API_ROUTES={len(collisions)}")
if not collisions:
    raise SystemExit("API_ROUTE_DISCOVERY_FAILED")
