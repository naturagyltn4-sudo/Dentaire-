"""Inspecte les révisions Alembic via ast.parse (fiable, supporte tuples
multi-lignes et annotations de type) pour reconstruire le graphe complet."""
import ast as ast_mod
from pathlib import Path


def _eval_down(v):
    if isinstance(v, ast_mod.Constant) and v.value is None:
        return [None]
    if isinstance(v, ast_mod.Tuple):
        return [e.value for e in v.elts if isinstance(e, ast_mod.Constant)]
    if isinstance(v, ast_mod.Constant):
        return [v.value]
    return None


versions = Path(__file__).resolve().parent.parent / "alembic" / "versions"
graph = {}
for f in sorted(versions.glob("*.py")):
    try:
        tree = ast_mod.parse(f.read_text())
    except SyntaxError:
        print(f"! SYNTAX {f.name}")
        continue
    rev = down = None
    for n in ast_mod.walk(tree):
        if isinstance(n, ast_mod.Assign):
            for tg in n.targets:
                if isinstance(tg, ast_mod.Name):
                    if tg.id == "revision" and isinstance(n.value, ast_mod.Constant):
                        rev = n.value.value
                    elif tg.id == "down_revision":
                        down = _eval_down(n.value)
        elif isinstance(n, ast_mod.AnnAssign):
            if isinstance(n.target, ast_mod.Name) and n.value is not None:
                if n.target.id == "revision" and isinstance(n.value, ast_mod.Constant):
                    rev = n.value.value
                elif n.target.id == "down_revision":
                    down = _eval_down(n.value)
    if rev is None:
        print(f"! SKIP {f.name}")
        continue
    graph[rev] = down or []
    print(f"{f.name:<55} rev={rev:<30} down={down}")

heads = [
    r for r, d in graph.items()
    if r not in {x for ds in graph.values() for x in ds if x is not None}
]
print("\nHEADS:", heads)
