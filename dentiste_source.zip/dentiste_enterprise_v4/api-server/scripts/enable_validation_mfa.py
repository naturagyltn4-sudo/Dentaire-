import asyncio

from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from config import get_settings
from models.database import Utilisateur

EMAIL = "e2e.directrice@validation.example.com"
MFA_SECRET = "JBSWY3DPEHPK3PXP"


async def main() -> None:
    settings = get_settings()
    engine = create_async_engine(settings.database_url)
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    try:
        async with session_factory() as db:
            user = (await db.execute(select(Utilisateur).where(Utilisateur.email == EMAIL))).scalar_one()
            user.mfa_enabled = True
            user.mfa_secret = MFA_SECRET
            await db.commit()
            print(f"MFA_ENABLED={user.email}")
    finally:
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
