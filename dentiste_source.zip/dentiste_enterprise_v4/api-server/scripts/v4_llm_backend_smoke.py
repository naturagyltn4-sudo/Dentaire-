import asyncio
import os

from config import Settings
from core.llm_client import LLMClient, LLMResponse


async def main() -> None:
    settings = Settings(
        env="test",
        llm_provider="openai",
        openai_api_key=os.environ["OPENAI_API_KEY"],
        openai_api_base=os.environ["OPENAI_API_BASE"],
        openai_model="gpt-5-nano",
        copilote_ia_enabled=True,
    )
    client = LLMClient(settings)
    try:
        result = await client.chat(
            [
                {"role": "system", "content": "Réponds uniquement par OK."},
                {"role": "user", "content": "Test backend sans donnée clinique."},
            ],
            model="gpt-5-nano",
            max_tokens=16,
            use_cache=False,
        )
        if not isinstance(result, LLMResponse):
            raise SystemExit(f"LLM_BACKEND_FAIL provider={result.provider} reason={result.reason}")
        print(f"LLM_BACKEND_OK provider={result.provider} model={result.model} text={result.text!r}")
        print(f"LLM_BACKEND_USAGE={result.usage}")
    finally:
        await client.aclose()


if __name__ == "__main__":
    asyncio.run(main())
