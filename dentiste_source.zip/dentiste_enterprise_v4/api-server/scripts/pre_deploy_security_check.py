#!/usr/bin/env python3
"""
AutoCommerce Clinic — Vérification pré-déploiement sécurité
Exécute les contrôles suivants :
  1. Aucun secret par défaut restant (SECRET_KEY, FERNET_KEY, DATABASE_URL, REDIS_URL)
  2. CORS != *
  3. ENV = production
  4. FERNET_KEY longueur >= 32 chars
  5. PHOTO_ENCRYPTION_KEY != DEFAULT
  6. Pas de print() dans les services métier (mauvaise pratique)
  7. BACKUP_ENCRYPTION_KEY présente, robuste, non-placeholder et indépendante
"""

import sys
import os
import re
from pathlib import Path

# ── Chargement config ──────────────────────────────────────
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import Settings, _validate_production_secrets, get_settings

DEFAULT_SECRET = "change-me-in-production-64-chars-minimum-for-jwt-signing"

errors = []
warnings = []


def check_secrets(settings):
    if settings.secret_key == DEFAULT_SECRET or len(settings.secret_key) < 32:
        errors.append("SECRET_KEY : valeur par défaut ou trop courte (< 32 chars)")
    if "changeme" in settings.database_url.lower():
        errors.append("DATABASE_URL : contient 'changeme' — mot de passe non modifié")
    if "changeme" in settings.redis_url.lower():
        errors.append("REDIS_URL : contient 'changeme' — mot de passe non modifié")
    if settings.cors_origins.strip() == "*":
        errors.append("CORS_ORIGINS : '*' est interdit en production")
    if settings.env != "production":
        errors.append(f"ENV : doit être 'production', actuellement '{settings.env}'")
    if len(settings.fernet_key) < 32:
        errors.append(
            f"FERNET_KEY : trop courte ({len(settings.fernet_key)} chars, min 32)"
        )
    if settings.photo_encryption_key == "default-photo-key-for-local-dev":
        errors.append("PHOTO_ENCRYPTION_KEY : valeur par défaut détectée")

    backup_key = settings.backup_encryption_key.strip()
    if len(backup_key) < 32:
        errors.append("BACKUP_ENCRYPTION_KEY : absente ou trop courte (< 32 chars)")
    if not backup_key:
        errors.append("BACKUP_ENCRYPTION_KEY : vide — chiffrement des sauvegardes désactivé")
    if any(token in backup_key.lower() for token in ("change-me", "generate-", "placeholder", "example")):
        errors.append("BACKUP_ENCRYPTION_KEY : valeur placeholder détectée")
    if backup_key and backup_key in {
        settings.secret_key,
        settings.fernet_key,
        settings.photo_encryption_key,
        settings.postgres_password,
        settings.redis_password,
    }:
        errors.append("BACKUP_ENCRYPTION_KEY : doit être indépendante des autres secrets")

    if not settings.fernet_key or len(settings.fernet_key) == 0:
        errors.append("FERNET_KEY : vide — chiffrement RGPD désactivé")


def check_no_print_in_services():
    """Vérifie qu'aucun print() n'est présent dans les services métier."""
    services_dir = Path(__file__).resolve().parent.parent / "services"
    for py_file in services_dir.rglob("*.py"):
        if py_file.name == "__init__.py":
            continue
        content = py_file.read_text()
        # Chercher des print() non dans des commentaires
        for i, line in enumerate(content.splitlines(), 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue
            if re.match(r"^\s*print\s*\(", stripped):
                warnings.append(
                    f"{py_file.relative_to(services_dir.parent)}:{i}: print() détecté (utiliser logger)"
                )


def check_dockerfile_no_env():
    """Vérifie que le Dockerfile ne copie PAS .env.clinic."""
    dockerfile = Path(__file__).resolve().parent.parent / "Dockerfile"
    if not dockerfile.exists():
        warnings.append("Dockerfile introuvable")
        return
    content = dockerfile.read_text()
    if ".env.clinic" in content:
        errors.append("Dockerfile : copie .env.clinic — secret exposé dans l'image !")


def check_production_nginx():
    """Vérifie Nginx, TLS et CSP sans accepter de placeholders."""
    project_root = Path(__file__).resolve().parent.parent.parent
    configured_path = os.environ.get("NGINX_PRODUCTION_CONF", "").strip()
    nginx_candidates = (
        Path(configured_path) if configured_path else None,
        project_root / "nginx-production.conf",
        project_root / "infrastructure" / "nginx" / "production.conf",
    )
    nginx_file = next((path for path in nginx_candidates if path and path.exists()), None)
    if nginx_file is None:
        errors.append(
            "Configuration Nginx de production manquante — pas de TLS configuré en production"
        )
        return
    content = nginx_file.read_text(encoding="utf-8")
    if "server_name _;" in content:
        errors.append("Nginx : server_name _ est encore un placeholder")
    if "/etc/nginx/ssl/server.crt" in content or "/etc/nginx/ssl/server.key" in content:
        errors.append("Nginx : certificats TLS placeholders non remplacés")
    if "connect-src 'self' *" in content or "connect-src 'self' https:;" in content:
        errors.append("Nginx : CSP connect-src trop large")

    frontend_dockerfile = project_root / "validation-private-frontend" / "Dockerfile"
    if frontend_dockerfile.exists():
        frontend_content = frontend_dockerfile.read_text(encoding="utf-8")
        if "connect-src 'self' *" in frontend_content:
            errors.append("Frontend Dockerfile : CSP connect-src trop large")
        if "localhost:8000/api/v1" in frontend_content:
            errors.append("Frontend Dockerfile : URL API localhost utilisée par défaut")


if __name__ == "__main__":
    print("=" * 60)
    print("AUTO-COMMERCE CLINIC — Vérification pré-déploiement")
    print("=" * 60)

    try:
        env_file = os.environ.get("DEPLOY_ENV_FILE", "").strip()
        if env_file and Path(env_file).exists():
            settings = Settings(_env_file=env_file)
            _validate_production_secrets(settings)
        else:
            settings = get_settings()
        check_secrets(settings)
    except Exception as e:
        errors.append(f"Erreur chargement config : {e}")

    check_no_print_in_services()
    check_dockerfile_no_env()
    check_production_nginx()

    if errors:
        print(f"\n❌ BLOCAGES ({len(errors)} erreurs) :")
        for e in errors:
            print(f"  - {e}")

    if warnings:
        print(f"\n⚠️  ATTENTIONS ({len(warnings)} warnings) :")
        for w in warnings:
            print(f"  - {w}")

    if not errors and not warnings:
        print("\n✅ Tous les contrôles sont passés — déploiement autorisé")

    print("\n" + "=" * 60)
    sys.exit(1 if errors else 0)
