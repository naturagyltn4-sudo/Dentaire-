"""Vérification HTTP du parcours public -> accueil -> Super Admin."""

from datetime import datetime, timedelta

import requests

BASE = "http://127.0.0.1:8000/api/v1"
PASSWORD = "Validation-Dentaire-2026!"


def login(email: str) -> str:
    response = requests.post(f"{BASE}/auth/login", json={"email": email, "password": PASSWORD}, timeout=10)
    response.raise_for_status()
    return response.json()["access_token"]


def main() -> None:
    practitioners = requests.get(f"{BASE}/public/praticiens", timeout=10).json()
    procedures = requests.get(f"{BASE}/public/actes", timeout=10).json()
    assert practitioners and procedures
    practitioner_id = practitioners[0]["id"]
    acte_id = procedures[0]["id"]
    selected_slot = None
    for offset in range(0, 5):
        date = (datetime.utcnow() + timedelta(days=offset)).date().isoformat()
        response = requests.get(f"{BASE}/public/disponibilites/{practitioner_id}", params={"date": date, "acte_id": acte_id}, timeout=10)
        if response.ok and response.json().get("creneaux"):
            selected_slot = response.json()["creneaux"][0]["datetime"]
            break
    assert selected_slot, "Aucun créneau de validation disponible"

    booking = requests.post(
        f"{BASE}/public/reservation",
        json={"nom": "Online", "prenom": "Validation", "telephone": "+21620000009", "praticien_id": practitioner_id, "acte_id": acte_id, "date_heure": selected_slot},
        timeout=10,
    )
    assert booking.status_code == 201, booking.text
    booking_data = booking.json()
    assert booking_data["statut"] == "pending" and booking_data["rdv_id"] is None
    print(f"public_booking=pending request_id={booking_data['booking_request_id']}")

    reception_token = login("assistante@dentiste-validation.tn")
    headers = {"Authorization": f"Bearer {reception_token}"}
    pending = requests.get(f"{BASE}/booking-requests", headers=headers, timeout=10)
    assert pending.status_code == 200, pending.text
    assert any(item["id"] == booking_data["booking_request_id"] for item in pending.json())
    approval = requests.post(f"{BASE}/booking-requests/{booking_data['booking_request_id']}/approve", headers=headers, timeout=10)
    assert approval.status_code == 200, approval.text
    assert approval.json()["statut"] == "accepted"
    print(f"reception_approval=accepted rdv_id={approval.json()['rdv_id']}")

    superadmin_token = login("superadmin@dentiste-validation.tn")
    overview = requests.get(f"{BASE}/super-admin/overview", headers={"Authorization": f"Bearer {superadmin_token}"}, timeout=10)
    assert overview.status_code == 200, overview.text
    print(f"superadmin_overview={overview.json()['clinics_count']} clinics, {overview.json()['users_count']} users, {overview.json()['appointments_count']} appointments")


if __name__ == "__main__":
    main()
