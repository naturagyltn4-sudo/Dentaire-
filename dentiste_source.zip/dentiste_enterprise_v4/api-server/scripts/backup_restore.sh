#!/usr/bin/env bash
# Sauvegardes PostgreSQL chiffrées et restaurations vérifiables.
# BACKUP_ENCRYPTION_KEY doit être injectée hors du dépôt en production.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$(dirname "$SCRIPT_DIR")")"

# La release Docker utilise .env.clinic; .env reste accepté pour les installations legacy.
for env_file in "$PROJECT_ROOT/.env.clinic" "$PROJECT_ROOT/.env"; do
    if [ -f "$env_file" ]; then
        set -a
        # Ne charger que les variables explicitement consommées par ce script.
        grep -E '^(PGHOST|PGPORT|PGUSER|PGPASSWORD|PGDATABASE|BACKUP_DIR|BACKUP_ENCRYPTION_KEY|BACKUP_RETENTION_DAYS|BACKUP_OFFSITE_SCRIPT)=' "$env_file" | source /dev/stdin 2>/dev/null || true
        set +a
        break
    fi
done

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-clinic_user}"
PGDATABASE="${PGDATABASE:-clinic_db}"
BACKUP_DIR="${BACKUP_DIR:-$PROJECT_ROOT/backups}"
BACKUP_RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-30}"

require_key() {
    local key="${BACKUP_ENCRYPTION_KEY:-}"
    if [ -z "$key" ] || [ "${#key}" -lt 32 ]; then
        echo "BACKUP_ENCRYPTION_KEY est requis et doit contenir au moins 32 caractères" >&2
        exit 2
    fi
    case "$key" in
        *change-me*|*generate-*|*placeholder*|*example*)
            echo "BACKUP_ENCRYPTION_KEY contient une valeur placeholder" >&2
            exit 2
            ;;
    esac
}

timestamp() { date +%Y%m%d_%H%M%S; }

gpg_with_key() {
    local input="$1"
    shift
    gpg --batch --yes --pinentry-mode loopback \
        --passphrase-file <(printf '%s' "$BACKUP_ENCRYPTION_KEY") "$@" "$input"
}

decrypt_to_temp() {
    local infile="$1"
    local tmpfile="$2"
    gpg --batch --yes --pinentry-mode loopback \
        --passphrase-file <(printf '%s' "$BACKUP_ENCRYPTION_KEY") \
        --decrypt --output "$tmpfile" "$infile" >/dev/null 2>&1
}

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

case "${1:-help}" in
    backup)
        require_key
        raw="$(mktemp "$BACKUP_DIR/.raw.XXXXXX.dump")"
        trap 'rm -f "$raw"' EXIT
        outfile="${2:-$BACKUP_DIR/backup_$(timestamp).dump.gpg}"
        case "$outfile" in *.gpg) ;; *) outfile="$outfile.gpg" ;; esac
        pg_dump -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -Fc -d "$PGDATABASE" -f "$raw"
        gpg_with_key "$raw" --symmetric --cipher-algo AES256 --output "$outfile"
        chmod 600 "$outfile"
        rm -f "$raw"
        "$0" verify "$outfile"
        find "$BACKUP_DIR" -type f -name '*.dump.gpg' -mtime "+$BACKUP_RETENTION_DAYS" -delete
        if [ -n "${BACKUP_OFFSITE_SCRIPT:-}" ]; then
            [ -f "$BACKUP_OFFSITE_SCRIPT" ] && [ -x "$BACKUP_OFFSITE_SCRIPT" ] || {
                echo "BACKUP_OFFSITE_SCRIPT doit être un script exécutable local" >&2
                exit 2
            }
            "$BACKUP_OFFSITE_SCRIPT" "$outfile"
        fi
        echo "Backup chiffré créé : $outfile ($(du -h "$outfile" | cut -f1))"
        ;;
    verify)
        require_key
        infile="${2:?usage: backup_restore.sh verify <fichier.dump.gpg>}"
        [ -f "$infile" ] || { echo "Fichier introuvable : $infile" >&2; exit 1; }
        tmp="$(mktemp)"
        trap 'rm -f "$tmp"' EXIT
        decrypt_to_temp "$infile" "$tmp"
        pg_restore -l "$tmp" >/dev/null
        echo "Backup chiffré valide : chiffrement et table des matières vérifiés."
        ;;
    restore)
        require_key
        infile="${2:?usage: backup_restore.sh restore <fichier.dump.gpg>}"
        [ -f "$infile" ] || { echo "Fichier introuvable : $infile" >&2; exit 1; }
        tmp="$(mktemp)"
        trap 'rm -f "$tmp"' EXIT
        decrypt_to_temp "$infile" "$tmp"
        restore_sql="$(mktemp)"
        trap 'rm -f "$tmp" "$restore_sql"' EXIT
        # PostgreSQL 17 pg_restore emits SET transaction_timeout, which PostgreSQL 16
        # does not recognize. Generate SQL, remove only that version-specific SET,
        # then let PostgreSQL execute the complete script with ON_ERROR_STOP.
        pg_restore --clean --if-exists --no-owner --no-privileges --file "$restore_sql" "$tmp"
        sed -i '/^SET transaction_timeout = 0;$/d' "$restore_sql"
        psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE" -v ON_ERROR_STOP=1 \
            -f "$restore_sql" >/dev/null
        psql -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE" -v ON_ERROR_STOP=1 \
            -c 'SELECT current_database(), COUNT(*) AS patients FROM patients;' >/dev/null
        echo "Restauration terminée et vérifiée par requête de cohérence."
        ;;
    *)
        echo "Usage: backup_restore.sh {backup|verify|restore} [fichier.dump.gpg]"
        exit 1
        ;;
esac
