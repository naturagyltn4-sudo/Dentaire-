import asyncio
import os

from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from config import Settings
from core.llm_client import LLMClient, LLMResponse


async def main() -> None:
    settings = Settings(
        env="production",
        llm_provider="openai",
        openai_api_key=os.environ["OPENAI_API_KEY"],
        openai_api_base=os.environ["OPENAI_API_BASE"],
        openai_model="gpt-5-nano",
        copilote_ia_enabled=True,
        ai_monthly_request_limit=10,
        ai_monthly_token_limit=10000,
        database_url=os.environ["DATABASE_URL"],
    )
    engine = create_async_engine(settings.database_url)
    factory = async_sessionmaker(engine, expire_on_commit=False)
    client = LLMClient(settings)
    try:
        async with factory() as db:
            result = await client.chat(
                [
                    {"role": "system", "content": "Réponds uniquement par OK."},
                    {"role": "user", "content": "Test production sans donnée clinique."},
                ],
                model="gpt-5-nano",
                max_tokens=16,
                use_cache=False,
                budget_session=db,
                clinic_id=1,
            )
            await db.rollback()
            if not isinstance(result, LLMResponse):
                raise SystemExit(f"LLM_PRODUCTION_FAIL provider={result.provider} reason={result.reason}")
            print(f"LLM_PRODUCTION_OK provider={result.provider} model={result.model} text={result.text!r}")
            print(f"LLM_PRODUCTION_USAGE={result.usage}")
    finally:
        await client.aclose()
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
