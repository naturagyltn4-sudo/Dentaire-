"""Matrice de permissions runtime pour les rôles cliniques et le Super Admin."""

import requests

BASE = "http://127.0.0.1:8000/api/v1"
PASSWORD = "Validation-Dentaire-2026!"
ACCOUNTS = {
    "directrice": "directrice@dentiste-validation.tn",
    "medecin": "dentiste@dentiste-validation.tn",
    "assistante": "assistante@dentiste-validation.tn",
    "admin": "admin@dentiste-validation.tn",
    "superadmin": "superadmin@dentiste-validation.tn",
}

EXPECTED = {
    "agenda": {"directrice": 200, "medecin": 200, "assistante": 200, "admin": 200, "superadmin": 403},
    "booking_requests": {"directrice": 200, "medecin": 403, "assistante": 200, "admin": 200, "superadmin": 403},
    "team": {"directrice": 200, "medecin": 403, "assistante": 403, "admin": 200, "superadmin": 403},
    "cephalometries": {"directrice": 200, "medecin": 403, "assistante": 403, "admin": 200, "superadmin": 403},
    "superadmin": {"directrice": 403, "medecin": 403, "assistante": 403, "admin": 403, "superadmin": 200},
}

ENDPOINTS = {
    "agenda": "/agenda",
    "booking_requests": "/booking-requests",
    "team": "/admin/team",
    "cephalometries": "/cephalometries",
    "superadmin": "/super-admin/overview",
}


def main() -> None:
    session = requests.Session()
    results = []
    for role, email in ACCOUNTS.items():
        login = session.post(f"{BASE}/auth/login", json={"email": email, "password": PASSWORD}, timeout=10)
        assert login.status_code == 200, f"login {role}: {login.status_code} {login.text}"
        token = login.json()["access_token"]
        headers = {"Authorization": f"Bearer {token}"}
        me = session.get(f"{BASE}/auth/me", headers=headers, timeout=10)
        assert me.status_code == 200 and me.json()["role"] == role, f"me {role}: {me.status_code} {me.text}"
        for name, path in ENDPOINTS.items():
            response = session.get(f"{BASE}{path}", headers=headers, timeout=10)
            expected = EXPECTED[name][role]
            assert response.status_code == expected, f"{role} {name}: got {response.status_code}, expected {expected}: {response.text}"
            results.append((role, name, response.status_code))
    for role, name, status in results:
        print(f"{role:10} {name:18} {status}")
    print(f"role_matrix=ok checks={len(results)}")


if __name__ == "__main__":
    main()
