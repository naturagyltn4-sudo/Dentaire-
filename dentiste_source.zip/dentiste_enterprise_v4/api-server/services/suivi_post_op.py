"""
AutoCommerce Clinic — Service Suivi Post-Opératoire (Bloc 8)
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from models.database import (
    SuiviPostOperatoire,
    RendezVous,
    ActeMedical,
    Patient,
    StatutSuiviPostOp,
)
from services.omnicanal_service import send_message
from services.clinic_settings import get_setting

logger = logging.getLogger(__name__)


async def trigger_suivi_post_op(
    rdv_id: int, db: AsyncSession, delay_days: Optional[int] = None
):
    """
    Déclenche la création d'un suivi post-opératoire si l'acte est chirurgical.
    """
    # Récupérer le RDV avec son acte
    result = await db.execute(select(RendezVous).where(RendezVous.id == rdv_id))
    rdv = result.scalar_one_or_none()

    if not rdv or not rdv.acte_id:
        return

    # Vérifier si l'acte est chirurgical
    result_acte = await db.execute(
        select(ActeMedical).where(ActeMedical.id == rdv.acte_id)
    )
    acte = result_acte.scalar_one_or_none()

    if not acte or not acte.is_chirurgical:
        return

    # Vérifier l'absence de doublon pour ce RDV
    # On considère qu'un RDV ne génère qu'un seul suivi à J+X
    # (Ou on pourrait vérifier s'il existe déjà un suivi planifié pour ce patient/acte proche de cette date)
    result_existing = await db.execute(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.patient_id == rdv.patient_id,
            SuiviPostOperatoire.acte_id == rdv.acte_id,
            SuiviPostOperatoire.statut == StatutSuiviPostOp.PLANIFIE.value,
        )
    )
    if result_existing.scalar_one_or_none():
        logger.info(
            f"Suivi déjà planifié pour le patient {rdv.patient_id} et l'acte {rdv.acte_id}"
        )
        return

    # Récupérer le délai configurable (Bloc 8)
    if delay_days is None:
        # On cherche dans les settings, défaut à 7 jours
        delay_days = await get_setting("suivi_post_op.delay_days", db, 7)

    # Créer le suivi
    date_controle = datetime.utcnow() + timedelta(days=delay_days)

    suivi = SuiviPostOperatoire(
        clinic_id=rdv.clinic_id,
        acte_id=rdv.acte_id,
        patient_id=rdv.patient_id,
        date_controle_prevue=date_controle,
        statut=StatutSuiviPostOp.PLANIFIE.value,
        praticien_id=rdv.praticien_id,
    )
    db.add(suivi)
    await db.flush()

    logger.info(
        f"Suivi post-op créé pour le patient {rdv.patient_id}, prévu le {date_controle}"
    )

    # Notification
    await notifier_suivi_post_op(suivi, db)

    return suivi


async def notifier_suivi_post_op(suivi: SuiviPostOperatoire, db: AsyncSession):
    """
    Envoie une notification au patient pour son suivi post-opératoire.
    """
    # Récupérer le patient
    result_patient = await db.execute(
        select(Patient).where(Patient.id == suivi.patient_id)
    )
    patient = result_patient.scalar_one_or_none()

    if not patient:
        return

    # Récupérer l'acte
    result_acte = await db.execute(
        select(ActeMedical).where(ActeMedical.id == suivi.acte_id)
    )
    acte = result_acte.scalar_one_or_none()

    acte_nom = acte.nom if acte else "votre intervention"
    date_str = suivi.date_controle_prevue.strftime("%d/%m/%Y")

    content = (
        f"Bonjour {patient.prenom}, votre suivi post-opératoire pour '{acte_nom}' "
        f"est prévu le {date_str}. Nous reviendrons vers vous pour confirmer l'heure."
    )

    # Utiliser le moteur omnicanal (WhatsApp par défaut si dispo, sinon SMS)
    channel = "whatsapp" if patient.whatsapp_phone else "sms"
    to = patient.whatsapp_phone or patient.telephone

    if to:
        try:
            await send_message(channel=channel, to=to, content=content)
            logger.info(f"Notification de suivi envoyée à {to} via {channel}")
        except Exception as e:
            logger.error(f"Erreur lors de l'envoi de la notification : {e}")
