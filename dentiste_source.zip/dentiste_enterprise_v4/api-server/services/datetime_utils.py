from datetime import datetime, timezone


def to_utc_naive(value: datetime) -> datetime:
    """Convertit une datetime ISO éventuelle avec timezone en UTC naïf.

    Les colonnes agenda de la release utilisent des timestamps sans timezone.
    Cette normalisation évite les comparaisons naïf/aware tout en conservant
    l’instant absolu reçu par l’API.
    """
    if value.tzinfo is not None:
        return value.astimezone(timezone.utc).replace(tzinfo=None)
    return value
