"""
AutoCommerce Clinic — Authentification Multi-Facteurs (MFA)

Implémentation TOTP (Time-Based One-Time Password) selon RFC 6238.
Utilise pyotp pour la génération/vérification, stocke le secret chiffré
dans la base de données. Génère 10 codes de secours à usage unique
lors de l'activation.

Flux :
  1. POST /auth/mfa/setup        → retourne secret + QR + backup_codes
  2. POST /auth/mfa/confirm      → vérifie le premier OTP, active MFA
  3. POST /auth/mfa/verify       → vérifie OTP lors de la connexion
  4. POST /auth/mfa/disable      → désactive MFA (mot de passe requis)
"""

import hashlib
import hmac
import io
import secrets

import pyotp
from cryptography.fernet import Fernet, InvalidToken
import qrcode

from config import get_settings

settings = get_settings()

# Durée de validité d'un OTP TOTP (30 secondes standard)
TOTP_PERIOD = 30
TOTP_DIGITS = 6

# Nombre de codes de secours générés
BACKUP_CODE_COUNT = 10

# Durée max d'un challenge MFA (5 minutes)
MFA_CHALLENGE_EXPIRY_MINUTES = 5

# Nombre max d'essais OTP avant verrouillage
MAX_MFA_ATTEMPTS = 5


def generate_mfa_secret() -> str:
    """Génère un secret TOTP aléatoire (base32)."""
    return pyotp.random_base32()


def _fernet() -> Fernet:
    key = getattr(settings, "fernet_key", "")
    if not key:
        raise RuntimeError("FERNET_KEY est requis pour protéger le secret MFA")
    return Fernet(key.encode() if isinstance(key, str) else key)


def encrypt_mfa_secret(secret: str) -> str:
    """Chiffre le secret TOTP avant persistance en base."""
    return _fernet().encrypt(secret.encode()).decode()


def decrypt_mfa_secret(value: str) -> str:
    """Déchiffre un secret TOTP persistant; refuse les valeurs invalides."""
    try:
        return _fernet().decrypt(value.encode()).decode()
    except (InvalidToken, ValueError, TypeError) as exc:
        raise ValueError("Secret MFA chiffré invalide") from exc


def decrypt_mfa_secret_compat(value: str) -> tuple[str, bool]:
    """Lit les anciennes valeurs plaintext pour permettre leur migration.

    Le booléen indique si la valeur était legacy. Les appelants doivent
    réenregistrer la valeur chiffrée dès qu'une lecture legacy réussit.
    """
    try:
        return decrypt_mfa_secret(value), False
    except ValueError:
        if value and pyotp.TOTP(value).secret == value:
            return value, True
        raise


def hash_backup_code(code: str) -> str:
    """Retourne uniquement le hash d'un code de secours normalisé."""
    return hashlib.sha256(code.strip().lower().encode()).hexdigest()


def hash_backup_codes(codes: list[str]) -> list[str]:
    return [hash_backup_code(code) for code in codes]


def consume_backup_code(code: str, stored_hashes: list[str]) -> tuple[bool, list[str]]:
    """Vérifie puis consomme un code de secours sans conserver le code brut."""
    candidate = hash_backup_code(code)
    for index, stored in enumerate(stored_hashes):
        if hmac.compare_digest(candidate, stored):
            return True, stored_hashes[:index] + stored_hashes[index + 1 :]
    return False, stored_hashes


def get_totp_uri(secret: str, email: str, clinic_name: str) -> str:
    """Retourne l'URI OTPAuth pour le QR code."""
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=email, issuer_name=clinic_name)


def generate_qr_code(uri: str) -> bytes:
    """Génère un QR code PNG 300x300px pour l'URI OTPAuth."""
    qr = qrcode.QRCode(version=1, box_size=10, border=2)
    qr.add_data(uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return buf.getvalue()


def generate_backup_codes(count: int = BACKUP_CODE_COUNT) -> list[str]:
    """Génère des codes de secours à usage unique.

    Chaque code est un hash SHA-256 d'un token aléatoire,
    tronqué aux 8 premiers caractères hexadécimaux pour facilité de saisie.
    """
    codes = []
    for _ in range(count):
        token = secrets.token_hex(16)
        code = hashlib.sha256(token.encode()).hexdigest()[:8]
        codes.append(code)
    return codes


def verify_backup_code(code: str, backup_codes: list[str]) -> bool:
    """Vérifie si un code de secours est valide et non utilisé."""
    return code.lower() in [c.lower() for c in backup_codes if c]


def verify_totp(secret: str, otp: str, window: int = 1) -> bool:
    """Vérifie un code OTP TOTP avec une fenêtre de ±1 période."""
    totp = pyotp.TOTP(secret)
    return totp.verify(otp, valid_window=window)


def get_current_totp(secret: str) -> str:
    """Retourne le code TOTP actuel (pour les tests uniquement)."""
    totp = pyotp.TOTP(secret)
    return totp.now()
