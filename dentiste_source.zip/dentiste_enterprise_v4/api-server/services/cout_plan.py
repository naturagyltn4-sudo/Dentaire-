"""Calcul déterministe des coûts de plans dentaires."""

from __future__ import annotations

from decimal import Decimal, ROUND_HALF_UP
from typing import Any, Mapping, Sequence

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.clinic_context import require_clinic_id
from models.database import ActeMedical, EstimationCoutPlan, PlanTraitementIA

CENT = Decimal("0.001")


def calculer_total_deterministe(
    lignes: Sequence[Mapping[str, Any]], tarifs: Mapping[int, Decimal]
) -> tuple[Decimal, list[dict[str, Any]]]:
    """Même lignes + mêmes tarifs => résultat identique, sans flottants binaires."""
    total = Decimal("0.000")
    details: list[dict[str, Any]] = []
    for index, ligne in enumerate(lignes):
        try:
            acte_id = int(ligne["acte_id"])
            quantite = Decimal(str(ligne.get("quantite", "1")))
        except (KeyError, TypeError, ValueError, ArithmeticError) as exc:
            raise ValueError(f"Ligne tarifaire invalide à l'index {index}") from exc
        if quantite <= 0 or quantite != quantite.to_integral_value():
            raise ValueError(f"Quantité invalide à l'index {index}")
        if acte_id not in tarifs:
            raise ValueError(f"Acte médical actif introuvable : {acte_id}")
        prix_unitaire = Decimal(str(tarifs[acte_id])).quantize(
            CENT, rounding=ROUND_HALF_UP
        )
        sous_total = (prix_unitaire * quantite).quantize(CENT, rounding=ROUND_HALF_UP)
        total += sous_total
        details.append(
            {
                "acte_id": acte_id,
                "quantite": str(quantite),
                "prix_unitaire": str(prix_unitaire),
                "sous_total": str(sous_total),
            }
        )
    return total.quantize(CENT, rounding=ROUND_HALF_UP), details


async def estimer_cout_plan(
    db: AsyncSession, plan_id: int, clinic_id: int | None = None
) -> dict[str, Any]:
    tenant_id = require_clinic_id(clinic_id, purpose="estimation du coût d’un plan")
    plan = (
        await db.execute(
            select(PlanTraitementIA).where(
                PlanTraitementIA.id == plan_id,
                PlanTraitementIA.clinic_id == tenant_id,
            )
        )
    ).scalar_one_or_none()
    if not plan:
        raise ValueError("Plan de traitement non trouvé")
    proposition = plan.proposition or {}
    lignes = proposition.get("lignes_tarifees")
    if not isinstance(lignes, list):
        raise ValueError(
            "La proposition ne contient pas de lignes_tarifees structurées"
        )
    acte_ids = {
        int(ligne["acte_id"]) for ligne in lignes if isinstance(ligne, dict) and "acte_id" in ligne
    }
    rows = (
        (
            await db.execute(
                select(ActeMedical).where(
                    ActeMedical.clinic_id == tenant_id,
                    ActeMedical.id.in_(acte_ids),
                    ActeMedical.is_active.is_(True),
                )
            )
        )
        .scalars()
        .all()
    )
    tarifs = {row.id: Decimal(str(row.prix_base)) for row in rows}
    total, details = calculer_total_deterministe(lignes, tarifs)
    existing = (
        await db.execute(
            select(EstimationCoutPlan).where(
                EstimationCoutPlan.clinic_id == tenant_id,
                EstimationCoutPlan.plan_id == plan_id,
            )
        )
    ).scalar_one_or_none()
    if existing:
        existing.total, existing.details = total, {"lignes": details}
        estimation = existing
    else:
        estimation = EstimationCoutPlan(
            clinic_id=plan.clinic_id,
            plan_id=plan.id,
            total=total,
            details={"lignes": details},
        )
        db.add(estimation)
    await db.flush()
    return {
        "plan_id": plan.id,
        "total": str(total),
        "devise": "EUR",
        "details": details,
        "llm_utilise": False,
    }
