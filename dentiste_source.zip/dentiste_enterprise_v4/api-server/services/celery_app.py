"""
AutoCommerce Clinic — Configuration Celery + tâches planifiées
"""

from celery import Celery
from celery.schedules import crontab
from config import get_settings
from middleware.clinic_context import require_clinic_id

settings = get_settings()


def _system_clinic_id() -> int:
    return require_clinic_id(settings.instance_clinic_id, purpose="une tâche système")


celery = Celery(
    "autocommerce_clinic",
    broker=settings.redis_url,
    backend=settings.redis_url,
    include=[
        "services.celery_app",
    ],
)

celery.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Africa/Tunis",
    enable_utc=True,
    beat_schedule={
        "reminder-j1": {
            "task": "services.celery_app.reminder_j1_task",
            "schedule": crontab(hour=18, minute=0),
        },
        "reminder-h2": {
            "task": "services.celery_app.reminder_h2_task",
            "schedule": crontab(minute="*/30"),
        },
        "check-stock-alerts": {
            "task": "services.celery_app.stock_alerts_task",
            "schedule": crontab(hour=8, minute=0),
        },
        "check-anniversaire": {
            "task": "services.celery_app.anniversaire_task",
            "schedule": crontab(hour=9, minute=0),
        },
        "check-inactivite": {
            "task": "services.celery_app.inactivite_task",
            "schedule": crontab(day_of_month=1, hour=10, minute=0),
        },
        "expire-points": {
            "task": "services.celery_app.expire_points_task",
            "schedule": crontab(day_of_month=1, hour=2, minute=0),
        },
        "calcul-commissions-mois": {
            "task": "services.celery_app.calcul_commissions_task",
            "schedule": crontab(day_of_month=1, hour=3, minute=0),
        },
        "injection-reminder": {
            "task": "services.celery_app.injection_reminder_task",
            "schedule": crontab(hour=9, minute=30),
        },
        "check-prothese-delays": {
            "task": "services.celery_app.prothese_delay_task",
            "schedule": crontab(hour=8, minute=30),
        },
    },
)


# ── Tâches ─────────────────────────────────────────────────


@celery.task
def extract_facture_ia_task(depense_id: int, clinic_id: int):
    """Tâche Celery : extraction IA d'une facture."""
    import asyncio
    from services.facture_scanner import extract_facture_ia
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            try:
                await extract_facture_ia(depense_id, db, clinic_id=clinic_id)
                await db.commit()
            except Exception:
                await db.rollback()
                raise

    asyncio.run(run())


@celery.task
def reminder_j1_task():
    """Rappel J-1 à 18h00."""
    import asyncio
    from services.agenda import reminder_j1
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await reminder_j1(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def reminder_h2_task():
    """Rappel H-2 toutes les 30 minutes."""
    import asyncio
    from services.agenda import reminder_h2
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await reminder_h2(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def stock_alerts_task():
    """Alertes stock quotidiennes."""
    import asyncio
    from services.alertes_stock import send_stock_alerts_whatsapp
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await send_stock_alerts_whatsapp(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def anniversaire_task():
    """Vérification anniversaires quotidienne."""
    import asyncio
    from services.fidelite_clinic import check_anniversaire
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await check_anniversaire(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def inactivite_task():
    """Relance inactivité mensuelle."""
    import asyncio
    from services.fidelite_clinic import check_inactivite
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await check_inactivite(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def expire_points_task():
    """Expiration points mensuelle."""
    import asyncio
    from services.fidelite_clinic import expire_points
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await expire_points(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def calcul_commissions_task():
    """Contrôle mensuel des commissions.

    Les commissions sont créées de manière idempotente au paiement d'une facture
    par ``services.factures``. Le job mensuel ne recalcule donc rien et sert de
    point d'observabilité sans appeler une API inexistante.
    """
    import logging

    logging.getLogger(__name__).info(
        "Contrôle mensuel des commissions exécuté pour clinic_id=%s",
        _system_clinic_id(),
    )


@celery.task
def injection_reminder_task():
    """Rappels injections quotidiens à 9h30."""
    import asyncio
    from services.rappels_injection import process_injection_reminders
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await process_injection_reminders(db, clinic_id=_system_clinic_id())

    asyncio.run(run())


@celery.task
def prothese_delay_task():
    """Vérification quotidienne des retards de prothèses à 8h30."""
    import asyncio
    from services.protheses import check_prothese_delays
    from models.database import get_async_engine, get_async_sessionmaker

    async def run():
        engine = get_async_engine(settings.database_url)
        session_factory = get_async_sessionmaker(engine)
        async with session_factory() as db:
            await check_prothese_delays(db, clinic_id=_system_clinic_id())

    asyncio.run(run())
