"""Réservation publique isolée de la clinique.

Le flux public crée d’abord une demande BookingRequest dans le contexte de
l’instance, applique les validations et la déduplication, puis seulement
ensuite crée le patient et le rendez-vous interne.
"""

import hashlib
import re
from datetime import datetime, timedelta

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from middleware.clinic_context import require_clinic_id
from models.database import (
    ActeMedical,
    BookingRequest,
    Patient,
    RendezVous,
    RoleEnum,
    StatutRDV,
    Utilisateur,
)
from services.agenda import creer_rdv, get_disponibilites
from services.datetime_utils import to_utc_naive

TELEPHONE_REGEX = re.compile(r"^\+?[0-9]{8,15}$")


def _valider_telephone(telephone: str) -> str:
    telephone = telephone.strip().replace(" ", "")
    if not TELEPHONE_REGEX.fullmatch(telephone):
        raise ValueError("Numéro de téléphone invalide")
    return telephone


def hash_source_ip(ip_address: str | None) -> str | None:
    """Stocke un hash non réversible de l’IP pour l’audit anti-spam."""
    if not ip_address:
        return None
    secret = get_settings().secret_key.encode("utf-8")
    return hashlib.sha256(secret + ip_address.encode("utf-8")).hexdigest()


async def _find_or_create_patient(
    nom: str, prenom: str, telephone: str, clinic_id: int, db: AsyncSession
) -> Patient:
    result = await db.execute(
        select(Patient).where(
            Patient.telephone == telephone,
            Patient.clinic_id == clinic_id,
        )
    )
    patient = result.scalar_one_or_none()
    if patient:
        return patient

    patient = Patient(
        clinic_id=clinic_id,
        nom=nom.strip(),
        prenom=prenom.strip(),
        telephone=telephone,
        whatsapp_phone=telephone,
        source_acquisition="landing_page",
    )
    db.add(patient)
    await db.flush()
    return patient


async def _select_dynamic_practitioner(
    specialite: str | None,
    acte_id: int,
    date_heure: datetime,
    clinic_id: int,
    db: AsyncSession,
) -> Utilisateur:
    acte_result = await db.execute(
        select(ActeMedical).where(
            ActeMedical.id == acte_id,
            ActeMedical.clinic_id == clinic_id,
            ActeMedical.is_active,
        )
    )
    acte = acte_result.scalar_one_or_none()
    if not acte:
        raise ValueError("Acte non trouvé")

    query = select(Utilisateur).where(
        Utilisateur.clinic_id == clinic_id,
        Utilisateur.is_active,
        Utilisateur.role.in_([
            RoleEnum.MEDECIN.value,
            RoleEnum.ORTHODONTISTE.value,
            RoleEnum.ESTHETICIENNE.value,
        ]),
    )
    if specialite:
        query = query.where(func.lower(Utilisateur.specialite) == specialite.strip().lower())
    practitioners = (await db.execute(query.order_by(Utilisateur.id))).scalars().all()
    if not practitioners:
        raise ValueError("Aucun praticien actif ne correspond à la spécialité demandée")

    available = []
    for practitioner in practitioners:
        slots = await get_disponibilites(
            practitioner.id,
            date_heure.date(),
            acte.duree_minutes,
            db,
            clinic_id=clinic_id,
        )
        if any(slot["datetime"] == date_heure.isoformat() for slot in slots):
            load = await db.scalar(
                select(func.count(RendezVous.id)).where(
                    and_(
                        RendezVous.clinic_id == clinic_id,
                        RendezVous.praticien_id == practitioner.id,
                        RendezVous.date_heure_debut >= datetime.utcnow(),
                        RendezVous.statut.in_([StatutRDV.PLANIFIE.value, StatutRDV.CONFIRME.value]),
                    )
                )
            )
            available.append((int(load or 0), practitioner.id, practitioner))
    if not available:
        raise ValueError("Aucun praticien disponible sur ce créneau")
    return min(available, key=lambda item: (item[0], item[1]))[2]


async def _validate_practitioner(
    praticien_id: int, acte_id: int, date_heure: datetime, clinic_id: int, db: AsyncSession
) -> Utilisateur:
    practitioner_result = await db.execute(
        select(Utilisateur).where(
            Utilisateur.id == praticien_id,
            Utilisateur.clinic_id == clinic_id,
            Utilisateur.is_active,
            Utilisateur.role.in_([
            RoleEnum.MEDECIN.value,
            RoleEnum.ORTHODONTISTE.value,
            RoleEnum.ESTHETICIENNE.value,
        ]),
        )
    )
    practitioner = practitioner_result.scalar_one_or_none()
    if not practitioner:
        raise ValueError("Praticien non trouvé")

    acte_result = await db.execute(
        select(ActeMedical).where(
            ActeMedical.id == acte_id,
            ActeMedical.clinic_id == clinic_id,
            ActeMedical.is_active,
        )
    )
    if not acte_result.scalar_one_or_none():
        raise ValueError("Acte non trouvé")

    # La vérification finale de disponibilité et des conflits est centralisée
    # dans `creer_rdv`, qui protège aussi les courses concurrentes.
    return practitioner


async def reserver_creneau_public(
    data: dict,
    db: AsyncSession,
    *,
    clinic_id: int | None = None,
    source_ip_hash: str | None = None,
) -> dict:
    clinic_id = require_clinic_id(
        clinic_id if clinic_id is not None else get_settings().instance_clinic_id,
        purpose="la réservation publique",
    )
    nom = str(data.get("nom", "")).strip()
    prenom = str(data.get("prenom", "")).strip()
    if not nom or not prenom:
        raise ValueError("Nom et prénom requis")

    date_heure = data.get("date_heure")
    if isinstance(date_heure, datetime):
        date_heure = to_utc_naive(date_heure)
    if not isinstance(date_heure, datetime) or date_heure <= datetime.utcnow():
        raise ValueError("La date du rendez-vous doit être future")

    telephone = _valider_telephone(str(data.get("telephone", "")))
    acte_id = int(data["acte_id"])
    praticien_id = data.get("praticien_id")

    if praticien_id is None:
        praticien = await _select_dynamic_practitioner(
            data.get("specialite"), acte_id, date_heure, clinic_id, db
        )
        praticien_id = praticien.id
    else:
        await _validate_practitioner(int(praticien_id), acte_id, date_heure, clinic_id, db)
        praticien_id = int(praticien_id)

    dedupe_since = datetime.utcnow() - timedelta(minutes=15)
    duplicate = await db.scalar(
        select(BookingRequest.id).where(
            BookingRequest.clinic_id == clinic_id,
            BookingRequest.telephone == telephone,
            BookingRequest.praticien_id == praticien_id,
            BookingRequest.acte_id == acte_id,
            BookingRequest.date_heure == date_heure,
            BookingRequest.created_at >= dedupe_since,
            BookingRequest.statut.in_(["pending", "accepted"]),
        )
    )
    if duplicate:
        raise ValueError("Une demande identique est déjà en cours de traitement")

    slot_conflict = await db.scalar(
        select(BookingRequest.id).where(
            BookingRequest.clinic_id == clinic_id,
            BookingRequest.praticien_id == praticien_id,
            BookingRequest.acte_id == acte_id,
            BookingRequest.date_heure == date_heure,
            BookingRequest.statut.in_(["pending", "accepted"]),
        )
    )
    if slot_conflict:
        raise ValueError("Conflit : ce créneau fait déjà l’objet d’une demande")

    booking_request = BookingRequest(
        clinic_id=clinic_id,
        nom=nom,
        prenom=prenom,
        telephone=telephone,
        praticien_id=praticien_id,
        acte_id=acte_id,
        date_heure=date_heure,
        specialite=data.get("specialite"),
        statut="pending",
        source_ip_hash=source_ip_hash,
    )
    db.add(booking_request)
    await db.flush()

    # La réservation publique reste une demande à traiter par la clinique.
    # Aucun patient ni rendez-vous interne ne doit être créé avant approbation.
    return {
        "booking_request_id": booking_request.id,
        "rdv_id": None,
        "patient_id": None,
        "praticien_id": praticien_id,
        "statut": "pending",
        "message": "Demande reçue — confirmation par la clinique à venir.",
    }


async def approuver_demande_public(
    booking_request_id: int,
    db: AsyncSession,
    *,
    clinic_id: int,
) -> dict:
    """Approuve une demande et crée alors le patient et le rendez-vous interne."""
    request = await db.scalar(
        select(BookingRequest)
        .where(
            BookingRequest.id == booking_request_id,
            BookingRequest.clinic_id == clinic_id,
        )
        .with_for_update()
    )
    if not request:
        raise ValueError("Demande publique introuvable")
    if request.statut != "pending":
        raise ValueError("Cette demande n’est plus en attente")

    await _validate_practitioner(
        request.praticien_id,
        request.acte_id,
        request.date_heure,
        clinic_id,
        db,
    )
    patient = await _find_or_create_patient(
        request.nom,
        request.prenom,
        request.telephone,
        clinic_id,
        db,
    )
    rdv, consentement_manquant = await creer_rdv(
        patient_id=patient.id,
        praticien_id=request.praticien_id,
        acte_id=request.acte_id,
        date_heure=request.date_heure,
        salle=None,
        db=db,
        clinic_id=clinic_id,
    )
    request.patient_id = patient.id
    request.rendez_vous_id = rdv.id
    request.statut = "accepted"
    request.validated_at = datetime.utcnow()
    await db.flush()
    return {
        "booking_request_id": request.id,
        "rdv_id": rdv.id,
        "patient_id": patient.id,
        "praticien_id": rdv.praticien_id,
        "statut": "accepted",
        "rdv_statut": rdv.statut,
        "consentement_a_signer_sur_place": consentement_manquant,
    }


async def rejeter_demande_public(
    booking_request_id: int,
    db: AsyncSession,
    *,
    clinic_id: int,
) -> dict:
    """Rejette une demande sans créer de patient ni de rendez-vous."""
    request = await db.scalar(
        select(BookingRequest)
        .where(
            BookingRequest.id == booking_request_id,
            BookingRequest.clinic_id == clinic_id,
        )
        .with_for_update()
    )
    if not request:
        raise ValueError("Demande publique introuvable")
    if request.statut != "pending":
        raise ValueError("Cette demande n’est plus en attente")
    request.statut = "rejected"
    request.rejected_at = datetime.utcnow()
    await db.flush()
    return {"booking_request_id": request.id, "statut": "rejected"}
