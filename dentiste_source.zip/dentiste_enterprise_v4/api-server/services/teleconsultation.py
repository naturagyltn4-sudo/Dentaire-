"""
AutoCommerce Clinic — Service Téléconsultation (V3 — P02-b)

Génération de liens visio et gestion d'état.

Stratégie :
  - La fonctionnalité est désactivée par défaut et doit être activée explicitement.
  - Si DAILY_API_KEY est configuré → création d'une room Daily.co privée.
  - En production, absence ou échec Daily.co → refus de création : aucun
    fallback vers un service vidéo public n'est autorisé.
  - En dev/test uniquement, fallback Jitsi public pour faciliter les essais.
  - Les garanties contractuelles et réglementaires du fournisseur doivent être
    vérifiées séparément par l'opérateur avant usage de données de santé.

Le lien généré stocke `provider` et `lien_visio` côté base + un
consentement éclairé écrit est obligatoire (`consent_url`).
"""

import logging
import time
import uuid
from typing import Optional
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
import httpx
from config import get_settings
from models.database import Teleconsultation, RendezVous
from middleware.clinic_context import require_clinic_id

logger = logging.getLogger(__name__)


async def _create_daily_room(
    clinic_id: int, rdv_id: int, expires_min: int
) -> Optional[str]:
    """Crée une room Daily.co privée ; renvoie l'URL ou None en cas d'échec."""
    s = get_settings()
    if not s.daily_api_key:
        return None
    room_name = f"clinic-{clinic_id}-rdv-{rdv_id}-{uuid.uuid4().hex[:8]}"
    payload = {
        "name": room_name,
        "privacy": "private",
        "properties": {
            "exp": int(time.time()) + expires_min * 60,
            "enable_chat": True,
            "enable_screenshare": False,
            "start_audio_off": False,
            "start_video_off": False,
            "eject_at_room_exp": True,
            "enable_recording": s.daily_enable_recording,
        },
    }
    url_created = f"{s.daily_api_base.rstrip('/')}/rooms"
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(
                url_created,
                headers={
                    "Authorization": f"Bearer {s.daily_api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            )
            r.raise_for_status()
            data = r.json()
            return data.get("url") or f"https://{room_name}.daily.co/{room_name}"
    except Exception as exc:  # pragma: no cover - réseau
        logger.exception("Daily.co room creation failed: %s", exc)
        return None


class TeleconsultationService:
    @staticmethod
    async def creer_pour_rdv(
        db: AsyncSession,
        rdv_id: int,
        clinic_id: int | None = None,
        consent_url: str | None = None,
    ) -> Optional[Teleconsultation]:
        clinic_id = require_clinic_id(clinic_id, purpose="la téléconsultation")
        settings = get_settings()
        if not getattr(settings, "teleconsultation_enabled", True):
            raise RuntimeError("La téléconsultation est désactivée par TELECONSULTATION_ENABLED")
        if not consent_url or not consent_url.lower().startswith("https://"):
            raise ValueError("Un lien HTTPS de consentement est requis")
        # Vérifier si le RDV existe
        stmt = select(RendezVous).where(
            RendezVous.id == rdv_id, RendezVous.clinic_id == clinic_id
        )
        result = await db.execute(stmt)
        rdv = result.scalar_one_or_none()
        if not rdv:
            return None

        # Vérifier si une téléconsultation existe déjà
        stmt_tc = select(Teleconsultation).where(
            Teleconsultation.rdv_id == rdv_id,
            Teleconsultation.clinic_id == clinic_id,
        )
        res_tc = await db.execute(stmt_tc)
        existing = res_tc.scalar_one_or_none()
        if existing:
            if not existing.consent_url:
                existing.consent_url = consent_url
                await db.commit()
                await db.refresh(existing)
            return existing

        # P02-b : Daily.co est obligatoire en production ; Jitsi est réservé
        # aux essais non productifs et ne doit jamais recevoir de données réelles.
        lien = await _create_daily_room(
            clinic_id, rdv_id, settings.daily_default_expires_min
        )
        if lien:
            provider = "daily"
        elif settings.env in {"production", "prod"}:
            raise RuntimeError(
                "DAILY_API_KEY et un compte Daily.co opérationnel sont requis en production"
            )
        else:
            room_name = f"Clinic-{clinic_id}-RDV-{rdv_id}-{uuid.uuid4().hex[:8]}"
            lien = f"https://meet.jit.si/{room_name}"
            provider = "jitsi"

        tc = Teleconsultation(
            clinic_id=clinic_id,
            rdv_id=rdv_id,
            lien_visio=lien,
            statut="planifiee",
            provider=provider,
            consent_url=consent_url,
        )
        db.add(tc)
        await db.commit()
        await db.refresh(tc)
        return tc

    @staticmethod
    async def get_by_rdv(
        db: AsyncSession,
        rdv_id: int,
        clinic_id: int | None = None,
    ) -> Optional[Teleconsultation]:
        clinic_id = require_clinic_id(clinic_id, purpose="lire une téléconsultation")
        stmt = select(Teleconsultation).where(
            Teleconsultation.rdv_id == rdv_id,
            Teleconsultation.clinic_id == clinic_id,
        )
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    async def marquer_terminee(
        db: AsyncSession,
        tc_id: int,
        duree: int = None,
        notes: str = None,
        clinic_id: int | None = None,
    ) -> bool:
        clinic_id = require_clinic_id(clinic_id, purpose="clôturer une téléconsultation")
        stmt = select(Teleconsultation).where(
            Teleconsultation.id == tc_id,
            Teleconsultation.clinic_id == clinic_id,
        )
        result = await db.execute(stmt)
        tc = result.scalar_one_or_none()
        if not tc:
            return False

        tc.statut = "terminee"
        if duree:
            tc.duree_reelle = duree
        if notes:
            tc.notes = notes

        await db.commit()
        return True
