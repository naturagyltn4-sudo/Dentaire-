"""
AutoCommerce Clinic — Gestion de l'E-réputation
Intégration OpenAI pour suggestions de réponses aux avis clients.
"""
from middleware.clinic_context import require_clinic_id

from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from models.database import AvisClient
from config import get_settings

settings = get_settings()


DEFAULT_OPENAI_MODEL = "gpt-4o"


def _get_model_name() -> str:
    """Renvoie le nom de modèle OpenAI à utiliser.

    Correctif Bug #6 (audit) : si ``settings.openai_model`` est absent
    ou laisse une chaîne vide, ``model=None`` fait echouer
    ``client.chat.completions.create`` au premier appel. La constante
    ``DEFAULT_OPENAI_MODEL = "gpt-4o"`` est utilisée comme garde-fou.
    Le rapport d'audit mentionne explicitement GPT-4o : la valeur par
    defaut dans ``config.py`` est deja ``"gpt-4o"``, mais cette
    double-securite evite toute regression si un dev met
    ``OPENAI_MODEL=`` dans son environment.
    """
    model = getattr(settings, "openai_model", None)
    if not model or not str(model).strip():
        return DEFAULT_OPENAI_MODEL
    return str(model).strip()


def _get_openai_client():
    """Initialisation paresseuse du client OpenAI.

    Correctif Bug #5 (audit) : le client était instancie au top-level du
    module, ce qui faisait planter l'application au demarrage en
    environnement de dev/CI sans ``OPENAI_API_KEY`` (openai.OpenAIError
    au constructeur). Le client est desormais cree a la premiere
    utilisation ; une cle absente ou invalide ne leve qu'au moment de
    l'appel reseau, avec un message d'erreur exploitable cote routeur.
    Le pattern miroir existe deja dans ``services/voice_transcription.py``.
    """
    api_key = getattr(settings, "openai_api_key", None)
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY manquant : renseignez settings.openai_api_key "
            "(variable d'environnement OPENAI_API_KEY) avant d'utiliser "
            "les fonctionnalites IA de reputation."
        )
    # Import local pour éviter le coût du module openai au démarrage de FastAPI.
    from openai import OpenAI

    return OpenAI(api_key=api_key)


async def generer_reponse_ia(
    avis: AvisClient, db: AsyncSession, clinic_id: int | None = None
) -> str:
    """Génère une réponse suggérée uniquement dans le tenant fourni."""
    if not isinstance(clinic_id, int) or clinic_id <= 0 or avis.clinic_id != clinic_id:
        raise ValueError("Avis hors clinique courante")

    system_prompt = (
        "Vous êtes le community manager d'une clinique d'esthétique haut de gamme (AutoCommerce Clinic). "
        "Votre ton doit être élégant, professionnel et empathique. "
        "RÈGLES CRITIQUES : "
        "1. Ne faites JAMAIS de promesse médicale ou de garantie de résultat. "
        "2. Ne faites JAMAIS de diagnostic. "
        "3. Remerciez le client pour son avis. "
        "4. Si l'avis est négatif, restez courtois et proposez un échange en privé. "
        "5. La réponse doit être concise et raffinée."
    )

    user_content = f"Plateforme : {avis.plateforme}\nNote : {avis.note}/5\nAvis : {avis.texte}\nAuteur : {avis.auteur_nom}"

    response = _get_openai_client().chat.completions.create(
        model=_get_model_name(),
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        temperature=0.7,
        max_tokens=500,
    )

    reponse_suggeree = response.choices[0].message.content.strip()

    # Mettre à jour l'avis
    avis.reponse_suggeree_ia = reponse_suggeree
    avis.statut = "suggere"
    await db.flush()

    return reponse_suggeree


async def valider_et_publier(
    avis_id: int,
    reponse_finale: str,
    db: AsyncSession,
    clinic_id: int | None = None,
) -> AvisClient:
    """Valide la réponse et marque l'avis comme publié dans le tenant."""
    clinic_id = require_clinic_id(clinic_id, purpose="publier un avis")
    result = await db.execute(
        select(AvisClient).where(
            AvisClient.id == avis_id,
            AvisClient.clinic_id == clinic_id,
        )
    )
    avis = result.scalar_one_or_none()

    if not avis:
        raise ValueError("Avis non trouvé")

    avis.reponse_publiee = reponse_finale
    avis.statut = "publie"
    await db.flush()

    return avis


async def get_avis(
    db: AsyncSession,
    plateforme: Optional[str] = None,
    clinic_id: int | None = None,
) -> List[AvisClient]:
    """Récupère la liste des avis du tenant fourni."""
    clinic_id = require_clinic_id(clinic_id, purpose="les avis")
    query = select(AvisClient).where(
        AvisClient.clinic_id == clinic_id
    ).order_by(AvisClient.created_at.desc())
    if plateforme:
        query = query.where(AvisClient.plateforme == plateforme)

    result = await db.execute(query)
    return list(result.scalars().all())
