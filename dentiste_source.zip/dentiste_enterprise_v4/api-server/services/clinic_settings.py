"""Gestion des paramètres cliniques, isolés par instance serveur."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, field_validator
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.clinic_context import require_clinic_id
from config import get_settings
from models.database import ClinicSetting

CACHE_TTL_SECONDS = 300
_SETTING_CACHE: dict[str, tuple[Any, datetime]] = {}

JsonScalar = str | int | float | bool | None
JsonValue = JsonScalar | list["JsonValue"] | dict[str, "JsonValue"]


def _assert_json_compatible(value: Any, path: str = "value") -> None:
    """Valide récursivement une structure JSON avant écriture en base."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _assert_json_compatible(item, f"{path}[{index}]")
        return
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValueError(f"{path}: JSON object keys must be strings")
            _assert_json_compatible(item, f"{path}.{key}")
        return
    raise ValueError(f"{path}: unsupported JSON value type {type(value).__name__}")


class _SettingPayloadModel(BaseModel):
    payload: dict[str, Any]

    @field_validator("payload")
    @classmethod
    def validate_payload(cls, value: dict[str, Any]) -> dict[str, Any]:
        _assert_json_compatible(value)
        return value


def _normalize_setting_value(value: Any) -> dict[str, JsonValue]:
    payload = value if isinstance(value, dict) else {"value": value}
    validated = _SettingPayloadModel.model_validate({"payload": payload}, strict=True)
    return validated.payload


async def get_setting(
    key: str,
    db: AsyncSession,
    default: Any = None,
    clinic_id: int | None = None,
) -> Any:
    """Lit un paramètre uniquement dans la clinique de l’instance."""
    clinic_id = require_clinic_id(
        clinic_id if clinic_id is not None else get_settings().instance_clinic_id,
        purpose="les paramètres cliniques",
    )
    cache_key = f"{clinic_id}:{key}"
    cached = _SETTING_CACHE.get(cache_key)
    if cached is not None:
        cached_value, cached_at = cached
        if (datetime.utcnow() - cached_at).total_seconds() < CACHE_TTL_SECONDS:
            return cached_value

    result = await db.execute(
        select(ClinicSetting).where(
            ClinicSetting.key == key,
            ClinicSetting.clinic_id == clinic_id,
        )
    )
    setting = result.scalar_one_or_none()
    if setting is None:
        return default

    _SETTING_CACHE[cache_key] = (setting.value, datetime.utcnow())
    return setting.value


async def set_setting(
    key: str,
    value: Any,
    db: AsyncSession,
    description: Optional[str] = None,
    clinic_id: int | None = None,
) -> ClinicSetting:
    """Met à jour ou crée un paramètre de la clinique courante."""
    clinic_id = require_clinic_id(
        clinic_id if clinic_id is not None else get_settings().instance_clinic_id,
        purpose="les paramètres cliniques",
    )
    normalized_value = _normalize_setting_value(value)
    result = await db.execute(
        select(ClinicSetting).where(
            ClinicSetting.key == key,
            ClinicSetting.clinic_id == clinic_id,
        )
    )
    setting = result.scalar_one_or_none()

    if setting is None:
        setting = ClinicSetting(
            clinic_id=clinic_id,
            key=key,
            value=normalized_value,
            description=description,
        )
        db.add(setting)
    else:
        setting.value = normalized_value
        if description:
            setting.description = description

    await db.flush()
    await db.commit()
    await db.refresh(setting)
    _SETTING_CACHE.pop(f"{clinic_id}:{key}", None)
    return setting


async def get_all_settings(
    db: AsyncSession, clinic_id: int | None = None
) -> dict:
    """Retourne les paramètres de la clinique courante."""
    clinic_id = require_clinic_id(
        clinic_id if clinic_id is not None else get_settings().instance_clinic_id,
        purpose="les paramètres cliniques",
    )
    result = await db.execute(
        select(ClinicSetting).where(ClinicSetting.clinic_id == clinic_id)
    )
    settings = result.scalars().all()
    return {setting.key: setting.value for setting in settings}
