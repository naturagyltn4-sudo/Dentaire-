"""Fonctions IA dentaires : aide à la lecture, jamais décision automatique."""

from __future__ import annotations
from middleware.clinic_context import require_clinic_id

import base64
import io
import json
import logging
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from core.llm_client import LLMClient, LLMUnavailable, get_llm_if_enabled
from core.llm_privacy import pseudonymiser_prompt_payload
from models.database import (
    AnalyseCaries,
    EtatDentaire,
    HistoriqueDentaire,
    ImagerieRadio,
    PlanTraitementIA,
)
from services.radiologie import get_decrypted_radio
from services.audit_medical import log_access

logger = logging.getLogger("ia_dentaire")

CAVITY_SCHEMA = {
    "type": "object",
    "properties": {
        "zones_suspectes": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "dent_fdi": {"type": ["string", "null"]},
                    "x": {"type": "number"},
                    "y": {"type": "number"},
                    "largeur": {"type": "number"},
                    "hauteur": {"type": "number"},
                    "confiance": {"type": "number"},
                    "description": {"type": "string"},
                },
                "required": [
                    "dent_fdi",
                    "x",
                    "y",
                    "largeur",
                    "hauteur",
                    "confiance",
                    "description",
                ],
                "additionalProperties": False,
            },
        },
        "limites": {"type": "string"},
    },
    "required": ["zones_suspectes", "limites"],
    "additionalProperties": False,
}

PLAN_SCHEMA = {
    "type": "object",
    "properties": {
        "priorites": {"type": "array", "items": {"type": "string"}},
        "proposition": {"type": "array", "items": {"type": "string"}},
        "justification": {"type": "string"},
        "avertissement": {"type": "string"},
    },
    "required": ["priorites", "proposition", "justification", "avertissement"],
    "additionalProperties": False,
}


def _data_url(image_bytes: bytes, media_type: str) -> str:
    return f"data:{media_type};base64,{base64.b64encode(image_bytes).decode('ascii')}"


def _pseudonymiser_patient_payload(patient_id: int, payload: dict) -> dict:
    """Compatibilité locale : filtre les PII uniquement dans le payload LLM."""
    return pseudonymiser_prompt_payload(payload, patient_ref=f"PATIENT-{patient_id}")


def _parse_json(text: str) -> Dict[str, Any]:
    value = json.loads(text)
    if not isinstance(value, dict):
        raise ValueError("La réponse IA doit être un objet JSON")
    return value


def _validate_cavity_result(value: Dict[str, Any]) -> Dict[str, Any]:
    zones = value.get("zones_suspectes")
    if not isinstance(zones, list):
        raise ValueError("zones_suspectes doit être une liste")
    for zone in zones:
        if not isinstance(zone, dict):
            raise ValueError("Chaque zone suspecte doit être un objet")
        dent = zone.get("dent_fdi")
        if dent is not None and (
            not isinstance(dent, str) or len(dent) != 2 or not dent.isdigit()
        ):
            raise ValueError("dent_fdi doit être un numéro FDI à deux chiffres ou null")
        if not 0 <= float(zone.get("confiance", -1)) <= 1:
            raise ValueError("La confiance doit être comprise entre 0 et 1")
    if not isinstance(value.get("limites"), str):
        raise ValueError("limites est obligatoire")
    return value


async def detecter_caries(
    db: AsyncSession,
    radio_id: int,
    praticien_id: int,
    *,
    settings: Any = None,
    llm: Optional[LLMClient] = None,
    clinic_id: int | None = None,
) -> Dict[str, Any]:
    """Analyse une radio et retourne uniquement une aide structurée.

    Cette fonction ne modifie ni EtatDentaire, ni HistoriqueDentaire, ni le diagnostic,
    ni le plan de traitement. Elle persiste seulement le résultat explicite de l’analyse.
    """
    clinic_id = require_clinic_id(clinic_id, purpose="l'IA dentaire")
    radio_result = await db.execute(
        select(ImagerieRadio).where(
            ImagerieRadio.id == radio_id,
            ImagerieRadio.clinic_id == clinic_id,
        )
    )
    radio = radio_result.scalar_one_or_none()
    if not radio:
        raise ValueError("Radio non trouvée")
    image_bytes, _ = await get_decrypted_radio(
        radio_id, praticien_id, db, clinic_id=clinic_id
    )
    media_type = "image/jpeg"
    if image_bytes.startswith(b"\x89PNG"):
        media_type = "image/png"
    elif radio.dicom_metadata and "error" not in radio.dicom_metadata:
        try:
            import pydicom
            from PIL import Image

            ds = pydicom.dcmread(io.BytesIO(image_bytes))
            pixels = ds.pixel_array
            image = Image.fromarray(pixels)
            output = io.BytesIO()
            image.save(output, format="PNG")
            image_bytes, media_type = output.getvalue(), "image/png"
        except Exception as exc:
            raise ValueError(f"Conversion DICOM impossible : {exc}") from exc

    client = get_llm_if_enabled(settings or get_settings(), llm)
    if client is None:
        raise RuntimeError("Copilote IA désactivé (COPILOTE_IA_ENABLED=false) — analyse impossible")
    messages = [
        {
            "role": "system",
            "content": (
                "Tu es une aide à la lecture de radiographies dentaires. Tu ne poses jamais de diagnostic. "
                "Retourne uniquement le JSON demandé. Les coordonnées sont normalisées entre 0 et 1. "
                "Associe un numéro FDI seulement si l'image le permet, sinon null."
            ),
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "Détecte les zones pouvant évoquer une carie et décris les limites de l'analyse.",
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": _data_url(image_bytes, media_type),
                        "detail": "high",
                    },
                },
            ],
        },
    ]
    out = await client.chat(
        messages,
        max_tokens=1200,
        response_format_json=True,
        use_cache=False,
        budget_session=db,
        clinic_id=clinic_id,
        cache_context={"clinic_id": clinic_id, "data_classification": "medical"},
    )
    if isinstance(out, LLMUnavailable):
        raise RuntimeError(f"LLM indisponible : {out.reason}")
    try:
        result = _validate_cavity_result(_parse_json(out.text))
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        raise RuntimeError(f"Résultat IA invalide : {exc}") from exc
    analysis = AnalyseCaries(
        clinic_id=radio.clinic_id,
        radio_id=radio.id,
        patient_id=radio.patient_id,
        praticien_id=praticien_id,
        resultat=result,
        created_at=datetime.utcnow(),
    )
    db.add(analysis)
    await db.flush()

    await log_access(
        db=db,
        utilisateur_id=praticien_id,
        patient_id=radio.patient_id,
        action="IA_CARIES_ANALYSIS",
        resource_type="analyse_caries",
        resource_id=analysis.id,
        clinic_id=radio.clinic_id,
        details={"radio_id": radio.id},
    )

    return {
        "id": analysis.id,
        "radio_id": radio.id,
        "patient_id": radio.patient_id,
        "resultat": result,
        "aide_uniquement": True,
    }


async def proposer_plan_traitement(
    db: AsyncSession,
    patient_id: int,
    praticien_id: int,
    *,
    settings: Any = None,
    llm: Optional[LLMClient] = None,
    clinic_id: int | None = None,
) -> Dict[str, Any]:
    """Produit une proposition non validée, sans créer d'acte ni modifier l'état dentaire."""
    clinic_id = require_clinic_id(clinic_id, purpose="l'IA dentaire")
    etats = (
        (
            await db.execute(
                select(EtatDentaire).where(
                    EtatDentaire.patient_id == patient_id,
                    EtatDentaire.clinic_id == clinic_id,
                )
            )
        )
        .scalars()
        .all()
    )
    historique = (
        (
            await db.execute(
                select(HistoriqueDentaire)
                .where(HistoriqueDentaire.patient_id == patient_id)
                .where(HistoriqueDentaire.clinic_id == clinic_id)
                .order_by(HistoriqueDentaire.created_at.desc())
                .limit(50)
            )
        )
        .scalars()
        .all()
    )
    analyses = (
        (
            await db.execute(
                select(AnalyseCaries)
                .where(AnalyseCaries.patient_id == patient_id)
                .where(AnalyseCaries.clinic_id == clinic_id)
                .order_by(AnalyseCaries.created_at.desc())
                .limit(20)
            )
        )
        .scalars()
        .all()
    )
    raw_payload = {
        "etat_dentaire": [
            {"dent": e.numero_dent, "statut": e.statut, "face": e.face} for e in etats
        ],
        "historique_dentaire": [
            {
                "dent": h.numero_dent,
                "ancien": h.statut_ancien,
                "nouveau": h.statut_nouveau,
            }
            for h in historique
        ],
        "analyses_caries": [a.resultat for a in analyses],
    }
    payload = _pseudonymiser_patient_payload(patient_id, raw_payload)
    client = get_llm_if_enabled(settings or get_settings(), llm)
    if client is None:
        raise RuntimeError("Copilote IA désactivé (COPILOTE_IA_ENABLED=false) — proposition impossible")
    out = await client.chat(
        [
            {
                "role": "system",
                "content": "Tu proposes un plan de traitement dentaire à faire valider par un praticien. Ne valides jamais le plan. Retourne uniquement le JSON demandé.",
            },
            {
                "role": "user",
                "content": json.dumps(payload, ensure_ascii=False, default=str),
            },
        ],
        max_tokens=1200,
        response_format_json=True,
        use_cache=False,
        budget_session=db,
        clinic_id=clinic_id,
        cache_context={"clinic_id": clinic_id, "data_classification": "medical"},
    )
    if isinstance(out, LLMUnavailable):
        raise RuntimeError(f"LLM indisponible : {out.reason}")
    try:
        proposal = _parse_json(out.text)
        for key in PLAN_SCHEMA["required"]:
            if key not in proposal:
                raise ValueError(f"Champ manquant : {key}")
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        raise RuntimeError(f"Proposition IA invalide : {exc}") from exc
    plan = PlanTraitementIA(
        clinic_id=clinic_id,
        patient_id=patient_id,
        cree_par_praticien_id=praticien_id,
        proposition=proposal,
    )
    db.add(plan)
    await db.flush()

    await log_access(
        db=db,
        utilisateur_id=praticien_id,
        patient_id=patient_id,
        action="IA_PROPOSITION_PLAN_TRAITEMENT",
        resource_type="plan_traitement_ia",
        resource_id=plan.id,
        clinic_id=clinic_id,
    )

    return {
        "id": plan.id,
        "patient_id": patient_id,
        "proposition": proposal,
        "valide_par_praticien_id": None,
        "statut": "a_valider",
    }


async def valider_plan(
    db: AsyncSession,
    plan_id: int,
    praticien_id: int,
    clinic_id: int | None = None,
) -> PlanTraitementIA:
    clinic_id = require_clinic_id(clinic_id, purpose="la validation du plan IA")
    plan_result = await db.execute(
        select(PlanTraitementIA).where(
            PlanTraitementIA.id == plan_id,
            PlanTraitementIA.clinic_id == clinic_id,
        )
    )
    plan = plan_result.scalar_one_or_none() if hasattr(plan_result, "scalar_one_or_none") else plan_result
    if plan is not None and hasattr(plan, "clinic_id") and plan.clinic_id != clinic_id:
        plan = None
    if not plan:
        raise ValueError("Plan non trouvé")
    plan.valide_par_praticien_id = praticien_id
    plan.valide_at = datetime.utcnow()
    await db.flush()

    await log_access(
        db=db,
        utilisateur_id=praticien_id,
        patient_id=plan.patient_id,
        action="IA_VALIDATION_PLAN_TRAITEMENT",
        resource_type="plan_traitement_ia",
        resource_id=plan.id,
        clinic_id=clinic_id,
    )

    return plan


async def valider_analyse_caries(
    db: AsyncSession,
    analyse_id: int,
    praticien_id: int,
    clinic_id: int | None = None,
) -> AnalyseCaries:
    clinic_id = require_clinic_id(clinic_id, purpose="la validation de l’analyse IA")
    analyse_result = await db.execute(
        select(AnalyseCaries).where(
            AnalyseCaries.id == analyse_id,
            AnalyseCaries.clinic_id == clinic_id,
        )
    )
    analyse = analyse_result.scalar_one_or_none() if hasattr(analyse_result, "scalar_one_or_none") else analyse_result
    if analyse is not None and hasattr(analyse, "clinic_id") and analyse.clinic_id != clinic_id:
        analyse = None
    if not analyse:
        raise ValueError("Analyse non trouvée")
    if analyse.valide_par_praticien_id is not None:
        raise ValueError("Analyse déjà validée")
    analyse.valide_par_praticien_id = praticien_id
    analyse.valide_at = datetime.utcnow()
    await db.flush()

    await log_access(
        db=db,
        utilisateur_id=praticien_id,
        patient_id=analyse.patient_id,
        action="IA_VALIDATION_DETECTION_CARIES",
        resource_type="analyse_caries",
        resource_id=analyse.id,
        clinic_id=clinic_id,
    )
    return analyse


async def envoyer_plan_patient(
    db: AsyncSession,
    plan_id: int,
    praticien_id: int,
    clinic_id: int | None = None,
) -> Dict[str, Any]:
    clinic_id = require_clinic_id(clinic_id, purpose="l’envoi du plan IA")
    plan_result = await db.execute(
        select(PlanTraitementIA).where(
            PlanTraitementIA.id == plan_id,
            PlanTraitementIA.clinic_id == clinic_id,
        )
    )
    plan = plan_result.scalar_one_or_none() if hasattr(plan_result, "scalar_one_or_none") else plan_result
    if plan is not None and hasattr(plan, "clinic_id") and plan.clinic_id != clinic_id:
        plan = None
    if not plan:
        raise ValueError("Plan non trouvé")
    if plan.valide_par_praticien_id is None:
        raise PermissionError(
            "Le plan doit être validé par un praticien avant tout envoi"
        )
    plan.envoye_at = datetime.utcnow()
    await db.flush()

    await log_access(
        db=db,
        utilisateur_id=praticien_id,
        patient_id=plan.patient_id,
        action="IA_ENVOI_PLAN_TRAITEMENT",
        resource_type="plan_traitement_ia",
        resource_id=plan.id,
        clinic_id=clinic_id,
    )

    return {
        "plan_id": plan.id,
        "patient_id": plan.patient_id,
        "envoye": True,
        "envoye_par_praticien_id": praticien_id,
    }
