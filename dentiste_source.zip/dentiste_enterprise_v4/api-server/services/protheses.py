"""
AutoCommerce Clinic — Service Prothèses et Laboratoire (BLOC 6)
"""
from middleware.clinic_context import require_clinic_id

from datetime import date, datetime
from decimal import Decimal
from typing import Optional

from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from services.audit_medical import log_access

from models.database import (
    CommandeProthese,
    EtatDentaire,
    HistoriqueDentaire,
    StatutDent,
    StatutProthese,
    TypeProthese,
    Patient,
    Utilisateur,
    RoleEnum,
)
from services.notification_equipe import envoyer_message


async def create_commande_prothese(
    db: AsyncSession,
    patient_id: int,
    type_prothese: str,
    laboratoire: str,
    date_reception_prevue: date,
    cout: Decimal,
    dent: Optional[str] = None,
    dents: Optional[str] = None,
    date_commande: Optional[date] = None,
    clinic_id: int | None = None,
    praticien_id: Optional[int] = None,
) -> CommandeProthese:
    """Créer une commande de prothèse dentaire dans le tenant fourni."""
    clinic_id = require_clinic_id(clinic_id, purpose="créer une prothèse")
    if type_prothese not in [t.value for t in TypeProthese]:
        raise ValueError(f"Type de prothèse invalide : {type_prothese}")

    # Vérifier patient
    patient = await db.scalar(
        select(Patient).where(
            Patient.id == patient_id,
            Patient.clinic_id == clinic_id,
        )
    )
    if not patient:
        raise ValueError("Patient non trouvé")

    if praticien_id is not None:
        praticien = await db.scalar(
            select(Utilisateur).where(
                Utilisateur.id == praticien_id,
                Utilisateur.clinic_id == clinic_id,
                Utilisateur.is_active,
            )
        )
        if not praticien:
            raise ValueError("Praticien non trouvé dans la clinique courante")

    commande = CommandeProthese(
        clinic_id=clinic_id,
        patient_id=patient_id,
        dent=dent,
        dents=dents or dent,
        type=type_prothese,
        laboratoire=laboratoire,
        date_commande=date_commande or date.today(),
        date_reception_prevue=date_reception_prevue,
        statut=StatutProthese.COMMANDE.value,
        cout=cout,
    )
    db.add(commande)
    await db.flush()

    if praticien_id is not None:
        await log_access(
            db=db,
            utilisateur_id=praticien_id,
            patient_id=patient_id,
            action="CREATE_COMMANDE_PROTHESE",
            resource_type="commande_prothese",
            resource_id=commande.id,
            clinic_id=clinic_id,
            details={"type": type_prothese, "laboratoire": laboratoire},
        )

    return commande


async def poser_prothese(
    db: AsyncSession,
    prothese_id: int,
    praticien_id: int,
    clinic_id: int | None = None,
) -> CommandeProthese:
    """
    Pose une prothèse dentaire dans une transaction unique :
    1. Met à jour le statut de la commande à 'pose' et date_reception_reelle à aujourd'hui.
    2. Met à jour l'EtatDentaire pour chaque dent concernée (crée ou met à jour).
    3. Crée un HistoriqueDentaire append-only pour chaque dent modifiée.
    """
    clinic_id = require_clinic_id(clinic_id, purpose="poser une prothèse")

    # 1. Récupérer la commande
    commande = await db.scalar(
        select(CommandeProthese).where(
            and_(
                CommandeProthese.id == prothese_id,
                CommandeProthese.clinic_id == clinic_id,
            )
        )
    )
    if not commande:
        raise ValueError("Commande de prothèse introuvable")

    if commande.statut == StatutProthese.POSE.value:
        raise ValueError("Cette prothèse a déjà été posée")

    # Vérifier praticien
    praticien = await db.scalar(
        select(Utilisateur).where(
            Utilisateur.id == praticien_id,
            Utilisateur.clinic_id == clinic_id,
            Utilisateur.is_active,
        )
    )
    if not praticien:
        raise ValueError("Praticien introuvable")

    # Déterminer le statut dentaire correspondant au type de prothèse
    statut_dent_map = {
        TypeProthese.COURONNE.value: StatutDent.COURONNE.value,
        TypeProthese.BRIDGE.value: StatutDent.BRIDGE.value,
        TypeProthese.IMPLANT.value: StatutDent.IMPLANT.value,
        TypeProthese.PROTHESE_AMOVIBLE.value: StatutDent.ABSENTE.value,  # ou autre selon convention, par défaut couronne/implant/etc.
    }
    nouveau_statut_dent = statut_dent_map.get(commande.type, StatutDent.COURONNE.value)

    # Extraire les numéros de dents (ex: "16" ou "16,17" ou "16 17")
    dents_str = commande.dents or commande.dent or ""
    # Nettoyage et séparation des numéros de dents FDI
    import re

    numeros_dents = [d.strip() for d in re.split(r"[,;\s]+", dents_str) if d.strip()]

    # Transaction atomique
    try:
        commande.statut = StatutProthese.POSE.value
        if not commande.date_reception_reelle:
            commande.date_reception_reelle = date.today()
        commande.updated_at = datetime.utcnow()

        for numero_dent in numeros_dents:
            # Récupérer ou créer l'état dentaire
            etat = await db.scalar(
                select(EtatDentaire).where(
                    and_(
                        EtatDentaire.patient_id == commande.patient_id,
                        EtatDentaire.clinic_id == clinic_id,
                        EtatDentaire.numero_dent == numero_dent,
                    )
                )
            )

            if not etat:
                etat = EtatDentaire(
                    clinic_id=clinic_id,
                    patient_id=commande.patient_id,
                    numero_dent=numero_dent,
                    statut=nouveau_statut_dent,
                    praticien_id=praticien_id,
                    notes=f"Pose prothèse {commande.type} (ref: #{commande.id})",
                    date_modification=datetime.utcnow(),
                )
                db.add(etat)
                await db.flush()

                historique = HistoriqueDentaire(
                    clinic_id=clinic_id,
                    etat_dentaire_id=etat.id,
                    patient_id=commande.patient_id,
                    numero_dent=numero_dent,
                    statut_ancien=None,
                    statut_nouveau=nouveau_statut_dent,
                    praticien_id=praticien_id,
                    notes=f"Pose prothèse #{commande.id}",
                )
                db.add(historique)
            else:
                statut_ancien = etat.statut
                etat.statut = nouveau_statut_dent
                etat.praticien_id = praticien_id
                etat.notes = f"Pose prothèse {commande.type} (ref: #{commande.id})"
                etat.date_modification = datetime.utcnow()
                etat.updated_at = datetime.utcnow()

                historique = HistoriqueDentaire(
                    clinic_id=clinic_id,
                    etat_dentaire_id=etat.id,
                    patient_id=commande.patient_id,
                    numero_dent=numero_dent,
                    statut_ancien=statut_ancien,
                    statut_nouveau=nouveau_statut_dent,
                    praticien_id=praticien_id,
                    notes=f"Pose prothèse #{commande.id}",
                )
                db.add(historique)

        await db.commit()
        await db.refresh(commande)

        await log_access(
            db=db,
            utilisateur_id=praticien_id,
            patient_id=commande.patient_id,
            action="VALIDATE_POSE_PROTHESE",
            resource_type="commande_prothese",
            resource_id=commande.id,
            clinic_id=clinic_id,
            details={
                "type": commande.type,
                "dents": numeros_dents,
                "statut_ancien": "commande",
            },
        )

        return commande
    except Exception:
        await db.rollback()
        raise


async def check_prothese_delays(db: AsyncSession, clinic_id: int | None = None) -> int:
    clinic_id = require_clinic_id(clinic_id, purpose="les retards de prothèses")
    """
    Vérifie si la date prévue de réception d'une prothèse est dépassée
    et que la prothèse n'est ni reçue ni posée.
    Utilise le moteur de notifications existant (messages internes / équipe).
    """
    today = date.today()
    stmt = select(CommandeProthese).where(
        and_(
            CommandeProthese.clinic_id == clinic_id,
            CommandeProthese.date_reception_prevue < today,
            CommandeProthese.statut.in_(
                [
                    StatutProthese.COMMANDE.value,
                    StatutProthese.EN_FABRICATION.value,
                    StatutProthese.RETOUR_LABO.value,
                ]
            ),
        )
    )
    result = await db.execute(stmt)
    en_retard = result.scalars().all()

    notif_count = 0
    # Récupérer un administrateur ou la directrice pour notifier
    admin_result = await db.execute(
        select(Utilisateur.id)
        .where(
            Utilisateur.role.in_(
                [
                    RoleEnum.DIRECTRICE.value,
                    RoleEnum.ADMIN.value,
                    RoleEnum.MEDECIN.value,
                    RoleEnum.ASSISTANTE.value,
                ]
            )
        )
        .where(Utilisateur.clinic_id == clinic_id)
        .where(Utilisateur.is_active)
        .limit(1)
    )
    admin_id = admin_result.scalar_one_or_none()

    if not admin_id:
        # Fallback sur n'importe quel utilisateur actif
        user_result = await db.execute(
            select(Utilisateur.id)
            .where(Utilisateur.clinic_id == clinic_id)
            .where(Utilisateur.is_active)
            .limit(1)
        )
        admin_id = user_result.scalar_one_or_none()

    if not admin_id:
        return 0

    for proth in en_retard:
        sujet = f"Retard Prothèse #{proth.id} — Labo {proth.laboratoire}"
        contenu = (
            f"La prothèse ({proth.type}) pour le patient #{proth.patient_id} "
            f"prévue le {proth.date_reception_prevue.strftime('%d/%m/%Y')} est en retard "
            f"(statut actuel : {proth.statut})."
        )
        try:
            # Utilise le moteur de notifications existant (messages internes)
            await envoyer_message(
                db=db,
                expediteur_id=admin_id,
                destinataire_id=admin_id,
                sujet=sujet,
                contenu=contenu,
                clinic_id=proth.clinic_id,
            )
            notif_count += 1
        except Exception:
            pass

    await db.commit()
    return notif_count
