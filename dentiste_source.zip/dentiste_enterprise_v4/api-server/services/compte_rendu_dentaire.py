"""Compte rendu dentaire assisté par LLM, toujours soumis à validation humaine."""
from middleware.clinic_context import require_clinic_id

import json
from datetime import datetime
from typing import Any

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from core.llm_client import LLMUnavailable, get_llm_if_enabled
from core.llm_privacy import pseudonymiser_prompt_payload
from models.database import (
    CompteRenduDentaire,
    EtatDentaire,
    HistoriqueDentaire,
    Patient,
    PlanTraitementIA,
    StatutCompteRenduDentaire,
)


async def _contexte_dentaire(
    db: AsyncSession,
    patient_id: int,
    plan_id: int | None,
    clinic_id: int | None = None,
) -> dict[str, Any]:
    clinic_id = require_clinic_id(clinic_id, purpose="le compte rendu dentaire")
    patient = (
        await db.execute(
            select(Patient).where(
                Patient.id == patient_id,
                Patient.clinic_id == clinic_id,
            )
        )
    ).scalar_one_or_none()
    if patient is None:
        raise ValueError("Patient non trouvé")
    etats = (
        await db.execute(select(EtatDentaire).where(
            EtatDentaire.patient_id == patient_id,
            EtatDentaire.clinic_id == clinic_id,
        ))
    ).scalars().all()
    historique = (
        await db.execute(
            select(HistoriqueDentaire)
                            .where(HistoriqueDentaire.patient_id == patient_id)
                .where(HistoriqueDentaire.clinic_id == clinic_id)

            .order_by(HistoriqueDentaire.created_at.desc())
            .limit(50)
        )
    ).scalars().all()
    plan = None
    if plan_id:
        plan = (
            await db.execute(
                select(PlanTraitementIA).where(
                    PlanTraitementIA.id == plan_id,
                    PlanTraitementIA.clinic_id == clinic_id,
                )
            )
        ).scalar_one_or_none()
    return {
        "patient_id": patient_id,
        "etat_dentaire": [
            {"dent_fdi": e.numero_dent, "statut": e.statut, "notes": e.notes}
            for e in etats
        ],
        "historique_dentaire": [
            {"dent_fdi": h.numero_dent, "ancien": h.statut_ancien, "nouveau": h.statut_nouveau}
            for h in historique
        ],
        "plan": plan.proposition if plan else None,
    }


async def generer_compte_rendu(
    db: AsyncSession,
    patient_id: int,
    praticien_id: int,
    plan_id: int | None = None,
    clinic_id: int | None = None,
) -> CompteRenduDentaire:
    clinic_id = require_clinic_id(clinic_id, purpose="le compte rendu dentaire")
    contexte = await _contexte_dentaire(db, patient_id, plan_id, clinic_id=clinic_id)
    prompt_contexte = pseudonymiser_prompt_payload(
        contexte, patient_ref=f"PATIENT-{patient_id}"
    )
    messages = [
        {
            "role": "system",
            "content": (
                "Tu es un assistant de rédaction dentaire. Rédige une proposition de compte rendu "
                "structurée en français. Ne pose aucun diagnostic définitif et ne valide aucun plan. "
                "Retourne uniquement un JSON avec titre, observations, actes_proposes, suivi_recommande."
            ),
        },
        {"role": "user", "content": json.dumps(prompt_contexte, ensure_ascii=False, default=str)},
    ]
    llm = get_llm_if_enabled(get_settings())
    if llm is None:
        raise RuntimeError("Copilote IA désactivé (COPILOTE_IA_ENABLED=false)")
    out = await llm.chat(
        messages,
        max_tokens=1200,
        response_format_json=True,
        budget_session=db,
        clinic_id=clinic_id,
        cache_context={"clinic_id": clinic_id, "data_classification": "medical"},
    )
    if isinstance(out, LLMUnavailable):
        raise RuntimeError(f"LLM indisponible: {out.reason}")
    try:
        contenu = json.dumps(json.loads(out.text), ensure_ascii=False)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("Réponse du LLM non structurée") from exc
    compte_rendu = CompteRenduDentaire(
        clinic_id=clinic_id,
        patient_id=patient_id,
        plan_id=plan_id,
        contenu=contenu,
        statut=StatutCompteRenduDentaire.PROPOSITION.value,
        cree_par_praticien_id=praticien_id,
    )
    db.add(compte_rendu)
    await db.flush()
    return compte_rendu


async def modifier_compte_rendu(
    db: AsyncSession,
    compte_rendu_id: int,
    praticien_id: int,
    contenu: str,
    clinic_id: int | None = None,
) -> CompteRenduDentaire:
    clinic_id = require_clinic_id(clinic_id, purpose="le compte rendu dentaire")
    compte_rendu = (
        await db.execute(
            select(CompteRenduDentaire).where(
                CompteRenduDentaire.id == compte_rendu_id,
                CompteRenduDentaire.clinic_id == clinic_id,
            )
        )
    ).scalar_one_or_none()
    if compte_rendu is None:
        raise ValueError("Compte rendu introuvable")
    if compte_rendu.cree_par_praticien_id != praticien_id and compte_rendu.valide_par_praticien_id != praticien_id:
        raise PermissionError("Modification réservée au praticien autorisé")
    compte_rendu.contenu = contenu
    compte_rendu.modifie_at = datetime.utcnow()
    await db.flush()
    return compte_rendu


async def valider_compte_rendu(
    db: AsyncSession,
    compte_rendu_id: int,
    praticien_id: int,
    clinic_id: int | None = None,
) -> CompteRenduDentaire:
    clinic_id = require_clinic_id(clinic_id, purpose="le compte rendu dentaire")
    compte_rendu = (
        await db.execute(
            select(CompteRenduDentaire).where(
                CompteRenduDentaire.id == compte_rendu_id,
                CompteRenduDentaire.clinic_id == clinic_id,
            )
        )
    ).scalar_one_or_none()
    if compte_rendu is None:
        raise ValueError("Compte rendu introuvable")
    compte_rendu.statut = StatutCompteRenduDentaire.VALIDE.value
    compte_rendu.valide_par_praticien_id = praticien_id
    compte_rendu.valide_at = datetime.utcnow()
    await db.flush()
    return compte_rendu
