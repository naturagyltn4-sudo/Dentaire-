"""
AutoCommerce Clinic — Gestion agenda
Disponibilités, création RDV, rappels WhatsApp
"""
from middleware.clinic_context import require_clinic_id

import logging
from datetime import datetime, timedelta, date
from typing import List, Optional

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, text

logger = logging.getLogger(__name__)

from models.database import (  # noqa: E402
    RendezVous,
    Patient,
    Utilisateur,
    ActeMedical,
    StatutRDV,
    Salle,
)
from services.consentement import verify_consent  # noqa: E402
from services.whatsapp_service import send_whatsapp_message  # noqa: E402
from services.branding import get_branding_context  # noqa: E402
from config import WA_TEMPLATES  # noqa: E402


async def _lock_booking_scope(
    db: AsyncSession,
    clinic_id: int,
    praticien_id: int,
    date_heure: datetime,
    salle_id: Optional[int] = None,
) -> None:
    """Sérialise les réservations concurrentes sur le même périmètre.

    PostgreSQL conserve ce verrou jusqu'au commit/rollback. Cela évite que deux
    requêtes simultanées voient la même disponibilité puis créent un doublon.
    Les moteurs de test non-PostgreSQL continuent avec les vérifications métier.
    """
    bind = db.get_bind()
    if bind is None or bind.dialect.name != "postgresql":
        return
    lock_key = f"{clinic_id}:{date_heure.date().isoformat()}:{praticien_id}:{salle_id or 0}"
    await db.execute(
        text("SELECT pg_advisory_xact_lock(hashtextextended(:lock_key, 0))"),
        {"lock_key": lock_key},
    )


async def get_disponibilites(
    praticien_id: int,
    date_jour: date,
    duree_minutes: int,
    db: AsyncSession,
    salle_id: Optional[int] = None,
    fauteuil_numero: Optional[int] = None,
    clinic_id: int | None = None,
) -> List[dict]:
    """Retourne les créneaux libres d'un praticien dans le tenant courant."""
    clinic_id = require_clinic_id(clinic_id, purpose="les disponibilités")
    # Déterminer les horaires selon le jour
    jour_semaine = date_jour.weekday()  # 0=lundi, 6=dimanche
    if jour_semaine >= 5:  # weekend
        return []

    heure_debut = 9
    heure_fin = 18 if jour_semaine < 4 else 13

    # Créneaux de base (toutes les 30 min)
    creneaux = []
    current = datetime.combine(date_jour, datetime.min.time().replace(hour=heure_debut))
    end = datetime.combine(date_jour, datetime.min.time().replace(hour=heure_fin))

    while current + timedelta(minutes=duree_minutes) <= end:
        creneaux.append(current)
        current += timedelta(minutes=30)

    # Récupérer RDV existants du praticien
    result = await db.execute(
        select(RendezVous)
        .where(
            RendezVous.praticien_id == praticien_id,
            RendezVous.clinic_id == clinic_id,
        )
        .where(
            RendezVous.date_heure_debut
            >= datetime.combine(date_jour, datetime.min.time())
        )
        .where(
            RendezVous.date_heure_debut
            < datetime.combine(date_jour + timedelta(days=1), datetime.min.time())
        )
        .where(
            RendezVous.statut.notin_([StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value])
        )
    )
    rdvs_praticien = result.scalars().all()

    # Récupérer RDV existants pour la salle/fauteuil si spécifiés
    rdvs_ressource = []
    salle_obj = None
    if salle_id:
        salle_res = await db.execute(
            select(Salle).where(
                Salle.id == salle_id,
                Salle.clinic_id == clinic_id,
            )
        )
        salle_obj = salle_res.scalar_one_or_none()
        if salle_obj is None:
            return []
        if fauteuil_numero is not None and (
            fauteuil_numero < 1 or fauteuil_numero > salle_obj.capacite_fauteuils
        ):
            return []

        if fauteuil_numero is not None:
            res = await db.execute(
                select(RendezVous)
                .where(
                    RendezVous.salle_id == salle_id,
                    RendezVous.clinic_id == clinic_id,
                )
                .where(RendezVous.fauteuil_numero == fauteuil_numero)
                .where(
                    RendezVous.date_heure_debut
                    >= datetime.combine(date_jour, datetime.min.time())
                )
                .where(
                    RendezVous.date_heure_debut
                    < datetime.combine(
                        date_jour + timedelta(days=1), datetime.min.time()
                    )
                )
                .where(
                    RendezVous.statut.notin_(
                        [StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value]
                    )
                )
            )
            rdvs_ressource = res.scalars().all()
        else:
            # On récupère tous les RDV de la salle pour vérifier la capacité
            res = await db.execute(
                select(RendezVous)
                .where(
                    RendezVous.salle_id == salle_id,
                    RendezVous.clinic_id == clinic_id,
                )
                .where(
                    RendezVous.date_heure_debut
                    >= datetime.combine(date_jour, datetime.min.time())
                )
                .where(
                    RendezVous.date_heure_debut
                    < datetime.combine(
                        date_jour + timedelta(days=1), datetime.min.time()
                    )
                )
                .where(
                    RendezVous.statut.notin_(
                        [StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value]
                    )
                )
            )
            rdvs_ressource = res.scalars().all()
    # Filtrer les créneaux occupés
    creneaux_libres = []
    for creneau in creneaux:
        fin_creneau = creneau + timedelta(minutes=duree_minutes)
        occupe = False

        # Conflit praticien
        for rdv in rdvs_praticien:
            rdv_fin = rdv.date_heure_fin or rdv.date_heure_debut + timedelta(minutes=30)
            if not (fin_creneau <= rdv.date_heure_debut or creneau >= rdv_fin):
                occupe = True
                break

        if occupe:
            continue

        # Conflit ressource (salle/fauteuil)
        if salle_id:
            if fauteuil_numero:
                for rdv in rdvs_ressource:
                    rdv_fin = rdv.date_heure_fin or rdv.date_heure_debut + timedelta(
                        minutes=30
                    )
                    if not (fin_creneau <= rdv.date_heure_debut or creneau >= rdv_fin):
                        occupe = True
                        break
            else:
                # Vérifier capacité
                nb_occupants = 0
                for rdv in rdvs_ressource:
                    rdv_fin = rdv.date_heure_fin or rdv.date_heure_debut + timedelta(
                        minutes=30
                    )
                    if not (fin_creneau <= rdv.date_heure_debut or creneau >= rdv_fin):
                        nb_occupants += 1
                if nb_occupants >= salle_obj.capacite_fauteuils:
                    occupe = True

        if not occupe:
            creneaux_libres.append(creneau)

    return [
        {
            "heure": c.strftime("%H:%M"),
            "datetime": c.isoformat(),
        }
        for c in creneaux_libres
    ]


async def creer_rdv(
    patient_id: int,
    praticien_id: int,
    acte_id: int,
    date_heure: datetime,
    salle: Optional[str] = None,
    db: AsyncSession = None,
    created_by: Optional[int] = None,
    clinic_id: int | None = None,
    salle_id: Optional[int] = None,
    fauteuil_numero: Optional[int] = None,
) -> RendezVous:
    """Crée un rendez-vous dans le tenant fourni."""
    clinic_id = require_clinic_id(clinic_id, purpose="créer un rendez-vous")
    patient_result = await db.execute(
        select(Patient).where(
            Patient.id == patient_id,
            Patient.clinic_id == clinic_id,
        )
    )
    if patient_result.scalar_one_or_none() is None:
        raise ValueError("Patient non trouvé dans la clinique courante")
    praticien_result = await db.execute(
        select(Utilisateur).where(
            Utilisateur.id == praticien_id,
            Utilisateur.clinic_id == clinic_id,
            Utilisateur.is_active,
        )
    )
    if praticien_result.scalar_one_or_none() is None:
        raise ValueError("Praticien non trouvé dans la clinique courante")
    # Récupérer durée acte
    result = await db.execute(
        select(ActeMedical).where(
            ActeMedical.id == acte_id,
            ActeMedical.clinic_id == clinic_id,
        )
    )
    acte = result.scalar_one_or_none()
    if not acte:
        raise ValueError("Acte non trouvé")

    duree = acte.duree_minutes
    date_fin = date_heure + timedelta(minutes=duree)

    await _lock_booking_scope(
        db,
        clinic_id=clinic_id,
        praticien_id=praticien_id,
        date_heure=date_heure,
        salle_id=salle_id,
    )

    # Vérifier conflit praticien et ressource dans la même transaction verrouillée.
    conflit_praticien = await db.execute(
        select(RendezVous)
        .where(
            RendezVous.praticien_id == praticien_id,
            RendezVous.clinic_id == clinic_id,
        )
        .where(
            RendezVous.statut.notin_([StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value])
        )
        .where(
            and_(
                RendezVous.date_heure_debut < date_fin,
                RendezVous.date_heure_fin > date_heure,
            )
        )
    )
    if conflit_praticien.scalar_one_or_none():
        raise ValueError("Conflit : le praticien a déjà un RDV sur ce créneau")

    # Vérifier conflit salle / fauteuil
    if salle_id:
        # Un fauteuil spécifique dans une salle
        if fauteuil_numero:
            conflit_fauteuil = await db.execute(
                select(RendezVous)
                .where(
                    RendezVous.salle_id == salle_id,
                    RendezVous.clinic_id == clinic_id,
                )
                .where(RendezVous.fauteuil_numero == fauteuil_numero)
                .where(
                    RendezVous.statut.notin_(
                        [StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value]
                    )
                )
                .where(
                    and_(
                        RendezVous.date_heure_debut < date_fin,
                        RendezVous.date_heure_fin > date_heure,
                    )
                )
            )
            if conflit_fauteuil.scalar_one_or_none():
                raise ValueError(
                    f"Conflit : le fauteuil {fauteuil_numero} de cette salle est déjà occupé"
                )
        else:
            # Si pas de fauteuil spécifié, on vérifie si la salle est pleine
            # (Optionnel selon l'énoncé, mais cohérent avec capacite_fauteuils)
            res_salle = await db.execute(
                select(Salle).where(
                    Salle.id == salle_id,
                    Salle.clinic_id == clinic_id,
                )
            )
            salle_obj = res_salle.scalar_one_or_none()
            if salle_obj:
                occupants = await db.execute(
                    select(RendezVous)
                    .where(RendezVous.salle_id == salle_id)
                    .where(
                        RendezVous.statut.notin_(
                            [StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value]
                        )
                    )
                    .where(
                        and_(
                            RendezVous.date_heure_debut < date_fin,
                            RendezVous.date_heure_fin > date_heure,
                        )
                    )
                )
                if len(occupants.scalars().all()) >= salle_obj.capacite_fauteuils:
                    raise ValueError(
                        f"Conflit : la salle {salle_obj.nom} est déjà au complet"
                    )

    # Vérifier conflit salle (ancienne version string pour compatibilité)
    if salle and not salle_id:
        conflit_salle = await db.execute(
            select(RendezVous)
            .where(
                RendezVous.salle == salle,
                RendezVous.clinic_id == clinic_id,
            )
            .where(
                RendezVous.statut.notin_(
                    [StatutRDV.ANNULE.value, StatutRDV.NO_SHOW.value]
                )
            )
            .where(
                and_(
                    RendezVous.date_heure_debut < date_fin,
                    RendezVous.date_heure_fin.is_not(None),
                    RendezVous.date_heure_fin > date_heure,
                )
            )
        )
        if conflit_salle.scalar_one_or_none():
            raise ValueError(f"Conflit : la salle {salle} est déjà occupée")

    # Vérifier consentement
    consentement_manquant = not await verify_consent(
        patient_id, acte_id, db, clinic_id=clinic_id
    )

    rdv = RendezVous(
        clinic_id=clinic_id,
        patient_id=patient_id,
        praticien_id=praticien_id,
        acte_id=acte_id,
        date_heure_debut=date_heure,
        date_heure_fin=date_fin,
        salle=salle,
        salle_id=salle_id,
        fauteuil_numero=fauteuil_numero,
        statut=StatutRDV.PLANIFIE.value,
        created_by=created_by,
    )
    db.add(rdv)
    await db.flush()

    # Notification WhatsApp confirmation
    patient_result = await db.execute(select(Patient).where(Patient.id == patient_id))
    patient = patient_result.scalar_one()

    if patient.whatsapp_phone and not patient.opted_out:
        praticien_result = await db.execute(
            select(Utilisateur).where(Utilisateur.id == praticien_id)
        )
        praticien = praticien_result.scalar_one()
        branding = await get_branding_context(db, clinic_id)

        message = f"{branding['clinic_name']} — " + WA_TEMPLATES[
            "rdv_confirmation"
        ].format(
            date=date_heure.strftime("%d/%m/%Y"),
            heure=date_heure.strftime("%H:%M"),
            praticien=f"{praticien.prenom} {praticien.nom}",
        )
        result = await send_whatsapp_message(patient.whatsapp_phone, message)
        if result.get("status") == "dev_mode":
            logger.warning(
                f"Rappel RDV confirmation non envoyé (WhatsApp non configuré) : patient_id={patient_id}"
            )

    return rdv, consentement_manquant


async def annuler_rdv(
    rdv_id: int,
    raison: str,
    db: AsyncSession,
    clinic_id: int | None = None,
) -> RendezVous:
    """Annule un RDV dans le tenant fourni et envoie WhatsApp au patient."""
    clinic_id = require_clinic_id(clinic_id, purpose="annuler un rendez-vous")
    result = await db.execute(
        select(RendezVous).where(
            RendezVous.id == rdv_id,
            RendezVous.clinic_id == clinic_id,
        )
    )
    rdv = result.scalar_one_or_none()
    if not rdv:
        raise ValueError("RDV non trouvé")

    rdv.statut = StatutRDV.ANNULE.value
    rdv.notes_post_acte = f"Annulé : {raison}"
    await db.flush()

    # Notification WhatsApp
    patient_result = await db.execute(
        select(Patient).where(
            Patient.id == rdv.patient_id,
            Patient.clinic_id == clinic_id,
        )
    )
    patient = patient_result.scalar_one()

    if patient.whatsapp_phone and not patient.opted_out:
        branding = await get_branding_context(db, clinic_id)
        message = (
            f"{branding['clinic_name']} — Votre rendez-vous du {rdv.date_heure_debut.strftime('%d/%m à %Hh%M')} a été annulé.\n"
            f"Raison : {raison}\nPour reprogrammer, répondez RDV."
        )
        result = await send_whatsapp_message(patient.whatsapp_phone, message)
        if result.get("status") == "dev_mode":
            logger.warning(
                f"Notification annulation non envoyée (WhatsApp non configuré) : patient_id={patient.id}"
            )

    return rdv


async def reminder_j1(db: AsyncSession, clinic_id: int | None = None):
    """Tâche Celery : rappel J-1 à 18h00.

    Tous les RDV de demain non annulés.
    WA : rappel + confirmation OUI/NON.
    Si NON → alerte secrétariat.
    """
    demain = date.today() + timedelta(days=1)
    debut = datetime.combine(demain, datetime.min.time())
    fin = datetime.combine(demain + timedelta(days=1), datetime.min.time())

    result = await db.execute(
        select(RendezVous, Patient, Utilisateur)
        .join(Patient, RendezVous.patient_id == Patient.id)
        .join(Utilisateur, RendezVous.praticien_id == Utilisateur.id)
        .where(RendezVous.clinic_id == clinic_id)
        .where(Patient.clinic_id == clinic_id)
        .where(Utilisateur.clinic_id == clinic_id)
        .where(RendezVous.date_heure_debut >= debut)
        .where(RendezVous.date_heure_debut < fin)
        .where(
            RendezVous.statut.in_([StatutRDV.PLANIFIE.value, StatutRDV.CONFIRME.value])
        )
        .where(not RendezVous.rappel_j1_envoye)
    )

    branding = await get_branding_context(db, clinic_id)

    for rdv, patient, praticien in result.all():
        if patient.whatsapp_phone and not patient.opted_out:
            message = f"{branding['clinic_name']} — " + WA_TEMPLATES[
                "rdv_rappel_j1"
            ].format(
                heure=rdv.date_heure_debut.strftime("%H:%M"),
                praticien=f"{praticien.prenom} {praticien.nom}",
            )
            result = await send_whatsapp_message(patient.whatsapp_phone, message)
            if result.get("status") == "dev_mode":
                logger.warning(
                    f"Rappel J-1 non envoyé (WhatsApp non configuré) : patient_id={patient.id}, rdv_id={rdv.id}"
                )
            else:
                rdv.rappel_j1_envoye = True

    await db.flush()


async def reminder_h2(db: AsyncSession, clinic_id: int | None = None):
    """Tâche Celery : rappel H-2.

    RDV dans exactement 2 heures.
    """
    now = datetime.utcnow()
    dans_2h = now + timedelta(hours=2)
    marge = timedelta(minutes=5)

    result = await db.execute(
        select(RendezVous, Patient)
        .join(Patient, RendezVous.patient_id == Patient.id)
        .where(RendezVous.clinic_id == clinic_id)
        .where(Patient.clinic_id == clinic_id)
        .where(RendezVous.date_heure_debut >= dans_2h - marge)
        .where(RendezVous.date_heure_debut <= dans_2h + marge)
        .where(
            RendezVous.statut.in_([StatutRDV.PLANIFIE.value, StatutRDV.CONFIRME.value])
        )
        .where(not RendezVous.rappel_h2_envoye)
    )

    branding = await get_branding_context(db, clinic_id)

    for rdv, patient in result.all():
        if patient.whatsapp_phone and not patient.opted_out:
            message = WA_TEMPLATES["rdv_rappel_h2"].format(
                clinique=branding["clinic_name"],
                adresse=branding["address"] or "Adresse communiquée par la clinique",
            )
            result = await send_whatsapp_message(patient.whatsapp_phone, message)
            if result.get("status") == "dev_mode":
                logger.warning(
                    f"Rappel H-2 non envoyé (WhatsApp non configuré) : patient_id={patient.id}, rdv_id={rdv.id}"
                )
            else:
                rdv.rappel_h2_envoye = True

    await db.flush()
