"""Agrégation sécurisée du parcours patient pour la vue 360°."""
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.clinic_context import require_clinic_id
from models.database import (
    DevisTraitement,
    DossierMedical,
    Facture,
    Patient,
    PlanTraitement,
    EtapePlanTraitement,
    RendezVous,
    StatutFacture,
    StatutRDV,
    SuiviPostOperatoire,
)
from services.patients import get_patient


async def get_patient_360(patient_id: int, current_user: dict, db: AsyncSession) -> dict:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="lire la synthèse patient")
    patient = await db.scalar(
        select(Patient).where(Patient.id == patient_id, Patient.clinic_id == clinic_id)
    )
    if not patient:
        raise ValueError("Patient non trouvé")
    if current_user.get("role") == "commercial" and patient.commercial_id != current_user.get("id"):
        raise PermissionError("Ce patient n'est pas rattaché à ce commercial")

    appointments = (await db.execute(
        select(RendezVous)
        .where(RendezVous.patient_id == patient_id, RendezVous.clinic_id == clinic_id)
        .order_by(RendezVous.date_heure_debut.desc())
        .limit(20)
    )).scalars().all()
    dossiers = (await db.execute(
        select(DossierMedical)
        .where(DossierMedical.patient_id == patient_id, DossierMedical.clinic_id == clinic_id)
        .order_by(DossierMedical.date_acte.desc())
        .limit(10)
    )).scalars().all()
    devis = (await db.execute(
        select(DevisTraitement)
        .where(DevisTraitement.patient_id == patient_id, DevisTraitement.clinic_id == clinic_id)
        .order_by(DevisTraitement.created_at.desc())
        .limit(10)
    )).scalars().all()
    factures = (await db.execute(
        select(Facture)
        .where(Facture.patient_id == patient_id, Facture.clinic_id == clinic_id)
        .order_by(Facture.date_emission.desc())
        .limit(10)
    )).scalars().all()
    suivis = (await db.execute(
        select(SuiviPostOperatoire)
        .where(
            SuiviPostOperatoire.patient_id == patient_id,
            SuiviPostOperatoire.clinic_id == clinic_id,
        )
        .order_by(SuiviPostOperatoire.date_controle_prevue.desc())
        .limit(10)
    )).scalars().all()
    plans = (await db.execute(
        select(PlanTraitement)
        .where(PlanTraitement.patient_id == patient_id, PlanTraitement.clinic_id == clinic_id)
        .order_by(PlanTraitement.updated_at.desc())
        .limit(10)
    )).scalars().all()

    # La base patient applique déjà le filtrage des champs médicaux chiffrés.
    summary = await get_patient(patient_id, current_user, db)
    actions: list[dict] = []
    if any(item.suivi_requis and item.date_suivi_recommandee for item in dossiers):
        actions.append({"type": "suivi", "priorite": "haute", "libelle": "Contrôle ou suivi recommandé à planifier"})
    if any(item.statut in {"envoye", "brouillon"} for item in devis):
        actions.append({"type": "devis", "priorite": "normale", "libelle": "Devis en attente de décision"})
    if any(item.statut in {StatutFacture.ENVOYEE.value, StatutFacture.PARTIELLEMENT_PAYEE.value} for item in factures):
        actions.append({"type": "paiement", "priorite": "normale", "libelle": "Paiement ou solde à vérifier"})
    if any(item.statut == StatutRDV.NO_SHOW.value for item in appointments):
        actions.append({"type": "rdv", "priorite": "normale", "libelle": "Rendez-vous manqué à reprogrammer"})
    if any(item.statut == "planifie" for item in suivis):
        actions.append({"type": "post_op", "priorite": "haute", "libelle": "Suivi postopératoire planifié"})

    return {
        "patient": summary,
        "actions_aujourdhui": actions[:20],
        "rendez_vous": [
            {"id": item.id, "date_heure_debut": item.date_heure_debut, "date_heure_fin": item.date_heure_fin, "statut": item.statut, "praticien_id": item.praticien_id, "acte_id": item.acte_id}
            for item in appointments
        ],
        "dossiers": [
            {"id": item.id, "date_acte": item.date_acte, "acte_id": item.acte_id, "suivi_requis": item.suivi_requis, "date_suivi_recommandee": item.date_suivi_recommandee}
            for item in dossiers
        ],
        "devis": [
            {"id": item.id, "prix": item.prix, "statut": item.statut, "date_validite": item.date_validite, "acte_id": item.acte_id}
            for item in devis
        ],
        "factures": [
            {"id": item.id, "numero_facture": item.numero_facture, "total_ttc": item.total_ttc, "statut": item.statut, "date_echeance": item.date_echeance}
            for item in factures
        ],
        "suivis_post_op": [
            {"id": item.id, "date_prevue": item.date_controle_prevue, "statut": item.statut, "acte_id": item.acte_id}
            for item in suivis
        ],
        "plans_traitement": [
            {
                "id": plan.id,
                "titre": plan.titre,
                "statut": plan.statut,
                "date_cible": plan.date_cible,
                "etapes_total": int(await db.scalar(select(func.count(EtapePlanTraitement.id)).where(EtapePlanTraitement.plan_id == plan.id, EtapePlanTraitement.clinic_id == clinic_id)) or 0),
            }
            for plan in plans
        ],
    }
