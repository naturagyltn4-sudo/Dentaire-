"""Gestion Radiologie & Imagerie DICOM.

Les fichiers sont chiffrés au repos et toutes les lectures sont bornées par
clinic_id côté serveur avant tout accès disque.
"""
from middleware.clinic_context import require_clinic_id

import io
import os
from datetime import datetime
from typing import List, Optional, Tuple

import pydicom
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from models.database import ImagerieRadio, Patient
from services.audit_medical import log_access
from services.photos_clinic import _calculate_hash, _decrypt_file, _encrypt_file

settings = get_settings()
ALLOWED_RADIO_TYPES = ["panoramique", "CBCT", "retro-alveolaire"]


def _extract_dicom_metadata(file_bytes: bytes) -> dict:
    """Extrait uniquement les métadonnées DICOM non pixelisées."""
    try:
        with io.BytesIO(file_bytes) as file_obj:
            dataset = pydicom.dcmread(file_obj)
        return {
            "Modality": getattr(dataset, "Modality", "Unknown"),
            "BodyPartExamined": getattr(dataset, "BodyPartExamined", "Unknown"),
            "StudyDate": getattr(dataset, "StudyDate", "Unknown"),
            "Manufacturer": getattr(dataset, "Manufacturer", "Unknown"),
            "InstitutionName": getattr(dataset, "InstitutionName", "Unknown"),
            "StationName": getattr(dataset, "StationName", "Unknown"),
            "SoftwareVersions": getattr(dataset, "SoftwareVersions", "Unknown"),
        }
    except Exception:
        return {"error": "Non-DICOM or invalid DICOM file"}


async def upload_radio(
    patient_id: int,
    praticien_id: int,
    type_radio: str,
    file_bytes: bytes,
    dent_associee: Optional[str] = None,
    notes: Optional[str] = None,
    db: AsyncSession = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    clinic_id: int | None = None,
) -> ImagerieRadio:
    """Uploader une radio après vérification patient/clinique côté serveur."""
    clinic_id = require_clinic_id(clinic_id, purpose="la radiologie")
    if type_radio not in ALLOWED_RADIO_TYPES:
        raise ValueError(f"Type de radio non autorisé. Autorisés : {ALLOWED_RADIO_TYPES}")
    if not file_bytes or len(file_bytes) > settings.max_photo_size_mb * 1024 * 1024:
        raise ValueError("Fichier radio vide ou trop volumineux")

    patient_res = await db.execute(
        select(Patient).where(Patient.id == patient_id, Patient.clinic_id == clinic_id)
    )
    patient = patient_res.scalar_one_or_none()
    if not patient:
        raise ValueError("Patient non trouvé")

    dicom_meta = _extract_dicom_metadata(file_bytes)
    file_hash = _calculate_hash(file_bytes)
    nonce, ciphertext = _encrypt_file(file_bytes)

    date_dir = datetime.utcnow().strftime("%Y/%m/radios")
    base_path = os.path.join(str(settings.photos_dir), date_dir)
    os.makedirs(base_path, exist_ok=True)
    filename = f"radio_{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S_%f')}.enc"
    full_path = os.path.join(base_path, filename)
    with open(full_path, "wb") as file_obj:
        file_obj.write(nonce + ciphertext)

    radio = ImagerieRadio(
        clinic_id=clinic_id,
        patient_id=patient_id,
        praticien_id=praticien_id,
        type_radio=type_radio,
        dent_associee=dent_associee,
        url_stockage=full_path,
        hash_fichier=file_hash,
        taille_octets=len(file_bytes),
        dicom_metadata=dicom_meta,
        notes=notes,
        date_prise=datetime.utcnow(),
    )
    db.add(radio)
    await db.flush()
    await log_access(
        db=db,
        utilisateur_id=praticien_id,
        patient_id=patient_id,
        action="UPLOAD_RADIO",
        resource_type="radio",
        resource_id=radio.id,
        clinic_id=clinic_id,
        ip_address=ip_address,
        user_agent=user_agent,
        details={"type": type_radio, "dent": dent_associee},
    )
    return radio


async def get_decrypted_radio(
    radio_id: int,
    utilisateur_id: int,
    db: AsyncSession,
    clinic_id: int | None = None,
) -> Tuple[bytes, ImagerieRadio]:
    """Récupérer une radio uniquement dans le contexte de l’instance."""
    clinic_id = require_clinic_id(clinic_id, purpose="la radiologie")
    res = await db.execute(
        select(ImagerieRadio).where(
            ImagerieRadio.id == radio_id,
            ImagerieRadio.clinic_id == clinic_id,
        )
    )
    radio = res.scalar_one_or_none()
    if not radio:
        raise ValueError("Radio non trouvée")
    if not radio.url_stockage or not os.path.exists(radio.url_stockage):
        raise FileNotFoundError("Fichier radio manquant sur le disque")

    with open(radio.url_stockage, "rb") as file_obj:
        data = file_obj.read()
    if len(data) <= 12:
        raise ValueError("Fichier radio chiffré invalide")
    decrypted_bytes = _decrypt_file(data[:12], data[12:])
    await log_access(
        db=db,
        utilisateur_id=utilisateur_id,
        patient_id=radio.patient_id,
        action="VIEW_RADIO",
        resource_type="radio",
        resource_id=radio.id,
        clinic_id=clinic_id,
        details={"type": radio.type_radio, "clinic_id": clinic_id},
    )
    return decrypted_bytes, radio


async def list_radios(
    patient_id: int, db: AsyncSession, clinic_id: int | None = None
) -> List[ImagerieRadio]:
    """Lister les radios d’un patient dans la clinique de l’instance."""
    clinic_id = require_clinic_id(clinic_id, purpose="la radiologie")
    res = await db.execute(
        select(ImagerieRadio)
        .where(ImagerieRadio.patient_id == patient_id, ImagerieRadio.clinic_id == clinic_id)
        .order_by(ImagerieRadio.date_prise.desc())
    )
    return list(res.scalars().all())
