"""Fiche personnel légère, sans paie ni RH complet."""
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.clinic_context import require_clinic_id
from models.database import PersonnelProfile, Utilisateur


def _serialize(profile: PersonnelProfile, user: Utilisateur, include_private: bool = False) -> dict:
    result = {
        "id": profile.id,
        "user_id": user.id,
        "nom": user.nom,
        "prenom": user.prenom,
        "email": user.email,
        "telephone": user.telephone,
        "role": user.role,
        "photo_profil_url": user.photo_profil_url,
        "is_active": user.is_active,
        "adresse": profile.adresse,
        "fonction": profile.fonction,
        "date_embauche": profile.date_embauche,
        "diplomes": profile.diplomes,
        "specialisations": profile.specialisations,
        "certifications": profile.certifications,
        "documents": profile.documents or [] if include_private else [],
        "notes_internes": profile.notes_internes if include_private else None,
        "created_at": profile.created_at,
        "updated_at": profile.updated_at,
    }
    return result


async def get_or_create_profile(user_id: int, current_user: dict, db: AsyncSession) -> dict:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="lire une fiche personnel")
    user = await db.scalar(select(Utilisateur).where(Utilisateur.id == user_id, Utilisateur.clinic_id == clinic_id))
    if not user:
        raise ValueError("Membre introuvable")
    profile = await db.scalar(select(PersonnelProfile).where(PersonnelProfile.user_id == user_id, PersonnelProfile.clinic_id == clinic_id))
    if not profile:
        profile = PersonnelProfile(clinic_id=clinic_id, user_id=user_id)
        db.add(profile)
        await db.flush()
    return _serialize(profile, user, include_private=current_user.get("role") in {"directrice", "admin"})


async def update_profile(user_id: int, data: dict, current_user: dict, db: AsyncSession) -> dict:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="modifier une fiche personnel")
    user = await db.scalar(select(Utilisateur).where(Utilisateur.id == user_id, Utilisateur.clinic_id == clinic_id))
    if not user:
        raise ValueError("Membre introuvable")
    profile = await db.scalar(select(PersonnelProfile).where(PersonnelProfile.user_id == user_id, PersonnelProfile.clinic_id == clinic_id))
    if not profile:
        profile = PersonnelProfile(clinic_id=clinic_id, user_id=user_id)
        db.add(profile)
    for field in ("adresse", "fonction", "date_embauche", "diplomes", "specialisations", "certifications", "documents", "notes_internes"):
        if field not in data:
            continue
        value = data[field]
        if field == "documents":
            if value is not None and (not isinstance(value, list) or len(value) > 50):
                raise ValueError("La liste de documents est invalide")
            value = value or []
        elif isinstance(value, str):
            value = value.strip()
            max_length = 300 if field == "adresse" else 100 if field == "fonction" else 4000
            value = value[:max_length] or None
        setattr(profile, field, value)
    await db.flush()
    return _serialize(profile, user, include_private=current_user.get("role") in {"directrice", "admin"})


async def list_profiles(current_user: dict, db: AsyncSession) -> list[dict]:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="lister le personnel")
    result = await db.execute(
        select(Utilisateur, PersonnelProfile)
        .outerjoin(PersonnelProfile, (PersonnelProfile.user_id == Utilisateur.id) & (PersonnelProfile.clinic_id == clinic_id))
        .where(Utilisateur.clinic_id == clinic_id)
        .order_by(Utilisateur.is_active.desc(), Utilisateur.nom, Utilisateur.prenom)
    )
    profiles = []
    for user, profile in result.all():
        if profile is None:
            profile = PersonnelProfile(clinic_id=clinic_id, user_id=user.id)
            db.add(profile)
            await db.flush()
        profiles.append(_serialize(profile, user, include_private=current_user.get("role") in {"directrice", "admin"}))
    return profiles
