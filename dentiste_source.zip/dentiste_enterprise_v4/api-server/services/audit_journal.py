"""Journal applicatif d'audit, utilisé pour les comptes et les dossiers."""

from datetime import datetime
from typing import Any, Optional

from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from models.database import JournalAudit, Utilisateur


async def log_event(
    db: AsyncSession,
    *,
    utilisateur_id: int,
    clinic_id: int,
    action: str,
    resource_type: str,
    resource_id: Optional[int] = None,
    patient_id: Optional[int] = None,
    details: Optional[dict[str, Any]] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
) -> JournalAudit:
    event = JournalAudit(
        clinic_id=clinic_id,
        utilisateur_id=utilisateur_id,
        patient_id=patient_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        details=details or {},
        ip_address=ip_address,
        user_agent=user_agent,
        created_at=datetime.utcnow(),
    )
    db.add(event)
    await db.flush()
    return event


async def list_events(
    db: AsyncSession,
    *,
    clinic_id: int,
    patient_id: Optional[int] = None,
    utilisateur_id: Optional[int] = None,
    resource_type: Optional[str] = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    query = (
        select(JournalAudit, Utilisateur)
        .join(Utilisateur, Utilisateur.id == JournalAudit.utilisateur_id)
        .where(JournalAudit.clinic_id == clinic_id)
        .order_by(desc(JournalAudit.created_at), desc(JournalAudit.id))
        .limit(limit)
    )
    if patient_id is not None:
        query = query.where(JournalAudit.patient_id == patient_id)
    if utilisateur_id is not None:
        query = query.where(JournalAudit.utilisateur_id == utilisateur_id)
    if resource_type:
        query = query.where(JournalAudit.resource_type == resource_type)

    result = await db.execute(query)
    return [
        {
            "id": event.id,
            "created_at": event.created_at.isoformat() if event.created_at else None,
            "action": event.action,
            "resource_type": event.resource_type,
            "resource_id": event.resource_id,
            "patient_id": event.patient_id,
            "utilisateur_id": event.utilisateur_id,
            "utilisateur_nom": f"{actor.prenom} {actor.nom}",
            "utilisateur_role": actor.role,
            "details": event.details or {},
            "ip_address": event.ip_address,
        }
        for event, actor in result.all()
    ]
