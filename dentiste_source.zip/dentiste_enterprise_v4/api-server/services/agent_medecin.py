"""Agent IA praticien dédié, borné par clinique, whitelist et consentement."""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from core.llm_client import LLMUnavailable, get_llm_if_enabled
from core.llm_privacy import pseudonymiser_prompt_payload
from models.database import RendezVous, Teleconsultation
from models.security import AssistantMedecinWhitelist

logger = logging.getLogger("agent_medecin")

SYSTEM_PROMPT = (
    "Tu es l'agent IA personnel du praticien. Tu réponds uniquement aux demandes "
    "autorisées sur la ligne praticien dédiée. Tu n'agis jamais sur le dossier "
    "patient sans une téléconsultation associée et un consentement explicite. "
    "Hors périmètre (données financières, agenda global, CRM cabinet), tu refuses. "
    "Tu ne poses pas de diagnostic et tu recommandes un professionnel lorsque la "
    "question dépasse un échange préparatoire."
)


ROLE_NAMES = {"admin", "medecin", "estheticienne"}


def _value(user: Any, key: str) -> Any:
    if isinstance(user, dict):
        return user.get(key)
    return getattr(user, key, None)


def _role_name(user: Any) -> str:
    role = _value(user, "role")
    return str(getattr(role, "value", role) or "").lower()


async def handle_agent_medecin_message(
    numero: str,
    question: str,
    current_user: Any,
    db: AsyncSession,
    teleconsultation_id: int,
) -> dict[str, Any]:
    """Traiter un message après vérification d’identité, de whitelist et consentement."""
    role = _role_name(current_user)
    if role not in ROLE_NAMES:
        return {"ok": False, "error": "Rôle non autorisé pour l'agent médecin"}

    clinic_id = _value(current_user, "clinic_id")
    user_id = _value(current_user, "id")
    if not isinstance(clinic_id, int) or clinic_id <= 0:
        return {"ok": False, "error": "Contexte clinique manquant"}

    now = datetime.utcnow()
    whitelist_query = select(AssistantMedecinWhitelist).where(
        AssistantMedecinWhitelist.clinic_id == clinic_id,
        AssistantMedecinWhitelist.numero == numero,
        AssistantMedecinWhitelist.statut == "active",
        AssistantMedecinWhitelist.revoked_at.is_(None),
        or_(
            AssistantMedecinWhitelist.expires_at.is_(None),
            AssistantMedecinWhitelist.expires_at > now,
        ),
    )
    if role != "admin":
        whitelist_query = whitelist_query.where(
            AssistantMedecinWhitelist.utilisateur_id == user_id
        )
    whitelist = (await db.execute(whitelist_query)).scalar_one_or_none()
    if whitelist is None:
        return {"ok": False, "error": "Numéro non whitelisté pour cet agent"}

    teleconsultation = (
        await db.execute(
            select(Teleconsultation)
            .join(RendezVous, RendezVous.id == Teleconsultation.rdv_id)
            .where(
                Teleconsultation.id == teleconsultation_id,
                Teleconsultation.clinic_id == clinic_id,
                RendezVous.clinic_id == clinic_id,
                RendezVous.praticien_id == user_id if role != "admin" else True,
                Teleconsultation.consent_url.is_not(None),
                Teleconsultation.consent_url != "",
                Teleconsultation.statut.in_(["planifiee", "en_cours"]),
            )
        )
    ).scalar_one_or_none()
    if teleconsultation is None:
        return {
            "ok": False,
            "error": "Téléconsultation active avec consentement requise",
        }

    audit_id = f"audit_medecin:{clinic_id}:{user_id}:{teleconsultation_id}:{now.strftime('%Y%m%d%H%M%S%f')}"
    pseudonymized = pseudonymiser_prompt_payload(question)
    settings = get_settings()

    if not settings.copilote_ia_enabled or settings.llm_provider not in {"openai"}:
        logger.info("Agent médecin en mode dégradé — %s", audit_id)
        return {
            "ok": True,
            "used_llm": False,
            "reponse": (
                "L'agent médecin est en mode dégradé. Activez le fournisseur LLM "
                "autorisé ou contactez votre administrateur."
            ),
            "audit_id": audit_id,
        }

    try:
        client = get_llm_if_enabled(provider="openai", model=None)
    except LLMUnavailable:
        return {
            "ok": False,
            "used_llm": False,
            "error": "LLM indisponible",
            "audit_id": audit_id,
        }
    except Exception:
        logger.exception("Initialisation LLM échouée — %s", audit_id)
        return {
            "ok": False,
            "used_llm": False,
            "error": "Backend LLM indisponible",
            "audit_id": audit_id,
        }

    if client is None:
        return {
            "ok": True,
            "used_llm": False,
            "reponse": "LLM non disponible, merci de réessayer plus tard.",
            "audit_id": audit_id,
        }

    try:
        result = await client.complete(
            system=SYSTEM_PROMPT,
            user=pseudonymized,
            max_tokens=512,
        )
        return {
            "ok": True,
            "used_llm": True,
            "reponse": result.text,
            "provider": result.provider,
            "model": result.model,
            "audit_id": audit_id,
        }
    except Exception:
        logger.exception("Appel LLM échoué — %s", audit_id)
        return {
            "ok": False,
            "used_llm": False,
            "error": "Échec LLM, réessayez",
            "audit_id": audit_id,
        }
