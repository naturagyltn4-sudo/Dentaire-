"""Service des plans de traitement opérationnels.

Les plans regroupent les étapes de prise en charge sans dupliquer les rendez-vous,
les devis ou les suivis déjà gérés par les modules existants.
"""
from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.clinic_context import require_clinic_id
from models.database import (
    DevisTraitement,
    EtapePlanTraitement,
    Patient,
    RendezVous,
    Utilisateur,
    PlanTraitement,
    StatutEtapeTraitement,
    StatutPlanTraitement,
)


PLAN_STATUTS = {item.value for item in StatutPlanTraitement}
ETAPE_STATUTS = {item.value for item in StatutEtapeTraitement}


def _serialize_step(step: EtapePlanTraitement) -> dict:
    return {
        "id": step.id,
        "plan_id": step.plan_id,
        "patient_id": step.patient_id,
        "ordre": step.ordre,
        "titre": step.titre,
        "type_etape": step.type_etape,
        "statut": step.statut,
        "date_prevue": step.date_prevue,
        "date_realisation": step.date_realisation,
        "rendez_vous_id": step.rendez_vous_id,
        "devis_id": step.devis_id,
        "notes": step.notes,
    }


def _serialize_plan(plan: PlanTraitement, steps: list[EtapePlanTraitement]) -> dict:
    total = len(steps)
    completed = sum(step.statut == StatutEtapeTraitement.TERMINEE.value for step in steps)
    return {
        "id": plan.id,
        "clinic_id": plan.clinic_id,
        "patient_id": plan.patient_id,
        "praticien_id": plan.praticien_id,
        "titre": plan.titre,
        "objectif": plan.objectif,
        "statut": plan.statut,
        "date_debut": plan.date_debut,
        "date_cible": plan.date_cible,
        "created_at": plan.created_at,
        "updated_at": plan.updated_at,
        "progression": round((completed / total) * 100) if total else 0,
        "etapes_terminees": completed,
        "etapes_total": total,
        "etapes": [_serialize_step(step) for step in steps],
    }


async def _get_patient(patient_id: int, clinic_id: int, db: AsyncSession) -> Patient:
    patient = await db.scalar(
        select(Patient).where(Patient.id == patient_id, Patient.clinic_id == clinic_id)
    )
    if not patient:
        raise ValueError("Patient non trouvé")
    return patient


async def _get_plan(plan_id: int, clinic_id: int, db: AsyncSession) -> PlanTraitement:
    plan = await db.scalar(
        select(PlanTraitement).where(PlanTraitement.id == plan_id, PlanTraitement.clinic_id == clinic_id)
    )
    if not plan:
        raise ValueError("Plan de traitement non trouvé")
    return plan


async def _validate_practitioner(praticien_id: int | None, clinic_id: int, db: AsyncSession) -> None:
    if praticien_id is None:
        return
    practitioner = await db.scalar(
        select(Utilisateur).where(Utilisateur.id == praticien_id, Utilisateur.clinic_id == clinic_id, Utilisateur.is_active)
    )
    if not practitioner:
        raise ValueError("Praticien invalide pour cette clinique")


async def _validate_links(
    patient_id: int,
    clinic_id: int,
    data: dict,
    db: AsyncSession,
) -> None:
    if data.get("rendez_vous_id") is not None:
        appointment = await db.scalar(
            select(RendezVous).where(
                RendezVous.id == data["rendez_vous_id"],
                RendezVous.patient_id == patient_id,
                RendezVous.clinic_id == clinic_id,
            )
        )
        if not appointment:
            raise ValueError("Rendez-vous invalide pour ce patient")
    if data.get("devis_id") is not None:
        quote = await db.scalar(
            select(DevisTraitement).where(
                DevisTraitement.id == data["devis_id"],
                DevisTraitement.patient_id == patient_id,
                DevisTraitement.clinic_id == clinic_id,
            )
        )
        if not quote:
            raise ValueError("Devis invalide pour ce patient")


async def list_plans(patient_id: int, current_user: dict, db: AsyncSession) -> list[dict]:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="lire les plans de traitement")
    await _get_patient(patient_id, clinic_id, db)
    plans = (await db.execute(
        select(PlanTraitement)
        .where(PlanTraitement.patient_id == patient_id, PlanTraitement.clinic_id == clinic_id)
        .order_by(PlanTraitement.updated_at.desc(), PlanTraitement.id.desc())
    )).scalars().all()
    output = []
    for plan in plans:
        steps = (await db.execute(
            select(EtapePlanTraitement)
            .where(EtapePlanTraitement.plan_id == plan.id, EtapePlanTraitement.clinic_id == clinic_id)
            .order_by(EtapePlanTraitement.ordre, EtapePlanTraitement.id)
        )).scalars().all()
        output.append(_serialize_plan(plan, list(steps)))
    return output


async def create_plan(patient_id: int, data: dict, current_user: dict, db: AsyncSession) -> dict:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="créer un plan de traitement")
    await _get_patient(patient_id, clinic_id, db)
    titre = str(data.get("titre", "")).strip()
    if len(titre) < 2 or len(titre) > 200:
        raise ValueError("Le titre du plan doit contenir entre 2 et 200 caractères")
    statut = data.get("statut") or StatutPlanTraitement.BROUILLON.value
    if statut not in PLAN_STATUTS:
        raise ValueError("Statut de plan invalide")
    await _validate_practitioner(data.get("praticien_id"), clinic_id, db)
    plan = PlanTraitement(
        clinic_id=clinic_id,
        patient_id=patient_id,
        praticien_id=data.get("praticien_id"),
        titre=titre,
        objectif=(str(data["objectif"]).strip()[:4000] if data.get("objectif") else None),
        statut=statut,
        date_debut=data.get("date_debut"),
        date_cible=data.get("date_cible"),
        cree_par_id=current_user["id"],
    )
    db.add(plan)
    await db.flush()
    return _serialize_plan(plan, [])


async def add_step(plan_id: int, data: dict, current_user: dict, db: AsyncSession) -> dict:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="ajouter une étape")
    plan = await _get_plan(plan_id, clinic_id, db)
    titre = str(data.get("titre", "")).strip()
    if len(titre) < 2 or len(titre) > 200:
        raise ValueError("Le titre de l’étape doit contenir entre 2 et 200 caractères")
    statut = data.get("statut") or StatutEtapeTraitement.A_FAIRE.value
    if statut not in ETAPE_STATUTS:
        raise ValueError("Statut d’étape invalide")
    if data.get("ordre") is None:
        last = await db.scalar(
            select(EtapePlanTraitement.ordre)
            .where(EtapePlanTraitement.plan_id == plan.id, EtapePlanTraitement.clinic_id == clinic_id)
            .order_by(EtapePlanTraitement.ordre.desc())
            .limit(1)
        )
        ordre = int(last or 0) + 1
    else:
        ordre = int(data["ordre"])
    if ordre < 1 or ordre > 1000:
        raise ValueError("Ordre d’étape invalide")
    await _validate_links(plan.patient_id, clinic_id, data, db)
    step = EtapePlanTraitement(
        clinic_id=clinic_id,
        plan_id=plan.id,
        patient_id=plan.patient_id,
        ordre=ordre,
        titre=titre,
        type_etape=(str(data["type_etape"]).strip()[:50] if data.get("type_etape") else None),
        statut=statut,
        date_prevue=data.get("date_prevue"),
        date_realisation=data.get("date_realisation"),
        rendez_vous_id=data.get("rendez_vous_id"),
        devis_id=data.get("devis_id"),
        notes=(str(data["notes"]).strip()[:4000] if data.get("notes") else None),
    )
    db.add(step)
    await db.flush()
    return _serialize_step(step)


async def update_step(step_id: int, data: dict, current_user: dict, db: AsyncSession) -> dict:
    clinic_id = require_clinic_id(current_user.get("clinic_id"), purpose="modifier une étape")
    step = await db.scalar(
        select(EtapePlanTraitement).where(
            EtapePlanTraitement.id == step_id, EtapePlanTraitement.clinic_id == clinic_id
        )
    )
    if not step:
        raise ValueError("Étape de traitement non trouvée")
    await _validate_links(step.patient_id, clinic_id, data, db)
    allowed = {"titre", "type_etape", "statut", "date_prevue", "date_realisation", "rendez_vous_id", "devis_id", "notes", "ordre"}
    for key, value in data.items():
        if key not in allowed or value is None:
            continue
        if key == "statut" and value not in ETAPE_STATUTS:
            raise ValueError("Statut d’étape invalide")
        if key == "titre":
            value = str(value).strip()[:200]
            if len(value) < 2:
                raise ValueError("Le titre de l’étape est requis")
        if key in {"type_etape", "notes"}:
            value = str(value).strip()[:4000 if key == "notes" else 50]
        setattr(step, key, value)
    if step.statut == StatutEtapeTraitement.TERMINEE.value and step.date_realisation is None:
        step.date_realisation = date.today()
    await db.flush()
    return _serialize_step(step)
