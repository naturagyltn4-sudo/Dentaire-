"""
AutoCommerce Clinic — Simulation IA / Morphing
Génération de résultats simulés avec filigrane obligatoire et chiffrement.
"""
from middleware.clinic_context import require_clinic_id

import base64
import io
import os
from datetime import datetime
from typing import Any, Optional

import requests
from PIL import Image as PILImage
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from config import get_settings
from core.ai_budget import AIBudgetExceeded, reserve_ai_budget
from models.database import Patient, PhotoClinic, SimulationIA
from services.audit_medical import log_access
from services.consentement import verify_consent
from services.photos_clinic import (
    _add_watermark,
    _create_thumbnail,
    _decrypt_file,
    _encrypt_file,
    _save_signed_jpeg,
)

settings = get_settings()


OPENAI_IMAGE_EDIT_ENDPOINT = "https://api.openai.com/v1/images/edits"


def _resolve_image_model() -> str:
    """Retourne un modèle compatible avec l'édition d'image.

    Correctif Bug #9 : ``dall-e-3`` ne doit pas être utilisé comme valeur
    par défaut pour un flux d'édition/morphing car l'API d'édition moderne
    attend un modèle image dédié. On bascule donc automatiquement vers
    ``gpt-image-1`` si l'instance est restée sur l'ancien défaut.
    """
    configured = (getattr(settings, "openai_image_model", "") or "").strip()
    if not configured:
        return "gpt-image-1"

    legacy_models = {"dall-e-2", "dall-e-3"}
    if configured.lower() in legacy_models:
        return "gpt-image-1"

    return configured


def _normalize_intensite(intensite: int) -> int:
    """Borne l'intensité même si le service est appelé hors route FastAPI."""
    return max(0, min(100, int(intensite)))


def _build_simulation_prompt(zone: str, intensite: int) -> str:
    """Construit un prompt d'édition photoréaliste et médicalement prudent."""
    intensite = _normalize_intensite(intensite)
    zone_label = (zone or "zone esthétique concernée").strip()

    if intensite <= 20:
        intensity_label = "very subtle"
    elif intensite <= 45:
        intensity_label = "subtle"
    elif intensite <= 70:
        intensity_label = "moderate"
    else:
        intensity_label = "visible but still medically plausible"

    # Adaptation pour l'alignement dentaire/sourire (Bloc 9)
    ortho_context = ""
    if any(
        keyword in zone_label.lower()
        for keyword in ["dent", "sourire", "ortho", "teeth", "smile"]
    ):
        ortho_context = (
            "Specifically for dental alignment: adjust teeth to be perfectly aligned, "
            "symmetrical, and following a natural smile curve. Maintain natural tooth color "
            "and texture. Ensure the gums look healthy and natural. "
        )

    return (
        "Edit this clinical reference photo of the same patient into a realistic "
        "aesthetic-treatment projection. Preserve identity perfectly, keep the same "
        "camera angle, crop, background, skin texture, hair, expression, and lighting. "
        f"{ortho_context}"
        f"Only modify the anatomical area '{zone_label}' with a {intensity_label} result "
        f"corresponding to intensity {intensite}/100. The outcome must look like a conservative, "
        "credible post-treatment simulation used during a medical consultation. "
        "Do not create a split screen, no before/after collage, no extra text, no makeup change, "
        "no jewelry change, no cartoon effect, no exaggerated transformation. Keep all untreated "
        "areas unchanged and photorealistic."
    )


def _prepare_image_for_openai(photo_bytes: bytes) -> io.BytesIO:
    """Prépare la photo source dans un format robuste pour l'API d'édition."""
    img = PILImage.open(io.BytesIO(photo_bytes)).convert("RGBA")

    max_dim = 1536
    image_size = getattr(img, "size", None)
    if image_size and len(image_size) == 2 and max(image_size) > max_dim:
        img.thumbnail((max_dim, max_dim))

    prepared = io.BytesIO()
    img.save(prepared, format="PNG")
    prepared.seek(0)
    prepared.name = "simulation_source.png"
    return prepared


def _decode_openai_image_payload(payload: dict[str, Any]) -> bytes:
    """Extrait l'image binaire depuis la réponse JSON OpenAI."""
    data = payload.get("data") or []
    if not data:
        raise RuntimeError("Réponse OpenAI invalide : aucune image retournée")

    first = data[0] or {}
    b64_image = first.get("b64_json")
    if b64_image:
        return base64.b64decode(b64_image)

    image_url = first.get("url")
    if image_url:
        download = requests.get(image_url, timeout=60)
        download.raise_for_status()
        return download.content

    raise RuntimeError("Réponse OpenAI invalide : image introuvable dans la réponse")


def _generate_ai_simulation_image(
    photo_bytes: bytes,
    zone: str,
    intensite: int,
    *,
    masque_bytes: bytes | None = None,
    db: AsyncSession | None = None,
    clinic_id: int | None = None,
) -> bytes:
    """Génère une vraie simulation IA via l'API OpenAI Images Edits.

    Correctif Bug #9 : on supprime la fausse "simulation" basée sur un simple
    changement de luminosité et on remplace ce comportement par une édition
    d'image dédiée, centrée sur la zone anatomique et l'intensité demandées.
    """
    api_key = getattr(settings, "openai_api_key", None)
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY manquant : impossible de générer une vraie simulation IA. "
            "Aucune simulation dégradée locale n'est produite pour éviter un faux morphing."
        )

    model = _resolve_image_model()
    prompt = _build_simulation_prompt(zone, intensite)
    prepared_image = _prepare_image_for_openai(photo_bytes)
    files = {
        "image": (prepared_image.name, prepared_image.getvalue(), "image/png"),
    }
    if masque_bytes:
        prepared_mask = _prepare_image_for_openai(masque_bytes)
        prepared_mask.name = "simulation_mask.png"
        files["mask"] = (prepared_mask.name, prepared_mask.getvalue(), "image/png")

    response = requests.post(
        OPENAI_IMAGE_EDIT_ENDPOINT,
        headers={"Authorization": f"Bearer {api_key}"},
        data={
            "model": model,
            "prompt": prompt,
            "size": "1024x1024",
            "response_format": "b64_json",
        },
        files=files,
        timeout=180,
    )
    response.raise_for_status()
    return _decode_openai_image_payload(response.json())


async def generer_simulation_ia(
    patient_id: int,
    photo_source_id: int,
    zone: str,
    intensite: int,
    genere_par_id: int,
    db: AsyncSession,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    clinic_id: int | None = None,
    instructions: Optional[str] = None,
    masque_base64: Optional[str] = None,
) -> SimulationIA:
    """Génère une simulation de résultat par IA.

    1. Vérifie le consentement spécifique 'simulation_ia'
    2. Récupère et déchiffre la photo source
    3. Appelle l'API d'édition d'image OpenAI pour produire une vraie simulation
    4. Applique le filigrane déontologique obligatoire
    5. Chiffre et stocke le résultat
    6. Log l'accès sensible
    """

    intensite = _normalize_intensite(intensite)
    clinic_id = require_clinic_id(clinic_id, purpose="la simulation IA")

    patient_result = await db.execute(
        select(Patient).where(
            Patient.id == patient_id,
            Patient.clinic_id == clinic_id,
        )
    )
    if not patient_result.scalar_one_or_none():
        raise ValueError("Patient non trouvé")

    # 1. Vérification consentement spécifique
    consentement = await verify_consent(
        patient_id,
        None,
        db,
        type_consentement="simulation_ia",
        clinic_id=clinic_id,
    )
    if not consentement:
        raise ValueError("Consentement spécifique 'Simulation IA' non signé ou expiré")

    # 2. Récupérer photo source
    result = await db.execute(
        select(PhotoClinic).where(
            PhotoClinic.id == photo_source_id,
            PhotoClinic.patient_id == patient_id,
            PhotoClinic.clinic_id == clinic_id,
            ~PhotoClinic.is_deleted,
        )
    )
    photo_source = result.scalar_one_or_none()
    if not photo_source:
        raise ValueError("Photo source non trouvée")

    with open(photo_source.url_stockage, "rb") as f:
        raw = f.read()
    nonce, ciphertext = raw[:12], raw[12:]
    photo_bytes = _decrypt_file(nonce, ciphertext)

    masque_bytes = None
    url_masque = None
    if masque_base64:
        try:
            raw_mask = masque_base64.split(",", 1)[-1]
            masque_bytes = base64.b64decode(raw_mask, validate=True)
        except Exception as exc:
            raise ValueError("Masque d’annotation PNG invalide") from exc
        if len(masque_bytes) > 10 * 1024 * 1024:
            raise ValueError("Masque d’annotation trop volumineux")
        m_nonce, m_ciphertext = _encrypt_file(masque_bytes)
        date_dir = datetime.utcnow().strftime("%Y/%m")
        mask_dir = os.path.join(str(settings.photos_dir), "masks", date_dir)
        os.makedirs(mask_dir, exist_ok=True)
        mask_filename = f"mask_{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S_%f')}.enc"
        url_masque = os.path.join(mask_dir, mask_filename)
        with open(url_masque, "wb") as mask_file:
            mask_file.write(m_nonce + m_ciphertext)

    # 3. Réservation tenant-scoped avant le transfert de la photo au provider.
    try:
        await reserve_ai_budget(
            db,
            clinic_id,
            estimated_input_tokens=max(1, len(photo_bytes) // 4000),
            requested_output_tokens=1024,
            request_limit=getattr(settings, "ai_monthly_request_limit", 5000),
            token_limit=getattr(settings, "ai_monthly_token_limit", 500000),
        )
    except (AIBudgetExceeded, ValueError) as exc:
        raise RuntimeError(f"Simulation refusée par quota clinique : {exc}") from exc

    # 4. Simulation IA réelle
    simulated_bytes = _generate_ai_simulation_image(
        photo_bytes, zone=zone, intensite=intensite, masque_bytes=masque_bytes
    )
    img_simulated = PILImage.open(io.BytesIO(simulated_bytes)).convert("RGB")

    # 4. Filigrane obligatoire (CNOM)
    watermark_text = "Simulation non contractuelle"
    img_final = _add_watermark(img_simulated, watermark_text)

    # 5. Chiffrement et stockage
    signed_jpeg = _save_signed_jpeg(img_final, watermark_text, quality=90)
    nonce, ciphertext = _encrypt_file(signed_jpeg)

    date_dir = datetime.utcnow().strftime("%Y/%m")
    base_path = os.path.join(str(settings.photos_dir), "simulations", date_dir)
    os.makedirs(base_path, exist_ok=True)

    filename = f"sim_{patient_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.enc"
    file_path = os.path.join(base_path, filename)

    with open(file_path, "wb") as f:
        f.write(nonce + ciphertext)

    # Génération thumbnail (conservé pour l'écosystème photos si exploité plus tard)
    try:
        _create_thumbnail(img_final)
    except Exception:
        # La vignette n'est pas bloquante pour la simulation stockée.
        pass

    # 6. Créer l'entrée DB
    simulation = SimulationIA(
        clinic_id=clinic_id,
        photo_source_id=photo_source_id,
        patient_id=patient_id,
        zone_anatomique=zone,
        url_resultat=file_path,
        url_masque=url_masque,
        instructions=instructions,
        consentement_id=consentement.id,
        genere_par_id=genere_par_id,
    )
    db.add(simulation)
    await db.flush()

    # 7. Log audit
    await log_access(
        db=db,
        utilisateur_id=genere_par_id,
        patient_id=patient_id,
        action="GENERATE_IA_SIMULATION",
        resource_type="simulation_ia",
        resource_id=simulation.id,
        ip_address=ip_address,
        user_agent=user_agent,
        details={
            "zone": zone,
            "intensite": intensite,
            "image_model": _resolve_image_model(),
        },
    )

    return simulation


async def get_decrypted_simulation(
    simulation_id: int,
    patient_id: int,
    db: AsyncSession,
    utilisateur_id: Optional[int] = None,
    ip_address: Optional[str] = None,
    user_agent: Optional[str] = None,
    clinic_id: int | None = None,
) -> tuple[bytes, str]:
    """Déchiffre une simulation du tenant fourni et journalise la lecture."""
    clinic_id = require_clinic_id(clinic_id, purpose="lire une simulation IA")
    result = await db.execute(
        select(SimulationIA).where(
            SimulationIA.id == simulation_id,
            SimulationIA.patient_id == patient_id,
            SimulationIA.clinic_id == clinic_id,
        )
    )
    sim = result.scalar_one_or_none()
    if not sim:
        raise ValueError("Simulation non trouvée")

    if not os.path.exists(sim.url_resultat):
        raise ValueError("Fichier simulation introuvable")

    with open(sim.url_resultat, "rb") as f:
        raw = f.read()
    nonce, ciphertext = raw[:12], raw[12:]
    decrypted = _decrypt_file(nonce, ciphertext)

    if utilisateur_id is not None:
        await log_access(
            db=db,
            utilisateur_id=utilisateur_id,
            patient_id=patient_id,
            action="READ_IA_SIMULATION",
            resource_type="simulation_ia",
            resource_id=simulation_id,
            ip_address=ip_address,
            user_agent=user_agent,
            details={"zone": sim.zone_anatomique},
        )

    return decrypted, f"simulation_{simulation_id}.jpg"
