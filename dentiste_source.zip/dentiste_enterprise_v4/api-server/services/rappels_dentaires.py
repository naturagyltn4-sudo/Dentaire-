"""Rappels dentaires dédupliqués via le moteur omnicanal existant."""

from datetime import datetime

from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.clinic_context import require_clinic_id
from models.database import Patient, RappelDentaire, SuiviPostOperatoire
from services.omnicanal_service import send_message


async def generer_rappel_suivi(
    db: AsyncSession,
    suivi_id: int,
    canal: str = "whatsapp",
    clinic_id: int | None = None,
) -> RappelDentaire | None:
    tenant_id = require_clinic_id(clinic_id, purpose="génération d’un rappel dentaire")
    suivi = (
        await db.execute(
            select(SuiviPostOperatoire).where(
                SuiviPostOperatoire.id == suivi_id,
                SuiviPostOperatoire.clinic_id == tenant_id,
            )
        )
    ).scalar_one_or_none()
    if suivi is None:
        raise ValueError("Suivi post-opératoire introuvable")
    patient = (
        await db.execute(
            select(Patient).where(
                Patient.id == suivi.patient_id,
                Patient.clinic_id == tenant_id,
            )
        )
    ).scalar_one_or_none()
    if patient is None:
        raise ValueError("Patient introuvable")
    destinataire = patient.whatsapp_phone or patient.telephone
    if not destinataire:
        raise ValueError("Patient sans destinataire")
    contenu = (
        "Rappel dentaire : votre contrôle est prévu le "
        f"{suivi.date_controle_prevue.strftime('%d/%m/%Y à %H:%M')}."
    )
    rappel = RappelDentaire(
        clinic_id=suivi.clinic_id,
        patient_id=patient.id,
        source_type="suivi_post_operatoire",
        source_id=suivi.id,
        date_prevue=suivi.date_controle_prevue,
        canal=canal,
        destinataire=destinataire,
        contenu=contenu,
    )
    db.add(rappel)
    try:
        await db.flush()
    except IntegrityError:
        await db.rollback()
        result = await db.execute(
            select(RappelDentaire).where(
                RappelDentaire.clinic_id == suivi.clinic_id,
                RappelDentaire.source_type == "suivi_post_operatoire",
                RappelDentaire.source_id == suivi.id,
            )
        )
        return result.scalar_one_or_none()
    await send_message(channel=canal, to=destinataire, content=contenu)
    rappel.envoye_at = datetime.utcnow()
    await db.flush()
    return rappel


async def generer_rappels_du_jour(
    db: AsyncSession,
    now: datetime | None = None,
    clinic_id: int | None = None,
) -> list[RappelDentaire]:
    tenant_id = require_clinic_id(clinic_id, purpose="génération des rappels dentaires")
    instant = now or datetime.utcnow()
    result = await db.execute(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.clinic_id == tenant_id,
            SuiviPostOperatoire.date_controle_prevue <= instant,
            SuiviPostOperatoire.date_controle_reelle.is_(None),
        )
    )
    rappels = []
    for suivi in result.scalars().all():
        rappel = await generer_rappel_suivi(db, suivi.id, clinic_id=tenant_id)
        if rappel is not None:
            rappels.append(rappel)
    return rappels
