"""Provisionnement idempotent d'un unique compte administrateur de recette.

Ce module n'est actif que si l'environnement fournit explicitement les
variables TEST_ADMIN_* et active TEST_ADMIN_BOOTSTRAP_ENABLED. Il ne journalise
jamais l'adresse ni le mot de passe ; il sert uniquement à maintenir un accès
de recette contrôlé lors d'un déploiement Railway.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from middleware.auth import get_password_hash, verify_password
from middleware.clinic_context import require_clinic_id
from models.database import RoleEnum, Utilisateur


async def reconcile_test_admin(
    db: AsyncSession,
    *,
    email: str,
    nom: str,
    prenom: str,
    password: str,
    clinic_id: int | None,
    reset_existing: bool,
) -> str:
    """Crée ou, sur demande explicite, remet en état le seul compte QA configuré.

    La fonction ne crée aucun compte si les trois valeurs d'accès nécessaires
    ne sont pas présentes. Elle ne cible que l'adresse configurée : les autres
    utilisateurs, patients, rendez-vous et données cliniques sont hors périmètre.
    """
    normalized_email = email.strip().lower()
    if not normalized_email or not password:
        return "skipped"

    resolved_clinic_id = require_clinic_id(
        clinic_id,
        purpose="le bootstrap du compte administrateur de recette",
    )
    result = await db.execute(
        select(Utilisateur).where(
            Utilisateur.email == normalized_email,
            Utilisateur.clinic_id == resolved_clinic_id,
        )
    )
    user = result.scalar_one_or_none()
    if user is None:
        db.add(
            Utilisateur(
                clinic_id=resolved_clinic_id,
                email=normalized_email,
                hashed_password=get_password_hash(password),
                nom=nom or "Administrateur",
                prenom=prenom or "Recette",
                role=RoleEnum.DIRECTRICE.value,
                is_active=True,
            )
        )
        return "created"

    if not reset_existing:
        return "present"

    user.nom = nom or user.nom
    user.prenom = prenom or user.prenom
    user.role = RoleEnum.DIRECTRICE.value
    user.is_active = True
    if not verify_password(password, user.hashed_password):
        user.hashed_password = get_password_hash(password)
    return "reconciled"
