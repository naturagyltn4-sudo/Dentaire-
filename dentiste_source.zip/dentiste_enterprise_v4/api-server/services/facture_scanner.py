"""
AutoCommerce Clinic — Scan facture IA avec GPT-4o Vision
Upload, extraction, validation, notification WhatsApp
"""
from middleware.clinic_context import require_clinic_id

import io
import json
import os
from datetime import datetime
from decimal import Decimal
from typing import Optional

from core.llm_client import LLMUnavailable, get_llm_if_enabled
from pdf2image import convert_from_bytes
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from config import get_settings
from models.database import Depense, StatutDepense, Utilisateur, RoleEnum
from services.branding import get_branding_context

settings = get_settings()

EXTRACTION_PROMPT = """Analyse cette facture fournisseur de clinique esthétique médicale.
Réponds UNIQUEMENT en JSON valide, null si absent.

{
  "fournisseur_nom": "string|null",
  "fournisseur_tel": "string|null",
  "matricule_fiscal": "string|null",
  "numero_facture": "string|null",
  "date_facture": "YYYY-MM-DD|null",
  "lignes": [
    {
      "description": "string",
      "quantite": "number|null",
      "unite": "string|null",
      "prix_unitaire_ht": "number|null",
      "taux_tva": "number|null",
      "montant_ht": "number|null",
      "est_medicament": "boolean",
      "reference_lot": "string|null"
    }
  ],
  "total_ht": "number|null",
  "total_tva": "number|null",
  "total_ttc": "number|null",
  "devise": "string|null",
  "mode_paiement_indique": "string|null"
}

Règles :
- Si la facture contient des produits injectables (acide hyaluronique, toxine botulique, etc.), marque est_medicament=true
- Les montants sont en dinars tunisiens (TND) par défaut
- La date doit être au format YYYY-MM-DD
- Si une information est absente, utilise null
- Ne renvoie JAMAIS de texte hors du JSON"""


async def upload_facture(
    depense_id: int,
    file_bytes: bytes,
    mime_type: str,
    db: AsyncSession,
    clinic_id: int | None = None,
) -> str:
    """Stocke le fichier et retourne le chemin.
    Lance la tâche Celery d'extraction IA."""

    clinic_id = require_clinic_id(clinic_id, purpose="le scan de facture")
    # Vérifier dépense dans la clinique courante
    result = await db.execute(
        select(Depense).where(
            Depense.id == depense_id,
            Depense.clinic_id == clinic_id,
        )
    )
    depense = result.scalar_one_or_none()
    if not depense:
        raise ValueError(f"Dépense {depense_id} non trouvée")

    # Extension selon MIME
    ext = ".pdf" if mime_type == "application/pdf" else ".jpg"
    filename = f"facture_depense_{depense_id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}{ext}"
    filepath = os.path.join(str(settings.uploads_dir), filename)

    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "wb") as f:
        f.write(file_bytes)

    # Mettre à jour la dépense
    depense.facture_scan_url = filepath
    depense.facture_scan_statut = StatutDepense.EN_ATTENTE.value

    # Traitement documentaire externe strictement opt-in : par défaut aucune
    # image brute de facture ne doit être envoyée à un fournisseur LLM.
    if not settings.copilote_ia_enabled:
        depense.facture_scan_statut = StatutDepense.IA_DESACTIVEE.value
        depense.extraction_ia = {
            "ia_desactivee": True,
            "raison": "COPILOTE_IA_ENABLED=false",
        }
        await db.flush()
        return filepath

    await db.flush()

    # Lancer tâche Celery (async call)
    from services.celery_app import extract_facture_ia_task

    extract_facture_ia_task.delay(depense_id, clinic_id)

    return filepath


async def extract_facture_ia(
    depense_id: int,
    db: AsyncSession,
    clinic_id: int | None = None,
) -> dict:
    """Tâche Celery : extrait les données de la facture via GPT-4o Vision.

    Si PDF → convertir page 1 en image.
    Appel LLM vision avec prompt structuré.
    Sauvegarde JSON dans depense.extraction_ia.
    """
    clinic_id = require_clinic_id(clinic_id, purpose="l’extraction de facture")
    result = await db.execute(
        select(Depense).where(
            Depense.id == depense_id,
            Depense.clinic_id == clinic_id,
        )
    )
    depense = result.scalar_one_or_none()
    if not depense or not depense.facture_scan_url:
        raise ValueError("Dépense ou scan non trouvé")

    if not settings.copilote_ia_enabled:
        depense.facture_scan_statut = StatutDepense.IA_DESACTIVEE.value
        depense.extraction_ia = {
            "ia_desactivee": True,
            "raison": "COPILOTE_IA_ENABLED=false",
        }
        await db.flush()
        return depense.extraction_ia

    filepath = depense.facture_scan_url

    # Lire le fichier
    with open(filepath, "rb") as f:
        file_bytes = f.read()

    # Déterminer le type et convertir si PDF
    mime_type = "application/pdf" if filepath.endswith(".pdf") else "image/jpeg"

    if mime_type == "application/pdf":
        images = convert_from_bytes(file_bytes, dpi=300, first_page=1, last_page=1)
        if not images:
            raise ValueError("Impossible de convertir le PDF")
        img = images[0]
        img_bytes = io.BytesIO()
        img.save(img_bytes, format="JPEG", quality=95)
        img_bytes.seek(0)
        image_data = img_bytes.read()
        base64_image = _encode_image(image_data)
    else:
        base64_image = _encode_image(file_bytes)

    # Appel via le client central : sanitation, budget tenant-scoped et fail-closed.
    llm = get_llm_if_enabled(settings)
    if llm is None:
        raise RuntimeError("Copilote IA désactivé — extraction impossible")
    out = await llm.chat(
        [
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": EXTRACTION_PROMPT},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}",
                            "detail": "high",
                        },
                    },
                ],
            }
        ],
        model=settings.openai_model,
        max_tokens=2000,
        temperature=0.1,
        response_format_json=True,
        use_cache=False,
        budget_session=db,
        clinic_id=clinic_id,
        cache_context={
            "clinic_id": clinic_id,
            "data_classification": "financial",
        },
    )
    if isinstance(out, LLMUnavailable):
        raise RuntimeError(f"LLM indisponible : {out.reason}")
    raw_content = out.text

    # Parser le JSON
    try:
        # Nettoyer les backticks markdown si présents
        cleaned = raw_content.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned[7:]
        if cleaned.startswith("```"):
            cleaned = cleaned[3:]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()

        extraction = json.loads(cleaned)
    except json.JSONDecodeError:
        extraction = {"_raw_response": raw_content, "_parse_error": True}

    # Sauvegarder dans la dépense
    depense.extraction_ia = extraction
    depense.facture_scan_statut = StatutDepense.TRAITEE_IA.value
    await db.flush()

    # Notification WhatsApp directrice
    await _notify_directrice_extraction(depense, extraction, db)

    return extraction


def _encode_image(image_bytes: bytes) -> str:
    import base64

    return base64.b64encode(image_bytes).decode("utf-8")


async def _notify_directrice_extraction(
    depense: Depense, extraction: dict, db: AsyncSession
):
    """Envoie une notification WhatsApp à la directrice."""
    from services.whatsapp_service import send_whatsapp_message

    branding = await get_branding_context(db, depense.clinic_id)
    fournisseur = extraction.get("fournisseur_nom", "Fournisseur inconnu")
    total_ttc = extraction.get("total_ttc", "N/A")

    message = (
        f"{branding['clinic_name']} — Facture {fournisseur} analysée — {total_ttc} TND\n"
        f"Vérifiez et validez dans l'app ✅"
    )

    result = await db.execute(
        select(Utilisateur.telephone)
        .where(
            Utilisateur.role == RoleEnum.DIRECTRICE.value,
            Utilisateur.clinic_id == depense.clinic_id,
        )
        .where(Utilisateur.is_active)
        .limit(1)
    )
    phone = result.scalar_one_or_none()

    if phone:
        await send_whatsapp_message(phone, message)


async def valider_depense(
    depense_id: int,
    validateur_id: int,
    corrections: Optional[dict],
    db: AsyncSession,
    clinic_id: int | None = None,
) -> Depense:
    """Valide une dépense du tenant fourni avec corrections optionnelles.

    Applique les corrections sur l'extraction IA.
    Si lignes contiennent médicaments → propose création lot injectable.
    """
    clinic_id = require_clinic_id(clinic_id, purpose="valider une dépense")
    result = await db.execute(
        select(Depense).where(
            Depense.id == depense_id,
            Depense.clinic_id == clinic_id,
        )
    )
    depense = result.scalar_one_or_none()
    if not depense:
        raise ValueError("Dépense non trouvée")

    if depense.facture_scan_statut not in (
        StatutDepense.TRAITEE_IA.value,
        StatutDepense.EN_ATTENTE.value,
    ):
        raise ValueError(
            f"Statut invalide pour validation : {depense.facture_scan_statut}"
        )

    # Appliquer corrections
    if corrections:
        if "fournisseur" in corrections:
            depense.fournisseur = corrections["fournisseur"]
        if "montant_ht" in corrections:
            depense.montant_ht = Decimal(str(corrections["montant_ht"]))
        if "montant_tva" in corrections:
            depense.montant_tva = Decimal(str(corrections["montant_tva"]))
        if "montant_ttc" in corrections:
            depense.montant_ttc = Decimal(str(corrections["montant_ttc"]))
        if "titre" in corrections:
            depense.titre = corrections["titre"]
        if "categorie_id" in corrections:
            depense.categorie_id = corrections["categorie_id"]

    # Si extraction IA existe, tenter auto-remplissage
    if depense.extraction_ia and isinstance(depense.extraction_ia, dict):
        ext = depense.extraction_ia
        if not depense.fournisseur and ext.get("fournisseur_nom"):
            depense.fournisseur = ext["fournisseur_nom"]
        if depense.montant_ht == Decimal("0.000") and ext.get("total_ht"):
            depense.montant_ht = Decimal(str(ext["total_ht"]))
        if depense.montant_tva == Decimal("0.000") and ext.get("total_tva"):
            depense.montant_tva = Decimal(str(ext["total_tva"]))
        if depense.montant_ttc == Decimal("0.000") and ext.get("total_ttc"):
            depense.montant_ttc = Decimal(str(ext["total_ttc"]))
        if not depense.titre and ext.get("numero_facture"):
            depense.titre = f"Facture {ext['numero_facture']}"

    # Vérifier si médicaments présents
    medicaments = []
    if depense.extraction_ia and isinstance(depense.extraction_ia, dict):
        lignes = depense.extraction_ia.get("lignes", [])
        for ligne in lignes:
            if ligne.get("est_medicament"):
                medicaments.append(ligne)

    depense.facture_scan_statut = StatutDepense.VALIDEE.value
    depense.valide_par_id = validateur_id
    depense.validated_at = datetime.utcnow()
    await db.flush()

    return depense, medicaments
