"""AutoCommerce Clinic — Transcription des messages vocaux (assistant WhatsApp)

Rien ne transcrivait les messages vocaux jusqu'ici : un vocal arrivait
avec le contenu littéral "[Audio]" et ne déclenchait donc jamais aucune
intention côté assistant. Ce module télécharge le média WhatsApp et le
transcrit via Whisper (même clé OPENAI_API_KEY que facture_scanner.py).
"""

import logging
import tempfile

from openai import OpenAI

from config import get_settings
from core.ai_budget import AIBudgetExceeded, reserve_ai_budget

logger = logging.getLogger(__name__)

# Whisper détecte automatiquement la langue (français, arabe standard,
# darija transcrite en graphie arabe...) — inutile de la forcer, une
# langue imposée dégraderait la reconnaissance si l'utilisateur switch.
_SUPPORTED_AUDIO_MIME_EXT = {
    "audio/aac": "aac",
    "audio/mp4": "mp4",
    "audio/mpeg": "mp3",
    "audio/amr": "amr",
    "audio/ogg": "ogg",
    "audio/opus": "ogg",
}


async def transcribe_whatsapp_voice(
    media_id: str, db=None, clinic_id: int | None = None
) -> str | None:
    """Télécharge et transcrit un message vocal WhatsApp. Retourne le
    texte transcrit, ou None si la transcription échoue (config absente,
    fichier trop long, erreur API) — l'appelant doit alors informer
    poliment l'utilisateur plutôt que planter."""
    settings = get_settings()
    if not settings.openai_api_key:
        logger.warning("Transcription vocale demandée mais OPENAI_API_KEY absente")
        return None

    from services.omnicanal.whatsapp_connector import WhatsAppConnector

    connector = WhatsAppConnector()
    try:
        audio_bytes, mime_type = await connector.download_media(media_id)
    except Exception as e:
        logger.error(f"Échec du téléchargement du vocal {media_id}: {e}")
        return None

    ext = _SUPPORTED_AUDIO_MIME_EXT.get(mime_type, "ogg")
    if settings.env == "production" and (
        db is None or not isinstance(clinic_id, int) or clinic_id <= 0
    ):
        logger.error("Transcription refusée : contexte clinique/budget absent")
        return None
    if db is not None and isinstance(clinic_id, int) and clinic_id > 0:
        try:
            await reserve_ai_budget(
                db,
                clinic_id,
                estimated_input_tokens=max(1, len(audio_bytes) // 4000),
                requested_output_tokens=1000,
                request_limit=getattr(settings, "ai_monthly_request_limit", 5000),
                token_limit=getattr(settings, "ai_monthly_token_limit", 500000),
            )
        except (AIBudgetExceeded, ValueError) as exc:
            logger.warning("Transcription refusée par quota clinic_id=%s: %s", clinic_id, exc)
            return None

    try:
        with tempfile.NamedTemporaryFile(suffix=f".{ext}", delete=True) as tmp:
            tmp.write(audio_bytes)
            tmp.flush()
            client = OpenAI(api_key=settings.openai_api_key)
            with open(tmp.name, "rb") as audio_file:
                transcript = client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                )
        text = (transcript.text or "").strip()
        logger.info(f"Vocal {media_id} transcrit ({len(text)} caractères)")
        return text or None
    except Exception as e:
        logger.error(f"Échec de la transcription Whisper pour {media_id}: {e}")
        return None
