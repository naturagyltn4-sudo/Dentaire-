BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> 0f97a0a6fd44

CREATE TABLE actes_medicaux (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    nom VARCHAR(200) NOT NULL, 
    categorie VARCHAR(50) NOT NULL, 
    duree_minutes INTEGER NOT NULL, 
    prix_base NUMERIC(10, 3) NOT NULL, 
    description TEXT, 
    protocole TEXT, 
    is_active BOOLEAN NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE TABLE audit_logs_medicaux (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    utilisateur_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    action VARCHAR(100) NOT NULL, 
    resource_type VARCHAR(50) NOT NULL, 
    resource_id INTEGER NOT NULL, 
    ip_address VARCHAR(45), 
    user_agent VARCHAR(500), 
    details JSON, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_audit_logs_medicaux_patient_id ON audit_logs_medicaux (patient_id);

CREATE INDEX ix_audit_logs_medicaux_utilisateur_id ON audit_logs_medicaux (utilisateur_id);

CREATE INDEX ix_audit_patient_date ON audit_logs_medicaux (patient_id, created_at);

CREATE INDEX ix_audit_user_date ON audit_logs_medicaux (utilisateur_id, created_at);

CREATE TABLE categories_depenses (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    nom VARCHAR(100) NOT NULL, 
    code VARCHAR(30) NOT NULL, 
    icone VARCHAR(10), 
    couleur VARCHAR(7), 
    type VARCHAR(30) NOT NULL, 
    budget_mensuel NUMERIC(10, 3), 
    is_active BOOLEAN NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (code)
);

CREATE TABLE clinic_settings (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    key VARCHAR(100) NOT NULL, 
    value JSON NOT NULL, 
    description VARCHAR(300), 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE UNIQUE INDEX ix_clinic_settings_key ON clinic_settings (key);

CREATE TABLE produits_injectables (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    nom VARCHAR(200) NOT NULL, 
    fabricant VARCHAR(200), 
    categorie VARCHAR(50) NOT NULL, 
    reference_fabricant VARCHAR(100), 
    unite VARCHAR(20) NOT NULL, 
    prix_achat NUMERIC(10, 3) NOT NULL, 
    prix_vente NUMERIC(10, 3) NOT NULL, 
    stock_actuel NUMERIC(10, 2) NOT NULL, 
    stock_minimum NUMERIC(10, 2) NOT NULL, 
    stock_alerte NUMERIC(10, 2) NOT NULL, 
    temperature_conservation VARCHAR(50), 
    conditions_stockage TEXT, 
    is_active BOOLEAN NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_produits_injectables_nom ON produits_injectables (nom);

CREATE TABLE utilisateurs (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    email VARCHAR(255) NOT NULL, 
    hashed_password VARCHAR(255) NOT NULL, 
    nom VARCHAR(100) NOT NULL, 
    prenom VARCHAR(100) NOT NULL, 
    role VARCHAR(20) NOT NULL, 
    telephone VARCHAR(20), 
    photo_profil_url VARCHAR(500), 
    taux_commission NUMERIC(5, 2) NOT NULL, 
    agenda_color VARCHAR(7), 
    specialite VARCHAR(100), 
    is_active BOOLEAN NOT NULL, 
    last_login TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_utilisateurs_clinic_email ON utilisateurs (clinic_id, email);

CREATE UNIQUE INDEX ix_utilisateurs_email ON utilisateurs (email);

CREATE TABLE campagnes_marketing (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    nom VARCHAR(200) NOT NULL, 
    type VARCHAR(20) NOT NULL, 
    segment_cible JSON, 
    message_template TEXT, 
    date_envoi_planifiee TIMESTAMP WITHOUT TIME ZONE, 
    statut VARCHAR(20) NOT NULL, 
    nb_envoyes INTEGER NOT NULL, 
    nb_ouverts INTEGER NOT NULL, 
    created_by INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(created_by) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE TABLE candidatures (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    poste VARCHAR(200) NOT NULL, 
    nom_candidat VARCHAR(200) NOT NULL, 
    email VARCHAR(255) NOT NULL, 
    telephone VARCHAR(20), 
    cv_url VARCHAR(500), 
    lettre_url VARCHAR(500), 
    statut VARCHAR(20) NOT NULL, 
    notes_rh TEXT, 
    date_entretien TIMESTAMP WITHOUT TIME ZONE, 
    evaluateur_id INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(evaluateur_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE TABLE lots_injectables (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    produit_id INTEGER NOT NULL, 
    numero_lot VARCHAR(100) NOT NULL, 
    date_fabrication DATE, 
    date_expiration DATE NOT NULL, 
    quantite_initiale NUMERIC(10, 2) NOT NULL, 
    quantite_restante NUMERIC(10, 2) NOT NULL, 
    fournisseur VARCHAR(200), 
    date_reception DATE, 
    prix_achat_lot NUMERIC(10, 3) NOT NULL, 
    certificat_conformite_url VARCHAR(500), 
    qr_code_url VARCHAR(500), 
    barcode_url VARCHAR(500), 
    label_url VARCHAR(500), 
    statut VARCHAR(20) NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(produit_id) REFERENCES produits_injectables (id) ON DELETE RESTRICT
);

CREATE INDEX ix_lot_expiration_statut ON lots_injectables (date_expiration, statut);

CREATE INDEX ix_lots_injectables_date_expiration ON lots_injectables (date_expiration);

CREATE UNIQUE INDEX ix_lots_injectables_numero_lot ON lots_injectables (numero_lot);

CREATE INDEX ix_lots_injectables_produit_id ON lots_injectables (produit_id);

CREATE TABLE patients (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    nom VARCHAR(100) NOT NULL, 
    prenom VARCHAR(100) NOT NULL, 
    date_naissance DATE, 
    genre VARCHAR(10), 
    telephone VARCHAR(20) NOT NULL, 
    email VARCHAR(255), 
    adresse VARCHAR(300), 
    ville VARCHAR(100), 
    groupe_sanguin VARCHAR(5), 
    allergies_enc TEXT, 
    antecedents_medicaux_enc TEXT, 
    contre_indications_enc TEXT, 
    note_interne_enc TEXT, 
    photo_profil_url VARCHAR(500), 
    source_acquisition VARCHAR(50), 
    commercial_id INTEGER, 
    statut VARCHAR(20), 
    is_active BOOLEAN NOT NULL, 
    whatsapp_phone VARCHAR(20), 
    opted_out BOOLEAN NOT NULL, 
    last_message_at TIMESTAMP WITHOUT TIME ZONE, 
    points_fidelite INTEGER NOT NULL, 
    niveau_fidelite VARCHAR(10) NOT NULL, 
    derniere_visite DATE, 
    consentement_rgpd_signe_le TIMESTAMP WITHOUT TIME ZONE, 
    consentement_marketing BOOLEAN NOT NULL, 
    anonymized_at TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(commercial_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_patients_clinic_niveau ON patients (clinic_id, niveau_fidelite);

CREATE INDEX ix_patients_clinic_nom ON patients (clinic_id, nom);

CREATE INDEX ix_patients_clinic_telephone ON patients (clinic_id, telephone);

CREATE INDEX ix_patients_nom ON patients (nom);

CREATE INDEX ix_patients_prenom ON patients (prenom);

CREATE UNIQUE INDEX ix_patients_telephone ON patients (telephone);

CREATE INDEX ix_patients_whatsapp_phone ON patients (whatsapp_phone);

CREATE TABLE consentements (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    acte_id INTEGER, 
    type_consentement VARCHAR(50) NOT NULL, 
    contenu_signe TEXT, 
    signe_le TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    methode_signature VARCHAR(50) NOT NULL, 
    signature_base64 TEXT, 
    ip_address VARCHAR(45), 
    est_valide BOOLEAN NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(acte_id) REFERENCES actes_medicaux (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT
);

CREATE INDEX ix_consentements_patient_id ON consentements (patient_id);

CREATE TABLE depenses (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    categorie_id INTEGER, 
    fournisseur VARCHAR(200), 
    titre VARCHAR(300) NOT NULL, 
    description TEXT, 
    montant_ht NUMERIC(10, 3) NOT NULL, 
    taux_tva NUMERIC(5, 3) NOT NULL, 
    montant_tva NUMERIC(10, 3) NOT NULL, 
    montant_ttc NUMERIC(10, 3) NOT NULL, 
    date_depense DATE NOT NULL, 
    periode_comptable DATE NOT NULL, 
    mode_paiement VARCHAR(50), 
    reference_paiement VARCHAR(100), 
    facture_scan_url VARCHAR(500), 
    facture_scan_statut VARCHAR(20) NOT NULL, 
    extraction_ia JSON, 
    lot_injectable_id INTEGER, 
    valide_par_id INTEGER, 
    validated_at TIMESTAMP WITHOUT TIME ZONE, 
    notes TEXT, 
    created_by INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(categorie_id) REFERENCES categories_depenses (id) ON DELETE SET NULL, 
    FOREIGN KEY(created_by) REFERENCES utilisateurs (id) ON DELETE SET NULL, 
    FOREIGN KEY(lot_injectable_id) REFERENCES lots_injectables (id) ON DELETE SET NULL, 
    FOREIGN KEY(valide_par_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_depenses_date_depense ON depenses (date_depense);

CREATE INDEX ix_depenses_periode_comptable ON depenses (periode_comptable);

CREATE TABLE fidelite_transactions (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    type VARCHAR(20) NOT NULL, 
    points INTEGER NOT NULL, 
    solde_apres INTEGER NOT NULL, 
    motif VARCHAR(100) NOT NULL, 
    reference_id INTEGER, 
    reference_type VARCHAR(50), 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT
);

CREATE INDEX ix_fidelite_transactions_patient_id ON fidelite_transactions (patient_id);

CREATE TABLE rendez_vous (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    praticien_id INTEGER NOT NULL, 
    acte_id INTEGER, 
    date_heure_debut TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    date_heure_fin TIMESTAMP WITHOUT TIME ZONE, 
    salle VARCHAR(50), 
    statut VARCHAR(20) NOT NULL, 
    notes_pre_acte TEXT, 
    notes_post_acte TEXT, 
    rappel_j1_envoye BOOLEAN NOT NULL, 
    rappel_h2_envoye BOOLEAN NOT NULL, 
    created_by INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(acte_id) REFERENCES actes_medicaux (id) ON DELETE SET NULL, 
    FOREIGN KEY(created_by) REFERENCES utilisateurs (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT, 
    FOREIGN KEY(praticien_id) REFERENCES utilisateurs (id) ON DELETE RESTRICT
);

CREATE INDEX ix_rdv_clinic_date ON rendez_vous (clinic_id, date_heure_debut);

CREATE INDEX ix_rdv_patient_date ON rendez_vous (patient_id, date_heure_debut);

CREATE INDEX ix_rdv_praticien_date ON rendez_vous (praticien_id, date_heure_debut);

CREATE INDEX ix_rendez_vous_date_heure_debut ON rendez_vous (date_heure_debut);

CREATE TABLE series_photos (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    nom_serie VARCHAR(200) NOT NULL, 
    zone_anatomique VARCHAR(50), 
    acte_id INTEGER, 
    date_debut DATE, 
    date_fin DATE, 
    is_public BOOLEAN NOT NULL, 
    notes TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(acte_id) REFERENCES actes_medicaux (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT
);

CREATE INDEX ix_series_photos_patient_id ON series_photos (patient_id);

CREATE TABLE dossiers_medicaux (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    praticien_id INTEGER NOT NULL, 
    rdv_id INTEGER, 
    acte_id INTEGER, 
    date_acte TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    zones_traitees JSON, 
    produits_utilises JSON, 
    observations_enc TEXT, 
    effets_secondaires TEXT, 
    satisfaction_patient INTEGER, 
    suivi_requis BOOLEAN NOT NULL, 
    date_suivi_recommandee DATE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(acte_id) REFERENCES actes_medicaux (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT, 
    FOREIGN KEY(praticien_id) REFERENCES utilisateurs (id) ON DELETE RESTRICT, 
    FOREIGN KEY(rdv_id) REFERENCES rendez_vous (id) ON DELETE SET NULL
);

CREATE INDEX ix_dossier_patient_date ON dossiers_medicaux (patient_id, date_acte);

CREATE INDEX ix_dossiers_medicaux_date_acte ON dossiers_medicaux (date_acte);

CREATE INDEX ix_dossiers_medicaux_patient_id ON dossiers_medicaux (patient_id);

CREATE TABLE factures (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    rdv_id INTEGER, 
    numero_facture VARCHAR(50) NOT NULL, 
    date_emission DATE NOT NULL, 
    date_echeance DATE, 
    actes JSON, 
    produits JSON, 
    sous_total NUMERIC(10, 3) NOT NULL, 
    taux_tva NUMERIC(5, 3) NOT NULL, 
    montant_tva NUMERIC(10, 3) NOT NULL, 
    total_ttc NUMERIC(10, 3) NOT NULL, 
    remise_globale_pct NUMERIC(5, 2) NOT NULL, 
    statut VARCHAR(20) NOT NULL, 
    mode_paiement VARCHAR(50), 
    notes TEXT, 
    created_by INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(created_by) REFERENCES utilisateurs (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT, 
    FOREIGN KEY(rdv_id) REFERENCES rendez_vous (id) ON DELETE SET NULL
);

CREATE INDEX ix_facture_clinic_date ON factures (clinic_id, date_emission);

CREATE INDEX ix_facture_clinic_statut ON factures (clinic_id, statut);

CREATE UNIQUE INDEX ix_factures_numero_facture ON factures (numero_facture);

CREATE INDEX ix_factures_patient_id ON factures (patient_id);

CREATE TABLE commissions (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    commercial_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    facture_id INTEGER NOT NULL, 
    montant_ca NUMERIC(10, 3) NOT NULL, 
    taux_commission NUMERIC(5, 2) NOT NULL, 
    montant_commission NUMERIC(10, 3) NOT NULL, 
    statut VARCHAR(20) NOT NULL, 
    periode_mois DATE NOT NULL, 
    validee_par_id INTEGER, 
    validated_at TIMESTAMP WITHOUT TIME ZONE, 
    date_paiement DATE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(commercial_id) REFERENCES utilisateurs (id) ON DELETE RESTRICT, 
    FOREIGN KEY(facture_id) REFERENCES factures (id) ON DELETE RESTRICT, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT, 
    FOREIGN KEY(validee_par_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_commissions_commercial_id ON commissions (commercial_id);

CREATE INDEX ix_commissions_periode_mois ON commissions (periode_mois);

CREATE TABLE photos_clinic (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    patient_id INTEGER NOT NULL, 
    dossier_id INTEGER, 
    serie_id INTEGER, 
    type VARCHAR(20) NOT NULL, 
    date_prise TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    zone_anatomique VARCHAR(50), 
    angle_prise VARCHAR(20), 
    url_stockage VARCHAR(500) NOT NULL, 
    url_thumbnail VARCHAR(500), 
    hash_fichier VARCHAR(64), 
    taille_octets INTEGER, 
    visible_patient BOOLEAN NOT NULL, 
    visible_marketing BOOLEAN NOT NULL, 
    filigrane_applique BOOLEAN NOT NULL, 
    notes TEXT, 
    prise_par_id INTEGER, 
    is_deleted BOOLEAN NOT NULL, 
    deleted_at TIMESTAMP WITHOUT TIME ZONE, 
    deleted_by INTEGER, 
    raison_suppression VARCHAR(200), 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(dossier_id) REFERENCES dossiers_medicaux (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT, 
    FOREIGN KEY(prise_par_id) REFERENCES utilisateurs (id) ON DELETE SET NULL, 
    FOREIGN KEY(serie_id) REFERENCES series_photos (id) ON DELETE SET NULL
);

CREATE INDEX ix_photo_patient_type ON photos_clinic (patient_id, type);

CREATE INDEX ix_photo_patient_zone ON photos_clinic (patient_id, zone_anatomique);

CREATE INDEX ix_photos_clinic_patient_id ON photos_clinic (patient_id);

CREATE TABLE utilisations_lot (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    lot_id INTEGER NOT NULL, 
    dossier_id INTEGER, 
    patient_id INTEGER NOT NULL, 
    praticien_id INTEGER NOT NULL, 
    date_utilisation TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    quantite_utilisee NUMERIC(10, 3) NOT NULL, 
    unite VARCHAR(20) NOT NULL, 
    notes TEXT, 
    PRIMARY KEY (id), 
    FOREIGN KEY(dossier_id) REFERENCES dossiers_medicaux (id) ON DELETE SET NULL, 
    FOREIGN KEY(lot_id) REFERENCES lots_injectables (id) ON DELETE RESTRICT, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE RESTRICT, 
    FOREIGN KEY(praticien_id) REFERENCES utilisateurs (id) ON DELETE RESTRICT
);

CREATE INDEX ix_utilisations_lot_lot_id ON utilisations_lot (lot_id);

CREATE INDEX ix_utilisations_lot_patient_id ON utilisations_lot (patient_id);

INSERT INTO alembic_version (version_num) VALUES ('0f97a0a6fd44') RETURNING alembic_version.version_num;

-- Running upgrade 0f97a0a6fd44 -> 2bfa8a61841c

CREATE TABLE social_posts (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    plateforme VARCHAR(20) NOT NULL, 
    contenu TEXT NOT NULL, 
    media_url VARCHAR(500), 
    date_publication_prevue TIMESTAMP WITHOUT TIME ZONE, 
    date_publication_reelle TIMESTAMP WITHOUT TIME ZONE, 
    statut VARCHAR(20) NOT NULL, 
    erreur VARCHAR(300), 
    plateforme_post_id VARCHAR(255), 
    likes INTEGER NOT NULL, 
    commentaires INTEGER NOT NULL, 
    partages INTEGER NOT NULL, 
    impressions INTEGER NOT NULL, 
    created_by INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(created_by) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_social_posts_clinic_plateforme ON social_posts (clinic_id, plateforme);

CREATE INDEX ix_social_posts_clinic_statut ON social_posts (clinic_id, statut);

CREATE TABLE social_messages (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    plateforme VARCHAR(20) NOT NULL, 
    contact_id VARCHAR(255) NOT NULL, 
    contact_nom VARCHAR(200), 
    direction VARCHAR(10) NOT NULL, 
    contenu TEXT NOT NULL, 
    statut VARCHAR(20) NOT NULL, 
    reponse_auto_envoyee BOOLEAN NOT NULL, 
    patient_id INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE SET NULL
);

CREATE INDEX ix_social_messages_clinic_plateforme ON social_messages (clinic_id, plateforme);

CREATE INDEX ix_social_messages_clinic_statut ON social_messages (clinic_id, statut);

CREATE INDEX ix_social_messages_contact_id ON social_messages (contact_id);

UPDATE alembic_version SET version_num='2bfa8a61841c' WHERE alembic_version.version_num = '0f97a0a6fd44';

-- Running upgrade 2bfa8a61841c -> 7a1c9e2f4b3d

ALTER TABLE commissions ADD COLUMN validee_par_id_2 INTEGER;

ALTER TABLE commissions ADD COLUMN validated_at_2 TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE commissions ADD CONSTRAINT fk_commissions_validee_par_id_2_utilisateurs FOREIGN KEY(validee_par_id_2) REFERENCES utilisateurs (id) ON DELETE SET NULL;

UPDATE alembic_version SET version_num='7a1c9e2f4b3d' WHERE alembic_version.version_num = '2bfa8a61841c';

-- Running upgrade 7a1c9e2f4b3d -> 4d6f9a2c8e1b

ALTER TABLE utilisateurs ADD COLUMN mfa_secret VARCHAR(100);

ALTER TABLE utilisateurs ADD COLUMN mfa_enabled BOOLEAN DEFAULT false NOT NULL;

ALTER TABLE utilisateurs ADD COLUMN mfa_backup_codes TEXT;

ALTER TABLE utilisateurs ADD COLUMN mfa_setup_at TIMESTAMP WITHOUT TIME ZONE;

ALTER TABLE utilisateurs ADD COLUMN mfa_failed_attempts INTEGER DEFAULT '0' NOT NULL;

ALTER TABLE utilisateurs ADD COLUMN mfa_locked_until TIMESTAMP WITHOUT TIME ZONE;

UPDATE alembic_version SET version_num='4d6f9a2c8e1b' WHERE alembic_version.version_num = '7a1c9e2f4b3d';

-- Running upgrade 4d6f9a2c8e1b -> f8baad288795

ALTER TABLE factures ALTER COLUMN date_emission SET DEFAULT CURRENT_DATE;

UPDATE alembic_version SET version_num='f8baad288795' WHERE alembic_version.version_num = '4d6f9a2c8e1b';

-- Running upgrade f8baad288795 -> a1b2c3d4e5f6

CREATE TABLE channel_configs (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    canal VARCHAR(20) NOT NULL, 
    statut VARCHAR(20) DEFAULT 'non_configure' NOT NULL, 
    api_key_enc TEXT, 
    api_secret_enc TEXT, 
    webhook_verify_token_enc TEXT, 
    account_id VARCHAR(255), 
    business_account_id VARCHAR(255), 
    sender_phone VARCHAR(20), 
    sender_name VARCHAR(200), 
    config_json TEXT, 
    messages_par_jour INTEGER, 
    messages_envoyes_aujourdhui INTEGER DEFAULT '0' NOT NULL, 
    derniere_reinitialisation_quota TIMESTAMP WITHOUT TIME ZONE, 
    notes TEXT, 
    is_active BOOLEAN DEFAULT '1' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT uq_channel_configs_canal UNIQUE (canal)
);

CREATE INDEX ix_channel_configs_clinic_canal ON channel_configs (clinic_id, canal);

CREATE TABLE conversations (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    canal_config_id INTEGER, 
    canal VARCHAR(20) NOT NULL, 
    contact_external_id VARCHAR(255) NOT NULL, 
    contact_nom VARCHAR(200), 
    patient_id INTEGER, 
    statut VARCHAR(20) DEFAULT 'ouverte' NOT NULL, 
    dernier_message_at TIMESTAMP WITHOUT TIME ZONE, 
    nb_messages INTEGER DEFAULT '0' NOT NULL, 
    tags VARCHAR(500), 
    assignee_id INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(canal_config_id) REFERENCES channel_configs (id) ON DELETE SET NULL, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE SET NULL, 
    FOREIGN KEY(assignee_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_conversations_contact ON conversations (contact_external_id);

CREATE INDEX ix_conversations_patient ON conversations (patient_id);

CREATE INDEX ix_conversations_statut ON conversations (clinic_id, statut);

CREATE INDEX ix_conversations_clinic_canal ON conversations (clinic_id, canal);

CREATE TABLE messages_omnicanal (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    conversation_id INTEGER NOT NULL, 
    direction VARCHAR(10) NOT NULL, 
    type_message VARCHAR(20) DEFAULT 'texte' NOT NULL, 
    contenu TEXT, 
    pieces_jointes TEXT, 
    statut VARCHAR(20) DEFAULT 'envoye' NOT NULL, 
    external_message_id VARCHAR(255), 
    delivre_a TIMESTAMP WITHOUT TIME ZONE, 
    lu_a TIMESTAMP WITHOUT TIME ZONE, 
    nb_retries INTEGER DEFAULT '0' NOT NULL, 
    dernier_retry_at TIMESTAMP WITHOUT TIME ZONE, 
    max_retries INTEGER DEFAULT '3' NOT NULL, 
    reponse_auto BOOLEAN DEFAULT '0' NOT NULL, 
    template_name VARCHAR(200), 
    template_language VARCHAR(10), 
    template_params TEXT, 
    erreur TEXT, 
    patient_id INTEGER, 
    envoye_par_id INTEGER, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(conversation_id) REFERENCES conversations (id) ON DELETE RESTRICT, 
    FOREIGN KEY(patient_id) REFERENCES patients (id) ON DELETE SET NULL, 
    FOREIGN KEY(envoye_par_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_messages_conversation_statut ON messages_omnicanal (conversation_id, statut);

CREATE INDEX ix_messages_clinic_date ON messages_omnicanal (clinic_id, created_at);

CREATE INDEX ix_messages_external_id ON messages_omnicanal (external_message_id);

CREATE TABLE channel_events (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    message_id INTEGER NOT NULL, 
    conversation_id INTEGER, 
    type_evenement VARCHAR(50) NOT NULL, 
    details TEXT, 
    raw_payload TEXT, 
    timestamp TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(message_id) REFERENCES messages_omnicanal (id) ON DELETE RESTRICT, 
    FOREIGN KEY(conversation_id) REFERENCES conversations (id) ON DELETE SET NULL
);

CREATE INDEX ix_channel_events_message_date ON channel_events (message_id, timestamp);

CREATE INDEX ix_channel_events_clinic_date ON channel_events (clinic_id, timestamp);

CREATE TABLE numeros_whitelist (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    numero VARCHAR(20) NOT NULL, 
    nom VARCHAR(200), 
    utilisateur_id INTEGER, 
    statut VARCHAR(20) DEFAULT 'active' NOT NULL, 
    expires_at TIMESTAMP WITHOUT TIME ZONE, 
    revoked_at TIMESTAMP WITHOUT TIME ZONE, 
    revoked_by_id INTEGER, 
    raison_revocation VARCHAR(300), 
    last_key_rotation TIMESTAMP WITHOUT TIME ZONE, 
    permissions_json TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CONSTRAINT uq_numeros_whitelist_numero UNIQUE (numero), 
    FOREIGN KEY(utilisateur_id) REFERENCES utilisateurs (id) ON DELETE SET NULL, 
    FOREIGN KEY(revoked_by_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_whitelist_clinic_numero ON numeros_whitelist (clinic_id, numero);

CREATE TABLE sessions_assistant (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    whitelist_id INTEGER NOT NULL, 
    numero VARCHAR(20) NOT NULL, 
    statut VARCHAR(20) DEFAULT 'active' NOT NULL, 
    token_session VARCHAR(255) NOT NULL, 
    expires_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    revoked_at TIMESTAMP WITHOUT TIME ZONE, 
    nb_tours INTEGER DEFAULT '0' NOT NULL, 
    nb_erreurs INTEGER DEFAULT '0' NOT NULL, 
    derniere_activite TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(whitelist_id) REFERENCES numeros_whitelist (id) ON DELETE RESTRICT
);

CREATE INDEX ix_sessions_assistant_token ON sessions_assistant (token_session);

CREATE INDEX ix_sessions_assistant_statut ON sessions_assistant (clinic_id, statut);

CREATE TABLE commandes_assistant (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    session_id INTEGER, 
    whitelist_id INTEGER, 
    numero VARCHAR(20) NOT NULL, 
    type_commande VARCHAR(50) NOT NULL, 
    question TEXT, 
    reponse TEXT, 
    statut VARCHAR(20) DEFAULT 'executed' NOT NULL, 
    raison_refus TEXT, 
    contexte_json TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(session_id) REFERENCES sessions_assistant (id) ON DELETE SET NULL, 
    FOREIGN KEY(whitelist_id) REFERENCES numeros_whitelist (id) ON DELETE SET NULL
);

CREATE INDEX ix_commandes_assistant_numero ON commandes_assistant (clinic_id, numero);

CREATE INDEX ix_commandes_assistant_date ON commandes_assistant (clinic_id, created_at);

CREATE TABLE confirmations_sensibles (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    utilisateur_id INTEGER, 
    type_operation VARCHAR(50) NOT NULL, 
    details_json TEXT, 
    resource_type VARCHAR(50), 
    resource_id INTEGER, 
    statut VARCHAR(20) DEFAULT 'en_attente' NOT NULL, 
    code_confirmation VARCHAR(8) NOT NULL, 
    expires_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    confirme_at TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(utilisateur_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_confirmations_clinic_date ON confirmations_sensibles (clinic_id, created_at);

CREATE TABLE alertes_securite (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    type_alerte VARCHAR(50) NOT NULL, 
    severite VARCHAR(20) NOT NULL, 
    statut VARCHAR(20) DEFAULT 'nouvelle' NOT NULL, 
    description TEXT NOT NULL, 
    details_json TEXT, 
    numero_concerne VARCHAR(20), 
    utilisateur_id INTEGER, 
    ip_address VARCHAR(45), 
    resolue_par_id INTEGER, 
    resolue_at TIMESTAMP WITHOUT TIME ZONE, 
    resolution_notes TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(utilisateur_id) REFERENCES utilisateurs (id) ON DELETE SET NULL, 
    FOREIGN KEY(resolue_par_id) REFERENCES utilisateurs (id) ON DELETE SET NULL
);

CREATE INDEX ix_alertes_clinic_type ON alertes_securite (clinic_id, type_alerte);

CREATE INDEX ix_alertes_clinic_statut ON alertes_securite (clinic_id, statut);

CREATE INDEX ix_alertes_clinic_severite ON alertes_securite (clinic_id, severite);

CREATE INDEX ix_alertes_date ON alertes_securite (clinic_id, created_at);

UPDATE alembic_version SET version_num='a1b2c3d4e5f6' WHERE alembic_version.version_num = 'f8baad288795';

-- Running upgrade f8baad288795 -> 8b2c3d4e5f6g

CREATE TABLE workflows (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    nom VARCHAR(200) NOT NULL, 
    description TEXT, 
    trigger_type VARCHAR(20) NOT NULL, 
    trigger_config JSON, 
    conditions JSON, 
    actions JSON NOT NULL, 
    enabled BOOLEAN DEFAULT 'true' NOT NULL, 
    status VARCHAR(20) DEFAULT 'draft' NOT NULL, 
    cron_expression VARCHAR(100), 
    next_execution TIMESTAMP WITHOUT TIME ZONE, 
    max_executions_per_day INTEGER, 
    execution_count_today INTEGER DEFAULT '0' NOT NULL, 
    created_by INTEGER NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_workflow_clinic_status ON workflows (clinic_id, status);

CREATE INDEX ix_workflow_clinic_enabled ON workflows (clinic_id, enabled);

CREATE TABLE workflow_executions (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    workflow_id INTEGER NOT NULL, 
    patient_id INTEGER, 
    trigger_reason VARCHAR(200) NOT NULL, 
    status VARCHAR(20) DEFAULT 'pending' NOT NULL, 
    result JSON, 
    error_message TEXT, 
    started_at TIMESTAMP WITHOUT TIME ZONE, 
    completed_at TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(workflow_id) REFERENCES workflows (id) ON DELETE CASCADE
);

CREATE INDEX ix_execution_workflow_status ON workflow_executions (workflow_id, status);

CREATE INDEX ix_execution_clinic_date ON workflow_executions (clinic_id, created_at);

CREATE TABLE workflow_templates (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    nom VARCHAR(200) NOT NULL, 
    description TEXT, 
    categorie VARCHAR(50) NOT NULL, 
    trigger_type VARCHAR(20) NOT NULL, 
    trigger_config JSON NOT NULL, 
    conditions JSON, 
    actions JSON NOT NULL, 
    icon VARCHAR(50), 
    color VARCHAR(7), 
    is_active BOOLEAN DEFAULT 'true' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    PRIMARY KEY (id)
);

CREATE TABLE workflow_actions_log (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    execution_id INTEGER NOT NULL, 
    action_type VARCHAR(50) NOT NULL, 
    action_config JSON NOT NULL, 
    status VARCHAR(20) DEFAULT 'pending' NOT NULL, 
    result JSON, 
    error_message TEXT, 
    executed_at TIMESTAMP WITHOUT TIME ZONE, 
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(execution_id) REFERENCES workflow_executions (id) ON DELETE CASCADE
);

CREATE INDEX ix_action_execution_type ON workflow_actions_log (execution_id, action_type);

CREATE TABLE workflow_schedules (
    id SERIAL NOT NULL, 
    clinic_id INTEGER DEFAULT '1' NOT NULL, 
    workflow_id INTEGER NOT NULL, 
    cron_expression VARCHAR(100) NOT NULL, 
    timezone VARCHAR(50) DEFAULT 'UTC' NOT NULL, 
    max_executions_per_day INTEGER, 
    execution_count_today INTEGER DEFAULT '0' NOT NULL, 
    last_execution TIMESTAMP WITHOUT TIME ZONE, 
    next_execution TIMESTAMP WITHOUT TIME ZONE, 
    enabled BOOLEAN DEFAULT 'true' NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE DEFAULT now() NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(workflow_id) REFERENCES workflows (id) ON DELETE CASCADE
);

INSERT INTO alembic_version (version_num) VALUES ('8b2c3d4e5f6g') RETURNING alembic_version.version_num;

-- Running upgrade 8b2c3d4e5f6g -> 9c3d4e5f6g7h

ALTER TABLE commandes_assistant ADD COLUMN intent_detecte VARCHAR(100);

ALTER TABLE commandes_assistant ADD COLUMN outil_appele VARCHAR(100);

ALTER TABLE commandes_assistant ADD COLUMN role_applique VARCHAR(50);

ALTER TABLE commandes_assistant ADD COLUMN parametres_appel JSON;

ALTER TABLE commandes_assistant ADD COLUMN tool_payload_json JSON;

ALTER TABLE commandes_assistant ADD COLUMN erreur_message TEXT;

ALTER TABLE commandes_assistant ADD COLUMN utilisateur_id INTEGER;

CREATE INDEX ix_commande_utilisateur ON commandes_assistant (utilisateur_id);

CREATE INDEX ix_commande_outil ON commandes_assistant (outil_appele);

UPDATE alembic_version SET version_num='9c3d4e5f6g7h' WHERE alembic_version.version_num = '8b2c3d4e5f6g';

-- Running upgrade 9c3d4e5f6g7h, a1b2c3d4e5f6 -> 62f1dcc65ced

DELETE FROM alembic_version WHERE alembic_version.version_num = '9c3d4e5f6g7h';

UPDATE alembic_version SET version_num='62f1dcc65ced' WHERE alembic_version.version_num = 'a1b2c3d4e5f6';

-- Running upgrade 62f1dcc65ced -> e1a2b3c4d5e6

CREATE TABLE consommables (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    nom VARCHAR(200) NOT NULL, 
    categorie VARCHAR(100) NOT NULL, 
    unite VARCHAR(50) NOT NULL, 
    stock_actuel NUMERIC(10, 2) NOT NULL, 
    seuil_alerte NUMERIC(10, 2) NOT NULL, 
    stock_minimum NUMERIC(10, 2) NOT NULL, 
    prix_unitaire NUMERIC(10, 3) NOT NULL, 
    fournisseur_id INTEGER, 
    is_active BOOLEAN NOT NULL, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    updated_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id)
);

CREATE INDEX ix_consommables_nom ON consommables (nom);

CREATE TABLE mouvements_consommables (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    consommable_id INTEGER NOT NULL, 
    type VARCHAR(20) NOT NULL, 
    quantite NUMERIC(10, 2) NOT NULL, 
    date_mouvement TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    utilisateur_id INTEGER NOT NULL, 
    motif VARCHAR(255), 
    reference VARCHAR(100), 
    PRIMARY KEY (id), 
    FOREIGN KEY(consommable_id) REFERENCES consommables (id) ON DELETE CASCADE, 
    FOREIGN KEY(utilisateur_id) REFERENCES utilisateurs (id) ON DELETE RESTRICT
);

UPDATE alembic_version SET version_num='e1a2b3c4d5e6' WHERE alembic_version.version_num = '62f1dcc65ced';

-- Running upgrade e1a2b3c4d5e6 -> f1a2b3c4d5e7

CREATE TABLE teleconsultations (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    rdv_id INTEGER NOT NULL, 
    lien_visio VARCHAR(500) NOT NULL, 
    statut VARCHAR(20) NOT NULL, 
    duree_reelle INTEGER, 
    notes TEXT, 
    created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(rdv_id) REFERENCES rendez_vous (id) ON DELETE CASCADE, 
    UNIQUE (rdv_id)
);

CREATE TABLE parrainages (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    parrain_patient_id INTEGER NOT NULL, 
    filleul_patient_id INTEGER, 
    code_parrain VARCHAR(20) NOT NULL, 
    statut VARCHAR(20) NOT NULL, 
    date_parrainage TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    recompense_attribuee BOOLEAN NOT NULL, 
    recompense_utilisee BOOLEAN NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(parrain_patient_id) REFERENCES patients (id) ON DELETE CASCADE, 
    FOREIGN KEY(filleul_patient_id) REFERENCES patients (id) ON DELETE SET NULL
);

CREATE INDEX ix_parrainages_code_parrain ON parrainages (code_parrain);

UPDATE alembic_version SET version_num='f1a2b3c4d5e7' WHERE alembic_version.version_num = 'e1a2b3c4d5e6';

-- Running upgrade 62f1dcc65ced -> b2c3d4e5f6g7

CREATE TABLE equipe_messages (
    id SERIAL NOT NULL, 
    clinic_id INTEGER NOT NULL, 
    expediteur_id INTEGER NOT NULL, 
    destinataire_id INTEGER NOT NULL, 
    sujet VARCHAR(200) NOT NULL, 
    contenu TEXT NOT NULL, 
    lu BOOLEAN NOT NULL, 
    lu_a TIMESTAMP WITHOUT TIME ZONE, 
    cree_a TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(expediteur_id) REFERENCES utilisateurs (id) ON DELETE CASCADE, 
    FOREIGN KEY(destinataire_id) REFERENCES utilisateurs (id) ON DELETE CASCADE
);

CREATE INDEX ix_equipe_messages_clinic_expediteur ON equipe_messages (clinic_id, expediteur_id);

CREATE INDEX ix_equipe_messages_clinic_destinataire ON equipe_messages (clinic_id, destinataire_id);

CREATE INDEX ix_equipe_messages_destinataire_lu ON equipe_messages (destinataire_id, lu);

INSERT INTO alembic_version (version_num) VALUES ('b2c3d4e5f6g7') RETURNING alembic_version.version_num;

-- Running upgrade b2c3d4e5f6g7, f1a2b3c4d5e7 -> 0da89332a77d

DELETE FROM alembic_version WHERE alembic_version.version_num = 'b2c3d4e5f6g7';

UPDATE alembic_version SET version_num='0da89332a77d' WHERE alembic_version.version_num = 'f1a2b3c4d5e7';

COMMIT;

