"""Contrôle de sécurité de configuration pour la release clinique.

Ce script est volontairement cohérent avec les garde-fous de config.py et du
contrôle pré-déploiement principal. Il n'est pas une preuve de staging réel.
"""

from pathlib import Path

from config import DEFAULT_SECRET_KEY, get_settings


def check() -> int:
    settings = get_settings()
    errors: list[str] = []

    if settings.env != "production":
        errors.append(f"ENV doit être production, valeur={settings.env!r}")
    if settings.cors_origins.strip() == "*":
        errors.append("CORS_ORIGINS ne doit pas valoir *")
    if settings.secret_key == DEFAULT_SECRET_KEY or len(settings.secret_key) < 32:
        errors.append("SECRET_KEY absente, par défaut ou trop courte")
    if len(settings.fernet_key) < 32:
        errors.append("FERNET_KEY absente ou trop courte")
    if len(settings.photo_encryption_key) < 32:
        errors.append("PHOTO_ENCRYPTION_KEY absente ou trop courte")
    if len(settings.backup_encryption_key) < 32:
        errors.append("BACKUP_ENCRYPTION_KEY absente ou trop courte")
    if settings.fernet_key == settings.photo_encryption_key:
        errors.append("FERNET_KEY et PHOTO_ENCRYPTION_KEY doivent être distinctes")
    if settings.backup_encryption_key in {
        settings.secret_key,
        settings.fernet_key,
        settings.photo_encryption_key,
        settings.postgres_password,
        settings.redis_password,
    }:
        errors.append("BACKUP_ENCRYPTION_KEY doit être indépendante")
    if "changeme" in settings.database_url.lower():
        errors.append("DATABASE_URL contient encore changeme")
    if "changeme" in settings.redis_url.lower():
        errors.append("REDIS_URL contient encore changeme")
    if not settings.redis_password:
        errors.append("REDIS_PASSWORD est vide")

    output = Path(__file__).resolve().parent.parent.parent / "configuration-security.txt"
    output.write_text(
        "\n".join(
            [
                f"CORS_ORIGINS is '*': {settings.cors_origins.strip() == '*'}",
                f"FERNET_KEY == PHOTO_ENCRYPTION_KEY: {settings.fernet_key == settings.photo_encryption_key}",
                f"BACKUP_ENCRYPTION_KEY length: {len(settings.backup_encryption_key)}",
                f"DATABASE_URL starts with postgresql: {settings.database_url.startswith('postgresql')}",
                f"errors: {len(errors)}",
            ]
            + [f"ERROR: {error}" for error in errors]
        )
        + "\n",
        encoding="utf-8",
    )
    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1
    print("Security config check: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(check())
