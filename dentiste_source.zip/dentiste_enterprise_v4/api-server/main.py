"""
AutoCommerce Clinic — Point d'entrée FastAPI

Ce fichier n'existait pas : l'API ne pouvait pas démarrer. Il monte
les routers de api/v1, expose des endpoints de santé/readiness, configure CORS, et ferme
proprement le pool de connexions DB à l'arrêt.
"""

from contextlib import asynccontextmanager
import logging

from fastapi import FastAPI, Depends, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import Response
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
import redis.asyncio as redis

from config import get_settings
from api.v1 import api_router
from api.deps import _get_sessionmaker, dispose_engine, limiter, get_db
from services.test_admin_bootstrap import reconcile_test_admin


logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    if settings.test_admin_bootstrap_enabled:
        async with _get_sessionmaker() as db:
            outcome = await reconcile_test_admin(
                db,
                email=settings.test_admin_email,
                nom=settings.test_admin_nom,
                prenom=settings.test_admin_prenom,
                password=settings.test_admin_password,
                clinic_id=settings.instance_clinic_id or settings.clinic_id,
                reset_existing=settings.test_admin_reset_existing,
            )
            await db.commit()
            logger.info("Test administrator bootstrap completed: %s", outcome)
    try:
        yield
    finally:
        await dispose_engine()


def create_app() -> FastAPI:
    settings = get_settings()

    app = FastAPI(
        title="AutoCommerce Clinic API",
        version="1.1.0",
        lifespan=lifespan,
    )

    app.state.limiter = limiter
    app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("X-Frame-Options", "DENY")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
        if settings.env in {"production", "prod"}:
            response.headers.setdefault(
                "Strict-Transport-Security", "max-age=31536000; includeSubDomains"
            )
        return response

    origins = [o.strip() for o in settings.cors_origins.split(",") if o.strip()]
    wildcard_cors = settings.cors_origins.strip() == "*"
    allow_origins = ["*"] if wildcard_cors else origins
    app.add_middleware(
        CORSMiddleware,
        allow_origins=allow_origins,
        allow_credentials=not wildcard_cors,
        allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Requested-With", "X-CSRF-Token"],
    )

    app.include_router(api_router)

    settings.branding_dir.mkdir(parents=True, exist_ok=True)
    app.mount(
        "/static/branding",
        StaticFiles(directory=str(settings.branding_dir)),
        name="branding",
    )

    @app.get("/health", tags=["health"])
    async def health():
        return {"status": "ok"}

    @app.get("/ready", tags=["health"])
    async def readiness(db: AsyncSession = Depends(get_db)):
        """Readiness réelle : PostgreSQL et Redis doivent répondre."""
        import logging

        logger = logging.getLogger(__name__)
        redis_client = redis.from_url(
            settings.redis_url,
            socket_connect_timeout=2,
            socket_timeout=2,
            health_check_interval=10,
        )
        try:
            await db.execute(select(1))
            await redis_client.ping()
            return {"status": "ready", "db": "ok", "redis": "ok"}
        except Exception:
            logger.exception("Readiness check failed")
            raise HTTPException(status_code=503, detail="Service temporairement indisponible")
        finally:
            await redis_client.aclose()

    @app.get("/metrics", tags=["health"], include_in_schema=False)
    async def metrics(request: Request):
        """Métriques réservées au monitoring local en production."""
        client_host = request.client.host if request.client else ""
        if settings.env == "production" and client_host not in {"127.0.0.1", "::1", "localhost"}:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not found")
        from prometheus_client import generate_latest, CONTENT_TYPE_LATEST

        return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

    # Instrumentation Prometheus (si Sentry/monitoring configuré)
    try:
        from prometheus_fastapi_instrumentator import Instrumentator

        Instrumentator().instrument(app)
    except Exception as exc:
        import logging
        logging.getLogger(__name__).warning("Prometheus instrumentation unavailable: %s", exc)

    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
