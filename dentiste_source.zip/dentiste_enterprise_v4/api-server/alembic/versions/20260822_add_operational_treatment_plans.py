"""Add operational treatment plans.

Revision ID: 20260822_treatment_plans
Revises: 20260821_callback_leads_dentiste
Create Date: 2026-08-22 10:00:00.000000
"""
from alembic import op
import sqlalchemy as sa


revision = "20260822_treatment_plans"
down_revision = "20260821_callback_leads_dentiste"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "plans_traitement",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("praticien_id", sa.Integer(), nullable=True),
        sa.Column("titre", sa.String(length=200), nullable=False),
        sa.Column("objectif", sa.Text(), nullable=True),
        sa.Column("statut", sa.String(length=20), nullable=False),
        sa.Column("date_debut", sa.Date(), nullable=True),
        sa.Column("date_cible", sa.Date(), nullable=True),
        sa.Column("cree_par_id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["praticien_id"], ["utilisateurs.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["cree_par_id"], ["utilisateurs.id"], ondelete="RESTRICT"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_plans_traitement_clinic_patient",
        "plans_traitement",
        ["clinic_id", "patient_id"],
    )
    op.create_index(
        "ix_plans_traitement_clinic_statut",
        "plans_traitement",
        ["clinic_id", "statut"],
    )

    op.create_table(
        "etapes_plans_traitement",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("plan_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("ordre", sa.Integer(), nullable=False),
        sa.Column("titre", sa.String(length=200), nullable=False),
        sa.Column("type_etape", sa.String(length=50), nullable=True),
        sa.Column("statut", sa.String(length=20), nullable=False),
        sa.Column("date_prevue", sa.Date(), nullable=True),
        sa.Column("date_realisation", sa.Date(), nullable=True),
        sa.Column("rendez_vous_id", sa.Integer(), nullable=True),
        sa.Column("devis_id", sa.Integer(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["plan_id"], ["plans_traitement.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["rendez_vous_id"], ["rendez_vous.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["devis_id"], ["devis_traitements.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("plan_id", "ordre", name="uq_etapes_plan_ordre"),
    )
    op.create_index(
        "ix_etapes_plan_clinic_plan",
        "etapes_plans_traitement",
        ["clinic_id", "plan_id", "ordre"],
    )
    op.create_index(
        "ix_etapes_plan_clinic_patient",
        "etapes_plans_traitement",
        ["clinic_id", "patient_id"],
    )

    op.create_table(
        "profils_personnel",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("user_id", sa.Integer(), nullable=False),
        sa.Column("adresse", sa.String(length=300), nullable=True),
        sa.Column("fonction", sa.String(length=100), nullable=True),
        sa.Column("date_embauche", sa.Date(), nullable=True),
        sa.Column("diplomes", sa.Text(), nullable=True),
        sa.Column("specialisations", sa.Text(), nullable=True),
        sa.Column("certifications", sa.Text(), nullable=True),
        sa.Column("documents", sa.JSON(), nullable=True),
        sa.Column("notes_internes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["utilisateurs.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("clinic_id", "user_id", name="uq_profils_personnel_clinic_user"),
    )
    op.create_index("ix_profils_personnel_clinic", "profils_personnel", ["clinic_id"])


def downgrade() -> None:
    op.drop_index("ix_profils_personnel_clinic", table_name="profils_personnel")
    op.drop_table("profils_personnel")
    op.drop_index("ix_etapes_plan_clinic_patient", table_name="etapes_plans_traitement")
    op.drop_index("ix_etapes_plan_clinic_plan", table_name="etapes_plans_traitement")
    op.drop_table("etapes_plans_traitement")
    op.drop_index("ix_plans_traitement_clinic_statut", table_name="plans_traitement")
    op.drop_index("ix_plans_traitement_clinic_patient", table_name="plans_traitement")
    op.drop_table("plans_traitement")
