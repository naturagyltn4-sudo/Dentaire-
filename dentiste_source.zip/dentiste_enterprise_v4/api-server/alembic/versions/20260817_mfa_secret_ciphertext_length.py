"""Allow encrypted MFA secrets to fit in the users table.

Revision ID: 20260817_mfa_secret_length
Revises: 20260817_booking_requests
Create Date: 2026-08-17
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "20260817_mfa_secret_length"
down_revision: Union[str, None] = "20260817_booking_requests"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "utilisateurs",
        "mfa_secret",
        existing_type=sa.String(length=100),
        type_=sa.String(length=255),
        existing_nullable=True,
    )


def downgrade() -> None:
    connection = op.get_bind()
    too_long = connection.execute(
        sa.text(
            "SELECT 1 FROM utilisateurs "
            "WHERE mfa_secret IS NOT NULL AND length(mfa_secret) > 100 LIMIT 1"
        )
    ).first()
    if too_long:
        raise RuntimeError(
            "Impossible de réduire utilisateurs.mfa_secret à 100 caractères "
            "tant que des secrets MFA chiffrés dépassent cette taille."
        )
    op.alter_column(
        "utilisateurs",
        "mfa_secret",
        existing_type=sa.String(length=255),
        type_=sa.String(length=100),
        existing_nullable=True,
    )
