"""scope business identifiers by clinic

Revision ID: 20260820_tenant_composite_uniques
Revises: f657100d5f20
Create Date: 2026-08-20

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "20260820_tenant_composite_uniques"
down_revision: Union[str, None] = "f657100d5f20"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_GLOBAL_UNIQUE_CONSTRAINTS = (
    ("patients", "patients_telephone_key"),
    ("lots_injectables", "lots_injectables_numero_lot_key"),
    ("factures", "factures_numero_facture_key"),
    ("clinic_settings", "clinic_settings_key_key"),
)


def _drop_known_global_constraints() -> None:
    """Drop PostgreSQL's default names without failing on already-clean DBs."""
    if op.get_bind().dialect.name != "postgresql":
        return
    for table, constraint in _GLOBAL_UNIQUE_CONSTRAINTS:
        op.execute(
            sa.text(
                f'ALTER TABLE "{table}" DROP CONSTRAINT IF EXISTS "{constraint}"'
            )
        )


def upgrade() -> None:
    # Le schéma Alembic historique limite version_num à 32 caractères,
    # alors que ce revision ID en contient 34.
    bind = op.get_bind()
    if bind.dialect.name == "postgresql":
        op.execute("ALTER TABLE alembic_version ALTER COLUMN version_num TYPE VARCHAR(64)")

    _drop_known_global_constraints()

    op.create_unique_constraint(
        "uq_patients_clinic_telephone", "patients", ["clinic_id", "telephone"]
    )
    op.create_unique_constraint(
        "uq_lots_clinic_numero", "lots_injectables", ["clinic_id", "numero_lot"]
    )
    op.create_unique_constraint(
        "uq_factures_clinic_numero", "factures", ["clinic_id", "numero_facture"]
    )
    op.create_unique_constraint(
        "uq_clinic_settings_clinic_key", "clinic_settings", ["clinic_id", "key"]
    )
    op.create_unique_constraint(
        "uq_etats_dentaires_clinic_patient_dent",
        "etats_dentaires",
        ["clinic_id", "patient_id", "numero_dent"],
    )


def downgrade() -> None:
    op.drop_constraint(
        "uq_etats_dentaires_clinic_patient_dent", "etats_dentaires", type_="unique"
    )
    op.drop_constraint(
        "uq_clinic_settings_clinic_key", "clinic_settings", type_="unique"
    )
    op.drop_constraint(
        "uq_factures_clinic_numero", "factures", type_="unique"
    )
    op.drop_constraint(
        "uq_lots_clinic_numero", "lots_injectables", type_="unique"
    )
    op.drop_constraint(
        "uq_patients_clinic_telephone", "patients", type_="unique"
    )

    if op.get_bind().dialect.name == "postgresql":
        for table, constraint in _GLOBAL_UNIQUE_CONSTRAINTS:
            op.create_unique_constraint(constraint, table, [
                {
                    "patients": "telephone",
                    "lots_injectables": "numero_lot",
                    "factures": "numero_facture",
                    "clinic_settings": "key",
                }[table]
            ])
