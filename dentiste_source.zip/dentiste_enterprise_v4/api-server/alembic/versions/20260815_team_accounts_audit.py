"""Ajoute le journal d'audit général pour les comptes et dossiers.

Revision ID: 20260815_team_accounts_audit
Revises: 20260815_delegues_cephalometries
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "20260815_team_accounts_audit"
down_revision: Union[str, None] = "20260815_delegues_cephalometries"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "journal_audit",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("utilisateur_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=True),
        sa.Column("action", sa.String(length=100), nullable=False),
        sa.Column("resource_type", sa.String(length=60), nullable=False),
        sa.Column("resource_id", sa.Integer(), nullable=True),
        sa.Column("details", sa.JSON(), nullable=True),
        sa.Column("ip_address", sa.String(length=45), nullable=True),
        sa.Column("user_agent", sa.String(length=500), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_journal_audit_clinic_date", "journal_audit", ["clinic_id", "created_at"])
    op.create_index("ix_journal_audit_patient_date", "journal_audit", ["patient_id", "created_at"])
    op.create_index("ix_journal_audit_user_date", "journal_audit", ["utilisateur_id", "created_at"])


def downgrade() -> None:
    op.drop_index("ix_journal_audit_user_date", table_name="journal_audit")
    op.drop_index("ix_journal_audit_patient_date", table_name="journal_audit")
    op.drop_index("ix_journal_audit_clinic_date", table_name="journal_audit")
    op.drop_table("journal_audit")
