"""bloc1_add_odontogramme_models

Revision ID: bloc1_odontogramme
Revises: d4e5f6g7h8i9
Create Date: 2026-08-07 16:45:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "bloc1_odontogramme"
down_revision: Union[str, None] = "d4e5f6g7h8i9"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create etats_dentaires table
    op.create_table(
        "etats_dentaires",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("numero_dent", sa.String(2), nullable=False),
        sa.Column("statut", sa.String(20), nullable=False, server_default="sain"),
        sa.Column("face", sa.String(50), nullable=True),
        sa.Column("praticien_id", sa.Integer(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("date_modification", sa.DateTime(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(
            ["praticien_id"], ["utilisateurs.id"], ondelete="RESTRICT"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_etat_dentaire_patient_dent",
        "etats_dentaires",
        ["patient_id", "numero_dent"],
    )
    op.create_index(
        "ix_etat_dentaire_patient_date",
        "etats_dentaires",
        ["patient_id", "date_modification"],
    )

    # Create historiques_dentaires table
    op.create_table(
        "historiques_dentaires",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("etat_dentaire_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("numero_dent", sa.String(2), nullable=False),
        sa.Column("statut_ancien", sa.String(20), nullable=True),
        sa.Column("statut_nouveau", sa.String(20), nullable=False),
        sa.Column("face_ancien", sa.String(50), nullable=True),
        sa.Column("face_nouveau", sa.String(50), nullable=True),
        sa.Column("praticien_id", sa.Integer(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(
            ["etat_dentaire_id"], ["etats_dentaires.id"], ondelete="RESTRICT"
        ),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(
            ["praticien_id"], ["utilisateurs.id"], ondelete="RESTRICT"
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_historique_dentaire_patient_date",
        "historiques_dentaires",
        ["patient_id", "created_at"],
    )
    op.create_index(
        "ix_historique_dentaire_etat_date",
        "historiques_dentaires",
        ["etat_dentaire_id", "created_at"],
    )


def downgrade() -> None:
    op.drop_index("ix_historique_dentaire_etat_date", "historiques_dentaires")
    op.drop_index("ix_historique_dentaire_patient_date", "historiques_dentaires")
    op.drop_table("historiques_dentaires")
    op.drop_index("ix_etat_dentaire_patient_date", "etats_dentaires")
    op.drop_index("ix_etat_dentaire_patient_dent", "etats_dentaires")
    op.drop_table("etats_dentaires")
