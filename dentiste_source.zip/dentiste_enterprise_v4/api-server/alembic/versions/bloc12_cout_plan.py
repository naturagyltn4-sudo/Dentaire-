"""Bloc 12 : estimation déterministe du coût des plans."""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "bloc12_cout_plan"
down_revision: Union[str, Sequence[str], None] = (
    "bloc10_11_ia_dentaire",
    "bloc8_9_suivi_ortho",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "estimations_cout_plan",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("plan_id", sa.Integer(), nullable=False, unique=True),
        sa.Column("total", sa.Numeric(12, 3), nullable=False),
        sa.Column("details", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(
            ["plan_id"], ["plans_traitement_ia.id"], ondelete="CASCADE"
        ),
    )


def downgrade() -> None:
    op.drop_table("estimations_cout_plan")
