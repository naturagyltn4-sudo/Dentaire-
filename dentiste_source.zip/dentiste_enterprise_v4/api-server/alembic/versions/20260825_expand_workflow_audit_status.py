"""expand_workflow_audit_status

Revision ID: 20260825_workflow_audit_status
Revises: 20260822_p02_release_final
Create Date: 2026-08-25

La validation humaine des actions de messagerie écrit notamment le statut
``drafted_for_validation`` (22 caractères). La colonne historique limitée à
20 caractères provoquait une troncature PostgreSQL et annulait l’exécution.
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "20260825_workflow_audit_status"
down_revision: Union[str, None] = "20260822_p02_release_final"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "workflow_audit_logs",
        "status",
        existing_type=sa.String(length=20),
        type_=sa.String(length=50),
        existing_nullable=False,
    )


def downgrade() -> None:
    op.alter_column(
        "workflow_audit_logs",
        "status",
        existing_type=sa.String(length=50),
        type_=sa.String(length=20),
        existing_nullable=False,
    )
