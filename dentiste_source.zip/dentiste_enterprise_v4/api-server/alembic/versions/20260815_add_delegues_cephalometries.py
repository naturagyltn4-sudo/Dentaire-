"""Add delegates and cephalometric studies.

Revision ID: 20260815_delegues_cephalometries
Revises: 7c2d9f1a4b6e
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "20260815_delegues_cephalometries"
down_revision: Union[str, Sequence[str], None] = "7c2d9f1a4b6e"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "delegues",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("nom", sa.String(length=100), nullable=False),
        sa.Column("prenom", sa.String(length=100), nullable=False),
        sa.Column("laboratoire_ou_societe", sa.String(length=150), nullable=False),
        sa.Column("telephone", sa.String(length=20), nullable=False),
        sa.Column("email", sa.String(length=255), nullable=True),
        sa.Column("specialite_produits", sa.String(length=200), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_delegues_clinic_nom", "delegues", ["clinic_id", "nom"])
    op.create_index("ix_delegues_clinic_societe", "delegues", ["clinic_id", "laboratoire_ou_societe"])

    op.create_table(
        "cephalometries",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("praticien_id", sa.Integer(), nullable=True),
        sa.Column("titre", sa.String(length=200), nullable=False),
        sa.Column("image_url", sa.String(length=500), nullable=False),
        sa.Column("mime_type", sa.String(length=100), nullable=False, server_default="image/jpeg"),
        sa.Column("analyse_data", sa.JSON(), nullable=True),
        sa.Column("conclusions", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["praticien_id"], ["utilisateurs.id"], ondelete="SET NULL"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_cephalometries_clinic_patient", "cephalometries", ["clinic_id", "patient_id"])
    op.create_index("ix_cephalometries_created_at", "cephalometries", ["created_at"])


def downgrade() -> None:
    op.drop_index("ix_cephalometries_created_at", table_name="cephalometries")
    op.drop_index("ix_cephalometries_clinic_patient", table_name="cephalometries")
    op.drop_table("cephalometries")
    op.drop_index("ix_delegues_clinic_societe", table_name="delegues")
    op.drop_index("ix_delegues_clinic_nom", table_name="delegues")
    op.drop_table("delegues")
