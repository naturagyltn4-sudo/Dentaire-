"""Add tenant-scoped AI usage budgets.

Revision ID: 20260817_ai_usage_budget
Revises: 20260817_mfa_secret_length
Create Date: 2026-08-17
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "20260817_ai_usage_budget"
down_revision: Union[str, None] = "20260817_mfa_secret_length"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "ai_usage",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("period_start", sa.Date(), nullable=False),
        sa.Column("requests_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("reserved_tokens", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("request_limit", sa.Integer(), nullable=False),
        sa.Column("token_limit", sa.Integer(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "clinic_id", "period_start", name="uq_ai_usage_clinic_period"
        ),
    )
    op.create_index("ix_ai_usage_clinic", "ai_usage", ["clinic_id"], unique=False)


def downgrade() -> None:
    op.drop_index("ix_ai_usage_clinic", table_name="ai_usage")
    op.drop_table("ai_usage")
