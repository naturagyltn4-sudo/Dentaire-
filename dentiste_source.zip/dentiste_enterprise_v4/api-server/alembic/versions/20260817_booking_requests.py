"""Add isolated public booking requests.

Revision ID: 20260817_booking_requests
Revises: 20260815_team_accounts_audit
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "20260817_booking_requests"
down_revision: Union[str, None] = "20260815_team_accounts_audit"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "booking_requests",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("nom", sa.String(length=100), nullable=False),
        sa.Column("prenom", sa.String(length=100), nullable=False),
        sa.Column("telephone", sa.String(length=20), nullable=False),
        sa.Column("praticien_id", sa.Integer(), nullable=True),
        sa.Column("acte_id", sa.Integer(), nullable=False),
        sa.Column("date_heure", sa.DateTime(), nullable=False),
        sa.Column("specialite", sa.String(length=120), nullable=True),
        sa.Column("statut", sa.String(length=20), nullable=False, server_default="pending"),
        sa.Column("patient_id", sa.Integer(), nullable=True),
        sa.Column("rendez_vous_id", sa.Integer(), nullable=True),
        sa.Column("source_ip_hash", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("validated_at", sa.DateTime(), nullable=True),
        sa.Column("rejected_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["praticien_id"], ["utilisateurs.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["acte_id"], ["actes_medicaux.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["rendez_vous_id"], ["rendez_vous.id"], ondelete="SET NULL"),
    )
    op.create_index("ix_booking_requests_clinic_id", "booking_requests", ["clinic_id"])
    op.create_index("ix_booking_requests_telephone", "booking_requests", ["telephone"])
    op.create_index(
        "ix_booking_requests_dedupe",
        "booking_requests",
        ["clinic_id", "telephone", "date_heure", "acte_id"],
    )


def downgrade() -> None:
    op.drop_index("ix_booking_requests_dedupe", table_name="booking_requests")
    op.drop_index("ix_booking_requests_telephone", table_name="booking_requests")
    op.drop_index("ix_booking_requests_clinic_id", table_name="booking_requests")
    op.drop_table("booking_requests")
