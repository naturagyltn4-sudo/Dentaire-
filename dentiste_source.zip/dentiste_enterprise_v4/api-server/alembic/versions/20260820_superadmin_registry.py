"""add superadmin tenant registry and subscriptions

Revision ID: 20260820_superadmin_registry
Revises: 20260820_tenant_composite_uniques
Create Date: 2026-08-20
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "20260820_superadmin_registry"
down_revision: Union[str, None] = "20260820_tenant_composite_uniques"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "cliniques",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("nom", sa.String(length=200), nullable=False),
        sa.Column("slug", sa.String(length=120), nullable=False),
        sa.Column("statut", sa.String(length=20), nullable=False, server_default="active"),
        sa.Column("email_contact", sa.String(length=255), nullable=True),
        sa.Column("telephone_contact", sa.String(length=30), nullable=True),
        sa.Column("fuseau_horaire", sa.String(length=60), nullable=False, server_default="Africa/Tunis"),
        sa.Column("metadata_json", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("slug"),
    )
    op.create_index("ix_cliniques_statut", "cliniques", ["statut"])
    op.create_table(
        "clinic_subscriptions",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("plan", sa.String(length=40), nullable=False, server_default="enterprise"),
        sa.Column("statut", sa.String(length=20), nullable=False, server_default="trial"),
        sa.Column("started_at", sa.DateTime(), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=True),
        sa.Column("user_limit", sa.Integer(), nullable=False, server_default="25"),
        sa.Column("storage_limit_gb", sa.Integer(), nullable=False, server_default="100"),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("metadata_json", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("clinic_id", name="uq_clinic_subscription_clinic"),
    )
    op.create_index("ix_clinic_subscription_status", "clinic_subscriptions", ["statut"])


def downgrade() -> None:
    op.drop_index("ix_clinic_subscription_status", table_name="clinic_subscriptions")
    op.drop_table("clinic_subscriptions")
    op.drop_index("ix_cliniques_statut", table_name="cliniques")
    op.drop_table("cliniques")
