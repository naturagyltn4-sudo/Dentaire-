"""Fusion finale : relie les 3 branches dentaires (blocs 8-9, 10-11 et 13-14)
et la branche des tables manquantes (radiologie, prothèses, devis, mutuelles,
agenda) en une seule tête. Aucun objet de schéma n'est créé ici — toutes les
tables existent déjà dans les branches parentes. Les branches 8-9 et 10-11 sont déjà consommées par le bloc 12, elles ne sont
donc pas répétées dans la fusion."""

from typing import Sequence, Union

revision: str = "merge_bloc_dentaire_final"
down_revision: Union[str, Sequence[str], None] = (
    "bloc13_14_compte_rendu_rappels",
    "missing_radios_protheses_devis",
)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
