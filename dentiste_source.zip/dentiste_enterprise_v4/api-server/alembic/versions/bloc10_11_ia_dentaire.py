"""Blocs 10-11 : IA dentaire, résultats isolés et validation praticien."""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "bloc10_11_ia_dentaire"
down_revision: Union[str, None] = "bloc1_odontogramme"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "analyses_caries",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("radio_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("praticien_id", sa.Integer(), nullable=False),
        sa.Column("resultat", sa.JSON(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(
            ["radio_id"], ["imagerie_radios.id"], ondelete="RESTRICT"
        ),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(
            ["praticien_id"], ["utilisateurs.id"], ondelete="RESTRICT"
        ),
    )
    op.create_index("ix_analyses_caries_radio_id", "analyses_caries", ["radio_id"])
    op.create_index("ix_analyses_caries_patient_id", "analyses_caries", ["patient_id"])
    op.create_table(
        "plans_traitement_ia",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("cree_par_praticien_id", sa.Integer(), nullable=False),
        sa.Column("proposition", sa.JSON(), nullable=False),
        sa.Column("valide_par_praticien_id", sa.Integer(), nullable=True),
        sa.Column("valide_at", sa.DateTime(), nullable=True),
        sa.Column("envoye_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(
            ["cree_par_praticien_id"], ["utilisateurs.id"], ondelete="RESTRICT"
        ),
        sa.ForeignKeyConstraint(
            ["valide_par_praticien_id"], ["utilisateurs.id"], ondelete="SET NULL"
        ),
    )
    op.create_index(
        "ix_plans_traitement_ia_patient_id", "plans_traitement_ia", ["patient_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_plans_traitement_ia_patient_id", table_name="plans_traitement_ia")
    op.drop_table("plans_traitement_ia")
    op.drop_index("ix_analyses_caries_patient_id", table_name="analyses_caries")
    op.drop_index("ix_analyses_caries_radio_id", table_name="analyses_caries")
    op.drop_table("analyses_caries")
