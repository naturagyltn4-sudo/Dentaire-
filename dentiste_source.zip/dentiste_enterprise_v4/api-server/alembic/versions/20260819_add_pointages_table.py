"""add pointages table

Revision ID: 20260819_add_pointages
Revises: merge_bloc_dentaire_final
Create Date: 2026-08-19 17:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '20260819_add_pointages'
down_revision = 'merge_bloc_dentaire_final'
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'pointages',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('clinic_id', sa.Integer(), nullable=False),
        sa.Column('utilisateur_id', sa.Integer(), nullable=False),
        sa.Column('debut', sa.DateTime(), nullable=False),
        sa.Column('fin', sa.DateTime(), nullable=True),
        sa.Column('duree_minutes', sa.Integer(), nullable=True),
        sa.Column('notes', sa.Text(), nullable=True),
        sa.Column('created_at', sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(['utilisateur_id'], ['utilisateurs.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_pointages_clinic_user', 'pointages', ['clinic_id', 'utilisateur_id'], unique=False)
    op.create_index('ix_pointages_clinic_debut', 'pointages', ['clinic_id', 'debut'], unique=False)


def downgrade() -> None:
    op.drop_index('ix_pointages_clinic_debut', table_name='pointages')
    op.drop_index('ix_pointages_clinic_user', table_name='pointages')
    op.drop_table('pointages')
