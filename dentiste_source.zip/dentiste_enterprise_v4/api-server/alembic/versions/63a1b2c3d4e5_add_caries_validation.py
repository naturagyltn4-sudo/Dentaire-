"""Ajoute la validation praticien individuelle des analyses de caries."""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "63a1b2c3d4e5"
down_revision: Union[str, Sequence[str], None] = "merge_bloc_dentaire_final"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("analyses_caries", recreate="auto") as batch_op:
        batch_op.add_column(
            sa.Column("valide_par_praticien_id", sa.Integer(), nullable=True)
        )
        batch_op.add_column(sa.Column("valide_at", sa.DateTime(), nullable=True))
        batch_op.create_foreign_key(
            "fk_analyses_caries_valide_par_praticien_id_utilisateurs",
            "utilisateurs",
            ["valide_par_praticien_id"],
            ["id"],
            ondelete="RESTRICT",
        )


def downgrade() -> None:
    with op.batch_alter_table("analyses_caries", recreate="auto") as batch_op:
        batch_op.drop_constraint(
            "fk_analyses_caries_valide_par_praticien_id_utilisateurs",
            type_="foreignkey",
        )
        batch_op.drop_column("valide_at")
        batch_op.drop_column("valide_par_praticien_id")
