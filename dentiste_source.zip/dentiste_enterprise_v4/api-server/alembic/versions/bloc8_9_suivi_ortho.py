"""add suivi post-op and ortho models

Revision ID: bloc8_9_suivi_ortho
Revises: bloc8b_avis_plateforme_enum
Create Date: 2026-08-07 12:00:00.000000

"""

from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = "bloc8_9_suivi_ortho"
down_revision = "bloc8b_avis_plateforme_enum"
branch_labels = None
depends_on = None


def upgrade():
    # 1. Ajouter is_chirurgical à actes_medicaux
    op.add_column(
        "actes_medicaux",
        sa.Column("is_chirurgical", sa.Boolean(), nullable=False, server_default="0"),
    )

    # 2. Créer table suivis_post_operatoires
    op.create_table(
        "suivis_post_operatoires",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("acte_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("date_controle_prevue", sa.DateTime(), nullable=False),
        sa.Column("date_controle_reelle", sa.DateTime(), nullable=True),
        sa.Column("statut", sa.String(length=20), nullable=False),
        sa.Column("observations", sa.Text(), nullable=True),
        sa.Column("complication", sa.Text(), nullable=True),
        sa.Column("praticien_id", sa.Integer(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["acte_id"], ["actes_medicaux.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(
            ["praticien_id"], ["utilisateurs.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )

    # 3. Créer table suivis_orthodontiques
    op.create_table(
        "suivis_orthodontiques",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("photo_reelle_id", sa.Integer(), nullable=False),
        sa.Column("date", sa.DateTime(), nullable=False),
        sa.Column("phase", sa.String(length=20), nullable=False),
        sa.Column("type_appareil", sa.String(length=20), nullable=False),
        sa.Column("observations", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="CASCADE"),
        sa.ForeignKeyConstraint(
            ["photo_reelle_id"], ["photos_clinic.id"], ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade():
    op.drop_table("suivis_orthodontiques")
    op.drop_table("suivis_post_operatoires")
    op.drop_column("actes_medicaux", "is_chirurgical")
