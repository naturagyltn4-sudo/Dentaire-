"""merge multiple heads

Revision ID: f657100d5f20
Revises: 20260817_ai_usage_budget, 20260819_add_pointages
Create Date: 2026-08-19 16:32:40.330060

"""
from typing import Sequence, Union

# revision identifiers, used by Alembic.
revision: str = 'f657100d5f20'
down_revision: Union[str, None] = ('20260817_ai_usage_budget', '20260819_add_pointages')
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
