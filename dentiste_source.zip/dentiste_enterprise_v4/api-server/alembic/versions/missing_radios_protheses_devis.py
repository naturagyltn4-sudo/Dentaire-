"""Ajoute les tables manquantes du schéma : radiologie (imagerie_radios),
prothèses (commandes_protheses), devis (devis_traitements), mutuelles
(prises_en_charge_mutuelle) et agenda (salles). Ces 5 tables existaient dans
les modèles SQLAlchemy mais aucune migration ne les créait — l'application
complète de `alembic upgrade head` sur PostgreSQL échouait à cause de la
contrainte de clé étrangère de analyses_caries vers imagerie_radios."""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "missing_radios_protheses_devis"
down_revision: Union[str, Sequence[str], None] = ("bloc1_odontogramme",)
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "salles",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("nom", sa.String(length=100), nullable=False),
        sa.Column("capacite_fauteuils", sa.Integer(), nullable=True, server_default="1"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_table(
        "devis_traitements",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("acte_id", sa.Integer(), nullable=True),
        sa.Column("dent", sa.String(length=2), nullable=True),
        sa.Column("lignes", sa.JSON(), nullable=True),
        sa.Column(
            "prix", sa.Numeric(precision=10, scale=3), nullable=True, server_default="0"
        ),
        sa.Column("date_validite", sa.Date(), nullable=True),
        sa.Column("statut", sa.String(length=20), nullable=True, server_default="brouillon"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["acte_id"], ["actes_medicaux.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
    )
    op.create_index(
        "ix_devis_traitements_patient_id", "devis_traitements", ["patient_id"]
    )
    op.create_table(
        "prises_en_charge_mutuelle",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("devis_id", sa.Integer(), nullable=True),
        sa.Column("facture_id", sa.Integer(), nullable=True),
        sa.Column("organisme", sa.String(length=200), nullable=False),
        sa.Column("numero_dossier", sa.String(length=100), nullable=True),
        sa.Column(
            "montant_pris_en_charge",
            sa.Numeric(precision=10, scale=3),
            nullable=True,
            server_default="0",
        ),
        sa.Column("statut", sa.String(length=20), nullable=True, server_default="en_attente"),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["devis_id"], ["devis_traitements.id"], ondelete="SET NULL"),
        sa.ForeignKeyConstraint(["facture_id"], ["factures.id"], ondelete="SET NULL"),
    )
    op.create_table(
        "commandes_protheses",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("dent", sa.String(length=10), nullable=True),
        sa.Column("dents", sa.String(length=50), nullable=True),
        sa.Column("type", sa.String(length=50), nullable=False),
        sa.Column("laboratoire", sa.String(length=200), nullable=False),
        sa.Column("date_commande", sa.Date(), nullable=False),
        sa.Column("date_reception_prevue", sa.Date(), nullable=False),
        sa.Column("date_reception_reelle", sa.Date(), nullable=True),
        sa.Column("statut", sa.String(length=30), nullable=False, server_default="commande"),
        sa.Column(
            "cout", sa.Numeric(precision=10, scale=3), nullable=False, server_default="0"
        ),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
    )
    op.create_index(
        "ix_commandes_protheses_patient",
        "commandes_protheses",
        ["clinic_id", "patient_id"],
    )
    op.create_index(
        "ix_commandes_protheses_statut",
        "commandes_protheses",
        ["clinic_id", "statut"],
    )
    op.create_table(
        "imagerie_radios",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("patient_id", sa.Integer(), nullable=False),
        sa.Column("praticien_id", sa.Integer(), nullable=False),
        sa.Column("type_radio", sa.String(length=50), nullable=False),
        sa.Column("dent_associee", sa.String(length=2), nullable=True),
        sa.Column("url_stockage", sa.String(length=500), nullable=False),
        sa.Column("hash_fichier", sa.String(length=64), nullable=True),
        sa.Column("taille_octets", sa.Integer(), nullable=True),
        sa.Column("dicom_metadata", sa.JSON(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("date_prise", sa.DateTime(), nullable=False),
        sa.Column("created_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["patient_id"], ["patients.id"], ondelete="RESTRICT"),
        sa.ForeignKeyConstraint(
            ["praticien_id"], ["utilisateurs.id"], ondelete="RESTRICT"
        ),
    )
    op.create_index(
        "ix_imagerie_radios_patient_id", "imagerie_radios", ["patient_id"]
    )


def downgrade() -> None:
    op.drop_index("ix_imagerie_radios_patient_id", table_name="imagerie_radios")
    op.drop_table("imagerie_radios")
    op.drop_index(
        "ix_commandes_protheses_statut", table_name="commandes_protheses"
    )
    op.drop_index(
        "ix_commandes_protheses_patient", table_name="commandes_protheses"
    )
    op.drop_table("commandes_protheses")
    op.drop_table("prises_en_charge_mutuelle")
    op.drop_index("ix_devis_traitements_patient_id", table_name="devis_traitements")
    op.drop_table("devis_traitements")
    op.drop_table("salles")
