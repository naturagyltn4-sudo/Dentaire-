"""Ajoute les comptes rendus dentaires et les rappels dédupliqués.

Revision ID: bloc13_14_compte_rendu_rappels
Revises: bloc12_cout_plan
"""

from alembic import op
import sqlalchemy as sa

revision = "bloc13_14_compte_rendu_rappels"
down_revision = "bloc12_cout_plan"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        "comptes_rendus_dentaires",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), sa.ForeignKey("patients.id", ondelete="CASCADE"), nullable=False),
        sa.Column("plan_id", sa.Integer(), sa.ForeignKey("plans_traitement_ia.id", ondelete="SET NULL")),
        sa.Column("contenu", sa.Text(), nullable=False),
        sa.Column("statut", sa.String(length=20), nullable=False),
        sa.Column("cree_par_praticien_id", sa.Integer(), sa.ForeignKey("utilisateurs.id", ondelete="RESTRICT"), nullable=False),
        sa.Column("valide_par_praticien_id", sa.Integer(), sa.ForeignKey("utilisateurs.id", ondelete="SET NULL")),
        sa.Column("cree_at", sa.DateTime(), nullable=False),
        sa.Column("modifie_at", sa.DateTime(), nullable=False),
        sa.Column("valide_at", sa.DateTime()),
    )
    op.create_index("ix_comptes_rendus_dentaires_patient_id", "comptes_rendus_dentaires", ["patient_id"])
    op.create_table(
        "rappels_dentaires",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("clinic_id", sa.Integer(), nullable=False),
        sa.Column("patient_id", sa.Integer(), sa.ForeignKey("patients.id", ondelete="CASCADE"), nullable=False),
        sa.Column("source_type", sa.String(length=50), nullable=False),
        sa.Column("source_id", sa.Integer(), nullable=False),
        sa.Column("date_prevue", sa.DateTime(), nullable=False),
        sa.Column("canal", sa.String(length=20), nullable=False),
        sa.Column("destinataire", sa.String(length=255), nullable=False),
        sa.Column("contenu", sa.Text(), nullable=False),
        sa.Column("envoye_at", sa.DateTime()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_rappels_dentaires_patient_id", "rappels_dentaires", ["patient_id"])
    op.create_index("ix_rappels_dentaires_date_prevue", "rappels_dentaires", ["date_prevue"])
    op.create_index("uq_rappel_dentaire_source", "rappels_dentaires", ["clinic_id", "source_type", "source_id"], unique=True)


def downgrade() -> None:
    op.drop_index("uq_rappel_dentaire_source", table_name="rappels_dentaires")
    op.drop_index("ix_rappels_dentaires_date_prevue", table_name="rappels_dentaires")
    op.drop_index("ix_rappels_dentaires_patient_id", table_name="rappels_dentaires")
    op.drop_table("rappels_dentaires")
    op.drop_index("ix_comptes_rendus_dentaires_patient_id", table_name="comptes_rendus_dentaires")
    op.drop_table("comptes_rendus_dentaires")
