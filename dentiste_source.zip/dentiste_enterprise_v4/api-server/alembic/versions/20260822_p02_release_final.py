"""P02 — intégrations médecin, omnicanal et téléconsultation.

Cette migration est volontairement PostgreSQL-first et doit rester idempotente
pour permettre un déploiement contrôlé sur un mono-VPS.
"""
from __future__ import annotations

import sqlalchemy as sa
from alembic import op


revision = "20260822_p02_release_final"
down_revision = "20260822_treatment_plans"
branch_labels = None
depends_on = None


def _column_exists(conn, table: str, column: str) -> bool:
    return (
        conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = current_schema() "
                "AND table_name = :t AND column_name = :c"
            ),
            {"t": table, "c": column},
        ).first()
        is not None
    )


def _index_exists(conn, index_name: str) -> bool:
    return (
        conn.execute(
            sa.text(
                "SELECT 1 FROM pg_class c "
                "JOIN pg_namespace n ON n.oid = c.relnamespace "
                "WHERE c.relkind = 'i' AND c.relname = :name "
                "AND n.nspname = current_schema()"
            ),
            {"name": index_name},
        ).first()
        is not None
    )


def _constraint_exists(conn, table: str, constraint_name: str) -> bool:
    return (
        conn.execute(
            sa.text(
                "SELECT 1 FROM pg_constraint c "
                "JOIN pg_class t ON t.oid = c.conrelid "
                "JOIN pg_namespace n ON n.oid = t.relnamespace "
                "WHERE c.conname = :name AND t.relname = :table "
                "AND n.nspname = current_schema()"
            ),
            {"name": constraint_name, "table": table},
        ).first()
        is not None
    )


def _add_fk_if_missing(conn, table: str, constraint_name: str, statement: str) -> None:
    if not _constraint_exists(conn, table, constraint_name):
        op.execute(sa.text(statement))


def upgrade() -> None:
    conn = op.get_bind()

    if not _column_exists(conn, "conversations", "assignee_id"):
        op.add_column(
            "conversations",
            sa.Column("assignee_id", sa.Integer(), nullable=True),
        )
    if not _index_exists(conn, "ix_conversations_assignee_id"):
        op.create_index(
            "ix_conversations_assignee_id",
            "conversations",
            ["assignee_id"],
        )
    _add_fk_if_missing(
        conn,
        "conversations",
        "fk_conversations_assignee_id_utilisateurs",
        "ALTER TABLE conversations ADD CONSTRAINT "
        "fk_conversations_assignee_id_utilisateurs "
        "FOREIGN KEY (assignee_id) REFERENCES utilisateurs(id) ON DELETE SET NULL",
    )

    for column_name, column_type in (
        ("provider", "VARCHAR(20)"),
        ("consent_url", "TEXT"),
        ("recording_url", "TEXT"),
    ):
        if not _column_exists(conn, "teleconsultations", column_name):
            op.execute(
                sa.text(
                    f"ALTER TABLE teleconsultations ADD COLUMN {column_name} {column_type}"
                )
            )

    op.execute(
        sa.text(
            """
            CREATE TABLE IF NOT EXISTS assistant_medecin_whitelist (
                id                  SERIAL PRIMARY KEY,
                clinic_id           INTEGER NOT NULL,
                utilisateur_id      INTEGER NOT NULL,
                numero              VARCHAR(32) NOT NULL,
                nom                 VARCHAR(120),
                statut              VARCHAR(20) NOT NULL DEFAULT 'active',
                expires_at          TIMESTAMP,
                revoked_at          TIMESTAMP,
                last_key_rotation   TIMESTAMP,
                created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                CONSTRAINT uq_assistant_medecin_whitelist_clinic_numero
                    UNIQUE (clinic_id, numero)
            )
            """
        )
    )
    op.execute(
        sa.text(
            "CREATE INDEX IF NOT EXISTS ix_assistant_medecin_whitelist_clinic "
            "ON assistant_medecin_whitelist (clinic_id)"
        )
    )
    for column_name, column_type in (
        ("permissions_json", "TEXT"),
        ("updated_at", "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"),
    ):
        if not _column_exists(conn, "assistant_medecin_whitelist", column_name):
            op.execute(
                sa.text(
                    f"ALTER TABLE assistant_medecin_whitelist ADD COLUMN {column_name} {column_type}"
                )
            )
    _add_fk_if_missing(
        conn,
        "assistant_medecin_whitelist",
        "fk_assistant_medecin_whitelist_utilisateur_id",
        "ALTER TABLE assistant_medecin_whitelist ADD CONSTRAINT "
        "fk_assistant_medecin_whitelist_utilisateur_id "
        "FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE",
    )

    # ── Réconciliation de numeros_whitelist ─────
    for column_name, column_type in (
        ("last_key_rotation", "TIMESTAMP"),
        ("permissions_json", "TEXT"),
        ("created_at", "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"),
        ("updated_at", "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP"),
    ):
        if not _column_exists(conn, "numeros_whitelist", column_name):
            op.execute(
                sa.text(
                    f"ALTER TABLE numeros_whitelist ADD COLUMN {column_name} {column_type}"
                )
            )
    op.execute(
        sa.text(
            "CREATE INDEX IF NOT EXISTS ix_whitelist_clinic_statut "
            "ON numeros_whitelist (clinic_id, statut)"
        )
    )
    # L’ancienne contrainte globale empêche deux cliniques d’utiliser le même
    # numéro. Elle est remplacée par l’unicité correcte dans le tenant.
    op.execute(
        sa.text("DROP INDEX IF EXISTS ix_numeros_whitelist_numero")
    )
    op.execute(
        sa.text(
            "ALTER TABLE numeros_whitelist "
            "DROP CONSTRAINT IF EXISTS uq_numeros_whitelist_numero"
        )
    )
    op.execute(
        sa.text(
            "CREATE INDEX IF NOT EXISTS ix_numeros_whitelist_numero "
            "ON numeros_whitelist (numero)"
        )
    )
    if not _constraint_exists(conn, "numeros_whitelist", "uq_numeros_whitelist_clinic_numero"):
        op.execute(
            sa.text(
                "ALTER TABLE numeros_whitelist ADD CONSTRAINT "
                "uq_numeros_whitelist_clinic_numero UNIQUE (clinic_id, numero)"
            )
        )


def downgrade() -> None:
    # Les données P02 sont conservées pour éviter une suppression accidentelle.
    pass
