"""add_salle_id_to_rendez_vous

Revision ID: 61dbd5e7d2bc
Revises: 63a1b2c3d4e5
Create Date: 2026-08-09 13:49:26.542033

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '61dbd5e7d2bc'
down_revision: Union[str, None] = '63a1b2c3d4e5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    columns = [c['name'] for c in inspector.get_columns('rendez_vous')]
    
    if 'salle_id' not in columns:
        op.add_column('rendez_vous', sa.Column('salle_id', sa.Integer(), nullable=True))
    if 'fauteuil_numero' not in columns:
        op.add_column('rendez_vous', sa.Column('fauteuil_numero', sa.Integer(), nullable=True))
        
    fks = [fk['constrained_columns'] for fk in inspector.get_foreign_keys('rendez_vous')]
    if ['salle_id'] not in fks:
        if bind.dialect.name == 'sqlite':
            # SQLite does not support adding FK via ALTER TABLE easily without batch mode,
            # but since table creation handles it or we can ignore if not supported in sqlite test runner,
            pass
        else:
            op.create_foreign_key('fk_rendez_vous_salle_id', 'rendez_vous', 'salles', ['salle_id'], ['id'], ondelete='SET NULL')


def downgrade() -> None:
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    fks = [fk['name'] for fk in inspector.get_foreign_keys('rendez_vous')]
    if 'fk_rendez_vous_salle_id' in fks:
        op.drop_constraint('fk_rendez_vous_salle_id', 'rendez_vous', type_='foreignkey')
    
    columns = [c['name'] for c in inspector.get_columns('rendez_vous')]
    if 'fauteuil_numero' in columns:
        op.drop_column('rendez_vous', 'fauteuil_numero')
    if 'salle_id' in columns:
        op.drop_column('rendez_vous', 'salle_id')
