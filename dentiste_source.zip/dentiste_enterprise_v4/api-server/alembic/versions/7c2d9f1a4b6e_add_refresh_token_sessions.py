"""add persistent refresh token sessions

Revision ID: 7c2d9f1a4b6e
Revises: 61dbd5e7d2bc
"""
from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa

revision: str = "7c2d9f1a4b6e"
down_revision: Union[str, None] = "61dbd5e7d2bc"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "refresh_token_sessions",
        sa.Column("id", sa.Integer(), primary_key=True, autoincrement=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("utilisateurs.id", ondelete="CASCADE"), nullable=False),
        sa.Column("clinic_id", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("jti", sa.String(length=64), nullable=False),
        sa.Column("token_hash", sa.String(length=64), nullable=False),
        sa.Column("expires_at", sa.DateTime(), nullable=False),
        sa.Column("revoked_at", sa.DateTime(), nullable=True),
        sa.Column("replaced_by_jti", sa.String(length=64), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False, server_default=sa.func.now()),
    )
    op.create_index("ix_refresh_sessions_jti", "refresh_token_sessions", ["jti"], unique=True)
    op.create_index("ix_refresh_sessions_token_hash", "refresh_token_sessions", ["token_hash"], unique=True)
    op.create_index("ix_refresh_sessions_user", "refresh_token_sessions", ["user_id", "clinic_id"])
    op.create_index("ix_refresh_sessions_expiry", "refresh_token_sessions", ["expires_at"])


def downgrade() -> None:
    op.drop_index("ix_refresh_sessions_expiry", table_name="refresh_token_sessions")
    op.drop_index("ix_refresh_sessions_user", table_name="refresh_token_sessions")
    op.drop_index("ix_refresh_sessions_token_hash", table_name="refresh_token_sessions")
    op.drop_index("ix_refresh_sessions_jti", table_name="refresh_token_sessions")
    op.drop_table("refresh_token_sessions")
