"""Add dental photo annotation fields.

Revision ID: 20260821_dental_photo_annotation
Revises: f657100d5f20
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "20260821_dental_photo_annotation"
down_revision: Union[str, Sequence[str], None] = ("f657100d5f20", "20260820_superadmin_registry")
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column("simulations_ia", sa.Column("url_masque", sa.String(length=500), nullable=True))
    op.add_column("simulations_ia", sa.Column("instructions", sa.Text(), nullable=True))


def downgrade() -> None:
    op.drop_column("simulations_ia", "instructions")
    op.drop_column("simulations_ia", "url_masque")
