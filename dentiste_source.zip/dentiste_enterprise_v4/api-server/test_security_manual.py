
import requests

def test_unauthenticated_access():
    routes = [
        "/api/v1/patients",
        "/api/v1/agenda",
        "/api/v1/factures",
        "/api/v1/ia-dentaire/caries/analyser"
    ]
    for route in routes:
        if "analyser" in route:
            response = requests.post(f"http://localhost:8000{route}")
        else:
            response = requests.get(f"http://localhost:8000{route}")
        print(f"{route} (no token): {response.status_code}")
        assert response.status_code == 401

def test_invalid_token():
    routes = ["/api/v1/patients"]
    for route in routes:
        response = requests.get(
            f"http://localhost:8000{route}",
            headers={"Authorization": "Bearer invalid_token"}
        )
        print(f"GET {route} (invalid token): {response.status_code}")
        assert response.status_code == 401

if __name__ == "__main__":
    test_unauthenticated_access()
    test_invalid_token()
