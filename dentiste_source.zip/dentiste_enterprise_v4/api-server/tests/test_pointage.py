from datetime import datetime, timedelta

import pytest
from sqlalchemy import select

from models.database import Pointage


@pytest.mark.asyncio
async def test_pointage_cloture_et_duree(db, medecin):
    debut = datetime(2026, 8, 19, 8, 0, 0)
    fin = debut + timedelta(hours=7, minutes=30)
    pointage = Pointage(
        clinic_id=1,
        utilisateur_id=medecin.id,
        debut=debut,
        fin=fin,
        duree_minutes=int((fin - debut).total_seconds() / 60),
    )
    db.add(pointage)
    await db.flush()

    result = await db.execute(
        select(Pointage).where(
            Pointage.clinic_id == 1,
            Pointage.utilisateur_id == medecin.id,
            Pointage.fin.is_not(None),
        )
    )
    stored = result.scalar_one()
    assert stored.duree_minutes == 450
    assert stored.fin == fin


@pytest.mark.asyncio
async def test_pointage_en_cours_est_retrouvable(db, medecin):
    pointage = Pointage(
        clinic_id=1,
        utilisateur_id=medecin.id,
        debut=datetime(2026, 8, 19, 9, 0, 0),
    )
    db.add(pointage)
    await db.flush()

    result = await db.execute(
        select(Pointage).where(
            Pointage.utilisateur_id == medecin.id,
            Pointage.fin.is_(None),
        )
    )
    assert result.scalar_one().id == pointage.id
