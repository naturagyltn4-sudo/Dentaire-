from public_main import app


def test_public_gateway_mounts_only_public_surface():
    paths = set(app.openapi()["paths"])

    assert "/api/v1/settings/branding" in paths
    assert "/api/v1/public/praticiens" in paths
    assert "/api/v1/public/actes" in paths
    assert "/api/v1/public/reservation" in paths
    assert "/ready" in paths

    assert "/api/v1/patients" not in paths
    assert "/api/v1/admin/users" not in paths
    assert "/api/v1/factures" not in paths
    assert "/api/v1/radiologie" not in paths
