from datetime import datetime

import pytest
from fastapi import HTTPException
from sqlalchemy import select

from api.v1.ia_dentaire import ValidationRequest, valider_analyse_caries_route
from models.database import AnalyseCaries, AuditLogMedical, ImagerieRadio
from services.ia_dentaire import valider_analyse_caries


async def _create_analyse(db, patient, medecin):
    radio = ImagerieRadio(
        clinic_id=1,
        patient_id=patient.id,
        praticien_id=medecin.id,
        type_radio="panoramique",
        url_stockage="encrypted://radio-test",
        date_prise=datetime.utcnow(),
    )
    db.add(radio)
    await db.flush()
    analyse = AnalyseCaries(
        clinic_id=1,
        radio_id=radio.id,
        patient_id=patient.id,
        praticien_id=medecin.id,
        resultat={"zones_suspectes": []},
    )
    db.add(analyse)
    await db.flush()
    return analyse


@pytest.mark.asyncio
async def test_valider_analyse_caries_journalise_et_refuse_double_validation(
    db, patient, medecin
):
    analyse = await _create_analyse(db, patient, medecin)

    validated = await valider_analyse_caries(db, analyse.id, medecin.id)
    assert validated.valide_par_praticien_id == medecin.id
    assert validated.valide_at is not None

    logs = (
        await db.execute(
            select(AuditLogMedical).where(
                AuditLogMedical.action == "IA_VALIDATION_DETECTION_CARIES",
                AuditLogMedical.resource_id == analyse.id,
            )
        )
    ).scalars().all()
    assert len(logs) == 1
    assert logs[0].patient_id == patient.id

    with pytest.raises(ValueError, match="Analyse déjà validée"):
        await valider_analyse_caries(db, analyse.id, medecin.id)


@pytest.mark.asyncio
async def test_route_validation_refuse_un_praticien_different_de_l_utilisateur_connecte(
    db, patient, medecin
):
    analyse = await _create_analyse(db, patient, medecin)
    with pytest.raises(HTTPException) as exc_info:
        await valider_analyse_caries_route(
            analyse_id=analyse.id,
            body=ValidationRequest(praticien_id=medecin.id + 1000),
            db=db,
            current_user={"id": medecin.id},
        )
    assert exc_info.value.status_code == 403
