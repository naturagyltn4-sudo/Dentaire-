import pytest
from sqlalchemy import select

from middleware.auth import get_password_hash, verify_password
from models.database import RoleEnum, Utilisateur
from services.test_admin_bootstrap import reconcile_test_admin


@pytest.mark.asyncio
async def test_reconcile_creates_only_configured_test_admin(db):
    outcome = await reconcile_test_admin(
        db,
        email="recette-admin@example.test",
        nom="Recette",
        prenom="Direction",
        password="MotDePasseRecetteSolide123",
        clinic_id=1,
        reset_existing=True,
    )
    await db.commit()

    result = await db.execute(
        select(Utilisateur).where(Utilisateur.email == "recette-admin@example.test")
    )
    user = result.scalar_one()
    assert outcome == "created"
    assert user.is_active is True
    assert user.role == RoleEnum.DIRECTRICE.value
    assert verify_password("MotDePasseRecetteSolide123", user.hashed_password)


@pytest.mark.asyncio
async def test_reconcile_does_not_modify_existing_account_without_reset(db):
    existing = Utilisateur(
        clinic_id=1,
        email="recette-admin@example.test",
        hashed_password=get_password_hash("AncienMotDePasseSolide123"),
        nom="Avant",
        prenom="Compte",
        role=RoleEnum.ADMIN.value,
        is_active=False,
    )
    db.add(existing)
    await db.commit()

    outcome = await reconcile_test_admin(
        db,
        email="recette-admin@example.test",
        nom="Apres",
        prenom="Recette",
        password="NouveauMotDePasseSolide123",
        clinic_id=1,
        reset_existing=False,
    )
    await db.commit()
    await db.refresh(existing)

    assert outcome == "present"
    assert existing.is_active is False
    assert existing.role == RoleEnum.ADMIN.value
    assert verify_password("AncienMotDePasseSolide123", existing.hashed_password)


@pytest.mark.asyncio
async def test_reconcile_resets_only_configured_existing_account(db):
    target = Utilisateur(
        clinic_id=1,
        email="recette-admin@example.test",
        hashed_password=get_password_hash("AncienMotDePasseSolide123"),
        nom="Avant",
        prenom="Compte",
        role=RoleEnum.ADMIN.value,
        is_active=False,
    )
    untouched = Utilisateur(
        clinic_id=1,
        email="autre-compte@example.test",
        hashed_password=get_password_hash("AutreMotDePasseSolide123"),
        nom="Autre",
        prenom="Compte",
        role=RoleEnum.MEDECIN.value,
        is_active=True,
    )
    db.add_all([target, untouched])
    await db.commit()

    outcome = await reconcile_test_admin(
        db,
        email="recette-admin@example.test",
        nom="Recette",
        prenom="Direction",
        password="NouveauMotDePasseSolide123",
        clinic_id=1,
        reset_existing=True,
    )
    await db.commit()
    await db.refresh(target)
    await db.refresh(untouched)

    assert outcome == "reconciled"
    assert target.is_active is True
    assert target.role == RoleEnum.DIRECTRICE.value
    assert target.nom == "Recette"
    assert target.prenom == "Direction"
    assert verify_password("NouveauMotDePasseSolide123", target.hashed_password)
    assert untouched.role == RoleEnum.MEDECIN.value
    assert verify_password("AutreMotDePasseSolide123", untouched.hashed_password)


@pytest.mark.asyncio
async def test_reconcile_skips_when_access_configuration_is_incomplete(db):
    outcome = await reconcile_test_admin(
        db,
        email="",
        nom="Recette",
        prenom="Direction",
        password="",
        clinic_id=1,
        reset_existing=True,
    )
    assert outcome == "skipped"
