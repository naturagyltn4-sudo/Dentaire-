import pytest
from unittest.mock import AsyncMock, patch
from datetime import datetime
from sqlalchemy import select
from models.database import (
    PhotoClinic,
    TypePhoto,
    SuiviOrthodontique,
    PhaseOrtho,
    AppareilOrtho,
)
from services.simulation_morphing import generer_simulation_ia
from services.simulation_morphing import settings as simulation_settings


@pytest.mark.asyncio
async def test_simulation_ia_ortho_prompt(db, patient, praticien):
    """
    Vérifie que le prompt est adapté pour l'orthodontie.
    """
    # Mock OpenAI
    with patch("services.simulation_morphing.requests.post") as mock_post:
        mock_post.return_value.status_code = 200
        mock_post.return_value.json.return_value = {
            "data": [{"b64_json": "ZmFrZV9pbWFnZV9kYXRh"}]  # "fake_image_data" in b64
        }

        # Créer une photo source
        photo = PhotoClinic(
            clinic_id=1,
            patient_id=patient.id,
            type=TypePhoto.AVANT.value,
            date_prise=datetime.utcnow(),
            url_stockage="/tmp/test_photo.enc",
            zone_anatomique="Sourire et dents",
        )
        db.add(photo)
        await db.flush()

        # Créer un fichier bidon chiffré pour le test
        with open(photo.url_stockage, "wb") as f:
            f.write(b"012345678901" + b"encrypteddata")

        # Mock du déchiffrement pour éviter les erreurs de padding
        with (
            patch.object(
                simulation_settings,
                "openai_api_key",
                "test-only-openai-key",
            ),
            patch(
                "services.simulation_morphing._decrypt_file",
                return_value=b"fake_raw_photo",
            ),
            patch("services.simulation_morphing.PILImage.open") as mock_pil,
            patch(
                "services.simulation_morphing.verify_consent",
                return_value=AsyncMock(id=1, type_consentement="simulation_ia"),
            ),
        ):
            # On force le retour d'une image PIL mockée
            mock_pil.return_value.convert.return_value = mock_pil.return_value

            # Appel du service
            await generer_simulation_ia(
                patient_id=patient.id,
                photo_source_id=photo.id,
                zone="Sourire",
                intensite=50,
                genere_par_id=praticien.id,
                db=db,
            )

            # Vérifier que le prompt contient les mots clés ortho
            args, kwargs = mock_post.call_args
            prompt = kwargs["data"]["prompt"]
            assert "dental alignment" in prompt
            assert "teeth" in prompt
            assert "smile" in prompt


@pytest.mark.asyncio
async def test_suivi_ortho_reel_pas_ia(db, patient):
    """
    Vérifie que le suivi réel ne déclenche aucun appel IA.
    """
    # Créer une photo
    photo = PhotoClinic(
        clinic_id=1,
        patient_id=patient.id,
        type=TypePhoto.PROGRESSION.value,
        date_prise=datetime.utcnow(),
        url_stockage="/tmp/ortho_real.jpg",
    )
    db.add(photo)
    await db.flush()

    # Créer le suivi réel
    with patch("services.simulation_morphing.generer_simulation_ia") as mock_ia:
        suivi = SuiviOrthodontique(
            clinic_id=1,
            patient_id=patient.id,
            photo_reelle_id=photo.id,
            phase=PhaseOrtho.PENDANT.value,
            type_appareil=AppareilOrtho.ALIGNEURS.value,
            observations="Alignement en cours",
        )
        db.add(suivi)
        await db.flush()

        # Vérifier qu'aucune simulation IA n'a été appelée
        mock_ia.assert_not_called()

        # Vérifier en base
        result = await db.execute(
            select(SuiviOrthodontique).where(SuiviOrthodontique.id == suivi.id)
        )
        assert result.scalar_one_or_none() is not None
