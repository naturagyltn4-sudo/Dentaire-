"""Tests — Bloc 4 : Facturation Dentaire, Devis et Mutuelle"""

import pytest
from decimal import Decimal
from services.factures import create_facture, accepter_devis
from models.database import (
    DevisTraitement,
    PriseEnChargeMutuelle,
    StatutDevis,
    StatutPriseEnCharge,
)
from sqlalchemy import select


@pytest.mark.asyncio
async def test_devis_acceptation_facture(db, patient, acte, medecin):
    # 1. Créer un devis
    devis = DevisTraitement(
        clinic_id=1,
        patient_id=patient.id,
        acte_id=acte.id,
        dent="16",
        prix=Decimal("500.000"),
        statut=StatutDevis.BROUILLON.value,
    )
    db.add(devis)
    await db.flush()

    # 2. Accepter le devis -> doit générer une facture
    facture = await accepter_devis(devis_id=devis.id, created_by=medecin.id, db=db)

    assert facture.patient_id == patient.id
    assert facture.total_ttc > Decimal("500.000")  # Prix + TVA
    assert devis.statut == StatutDevis.ACCEPTE.value
    assert f"devis #{devis.id}" in facture.notes


@pytest.mark.asyncio
async def test_calcul_reste_patient_decimal(db, patient, medecin):
    # 1. Créer une facture de 1000 DT TTC
    facture_data = {
        "patient_id": patient.id,
        "actes": [{"nom": "Implant", "prix": Decimal("840.336"), "quantite": 1}],
        "taux_tva": Decimal("0.190"),  # 840.336 * 1.19 = 999.99984 -> 1000.000
        "remise_globale_pct": Decimal("0.00"),
    }
    facture = await create_facture(facture_data, created_by=medecin.id, db=db)
    await db.flush()

    # Vérifier total_ttc
    assert facture.total_ttc == Decimal("1000.000")

    # 2. Ajouter une prise en charge mutuelle de 650.500 DT
    pec = PriseEnChargeMutuelle(
        clinic_id=1,
        facture_id=facture.id,
        organisme="STAR Mutuelle",
        montant_pris_en_charge=Decimal("650.500"),
        statut=StatutPriseEnCharge.ACCEPTE.value,
    )
    db.add(pec)
    await db.flush()

    # 3. Calculer le reste patient
    # 1000.000 - 650.500 = 349.500
    res_pec = await db.execute(
        select(PriseEnChargeMutuelle).where(
            PriseEnChargeMutuelle.facture_id == facture.id
        )
    )
    pecs = res_pec.scalars().all()
    total_mutuelle = sum((p.montant_pris_en_charge for p in pecs), Decimal("0.000"))
    reste = facture.total_ttc - total_mutuelle

    assert reste == Decimal("349.500")
    assert isinstance(reste, Decimal)


@pytest.mark.asyncio
async def test_pec_devis_transfert_facture(db, patient, acte, medecin):
    # 1. Devis avec PEC
    devis = DevisTraitement(
        clinic_id=1,
        patient_id=patient.id,
        acte_id=acte.id,
        prix=Decimal("100.000"),
        statut=StatutDevis.BROUILLON.value,
    )
    db.add(devis)
    await db.flush()

    pec = PriseEnChargeMutuelle(
        clinic_id=1,
        devis_id=devis.id,
        organisme="Mutuelle A",
        montant_pris_en_charge=Decimal("40.000"),
        statut=StatutPriseEnCharge.ACCEPTE.value,
    )
    db.add(pec)
    await db.flush()

    # 2. Accepter devis
    facture = await accepter_devis(devis_id=devis.id, created_by=medecin.id, db=db)

    # 3. La PEC doit être liée à la facture
    res_pec = await db.execute(
        select(PriseEnChargeMutuelle).where(
            PriseEnChargeMutuelle.facture_id == facture.id
        )
    )
    pec_liee = res_pec.scalar_one()
    assert pec_liee.montant_pris_en_charge == Decimal("40.000")
    assert pec_liee.organisme == "Mutuelle A"
