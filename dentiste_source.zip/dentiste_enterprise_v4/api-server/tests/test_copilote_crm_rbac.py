"""Régressions RBAC — routes Copilote CRM."""

import pytest
from fastapi import HTTPException

from api.v1.copilote_crm import CRM_ACCESS


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["directrice", "medecin", "estheticienne", "admin"])
async def test_copilote_access_allows_clinical_roles(role):
    user = {"id": 1, "clinic_id": 1, "role": role}
    assert await CRM_ACCESS.dependency(current_user=user) == user


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["assistante", "commercial"])
async def test_copilote_access_rejects_roles_without_medical_scope(role):
    with pytest.raises(HTTPException) as exc:
        await CRM_ACCESS.dependency(current_user={"id": 2, "clinic_id": 1, "role": role})
    assert exc.value.status_code == 403
