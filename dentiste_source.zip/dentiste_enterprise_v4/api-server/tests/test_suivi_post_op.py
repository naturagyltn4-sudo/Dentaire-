import pytest
from datetime import datetime, timedelta
from sqlalchemy import select
from models.database import (
    ActeMedical,
    RendezVous,
    StatutRDV,
    SuiviPostOperatoire,
    StatutSuiviPostOp,
)
from services.suivi_post_op import trigger_suivi_post_op


@pytest.mark.asyncio
async def test_cloture_acte_chirurgical_creation_suivi(db, patient, praticien):
    """
    Teste la clôture d'un acte chirurgical et la création automatique du suivi.
    """
    # 1. Créer un acte chirurgical
    acte = ActeMedical(
        clinic_id=1,
        nom="Implants Dentaires",
        categorie="Chirurgie",
        is_chirurgical=True,
        prix_base=1500.0,
    )
    db.add(acte)
    await db.flush()

    # 2. Créer un RDV pour cet acte
    rdv = RendezVous(
        clinic_id=1,
        patient_id=patient.id,
        praticien_id=praticien.id,
        acte_id=acte.id,
        date_heure_debut=datetime.utcnow(),
        statut=StatutRDV.PLANIFIE.value,
    )
    db.add(rdv)
    await db.flush()

    # 3. Clôturer l'acte (trigger manuel du service pour le test)
    # Dans l'API, c'est déclenché par le PATCH /statut
    await trigger_suivi_post_op(rdv.id, db, delay_days=7)
    await db.flush()

    # 4. Vérifier la création du suivi
    result = await db.execute(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.rdv_id == rdv.id
            if hasattr(SuiviPostOperatoire, "rdv_id")
            else SuiviPostOperatoire.patient_id == patient.id
        )
    )
    # Note: J'ai pas ajouté rdv_id au modèle SuiviPostOperatoire mais j'aurais pu.
    # Le sujet demandait acte, patient, praticien etc.
    result = await db.execute(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.patient_id == patient.id,
            SuiviPostOperatoire.acte_id == acte.id,
        )
    )
    suivi = result.scalar_one_or_none()

    assert suivi is not None
    assert suivi.statut == StatutSuiviPostOp.PLANIFIE.value
    assert suivi.praticien_id == praticien.id

    # 5. Vérifier la date (J+7)
    expected_date = (datetime.utcnow() + timedelta(days=7)).date()
    assert suivi.date_controle_prevue.date() == expected_date


@pytest.mark.asyncio
async def test_absence_doublon_suivi(db, patient, praticien):
    """
    Vérifie qu'on ne crée pas de doublon si on trigger deux fois.
    """
    acte = ActeMedical(
        clinic_id=1,
        nom="Extraction Sagesse",
        categorie="Chirurgie",
        is_chirurgical=True,
    )
    db.add(acte)
    await db.flush()

    rdv = RendezVous(
        clinic_id=1,
        patient_id=patient.id,
        praticien_id=praticien.id,
        acte_id=acte.id,
        date_heure_debut=datetime.utcnow(),
        statut=StatutRDV.PLANIFIE.value,
    )
    db.add(rdv)
    await db.flush()

    # Trigger deux fois
    await trigger_suivi_post_op(rdv.id, db, delay_days=7)
    await trigger_suivi_post_op(rdv.id, db, delay_days=7)
    await db.flush()

    # Vérifier qu'il n'y a qu'un seul suivi
    result = await db.execute(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.patient_id == patient.id,
            SuiviPostOperatoire.acte_id == acte.id,
        )
    )
    suivis = result.scalars().all()
    assert len(suivis) == 1


@pytest.mark.asyncio
async def test_non_chirurgical_pas_de_suivi(db, patient, praticien):
    """
    Vérifie qu'un acte non chirurgical ne crée pas de suivi.
    """
    acte = ActeMedical(
        clinic_id=1,
        nom="Détartrage simple",
        categorie="Hygiène",
        is_chirurgical=False,
    )
    db.add(acte)
    await db.flush()

    rdv = RendezVous(
        clinic_id=1,
        patient_id=patient.id,
        praticien_id=praticien.id,
        acte_id=acte.id,
        date_heure_debut=datetime.utcnow(),
        statut=StatutRDV.PLANIFIE.value,
    )
    db.add(rdv)
    await db.flush()

    await trigger_suivi_post_op(rdv.id, db, delay_days=7)
    await db.flush()

    result = await db.execute(
        select(SuiviPostOperatoire).where(
            SuiviPostOperatoire.patient_id == patient.id,
            SuiviPostOperatoire.acte_id == acte.id,
        )
    )
    suivi = result.scalar_one_or_none()
    assert suivi is None
