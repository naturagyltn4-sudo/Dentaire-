"""
Tests unitaires pour les constantes dentaires (BLOC 0)
"""

import pytest
from models.dental_constants import NotationDentaire


class TestNotationDentaire:
    """Tests pour l'Enum NotationDentaire."""

    def test_import_reussi(self):
        """Vérifier que l'import est réussi."""
        assert NotationDentaire is not None
        assert hasattr(NotationDentaire, "DENT_11")

    def test_exactement_32_valeurs(self):
        """Vérifier qu'il y a exactement 32 dents."""
        membres = list(NotationDentaire)
        assert len(membres) == 32, f"Attendu 32 dents, trouvé {len(membres)}"

    def test_valeurs_fdi_correctes(self):
        """Vérifier que les valeurs FDI sont correctes (11-48)."""
        fdi_values = [member.value for member in NotationDentaire]

        # Vérifier que toutes les valeurs sont des chaînes de 2 chiffres
        for value in fdi_values:
            assert isinstance(value, str), f"La valeur {value} n'est pas une chaîne"
            assert len(value) == 2, f"La valeur {value} n'a pas 2 caractères"
            assert value.isdigit(), f"La valeur {value} n'est pas numérique"

        # Vérifier la plage FDI
        expected_fdi = [
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",  # Quadrant 1
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",  # Quadrant 2
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",  # Quadrant 3
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",  # Quadrant 4
        ]

        assert sorted(fdi_values) == sorted(expected_fdi), (
            "Les valeurs FDI ne correspondent pas"
        )

    def test_get_all_fdi_numbers(self):
        """Tester la méthode get_all_fdi_numbers()."""
        fdi_numbers = NotationDentaire.get_all_fdi_numbers()
        assert len(fdi_numbers) == 32
        assert "11" in fdi_numbers
        assert "48" in fdi_numbers

    def test_get_quadrant(self):
        """Tester la méthode get_quadrant()."""
        # Quadrant 1 (maxillaire droit)
        assert NotationDentaire.get_quadrant("11") == 1
        assert NotationDentaire.get_quadrant("18") == 1

        # Quadrant 2 (maxillaire gauche)
        assert NotationDentaire.get_quadrant("21") == 2
        assert NotationDentaire.get_quadrant("28") == 2

        # Quadrant 3 (mandibulaire gauche)
        assert NotationDentaire.get_quadrant("31") == 3
        assert NotationDentaire.get_quadrant("38") == 3

        # Quadrant 4 (mandibulaire droit)
        assert NotationDentaire.get_quadrant("41") == 4
        assert NotationDentaire.get_quadrant("48") == 4

    def test_get_quadrant_invalide(self):
        """Tester get_quadrant() avec un numéro invalide."""
        with pytest.raises(ValueError, match="Numéro FDI invalide"):
            NotationDentaire.get_quadrant("99")

    def test_get_position_in_quadrant(self):
        """Tester la méthode get_position_in_quadrant()."""
        assert NotationDentaire.get_position_in_quadrant("11") == 1
        assert NotationDentaire.get_position_in_quadrant("18") == 8
        assert NotationDentaire.get_position_in_quadrant("25") == 5
        assert NotationDentaire.get_position_in_quadrant("48") == 8

    def test_get_position_in_quadrant_invalide(self):
        """Tester get_position_in_quadrant() avec un numéro invalide."""
        with pytest.raises(ValueError, match="Numéro FDI invalide"):
            NotationDentaire.get_position_in_quadrant("99")

    def test_enum_values_are_strings(self):
        """Vérifier que tous les membres de l'Enum sont des chaînes."""
        for member in NotationDentaire:
            assert isinstance(member.value, str)
            assert isinstance(member, NotationDentaire)

    def test_enum_members_accessible_by_name(self):
        """Vérifier que les membres sont accessibles par nom."""
        assert NotationDentaire.DENT_11.value == "11"
        assert NotationDentaire.DENT_48.value == "48"
        assert NotationDentaire.DENT_25.value == "25"
