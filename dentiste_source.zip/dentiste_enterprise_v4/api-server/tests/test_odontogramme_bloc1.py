"""
Tests unitaires pour l'API odontogramme (BLOC 1)
"""

import pytest
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession

from models.database import (
    EtatDentaire,
    HistoriqueDentaire,
    StatutDent,
    Patient,
    Utilisateur,
    RoleEnum,
    AuditLogMedical,
)
from models.dental_constants import NotationDentaire


@pytest.fixture
async def test_patient(db: AsyncSession):
    """Créer un patient de test."""
    patient = Patient(
        clinic_id=1,
        nom="Dupont",
        prenom="Jean",
        telephone="+216123456789",
        is_active=True,
    )
    db.add(patient)
    await db.commit()
    await db.refresh(patient)
    return patient


@pytest.fixture
async def test_praticien(db: AsyncSession):
    """Créer un praticien de test."""
    from passlib.context import CryptContext

    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    praticien = Utilisateur(
        clinic_id=1,
        email="praticien@clinic.local",
        hashed_password=pwd_context.hash("password123"),
        nom="Martin",
        prenom="Dr",
        role=RoleEnum.MEDECIN,
        is_active=True,
    )
    db.add(praticien)
    await db.commit()
    await db.refresh(praticien)
    return praticien


class TestEtatDentaire:
    """Tests pour le modèle EtatDentaire."""

    @pytest.mark.asyncio
    async def test_create_etat_dentaire(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Tester la création d'un état dentaire."""
        etat = EtatDentaire(
            clinic_id=1,
            patient_id=test_patient.id,
            numero_dent="11",
            statut=StatutDent.SAIN.value,
            praticien_id=test_praticien.id,
            notes="Dent saine",
            date_modification=datetime.utcnow(),
        )
        db.add(etat)
        await db.commit()
        await db.refresh(etat)

        assert etat.id is not None
        assert etat.numero_dent == "11"
        assert etat.statut == StatutDent.SAIN.value
        assert etat.patient_id == test_patient.id

    @pytest.mark.asyncio
    async def test_etat_dentaire_unique_constraint(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Tester que les doublons sont gérés correctement."""
        # Créer le premier état
        etat1 = EtatDentaire(
            clinic_id=1,
            patient_id=test_patient.id,
            numero_dent="11",
            statut=StatutDent.SAIN.value,
            praticien_id=test_praticien.id,
            date_modification=datetime.utcnow(),
        )
        db.add(etat1)
        await db.commit()
        await db.refresh(etat1)

        # Vérifier que le premier état existe
        assert etat1.id is not None
        assert etat1.numero_dent == "11"

    @pytest.mark.asyncio
    async def test_etat_dentaire_all_statuts(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Tester tous les statuts possibles."""
        statuts = [s.value for s in StatutDent]
        assert len(statuts) == 10

        for i, statut in enumerate(statuts):
            numero_dent = (
                f"{1 + (i // 8)}{1 + (i % 8)}"  # Générer des numéros FDI valides
            )
            etat = EtatDentaire(
                clinic_id=1,
                patient_id=test_patient.id,
                numero_dent=numero_dent,
                statut=statut,
                praticien_id=test_praticien.id,
                date_modification=datetime.utcnow(),
            )
            db.add(etat)

        await db.commit()

        # Vérifier que tous les statuts ont été créés
        from sqlalchemy import select

        stmt = select(EtatDentaire).where(EtatDentaire.patient_id == test_patient.id)
        etats = await db.scalars(stmt)
        etats_list = list(etats)
        assert len(etats_list) == 10


class TestHistoriqueDentaire:
    """Tests pour le modèle HistoriqueDentaire."""

    @pytest.mark.asyncio
    async def test_create_historique_dentaire(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Tester la création d'un événement historique."""
        # Créer d'abord un état dentaire
        etat = EtatDentaire(
            clinic_id=1,
            patient_id=test_patient.id,
            numero_dent="11",
            statut=StatutDent.SAIN.value,
            praticien_id=test_praticien.id,
            date_modification=datetime.utcnow(),
        )
        db.add(etat)
        await db.commit()
        await db.refresh(etat)

        # Créer un événement historique
        historique = HistoriqueDentaire(
            clinic_id=1,
            etat_dentaire_id=etat.id,
            patient_id=test_patient.id,
            numero_dent="11",
            statut_ancien=None,
            statut_nouveau=StatutDent.SAIN.value,
            praticien_id=test_praticien.id,
            notes="Création initiale",
        )
        db.add(historique)
        await db.commit()
        await db.refresh(historique)

        assert historique.id is not None
        assert historique.etat_dentaire_id == etat.id
        assert historique.statut_ancien is None
        assert historique.statut_nouveau == StatutDent.SAIN.value

    @pytest.mark.asyncio
    async def test_historique_append_only(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Tester que l'historique est append-only."""
        # Créer un état dentaire
        etat = EtatDentaire(
            clinic_id=1,
            patient_id=test_patient.id,
            numero_dent="11",
            statut=StatutDent.SAIN.value,
            praticien_id=test_praticien.id,
            date_modification=datetime.utcnow(),
        )
        db.add(etat)
        await db.commit()
        await db.refresh(etat)

        # Créer plusieurs événements historiques
        for i, nouveau_statut in enumerate(
            [StatutDent.CARIE.value, StatutDent.OBTURE.value]
        ):
            ancien_statut = StatutDent.SAIN.value if i == 0 else StatutDent.CARIE.value
            historique = HistoriqueDentaire(
                clinic_id=1,
                etat_dentaire_id=etat.id,
                patient_id=test_patient.id,
                numero_dent="11",
                statut_ancien=ancien_statut,
                statut_nouveau=nouveau_statut,
                praticien_id=test_praticien.id,
            )
            db.add(historique)

        await db.commit()

        # Vérifier que tous les événements ont été créés
        from sqlalchemy import select

        stmt = (
            select(HistoriqueDentaire)
            .where(HistoriqueDentaire.etat_dentaire_id == etat.id)
            .order_by(HistoriqueDentaire.created_at.asc())
        )
        historiques = await db.scalars(stmt)
        historiques_list = list(historiques)
        assert len(historiques_list) == 2


class TestNotationDentaire:
    """Tests pour la notation FDI."""

    def test_fdi_32_dents(self):
        """Tester qu'il y a 32 dents FDI."""
        fdi_numbers = NotationDentaire.get_all_fdi_numbers()
        assert len(fdi_numbers) == 32

    def test_fdi_quadrants(self):
        """Tester les quadrants FDI."""
        assert NotationDentaire.get_quadrant("11") == 1  # Maxillaire droit
        assert NotationDentaire.get_quadrant("21") == 2  # Maxillaire gauche
        assert NotationDentaire.get_quadrant("31") == 3  # Mandibulaire gauche
        assert NotationDentaire.get_quadrant("41") == 4  # Mandibulaire droit

    def test_fdi_position(self):
        """Tester la position dans le quadrant."""
        assert NotationDentaire.get_position_in_quadrant("11") == 1
        assert NotationDentaire.get_position_in_quadrant("18") == 8
        assert NotationDentaire.get_position_in_quadrant("48") == 8


class TestAuditLogMedical:
    """Tests pour l'audit médical."""

    @pytest.mark.asyncio
    async def test_audit_log_creation(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Tester la création d'un log d'audit."""
        audit_log = AuditLogMedical(
            clinic_id=1,
            utilisateur_id=test_praticien.id,
            patient_id=test_patient.id,
            action="UPDATE_DENT",
            resource_type="etat_dentaire",
            resource_id=1,
            ip_address="127.0.0.1",
            user_agent="Test Agent",
            details={"numero_dent": "11", "statut_nouveau": "carie"},
        )
        db.add(audit_log)
        await db.commit()
        await db.refresh(audit_log)

        assert audit_log.id is not None
        assert audit_log.action == "UPDATE_DENT"
        assert audit_log.resource_type == "etat_dentaire"


class TestOdontogrammeRouteAudit:
    """Régressions de tenant pour l'audit déclenché par les lectures."""

    @pytest.mark.asyncio
    async def test_get_odontogramme_audits_with_current_clinic(
        self, db: AsyncSession, test_patient, test_praticien
    ):
        """Une lecture ne doit jamais échouer faute de tenant dans le journal médical."""
        from sqlalchemy import select
        from starlette.requests import Request
        from api.v1.odontogramme import get_odontogramme

        request = Request(
            {
                "type": "http",
                "method": "GET",
                "path": f"/patients/{test_patient.id}/odontogramme",
                "headers": [],
                "client": ("127.0.0.1", 0),
                "scheme": "http",
                "server": ("testserver", 80),
            }
        )
        response = await get_odontogramme(
            patient_id=test_patient.id,
            request=request,
            db=db,
            current_user={"id": test_praticien.id, "clinic_id": 1},
        )
        await db.commit()

        audit_log = await db.scalar(
            select(AuditLogMedical).where(
                AuditLogMedical.patient_id == test_patient.id,
                AuditLogMedical.action == "READ_ODONTOGRAMME",
            )
        )
        assert response.patient_id == test_patient.id
        assert audit_log is not None
        assert audit_log.clinic_id == 1
