"""Régressions tenant pour les routes Consommables."""

from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from api.v1.consommables import (
    ConsommableCreate,
    MouvementCreate,
    add_mouvement,
    create_consommable,
    get_alertes,
    list_consommables,
)
from services.consommables import ConsommableService


@pytest.fixture
def directrice():
    return {"id": 42, "role": "directrice", "clinic_id": 7}


@pytest.mark.asyncio
async def test_list_consommables_forwards_authenticated_clinic(monkeypatch, directrice):
    service = AsyncMock(return_value=[])
    monkeypatch.setattr(ConsommableService, "get_all", service)

    db = object()
    response = await list_consommables(db=db, current_user=directrice)

    assert response == []
    service.assert_awaited_once_with(db, 7)


@pytest.mark.asyncio
async def test_create_consommable_forwards_authenticated_clinic(monkeypatch, directrice):
    service = AsyncMock()
    monkeypatch.setattr(ConsommableService, "create", service)
    data = ConsommableCreate(
        nom="Gants QA", categorie="protection", unite="boîte", stock_actuel=Decimal("5")
    )

    await create_consommable(data=data, db=object(), current_user=directrice)

    assert service.await_args.args[2] == 7


@pytest.mark.asyncio
async def test_mouvement_forwards_authenticated_clinic(monkeypatch, directrice):
    service = AsyncMock(return_value=SimpleNamespace(id=99))
    monkeypatch.setattr(ConsommableService, "add_mouvement", service)

    response = await add_mouvement(
        consommable_id=9,
        data=MouvementCreate(type="entree", quantite=2, motif="Réception QA"),
        db=object(),
        current_user=directrice,
    )

    assert response["status"] == "success"
    assert service.await_args.args[-1] == 7


@pytest.mark.asyncio
async def test_alertes_forwards_authenticated_clinic(monkeypatch, directrice):
    service = AsyncMock(return_value=[])
    monkeypatch.setattr(ConsommableService, "get_alertes", service)

    db = object()
    response = await get_alertes(db=db, current_user=directrice)

    assert response == []
    service.assert_awaited_once_with(db, 7)
