import pytest

from core.agent_runtime import AgentRuntime, ToolDef, ToolRegistry
from core.llm_client import LLMResponse


class FakeLLM:
    def __init__(self):
        self.calls = 0

    async def chat(self, messages, **kwargs):
        self.calls += 1
        if self.calls == 1:
            return LLMResponse(
                text='{"thought":"Je cherche le patient.","action":"lookup","args":{"patient_id":7}}',
                provider="fake",
                model="fake-model",
            )
        return LLMResponse(
            text='{"thought":"Recherche terminée.","action":"finish","args":{},"final_answer":"Patient trouvé"}',
            provider="fake",
            model="fake-model",
        )


@pytest.mark.asyncio
async def test_agent_runtime_registry_prompt_selection_validation_and_execution():
    calls = []

    async def lookup(patient_id: int):
        calls.append(patient_id)
        return {"patient_id": patient_id, "found": True}

    registry = ToolRegistry()
    registry.register(
        ToolDef(
            name="lookup",
            description="Recherche un patient par identifiant.",
            schema={
                "type": "object",
                "properties": {"patient_id": {"type": "integer"}},
                "required": ["patient_id"],
            },
            func=lookup,
            permission="patient.read",
            resource="patient",
        )
    )
    runtime = AgentRuntime(FakeLLM(), registry, max_steps=3)

    prompt = runtime._system_prompt({"clinic_id": 1})
    result = await runtime.run("Trouve le patient 7")

    assert "lookup" in prompt
    assert "Recherche un patient" in prompt
    assert result.success is True
    assert result.final_answer == "Patient trouvé"
    assert calls == [7]
    assert len(result.steps) == 2
    assert result.steps[0].observation is not None
