"""Tests — Bloc 5 : Radiologie et Imagerie (DICOM, Chiffrement, RBAC)"""

import pytest
from services.radiologie import upload_radio, get_decrypted_radio


@pytest.mark.asyncio
async def test_upload_radio_chiffrement_dicom(db, medecin, patient):
    # 1. Simuler un fichier DICOM (minimal)
    # Note: On utilise un contenu bidon car pydicom va échouer à lire mais le service doit gérer
    fake_dicom = b"DICM" + b"\x00" * 128 + b"FAKE-DATA"

    # 2. Upload
    radio = await upload_radio(
        patient_id=patient.id,
        praticien_id=medecin.id,
        type_radio="panoramique",
        file_bytes=fake_dicom,
        dent_associee="16",
        db=db,
    )

    assert radio.id is not None
    assert radio.type_radio == "panoramique"
    assert radio.dent_associee == "16"
    assert radio.url_stockage.endswith(".enc")

    # 3. Vérifier que le fichier sur disque est chiffré (pas le contenu original en clair)
    with open(radio.url_stockage, "rb") as f:
        encrypted_content = f.read()
    assert fake_dicom not in encrypted_content

    # 4. Déchiffrement
    decrypted_bytes, radio_info = await get_decrypted_radio(radio.id, medecin.id, db)
    assert decrypted_bytes == fake_dicom
    assert radio_info.id == radio.id


@pytest.mark.asyncio
async def test_radiologie_rbac_access(db, medecin, assistante, patient):
    # Créer une radio via service
    radio = await upload_radio(
        patient_id=patient.id,
        praticien_id=medecin.id,
        type_radio="retro-alveolaire",
        file_bytes=b"FAKE-RADIO-DATA",
        db=db,
    )

    # Test via API (simulé par les dépendances de rôles)
    # Normalement on testerait avec `client` et les tokens,
    # mais ici on valide la logique de service et l'existence du routeur.

    # Vérifier que le médecin peut déchiffrer
    data, _ = await get_decrypted_radio(radio.id, medecin.id, db)
    assert data == b"FAKE-RADIO-DATA"

    # L'assistante peut lister (RBAC check dans le routeur normalement)
    from services.radiologie import list_radios

    radios = await list_radios(patient.id, db)
    assert len(radios) > 0


@pytest.mark.asyncio
async def test_upload_radio_invalid_type(db, medecin, patient):
    with pytest.raises(ValueError, match="non autorisé"):
        await upload_radio(
            patient_id=patient.id,
            praticien_id=medecin.id,
            type_radio="photo_vacances",
            file_bytes=b"DATA",
            db=db,
        )
