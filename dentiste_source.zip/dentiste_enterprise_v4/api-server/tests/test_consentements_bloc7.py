"""
Tests unitaires — BLOC 7 : Consentements dentaires
"""

import pytest
from services.consentement import sign_consent, verify_consent
from models.database import Consentement


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "type_consentement",
    [
        "consentement_extraction",
        "consentement_implant",
        "consentement_orthodontie",
        "consentement_anesthesie",
    ],
)
async def test_creation_signature_lecture_consentement_dentaire(
    db, patient, tmp_path, monkeypatch, type_consentement
):
    from config import get_settings

    settings = get_settings()
    monkeypatch.setattr(settings, "data_dir", tmp_path)

    # 1. Signer / Créer le consentement
    consentement = await sign_consent(
        patient_id=patient.id,
        acte_id=None,
        signature_b64="data:image/png;base64,iVBORw0KGgo=",
        method="tactile",
        ip_address="127.0.0.1",
        db=db,
        type_consentement=type_consentement,
    )

    assert consentement.id is not None
    assert consentement.type_consentement == type_consentement
    assert consentement.est_valide is True
    assert consentement.signature_base64 is not None

    # 2. Lecture / Vérification du consentement
    verif = await verify_consent(
        patient_id=patient.id,
        acte_id=None,
        db=db,
        type_consentement=type_consentement,
    )
    assert verif is not False
    assert isinstance(verif, Consentement)
    assert verif.type_consentement == type_consentement
    assert verif.est_valide is True
