"""Tests — middleware/clinic_context.py

Documente le comportement actuel (mono-clinique assumé) : la valeur
par défaut est toujours 1, et set_clinic_id permet de la changer
dans le contexte courant si un jour le multi-tenant est activé.
"""

from types import SimpleNamespace

import pytest

import middleware.clinic_context as clinic_context
from middleware.clinic_context import get_current_clinic_id, set_clinic_id


def test_default_clinic_id_is_1():
    assert get_current_clinic_id() == 1


def test_set_clinic_id_changes_current_context():
    set_clinic_id(7)
    try:
        assert get_current_clinic_id() == 7
    finally:
        set_clinic_id(1)  # reset pour ne pas polluer les autres tests


def test_production_instance_rejects_cross_clinic_context(monkeypatch):
    monkeypatch.setattr(
        clinic_context,
        "get_settings",
        lambda: SimpleNamespace(env="production", instance_clinic_id=1),
    )
    with pytest.raises(ValueError, match="ne peut pas changer"):
        clinic_context.set_clinic_id(2)
