"""Tests — config.py (_validate_production_secrets)

Vérifie le garde-fou qui empêche de démarrer en production avec des
secrets par défaut ou absents.
"""

import pytest
from cryptography.fernet import Fernet

from config import Settings, _validate_production_secrets, DEFAULT_SECRET_KEY


VALID_FERNET_KEY = Fernet.generate_key().decode()
VALID_PHOTO_KEY = Fernet.generate_key().decode()


def _settings(**overrides):
    base = dict(
        env="production",
        secret_key="une-cle-suffisamment-longue-et-aleatoire-1234567890",
        fernet_key=VALID_FERNET_KEY,
        photo_encryption_key=VALID_PHOTO_KEY,
        backup_encryption_key="YmFja3VwLWtleS1kZS10ZXN0LTMyLWJ5dGVzLW9r",
        database_url="postgresql+asyncpg://real_user:real_pass@db.clinic.tn:5432/clinic",
        cors_origins="https://app.clinic.tn",
        dental_domain="app.clinic.tn",
    )
    base.update(overrides)
    return Settings(**base)


def test_valid_production_config_passes():
    _validate_production_secrets(_settings())  # ne doit pas lever


def test_default_secret_key_rejected_in_production():
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        _validate_production_secrets(_settings(secret_key=DEFAULT_SECRET_KEY))


def test_short_secret_key_rejected_in_production():
    with pytest.raises(RuntimeError, match="SECRET_KEY"):
        _validate_production_secrets(_settings(secret_key="trop-court"))


def test_missing_fernet_key_rejected_in_production():
    with pytest.raises(RuntimeError, match="FERNET_KEY"):
        _validate_production_secrets(_settings(fernet_key=""))


def test_missing_photo_encryption_key_rejected_in_production():
    with pytest.raises(RuntimeError, match="PHOTO_ENCRYPTION_KEY"):
        _validate_production_secrets(_settings(photo_encryption_key=""))


def test_missing_backup_encryption_key_rejected_in_production():
    with pytest.raises(RuntimeError, match="BACKUP_ENCRYPTION_KEY"):
        _validate_production_secrets(_settings(backup_encryption_key=""))


def test_backup_encryption_key_must_be_independent():
    with pytest.raises(RuntimeError, match="BACKUP_ENCRYPTION_KEY"):
        _validate_production_secrets(
            _settings(backup_encryption_key="une-cle-suffisamment-longue-et-aleatoire-1234567890")
        )


def test_photo_encryption_key_same_as_fernet_key_rejected():
    with pytest.raises(RuntimeError, match="PHOTO_ENCRYPTION_KEY"):
        _validate_production_secrets(
            _settings(photo_encryption_key=VALID_FERNET_KEY)
        )


def test_default_database_credentials_rejected_in_production():
    with pytest.raises(RuntimeError, match="DATABASE_URL"):
        _validate_production_secrets(
            _settings(
                database_url="postgresql+asyncpg://clinic_admin:changeme@localhost:5432/autocommerce_clinic"
            )
        )


def test_unknown_setting_is_rejected():
    with pytest.raises(Exception):
        Settings(REDIS_PASWORD="typo")


def test_development_env_skips_validation():
    """En dev/test, on ne bloque jamais — sinon on casse le développement local."""
    _validate_production_secrets(
        _settings(env="development", secret_key=DEFAULT_SECRET_KEY, fernet_key="")
    )


def test_all_errors_reported_together():
    with pytest.raises(RuntimeError) as exc:
        _validate_production_secrets(
            _settings(secret_key=DEFAULT_SECRET_KEY, fernet_key="")
        )
    assert "SECRET_KEY" in str(exc.value)
    assert "FERNET_KEY" in str(exc.value)


def test_invalid_fernet_key_rejected_in_production():
    with pytest.raises(RuntimeError, match="FERNET_KEY"):
        _validate_production_secrets(_settings(fernet_key="not-a-fernet-key"))


def test_missing_dental_domain_rejected_in_production():
    with pytest.raises(RuntimeError, match="DENTAL_DOMAIN"):
        _validate_production_secrets(_settings(dental_domain=""))


def test_non_https_cors_rejected_in_production():
    with pytest.raises(RuntimeError, match="CORS_ORIGINS"):
        _validate_production_secrets(_settings(cors_origins="http://app.clinic.tn"))


def test_teleconsultation_enabled_requires_daily_in_production():
    with pytest.raises(RuntimeError, match="TELECONSULTATION_ENABLED"):
        _validate_production_secrets(
            _settings(teleconsultation_enabled=True, daily_api_key="")
        )


def test_practitioner_agent_requires_complete_whatsapp_configuration():
    with pytest.raises(RuntimeError, match="PRACTITIONER_AGENT_ENABLED"):
        _validate_production_secrets(
            _settings(
                practitioner_agent_enabled=True,
                teleconsultation_enabled=True,
                wa_business_token_praticien="token",
                wa_phone_id_praticien="phone",
                wa_webhook_verify_token_praticien="",
                daily_api_key="daily",
            )
        )


def test_partial_practitioner_whatsapp_configuration_rejected():
    with pytest.raises(RuntimeError, match="trois variables"):
        _validate_production_secrets(
            _settings(wa_phone_id_praticien="phone")
        )
