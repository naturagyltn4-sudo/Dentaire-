"""Preuves d'isolation multi-clinique sur PostgreSQL réel.

Lancer avec POSTGRES_TEST_DATABASE_URL='postgresql+asyncpg://...'.
La suite est volontairement ignorée si aucune base PostgreSQL de test n'est fournie ;
un résultat Enterprise ne doit jamais confondre SQLite et PostgreSQL de production.
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta
from decimal import Decimal

import pytest
import pytest_asyncio
from sqlalchemy import select
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

from models.database import (
    ActeMedical,
    Base,
    Facture,
    Patient,
    PlanTraitementIA,
    RappelDentaire,
    RendezVous,
    RoleEnum,
    EstimationCoutPlan,
    SuiviPostOperatoire,
    StatutFacture,
    Utilisateur,
)
from models.omnicanal import Conversation, MessageOmnicanal, StatutMessageEnum
from services.agenda import creer_rdv
from services.cout_plan import estimer_cout_plan
from services.rappels_dentaires import generer_rappel_suivi
from services.factures import (
    annuler_facture,
    create_facture,
    list_factures,
    marquer_payee,
)
from services.fidelite import add_points, get_historique, get_overview
from services.omnicanal_service import (
    close_conversation,
    get_conversation_messages,
    list_conversations,
    retry_failed_message,
    send_reply,
)


PG_URL = os.getenv("POSTGRES_TEST_DATABASE_URL")
pytestmark = [
    pytest.mark.asyncio,
    pytest.mark.skipif(
        not PG_URL,
        reason="POSTGRES_TEST_DATABASE_URL absent: preuve PostgreSQL non exécutée",
    ),
]


@pytest_asyncio.fixture(scope="module")
async def pg_engine():
    assert PG_URL
    engine = create_async_engine(PG_URL, pool_pre_ping=True)
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    yield engine
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.drop_all)
    await engine.dispose()


@pytest_asyncio.fixture
async def pg_db(pg_engine):
    session_factory = async_sessionmaker(pg_engine, expire_on_commit=False)
    async with session_factory() as session:
        transaction = await session.begin()
        try:
            yield session
        finally:
            await transaction.rollback()


async def _seed_two_clinics(db):
    users = [
        Utilisateur(
            clinic_id=101,
            email="a-owner@example.invalid",
            hashed_password="test-hash-a",
            nom="A",
            prenom="Owner",
            role=RoleEnum.DIRECTRICE.value,
        ),
        Utilisateur(
            clinic_id=202,
            email="b-owner@example.invalid",
            hashed_password="test-hash-b",
            nom="B",
            prenom="Owner",
            role=RoleEnum.DIRECTRICE.value,
        ),
    ]
    patients = [
        Patient(
            clinic_id=101,
            nom="PatientA",
            prenom="Tenant",
            telephone="+21670000101",
            whatsapp_phone="+21670000101",
        ),
        Patient(
            clinic_id=202,
            nom="PatientB",
            prenom="Tenant",
            telephone="+21670000202",
            whatsapp_phone="+21670000202",
        ),
    ]
    actes = [
        ActeMedical(
            clinic_id=101,
            nom="Acte A",
            categorie="soin",
            duree_minutes=30,
            prix_base=Decimal("100.000"),
        ),
        ActeMedical(
            clinic_id=202,
            nom="Acte B",
            categorie="soin",
            duree_minutes=30,
            prix_base=Decimal("200.000"),
        ),
    ]
    db.add_all([*users, *patients, *actes])
    await db.flush()
    return users, patients, actes


async def test_postgres_facture_reads_and_mutations_are_tenant_scoped(pg_db):
    users, patients, _ = await _seed_two_clinics(pg_db)
    facture_b = Facture(
        clinic_id=202,
        patient_id=patients[1].id,
        numero_facture="F-PG-202-B",
        total_ttc=Decimal("250.000"),
        statut=StatutFacture.BROUILLON.value,
        created_by=users[1].id,
    )
    pg_db.add(facture_b)
    await pg_db.flush()

    factures_a, total_a = await list_factures(pg_db, clinic_id=101)
    assert factures_a == []
    assert total_a == 0

    with pytest.raises(ValueError, match="Facture non trouvée"):
        await marquer_payee(facture_b.id, "carte", pg_db, clinic_id=101)
    with pytest.raises(ValueError, match="Facture non trouvée"):
        await annuler_facture(facture_b.id, "cross-tenant", pg_db, clinic_id=101)
    with pytest.raises(ValueError, match="Patient non trouvé"):
        await create_facture(
            {
                "patient_id": patients[1].id,
                "actes": [],
                "produits": [],
            },
            created_by=users[0].id,
            db=pg_db,
            clinic_id=101,
        )

    assert facture_b.statut == StatutFacture.BROUILLON.value


async def test_postgres_agenda_rejects_cross_tenant_patient(pg_db):
    users, patients, actes = await _seed_two_clinics(pg_db)
    with pytest.raises(ValueError, match="Patient non trouvé"):
        await creer_rdv(
            patient_id=patients[1].id,
            praticien_id=users[0].id,
            acte_id=actes[0].id,
            date_heure=datetime.utcnow() + timedelta(days=2),
            db=pg_db,
            created_by=users[0].id,
            clinic_id=101,
        )

    rdvs = (await pg_db.execute(select(RendezVous))).scalars().all()
    assert rdvs == []


async def test_postgres_rappels_and_cost_plans_are_tenant_scoped(pg_db):
    users, patients, actes = await _seed_two_clinics(pg_db)
    suivi_b = SuiviPostOperatoire(
        clinic_id=202,
        acte_id=actes[1].id,
        patient_id=patients[1].id,
        date_controle_prevue=datetime.utcnow() + timedelta(days=1),
        praticien_id=users[1].id,
    )
    plan_b = PlanTraitementIA(
        clinic_id=202,
        patient_id=patients[1].id,
        cree_par_praticien_id=users[1].id,
        proposition={"lignes_tarifees": [{"acte_id": actes[1].id, "quantite": 1}]},
    )
    pg_db.add_all([suivi_b, plan_b])
    await pg_db.flush()

    with pytest.raises(ValueError, match="Suivi post-opératoire introuvable"):
        await generer_rappel_suivi(pg_db, suivi_b.id, clinic_id=101)
    with pytest.raises(ValueError, match="Plan de traitement non trouvé"):
        await estimer_cout_plan(pg_db, plan_b.id, clinic_id=101)

    assert (await pg_db.execute(select(RappelDentaire))).scalars().all() == []
    assert (await pg_db.execute(select(EstimationCoutPlan))).scalars().all() == []


async def test_postgres_omnicanal_ids_cannot_cross_tenants(pg_db):
    _, patients, _ = await _seed_two_clinics(pg_db)
    conversation_b = Conversation(
        clinic_id=202,
        canal="whatsapp",
        contact_external_id="+21670000202",
        patient_id=patients[1].id,
    )
    pg_db.add(conversation_b)
    await pg_db.flush()
    message_b = MessageOmnicanal(
        clinic_id=202,
        conversation_id=conversation_b.id,
        direction="sortant",
        type_message="texte",
        contenu="private B",
        statut=StatutMessageEnum.ECHEC.value,
    )
    pg_db.add(message_b)
    await pg_db.flush()

    assert await list_conversations(pg_db, clinic_id=101) == []
    assert await get_conversation_messages(
        conversation_b.id, pg_db, clinic_id=101
    ) == []
    with pytest.raises(ValueError, match="Conversation non trouvée"):
        await close_conversation(conversation_b.id, pg_db, clinic_id=101)
    with pytest.raises(ValueError, match="Conversation non trouvée"):
        await send_reply(
            conversation_b.id,
            "attempt",
            pg_db,
            clinic_id=101,
        )
    with pytest.raises(ValueError, match="Message non trouvé"):
        await retry_failed_message(message_b.id, pg_db, clinic_id=101)

    assert conversation_b.statut == "ouverte"
    assert message_b.contenu == "private B"


async def test_postgres_fidelite_is_tenant_scoped(pg_db):
    _, patients, _ = await _seed_two_clinics(pg_db)
    with pytest.raises(ValueError, match="Patient non trouvé"):
        await add_points(
            patients[1].id,
            10,
            "cross-tenant",
            pg_db,
            clinic_id=101,
        )
    assert await get_historique(patients[1].id, pg_db, clinic_id=101) == []
    overview_a = await get_overview(pg_db, clinic_id=101)
    assert overview_a["total_points"] == 0
    assert overview_a["transactions"] == []
