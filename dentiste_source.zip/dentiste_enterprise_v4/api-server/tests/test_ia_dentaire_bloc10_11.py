import pytest
from types import SimpleNamespace
from unittest.mock import AsyncMock

from core.llm_client import LLMResponse
from services.ia_dentaire import (
    detecter_caries,
    proposer_plan_traitement,
    envoyer_plan_patient,
    _validate_cavity_result,
)


class FakeScalar:
    def __init__(self, value):
        self.value = value

    def scalar_one_or_none(self):
        return self.value

    def scalars(self):
        return self

    def all(self):
        return self.value


class FakeDB:
    def __init__(self, values):
        self.values = iter(values)
        self.added = []

    async def execute(self, _stmt):
        return next(self.values)

    def add(self, item):
        self.added.append(item)

    async def flush(self):
        for item in self.added:
            if getattr(item, "id", None) is None:
                item.id = 99

    async def get(self, _model, _id):
        return next(self.values)


class FakeLLM:
    def __init__(self, text):
        self.text = text
        self.calls = []

    async def chat(self, messages, **kwargs):
        self.calls.append((messages, kwargs))
        return LLMResponse(self.text, "openai", "gpt-4o")


@pytest.mark.asyncio
async def test_analyse_caries_appelle_le_client_vision_et_ne_modifie_pas_etat(
    monkeypatch,
):
    radio = SimpleNamespace(id=7, patient_id=12, clinic_id=1, dicom_metadata={})
    db = FakeDB([FakeScalar(radio)])
    monkeypatch.setattr(
        "services.ia_dentaire.get_decrypted_radio",
        AsyncMock(return_value=(b"jpeg", radio)),
    )
    llm = FakeLLM(
        '{"zones_suspectes":[{"dent_fdi":"16","x":0.1,"y":0.2,"largeur":0.2,"hauteur":0.1,"confiance":0.91,"description":"zone suspecte"}],"limites":"A confirmer par un praticien."}'
    )
    result = await detecter_caries(db, 7, 3, llm=llm)
    assert result["resultat"]["zones_suspectes"][0]["dent_fdi"] == "16"
    assert llm.calls[0][0][1]["content"][1]["type"] == "image_url"
    assert all(type(x).__name__ != "EtatDentaire" for x in db.added)
    assert all(type(x).__name__ != "HistoriqueDentaire" for x in db.added)


def test_resultat_caries_rejette_un_json_non_structure():
    with pytest.raises(ValueError):
        _validate_cavity_result({"zones_suspectes": "non", "limites": "x"})


@pytest.mark.asyncio
async def test_proposition_plan_structuree_sans_mutation_clinique():
    db = FakeDB([FakeScalar([]), FakeScalar([]), FakeScalar([])])
    llm = FakeLLM(
        '{"priorites":["Dent 16"],"proposition":["Examen clinique"],"justification":"A confirmer.","avertissement":"Aide uniquement."}'
    )
    result = await proposer_plan_traitement(db, 12, 3, llm=llm)
    assert result["valide_par_praticien_id"] is None
    assert result["proposition"]["priorites"] == ["Dent 16"]
    assert type(db.added[0]).__name__ == "PlanTraitementIA"
    assert all(
        type(x).__name__ not in {"EtatDentaire", "HistoriqueDentaire"} for x in db.added
    )


@pytest.mark.asyncio
async def test_envoi_plan_non_valide_interdit():
    plan = SimpleNamespace(
        id=4, valide_par_praticien_id=None, patient_id=12, envoye_at=None
    )
    db = FakeDB([plan])
    with pytest.raises(PermissionError):
        await envoyer_plan_patient(db, 4, 3)
    assert plan.envoye_at is None


@pytest.mark.asyncio
async def test_envoi_plan_valide_autorise():
    plan = SimpleNamespace(
        id=4, valide_par_praticien_id=8, patient_id=12, envoye_at=None
    )
    db = FakeDB([plan])
    result = await envoyer_plan_patient(db, 4, 3)
    assert result["envoye"] is True
    assert plan.envoye_at is not None
