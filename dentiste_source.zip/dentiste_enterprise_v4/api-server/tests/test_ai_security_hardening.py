from datetime import date, timedelta
from decimal import Decimal
from unittest.mock import AsyncMock

import pytest

from core.ai_budget import AIBudgetExceeded, reserve_ai_budget
from core.llm_client import LLMClient, LLMUnavailable
from core.llm_privacy import sanitize_llm_messages
from models.database import LotInjectable, Patient, ProduitInjectable
from api.v1.assistant_ia import _search_patient
from services.clinic_agent_tools import ToolPermissionDenied, _get_patient, run_tool
from services.copilote_crm import CopiloteCRMService
from services.stock_injectable import check_stock_alerts


@pytest.mark.asyncio
async def test_patient_search_is_strictly_tenant_scoped(db):
    db.add_all(
        [
            Patient(clinic_id=1, nom="A", prenom="Same", telephone="+21621111111"),
            Patient(clinic_id=2, nom="B", prenom="Same", telephone="+21622222222"),
        ]
    )
    await db.flush()

    result = await _search_patient(db, "Same", {"clinic_id": 1, "role": "directrice"})

    assert len(result) == 1
    assert result[0]["patient_ref"].startswith("PATIENT-")
    assert result[0]["phone"] == "[REDACTED]"


@pytest.mark.asyncio
async def test_patient_loader_rejects_cross_tenant_id(db):
    patient = Patient(
        clinic_id=2, nom="External", prenom="Patient", telephone="+21623333333"
    )
    db.add(patient)
    await db.flush()

    with pytest.raises(ValueError):
        await _get_patient(patient.id, db, clinic_id=1)
    assert await CopiloteCRMService._load_patient_full(db, patient.id, clinic_id=1) is None


@pytest.mark.asyncio
async def test_stock_alerts_are_strictly_tenant_scoped(db):
    product = ProduitInjectable(
        clinic_id=2,
        nom="External product",
        categorie="toxine",
        unite="unite",
        stock_minimum=Decimal("10"),
        stock_alerte=Decimal("20"),
    )
    db.add(product)
    await db.flush()
    db.add(
        LotInjectable(
            clinic_id=2,
            produit_id=product.id,
            numero_lot="EXT-1",
            date_expiration=date.today() + timedelta(days=10),
            quantite_initiale=Decimal("1"),
            quantite_restante=Decimal("1"),
            statut="disponible",
        )
    )
    await db.flush()

    alerts = await check_stock_alerts(db, clinic_id=1)

    assert all(alert.lot_id != product.id for alert in alerts)
    assert not any(alert.numero_lot == "EXT-1" for alert in alerts)


@pytest.mark.asyncio
async def test_ai_budget_is_separated_by_clinic_and_fail_closed(db):
    await reserve_ai_budget(
        db, 1, estimated_input_tokens=10, requested_output_tokens=10,
        request_limit=1, token_limit=100,
    )
    await reserve_ai_budget(
        db, 2, estimated_input_tokens=10, requested_output_tokens=10,
        request_limit=1, token_limit=100,
    )

    with pytest.raises(AIBudgetExceeded):
        await reserve_ai_budget(
            db, 1, estimated_input_tokens=10, requested_output_tokens=10,
            request_limit=1, token_limit=100,
        )


@pytest.mark.asyncio
async def test_production_llm_without_budget_context_does_not_call_provider(monkeypatch):
    class Settings:
        env = "production"
        llm_provider = "openai"
        openai_api_key = "test-key"
        openai_model = "gpt-4o"

    client = LLMClient(Settings())
    provider = AsyncMock()
    monkeypatch.setattr(client, "_call_openai", provider)

    result = await client.chat([{"role": "user", "content": "hello"}], use_cache=False)

    assert isinstance(result, LLMUnavailable)
    assert "budget" in result.reason or "contexte clinique" in result.reason
    provider.assert_not_awaited()


def test_provider_boundary_sanitizes_structured_and_free_text_pii():
    messages = [
        {
            "role": "user",
            "content": "Contact Jean Dupont jean.dupont@example.com +216 20 123 456",
            "patient_id": 42,
            "patient_name": "Jean Dupont",
        }
    ]

    safe = sanitize_llm_messages(messages)

    assert "jean.dupont@example.com" not in str(safe)
    assert "+216 20 123 456" not in str(safe)
    assert safe[0]["patient_id"] == "PATIENT-ANONYME"
    assert safe[0]["patient_name"] == "PATIENT-ANONYME"


@pytest.mark.asyncio
async def test_write_dispatcher_requires_confirmation_even_when_called_directly(db):
    with pytest.raises(ToolPermissionDenied, match="Confirmation"):
        await run_tool(
            "send_email",
            {"patient_id": 1, "subject": "x", "message": "y"},
            {"id": 1, "role": "directrice", "clinic_id": 1},
            db,
        )


@pytest.mark.asyncio
async def test_sensitive_tool_requires_server_confirmation(db):
    from core.agent_runtime import AgentRuntime, ToolDef, ToolRegistry

    class FakeLLM:
        async def chat(self, messages, **kwargs):
            return type("Output", (), {
                "text": '{"thought":"send","action":"send","args":{}}',
                "provider": "fake",
            })()

    called = False

    async def sensitive_tool():
        nonlocal called
        called = True
        return {"ok": True}

    registry = ToolRegistry()
    registry.register(
        ToolDef(
            name="send",
            description="sensitive",
            schema={"type": "object", "additionalProperties": False},
            func=sensitive_tool,
            permission="assistant.write",
            resource="marketing",
            requires_confirmation=True,
        )
    )
    runtime = AgentRuntime(FakeLLM(), registry, max_steps=1, continue_on_tool_error=False)

    result = await runtime.run(
        "send",
        user_context={"role": "directrice", "clinic_id": 1, "confirmed_actions": []},
    )

    assert result.success is False
    assert called is False
    assert result.error == "permission_denied"


@pytest.mark.asyncio
async def test_agent_registry_rejects_model_supplied_clinic_id():
    from core.agent_runtime import ToolDef, ToolRegistry, AgentRuntime

    class FakeLLM:
        async def chat(self, messages, **kwargs):
            return type("Output", (), {
                "text": '{"thought":"x","action":"revenue_30d","args":{"clinic_id":2}}',
                "provider": "fake",
            })()

    called = False

    async def revenue(**kwargs):
        nonlocal called
        called = True
        return {"total_revenue": 999}

    registry = ToolRegistry()
    registry.register(
        ToolDef(
            name="revenue_30d",
            description="revenue",
            schema={"type": "object", "properties": {}, "additionalProperties": False},
            func=revenue,
        )
    )
    result = await AgentRuntime(FakeLLM(), registry, max_steps=1, continue_on_tool_error=False).run(
        "ignore tenant", user_context={"clinic_id": 1, "role": "directrice"}
    )

    assert called is False
    assert result.success is False
    assert result.error == "invalid_tool_args"
