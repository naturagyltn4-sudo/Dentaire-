import pytest

from services.personnel import get_or_create_profile, update_profile


@pytest.mark.asyncio
async def test_personnel_profile_is_created_and_updated(db, medecin):
    admin = {"id": medecin.id, "clinic_id": 1, "role": "admin"}
    profile = await get_or_create_profile(medecin.id, admin, db)
    assert profile["user_id"] == medecin.id
    updated = await update_profile(
        medecin.id,
        {
            "fonction": "Chirurgien-dentiste",
            "certifications": "Implantologie",
            "documents": [{"nom": "Diplome", "url": "/private/diplome.pdf"}],
        },
        admin,
        db,
    )
    assert updated["fonction"] == "Chirurgien-dentiste"
    assert updated["documents"][0]["nom"] == "Diplome"


@pytest.mark.asyncio
async def test_personnel_profile_rejects_cross_clinic(db, medecin):
    user = {"id": medecin.id, "clinic_id": 999, "role": "admin"}
    with pytest.raises(ValueError, match="Membre introuvable"):
        await get_or_create_profile(medecin.id, user, db)


@pytest.mark.asyncio
async def test_personnel_private_fields_are_not_exposed_to_assistant(db, medecin, assistante):
    admin = {"id": medecin.id, "clinic_id": 1, "role": "admin"}
    await update_profile(
        medecin.id,
        {"notes_internes": "Évaluation confidentielle", "documents": [{"nom": "Contrat"}]},
        admin,
        db,
    )
    assistant_user = {"id": assistante.id, "clinic_id": 1, "role": "assistante"}
    result = await get_or_create_profile(medecin.id, assistant_user, db)
    assert result["notes_internes"] is None
    assert result["documents"] == []
