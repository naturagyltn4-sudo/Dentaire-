from core.llm_privacy import pseudonymiser_prompt_payload


def test_pseudonymiser_prompt_payload_ne_modifie_pas_l_original():
    source = {
        "id": 42,
        "patient": {
            "prenom": "Amine",
            "nom": "Ben Salah",
            "email": "amine@example.com",
            "telephone": "+21620123456",
            "notes": "Information confidentielle",
            "actes": [{"type": "implant", "statut": "en_cours"}],
        },
    }

    sanitized = pseudonymiser_prompt_payload(source, patient_ref="PATIENT-42")

    assert source["patient"]["prenom"] == "Amine"
    assert source["patient"]["email"] == "amine@example.com"
    assert sanitized["id"] == "PATIENT-42"
    assert sanitized["patient"]["prenom"] == "PATIENT-42"
    assert sanitized["patient"]["nom"] == "PATIENT-42"
    assert sanitized["patient"]["email"] == "[REDACTED]"
    assert sanitized["patient"]["telephone"] == "[REDACTED]"
    assert sanitized["patient"]["notes"] == "[REDACTED]"
    assert sanitized["patient"]["actes"][0]["type"] == "implant"
    assert "Amine" not in str(sanitized)
    assert "amine@example.com" not in str(sanitized)
    assert "+21620123456" not in str(sanitized)
