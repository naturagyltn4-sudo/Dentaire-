from datetime import date

import pytest

from models.database import StatutEtapeTraitement
from services.patient360 import get_patient_360
from services.plans_traitement import add_step, create_plan, list_plans, update_step


@pytest.mark.asyncio
async def test_plan_creation_progression_and_step_update(db, medecin, patient):
    user = {"id": medecin.id, "clinic_id": 1, "role": "medecin"}
    plan = await create_plan(
        patient.id,
        {"titre": "Implant 36", "objectif": "Restauration complète"},
        user,
        db,
    )
    step = await add_step(
        plan["id"],
        {"titre": "Consultation", "type_etape": "consultation"},
        user,
        db,
    )
    updated = await update_step(
        step["id"],
        {"statut": StatutEtapeTraitement.TERMINEE.value, "date_realisation": date.today()},
        user,
        db,
    )
    assert updated["statut"] == "terminee"
    plans = await list_plans(patient.id, user, db)
    assert plans[0]["progression"] == 100
    assert plans[0]["etapes_terminees"] == 1


@pytest.mark.asyncio
async def test_patient360_rejects_cross_clinic_patient(db, medecin, patient):
    user = {"id": medecin.id, "clinic_id": 999, "role": "medecin"}
    with pytest.raises(ValueError, match="Patient non trouvé"):
        await get_patient_360(patient.id, user, db)


@pytest.mark.asyncio
async def test_patient360_lists_empty_sections_without_lazy_loading(db, medecin, patient):
    user = {"id": medecin.id, "clinic_id": 1, "role": "medecin"}
    result = await get_patient_360(patient.id, user, db)
    assert result["patient"]["id"] == patient.id
    assert result["actions_aujourdhui"] == []
    assert result["rendez_vous"] == []
    assert result["devis"] == []
    assert result["factures"] == []


@pytest.mark.asyncio
async def test_plan_rejects_foreign_practitioner(db, medecin, patient):
    from services.plans_traitement import create_plan

    user = {"id": medecin.id, "clinic_id": 1, "role": "medecin"}
    with pytest.raises(ValueError, match="Praticien invalide"):
        await create_plan(
            patient.id,
            {"titre": "Plan isolé", "praticien_id": 999999},
            user,
            db,
        )


@pytest.mark.asyncio
async def test_step_rejects_foreign_references(db, medecin, patient):
    user = {"id": medecin.id, "clinic_id": 1, "role": "medecin"}
    plan = await create_plan(patient.id, {"titre": "Plan sécurisé"}, user, db)
    with pytest.raises(ValueError, match="Rendez-vous invalide"):
        await add_step(plan["id"], {"titre": "Étape", "rendez_vous_id": 999999}, user, db)


@pytest.mark.asyncio
async def test_anonymization_rejects_foreign_clinic(db, patient):
    from services.patients import anonymize_patient

    with pytest.raises(ValueError, match="Patient non trouvé"):
        await anonymize_patient(patient.id, db, clinic_id=999)
