"""
Tests d'intégration pour BLOC 2 — Dossier Complet
Vérifie l'intégration odontogramme + dossier médical + photos + actes
"""

import pytest
from datetime import datetime, date
from sqlalchemy.ext.asyncio import AsyncSession

from models.database import (
    Patient,
    Utilisateur,
    RoleEnum,
    DossierMedical,
    EtatDentaire,
    HistoriqueDentaire,
    PhotoClinic,
    ActeMedical,
)


@pytest.fixture
async def test_patient_complet(db: AsyncSession):
    """Créer un patient avec données complètes."""
    patient = Patient(
        clinic_id=1,
        nom="Dupont",
        prenom="Jean",
        telephone="+216123456789",
        date_naissance=date(1990, 5, 15),
        is_active=True,
    )
    db.add(patient)
    await db.commit()
    await db.refresh(patient)
    return patient


@pytest.fixture
async def test_praticien(db: AsyncSession):
    """Créer un praticien de test."""
    from passlib.context import CryptContext

    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    praticien = Utilisateur(
        clinic_id=1,
        email="praticien@clinic.local",
        hashed_password=pwd_context.hash("password123"),
        nom="Martin",
        prenom="Dr",
        role=RoleEnum.MEDECIN,
        is_active=True,
    )
    db.add(praticien)
    await db.commit()
    await db.refresh(praticien)
    return praticien


@pytest.fixture
async def test_acte(db: AsyncSession):
    """Créer un acte médical de test."""
    acte = ActeMedical(
        clinic_id=1,
        nom="Détartrage",
        categorie="Hygiène",
        duree_minutes=30,
        prix_base=50.0,
    )
    db.add(acte)
    await db.commit()
    await db.refresh(acte)
    return acte


class TestDossierCompletIntegration:
    """Tests d'intégration pour le dossier complet."""

    @pytest.mark.asyncio
    async def test_dossier_complet_avec_donnees_completes(
        self, db: AsyncSession, test_patient_complet, test_praticien, test_acte
    ):
        """Tester le dossier complet avec toutes les données."""
        patient = test_patient_complet
        praticien = test_praticien
        acte = test_acte

        # Créer des états dentaires
        for i in range(5):
            numero_dent = f"{1 + (i // 2)}{1 + (i % 2)}"
            etat = EtatDentaire(
                clinic_id=1,
                patient_id=patient.id,
                numero_dent=numero_dent,
                statut="sain" if i % 2 == 0 else "carie",
                praticien_id=praticien.id,
                date_modification=datetime.utcnow(),
            )
            db.add(etat)

        # Créer un dossier médical
        dossier = DossierMedical(
            clinic_id=1,
            patient_id=patient.id,
            praticien_id=praticien.id,
            acte_id=acte.id,
            date_acte=datetime.utcnow(),
            zones_traitees={"dents": ["11", "12"]},
            observations_enc="Détartrage effectué",
            satisfaction_patient=5,
            suivi_requis=False,
        )
        db.add(dossier)

        # Créer une photo
        photo = PhotoClinic(
            clinic_id=1,
            patient_id=patient.id,
            type="avant",
            zone_anatomique="sourire",
            date_prise=datetime.utcnow(),
            url_stockage="/photos/test.jpg",
            visible_patient=True,
        )
        db.add(photo)

        await db.commit()

        # Vérifier que toutes les données ont été créées
        from sqlalchemy import select

        # Vérifier les états dentaires
        stmt = select(EtatDentaire).where(EtatDentaire.patient_id == patient.id)
        etats = await db.scalars(stmt)
        assert len(list(etats)) == 5

        # Vérifier le dossier médical
        stmt = select(DossierMedical).where(DossierMedical.patient_id == patient.id)
        dossiers = await db.scalars(stmt)
        dossiers_list = list(dossiers)
        assert len(dossiers_list) == 1
        assert dossiers_list[0].observations_enc == "Détartrage effectué"

        # Vérifier les photos
        stmt = select(PhotoClinic).where(PhotoClinic.patient_id == patient.id)
        photos = await db.scalars(stmt)
        photos_list = list(photos)
        assert len(photos_list) == 1

    @pytest.mark.asyncio
    async def test_pas_de_duplication_odontogramme_dans_dossier(
        self, db: AsyncSession, test_patient_complet, test_praticien
    ):
        """Vérifier qu'il n'y a pas de duplication odontogramme dans DossierMedical."""
        patient = test_patient_complet
        praticien = test_praticien

        # Créer un état dentaire
        etat = EtatDentaire(
            clinic_id=1,
            patient_id=patient.id,
            numero_dent="11",
            statut="carie",
            praticien_id=praticien.id,
            date_modification=datetime.utcnow(),
        )
        db.add(etat)

        # Créer un dossier médical avec zones_traitees
        dossier = DossierMedical(
            clinic_id=1,
            patient_id=patient.id,
            praticien_id=praticien.id,
            date_acte=datetime.utcnow(),
            zones_traitees={"dents": ["11"]},  # Résumé dénormalisé
        )
        db.add(dossier)

        await db.commit()

        # Vérifier que zones_traitees est un résumé, pas une duplication
        from sqlalchemy import select

        stmt = select(DossierMedical).where(DossierMedical.id == dossier.id)
        fetched_dossier = await db.scalar(stmt)
        assert fetched_dossier.zones_traitees == {"dents": ["11"]}

        # Vérifier que l'état dentaire est la source de vérité
        stmt = select(EtatDentaire).where(
            EtatDentaire.patient_id == patient.id,
            EtatDentaire.numero_dent == "11",
        )
        fetched_etat = await db.scalar(stmt)
        assert fetched_etat.statut == "carie"

    @pytest.mark.asyncio
    async def test_historique_dentaire_append_only(
        self, db: AsyncSession, test_patient_complet, test_praticien
    ):
        """Vérifier que l'historique dentaire est append-only."""
        patient = test_patient_complet
        praticien = test_praticien

        # Créer un état dentaire
        etat = EtatDentaire(
            clinic_id=1,
            patient_id=patient.id,
            numero_dent="11",
            statut="sain",
            praticien_id=praticien.id,
            date_modification=datetime.utcnow(),
        )
        db.add(etat)
        await db.commit()
        await db.refresh(etat)

        # Créer un événement historique
        historique = HistoriqueDentaire(
            clinic_id=1,
            etat_dentaire_id=etat.id,
            patient_id=patient.id,
            numero_dent="11",
            statut_ancien=None,
            statut_nouveau="sain",
            praticien_id=praticien.id,
        )
        db.add(historique)
        await db.commit()

        # Vérifier que l'historique ne peut pas être modifié
        from sqlalchemy import select

        stmt = select(HistoriqueDentaire).where(
            HistoriqueDentaire.etat_dentaire_id == etat.id
        )
        historiques = await db.scalars(stmt)
        historiques_list = list(historiques)
        assert len(historiques_list) == 1
        assert historiques_list[0].statut_ancien is None
        assert historiques_list[0].statut_nouveau == "sain"

    @pytest.mark.asyncio
    async def test_rbac_dossier_complet(
        self, db: AsyncSession, test_patient_complet, test_praticien
    ):
        """Vérifier que les permissions RBAC sont correctes."""
        # Créer un utilisateur avec rôle ASSISTANTE
        from passlib.context import CryptContext

        pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        assistante = Utilisateur(
            clinic_id=1,
            email="assistante@clinic.local",
            hashed_password=pwd_context.hash("password123"),
            nom="Dupont",
            prenom="Marie",
            role=RoleEnum.ASSISTANTE,
            is_active=True,
        )
        db.add(assistante)
        await db.commit()
        await db.refresh(assistante)

        # Vérifier que l'assistante a le rôle correct
        assert assistante.role == RoleEnum.ASSISTANTE

    @pytest.mark.asyncio
    async def test_routes_existantes_non_cassees(
        self, db: AsyncSession, test_patient_complet, test_praticien
    ):
        """Vérifier que les routes existantes ne sont pas cassées."""
        patient = test_patient_complet
        praticien = test_praticien

        # Créer un dossier médical
        dossier = DossierMedical(
            clinic_id=1,
            patient_id=patient.id,
            praticien_id=praticien.id,
            date_acte=datetime.utcnow(),
            observations_enc="Test",
        )
        db.add(dossier)
        await db.commit()

        # Vérifier que le dossier a été créé
        from sqlalchemy import select

        stmt = select(DossierMedical).where(DossierMedical.id == dossier.id)
        fetched_dossier = await db.scalar(stmt)
        assert fetched_dossier is not None
        assert fetched_dossier.observations_enc == "Test"

    @pytest.mark.asyncio
    async def test_patient_sans_donnees_dentaires(
        self, db: AsyncSession, test_patient_complet, test_praticien
    ):
        """Tester un patient sans données dentaires."""
        patient = test_patient_complet
        praticien = test_praticien

        # Créer un dossier médical sans état dentaire
        dossier = DossierMedical(
            clinic_id=1,
            patient_id=patient.id,
            praticien_id=praticien.id,
            date_acte=datetime.utcnow(),
        )
        db.add(dossier)
        await db.commit()

        # Vérifier que le dossier existe mais pas d'état dentaire
        from sqlalchemy import select

        stmt = select(EtatDentaire).where(EtatDentaire.patient_id == patient.id)
        etats = await db.scalars(stmt)
        assert len(list(etats)) == 0

        stmt = select(DossierMedical).where(DossierMedical.patient_id == patient.id)
        dossiers = await db.scalars(stmt)
        assert len(list(dossiers)) == 1

    @pytest.mark.asyncio
    async def test_multiple_dossiers_medicaux(
        self, db: AsyncSession, test_patient_complet, test_praticien
    ):
        """Tester un patient avec plusieurs dossiers médicaux."""
        patient = test_patient_complet
        praticien = test_praticien

        # Créer 3 dossiers médicaux
        for i in range(3):
            dossier = DossierMedical(
                clinic_id=1,
                patient_id=patient.id,
                praticien_id=praticien.id,
                date_acte=datetime.utcnow(),
                observations_enc=f"Dossier {i + 1}",
            )
            db.add(dossier)

        await db.commit()

        # Vérifier que les 3 dossiers ont été créés
        from sqlalchemy import select

        stmt = select(DossierMedical).where(DossierMedical.patient_id == patient.id)
        dossiers = await db.scalars(stmt)
        dossiers_list = list(dossiers)
        assert len(dossiers_list) == 3
