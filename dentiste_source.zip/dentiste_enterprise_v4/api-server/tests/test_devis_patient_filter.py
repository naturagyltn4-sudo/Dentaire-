from decimal import Decimal

import pytest

from api.v1.factures import list_devis_route
from models.database import DevisTraitement, Patient, StatutDevis


@pytest.mark.asyncio
async def test_list_devis_filtre_par_patient_id(db, patient, acte, medecin):
    autre_patient = Patient(
        clinic_id=1,
        nom="Autre",
        prenom="Patient",
        telephone="+21621000000",
    )
    db.add(autre_patient)
    await db.flush()

    db.add_all(
        [
            DevisTraitement(
                clinic_id=1,
                patient_id=patient.id,
                acte_id=acte.id,
                prix=Decimal("100.000"),
                statut=StatutDevis.BROUILLON.value,
            ),
            DevisTraitement(
                clinic_id=1,
                patient_id=autre_patient.id,
                acte_id=acte.id,
                prix=Decimal("200.000"),
                statut=StatutDevis.BROUILLON.value,
            ),
        ]
    )
    await db.flush()

    result = await list_devis_route(
        patient_id=patient.id,
        db=db,
        current_user={"id": medecin.id, "clinic_id": 1},
    )

    assert len(result) == 1
    assert result[0].patient_id == patient.id
