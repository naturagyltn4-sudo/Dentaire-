"""
Tests unitaires — BLOC 6 : Prothèses et Laboratoire
"""

from datetime import date, timedelta
from decimal import Decimal
import pytest

from services.protheses import (
    create_commande_prothese,
    poser_prothese,
    check_prothese_delays,
)
from models.database import EtatDentaire, HistoriqueDentaire, StatutProthese, StatutDent
from sqlalchemy import select


@pytest.mark.asyncio
async def test_creer_commande_prothese(db, patient):
    commande = await create_commande_prothese(
        db=db,
        patient_id=patient.id,
        type_prothese="couronne",
        laboratoire="Labo Dentaire Pro",
        date_reception_prevue=date.today() + timedelta(days=5),
        cout=Decimal("350.000"),
        dent="16",
    )
    await db.commit()

    assert commande.id is not None
    assert commande.patient_id == patient.id
    assert commande.type == "couronne"
    assert commande.laboratoire == "Labo Dentaire Pro"
    assert commande.statut == StatutProthese.COMMANDE.value
    assert commande.cout == Decimal("350.000")


@pytest.mark.asyncio
async def test_poser_prothese_met_a_jour_etat_et_historique(db, patient, medecin):
    # 1. Créer commande
    commande = await create_commande_prothese(
        db=db,
        patient_id=patient.id,
        type_prothese="implant",
        laboratoire="Implants & Co",
        date_reception_prevue=date.today() + timedelta(days=2),
        cout=Decimal("1200.500"),
        dent="36",
    )
    await db.commit()

    # 2. Poser la prothèse
    posée = await poser_prothese(
        db=db,
        prothese_id=commande.id,
        praticien_id=medecin.id,
    )

    assert posée.statut == StatutProthese.POSE.value
    assert posée.date_reception_reelle == date.today()

    # 3. Vérifier EtatDentaire mis à jour
    etat = await db.scalar(
        select(EtatDentaire).where(
            EtatDentaire.patient_id == patient.id,
            EtatDentaire.numero_dent == "36",
        )
    )
    assert etat is not None
    assert etat.statut == StatutDent.IMPLANT.value

    # 4. Vérifier HistoriqueDentaire créé
    historique = await db.scalar(
        select(HistoriqueDentaire).where(
            HistoriqueDentaire.patient_id == patient.id,
            HistoriqueDentaire.numero_dent == "36",
        )
    )
    assert historique is not None
    assert historique.statut_nouveau == StatutDent.IMPLANT.value


@pytest.mark.asyncio
async def test_check_prothese_delays(db, patient, medecin):
    # Créer une prothèse en retard (date_reception_prevue passée)
    await create_commande_prothese(
        db=db,
        patient_id=patient.id,
        type_prothese="bridge",
        laboratoire="Labo Retard",
        date_reception_prevue=date.today() - timedelta(days=3),
        cout=Decimal("800.000"),
        dent="21,22",
    )
    await db.commit()

    notif_count = await check_prothese_delays(db)
    assert notif_count >= 1
