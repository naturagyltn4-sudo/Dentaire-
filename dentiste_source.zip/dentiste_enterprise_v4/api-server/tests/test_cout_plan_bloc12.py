from decimal import Decimal

import pytest

from services.cout_plan import calculer_total_deterministe


def test_meme_entree_meme_resultat_sur_plusieurs_executions():
    lignes = [
        {"acte_id": 10, "quantite": 2},
        {"acte_id": 11, "quantite": "1"},
    ]
    tarifs = {10: Decimal("45.125"), 11: Decimal("100.375")}
    resultats = [calculer_total_deterministe(lignes, tarifs) for _ in range(20)]
    assert all(resultat == resultats[0] for resultat in resultats)
    assert resultats[0][0] == Decimal("190.625")
    assert resultats[0][1][0]["sous_total"] == "90.250"


def test_calcul_ne_depend_pas_du_llm(monkeypatch):
    def fail_llm(*args, **kwargs):
        raise AssertionError("Aucun LLM ne doit être appelé pour un prix")

    monkeypatch.setattr("services.cout_plan.get_llm_client", fail_llm, raising=False)
    total, _ = calculer_total_deterministe(
        [{"acte_id": 1, "quantite": 3}], {1: Decimal("12.345")}
    )
    assert total == Decimal("37.035")


def test_quantite_non_entiere_refusee():
    with pytest.raises(ValueError):
        calculer_total_deterministe(
            [{"acte_id": 1, "quantite": "0.5"}], {1: Decimal("10")}
        )
