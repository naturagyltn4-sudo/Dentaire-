from datetime import datetime, timedelta

import pytest
from sqlalchemy import select

from models.database import BookingRequest, Patient, RendezVous
from services.reservation_publique import (
    approuver_demande_public,
    rejeter_demande_public,
    reserver_creneau_public,
)

FUTURE_SLOT = datetime.utcnow() + timedelta(days=30)


@pytest.mark.asyncio
async def test_reservation_creates_pending_request_without_internal_records(db, medecin, acte):
    result = await reserver_creneau_public(
        {
            "nom": "Jelassi",
            "prenom": "Rania",
            "telephone": "+21622334455",
            "praticien_id": medecin.id,
            "acte_id": acte.id,
            "date_heure": FUTURE_SLOT.replace(hour=10, minute=0, second=0, microsecond=0),
        },
        db,
    )
    assert result["statut"] == "pending"
    assert result["rdv_id"] is None
    assert result["patient_id"] is None
    request = await db.scalar(select(BookingRequest).where(BookingRequest.id == result["booking_request_id"]))
    assert request is not None
    assert await db.scalar(select(Patient).where(Patient.telephone == "+21622334455")) is None
    assert await db.scalar(select(RendezVous).where(RendezVous.clinic_id == 1)) is None


@pytest.mark.asyncio
async def test_approval_creates_patient_and_internal_appointment(db, medecin, acte):
    data = {
        "nom": "Jelassi",
        "prenom": "Rania",
        "telephone": "+21622334457",
        "praticien_id": medecin.id,
        "acte_id": acte.id,
        "date_heure": FUTURE_SLOT.replace(hour=10, minute=30, second=0, microsecond=0),
    }
    pending = await reserver_creneau_public(data, db)
    result = await approuver_demande_public(pending["booking_request_id"], db, clinic_id=1)
    assert result["statut"] == "accepted"
    assert result["rdv_id"] is not None
    assert result["patient_id"] is not None


@pytest.mark.asyncio
async def test_rejection_does_not_create_internal_records(db, medecin, acte):
    pending = await reserver_creneau_public(
        {
            "nom": "Jelassi",
            "prenom": "Rania",
            "telephone": "+21622334458",
            "praticien_id": medecin.id,
            "acte_id": acte.id,
            "date_heure": FUTURE_SLOT.replace(hour=11, minute=0, second=0, microsecond=0),
        },
        db,
    )
    result = await rejeter_demande_public(pending["booking_request_id"], db, clinic_id=1)
    assert result["statut"] == "rejected"
    assert await db.scalar(select(Patient).where(Patient.telephone == "+21622334458")) is None


@pytest.mark.asyncio
async def test_duplicate_public_booking_is_rejected(db, medecin, acte):
    data = {
        "nom": "Jelassi",
        "prenom": "Rania",
        "telephone": "+21622334456",
        "praticien_id": medecin.id,
        "acte_id": acte.id,
        "date_heure": FUTURE_SLOT.replace(hour=15, minute=0, second=0, microsecond=0),
    }
    await reserver_creneau_public(data, db)
    with pytest.raises(ValueError, match="déjà en cours"):
        await reserver_creneau_public(data, db)


@pytest.mark.asyncio
async def test_reservation_does_not_create_duplicate_patient(db, medecin, acte, patient):
    result = await reserver_creneau_public(
        {
            "nom": "Autre nom",
            "prenom": "Autre prenom",
            "telephone": patient.telephone,
            "praticien_id": medecin.id,
            "acte_id": acte.id,
            "date_heure": FUTURE_SLOT.replace(hour=11, minute=30, second=0, microsecond=0),
        },
        db,
    )
    assert result["patient_id"] is None
    assert await db.scalar(select(Patient.id).where(Patient.telephone == patient.telephone)) == patient.id


@pytest.mark.asyncio
async def test_reservation_rejects_invalid_phone(db, medecin, acte):
    with pytest.raises(ValueError, match="téléphone invalide"):
        await reserver_creneau_public(
            {
                "nom": "X",
                "prenom": "Y",
                "telephone": "abc",
                "praticien_id": medecin.id,
                "acte_id": acte.id,
                "date_heure": FUTURE_SLOT.replace(hour=9, minute=0, second=0, microsecond=0),
            },
            db,
        )


@pytest.mark.asyncio
async def test_reservation_rejects_missing_nom(db, medecin, acte):
    with pytest.raises(ValueError, match="prénom requis"):
        await reserver_creneau_public(
            {
                "nom": "",
                "prenom": "Y",
                "telephone": "+21600000000",
                "praticien_id": medecin.id,
                "acte_id": acte.id,
                "date_heure": FUTURE_SLOT.replace(hour=9, minute=0, second=0, microsecond=0),
            },
            db,
        )


@pytest.mark.asyncio
async def test_pending_request_respects_conflict_detection(db, medecin, acte):
    debut = FUTURE_SLOT.replace(hour=14, minute=0, second=0, microsecond=0)
    await reserver_creneau_public(
        {
            "nom": "A",
            "prenom": "B",
            "telephone": "+21611112222",
            "praticien_id": medecin.id,
            "acte_id": acte.id,
            "date_heure": debut,
        },
        db,
    )

    with pytest.raises(ValueError, match="[Cc]onflit"):
        await reserver_creneau_public(
            {
                "nom": "C",
                "prenom": "D",
                "telephone": "+21633334444",
                "praticien_id": medecin.id,
                "acte_id": acte.id,
                "date_heure": debut,
            },
            db,
        )
