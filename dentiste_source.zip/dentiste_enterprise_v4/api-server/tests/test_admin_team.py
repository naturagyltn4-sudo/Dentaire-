from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from sqlalchemy import select

from api.v1.admin_team import TeamMemberCreate, create_team_member
from models.database import JournalAudit, RoleEnum, Utilisateur
from services.audit_journal import list_events
from middleware.auth import verify_password


@pytest.fixture
def admin_request():
    return SimpleNamespace(
        client=SimpleNamespace(host="127.0.0.1"),
        headers={"user-agent": "pytest"},
    )


@pytest.mark.asyncio
async def test_admin_creates_team_member_and_audit_event(db, admin_request):
    actor = Utilisateur(
        clinic_id=1,
        email="admin-team@clinic.tn",
        hashed_password="existing-hash",
        nom="Admin",
        prenom="Equipe",
        role=RoleEnum.ADMIN.value,
    )
    db.add(actor)
    await db.flush()

    payload = TeamMemberCreate(
        email="mme.x@clinic.tn",
        nom="X",
        prenom="Mme",
        role=RoleEnum.MEDECIN,
        mot_de_passe="MotDePasseTresSolide123!",
        specialite="Implantologie",
    )
    result = await create_team_member(
        payload,
        admin_request,
        db,
        {"id": actor.id, "clinic_id": 1, "role": RoleEnum.ADMIN.value},
    )

    assert result["email"] == "mme.x@clinic.tn"
    target = await db.scalar(select(Utilisateur).where(Utilisateur.email == "mme.x@clinic.tn"))
    assert target is not None
    assert target.role == RoleEnum.MEDECIN.value
    assert verify_password("MotDePasseTresSolide123!", target.hashed_password)

    events = await list_events(db, clinic_id=1, resource_type="utilisateur")
    assert any(event["action"] == "CREATE_TEAM_MEMBER" for event in events)
    assert any(event["resource_id"] == target.id for event in events)


@pytest.mark.asyncio
async def test_directrice_cannot_create_admin_account(db, admin_request):
    actor = Utilisateur(
        clinic_id=1,
        email="directrice-team@clinic.tn",
        hashed_password="existing-hash",
        nom="Direction",
        prenom="Clinique",
        role=RoleEnum.DIRECTRICE.value,
    )
    db.add(actor)
    await db.flush()

    payload = TeamMemberCreate(
        email="admin2@clinic.tn",
        nom="Admin",
        prenom="Deux",
        role=RoleEnum.ADMIN,
        mot_de_passe="MotDePasseTresSolide123!",
    )

    with pytest.raises(HTTPException) as exc:
        await create_team_member(
            payload,
            admin_request,
            db,
            {"id": actor.id, "clinic_id": 1, "role": RoleEnum.DIRECTRICE.value},
        )
    assert exc.value.status_code == 403
    assert await db.scalar(select(Utilisateur).where(Utilisateur.email == "admin2@clinic.tn")) is None


@pytest.mark.asyncio
async def test_journal_audit_keeps_patient_actor_and_details(db, admin_request):
    actor = Utilisateur(
        clinic_id=1,
        email="audit-team@clinic.tn",
        hashed_password="existing-hash",
        nom="Audit",
        prenom="Test",
        role=RoleEnum.MEDECIN.value,
    )
    db.add(actor)
    await db.flush()

    from services.audit_journal import log_event

    await log_event(
        db,
        utilisateur_id=actor.id,
        clinic_id=1,
        action="UPDATE_DOSSIER",
        resource_type="dossier_medical",
        resource_id=42,
        patient_id=7,
        details={"fields": ["observations"]},
        ip_address="127.0.0.1",
        user_agent="pytest",
    )
    event = (await db.execute(select(JournalAudit))).scalar_one()
    assert event.patient_id == 7
    assert event.utilisateur_id == actor.id
    assert event.details == {"fields": ["observations"]}
