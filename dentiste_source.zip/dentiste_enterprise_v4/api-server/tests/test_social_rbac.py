"""Régressions RBAC — routes Social CRM."""

import pytest
from fastapi import HTTPException

from api.v1.social import SOCIAL_ACCESS


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["directrice", "assistante", "commercial", "admin"])
async def test_social_access_allows_authorized_roles(role):
    user = {"id": 1, "clinic_id": 1, "role": role}
    assert await SOCIAL_ACCESS.dependency(current_user=user) == user


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["medecin", "estheticienne"])
async def test_social_access_rejects_roles_without_social_scope(role):
    with pytest.raises(HTTPException) as exc:
        await SOCIAL_ACCESS.dependency(current_user={"id": 2, "clinic_id": 1, "role": role})
    assert exc.value.status_code == 403
