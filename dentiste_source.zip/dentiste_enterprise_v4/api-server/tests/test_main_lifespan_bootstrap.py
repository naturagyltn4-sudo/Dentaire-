from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest


@pytest.mark.asyncio
async def test_lifespan_opens_a_session_instance_for_test_admin(monkeypatch):
    import main

    class FakeSession:
        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, traceback):
            return False

        commit = AsyncMock()

    session = FakeSession()
    reconcile = AsyncMock(return_value="created")
    dispose = AsyncMock()
    settings = SimpleNamespace(
        test_admin_bootstrap_enabled=True,
        test_admin_email="recette-admin@example.test",
        test_admin_nom="Recette",
        test_admin_prenom="Direction",
        test_admin_password="MotDePasseRecetteSolide123",
        instance_clinic_id=1,
        clinic_id=None,
        test_admin_reset_existing=True,
    )

    monkeypatch.setattr(main, "get_settings", lambda: settings)
    monkeypatch.setattr(main, "_get_sessionmaker", lambda: lambda: session)
    monkeypatch.setattr(main, "reconcile_test_admin", reconcile)
    monkeypatch.setattr(main, "dispose_engine", dispose)

    async with main.lifespan(None):
        pass

    reconcile.assert_awaited_once_with(
        session,
        email="recette-admin@example.test",
        nom="Recette",
        prenom="Direction",
        password="MotDePasseRecetteSolide123",
        clinic_id=1,
        reset_existing=True,
    )
    session.commit.assert_awaited_once()
    dispose.assert_awaited_once()


@pytest.mark.asyncio
async def test_lifespan_skips_bootstrap_when_disabled(monkeypatch):
    import main

    dispose = AsyncMock()
    settings = SimpleNamespace(test_admin_bootstrap_enabled=False)
    reconcile = AsyncMock()

    monkeypatch.setattr(main, "get_settings", lambda: settings)
    monkeypatch.setattr(main, "reconcile_test_admin", reconcile)
    monkeypatch.setattr(main, "dispose_engine", dispose)

    async with main.lifespan(None):
        pass

    reconcile.assert_not_awaited()
    dispose.assert_awaited_once()
