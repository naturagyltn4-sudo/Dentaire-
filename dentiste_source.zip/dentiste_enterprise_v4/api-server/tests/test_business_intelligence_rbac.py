"""Régressions RBAC — routes Business Intelligence."""

import pytest
from fastapi import HTTPException

from api.v1.business_intelligence import BI_ACCESS


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["directrice", "admin"])
async def test_bi_access_allows_direction_and_admin(role):
    user = {"id": 1, "clinic_id": 1, "role": role}
    assert await BI_ACCESS.dependency(current_user=user) == user


@pytest.mark.asyncio
@pytest.mark.parametrize("role", ["medecin", "estheticienne", "assistante", "commercial"])
async def test_bi_access_rejects_roles_without_financial_scope(role):
    with pytest.raises(HTTPException) as exc:
        await BI_ACCESS.dependency(current_user={"id": 2, "clinic_id": 1, "role": role})
    assert exc.value.status_code == 403
