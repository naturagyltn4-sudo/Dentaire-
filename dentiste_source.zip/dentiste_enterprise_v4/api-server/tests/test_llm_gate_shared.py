"""Tests — core/llm_client.get_llm_if_enabled

Verrouille le garde-fou partagé utilisé par copilote_crm.py ET
ia_dentaire.py : le traitement IA doit être explicitement activé,
sauf si un client est déjà injecté par l'appelant (tests, etc.).
"""
from types import SimpleNamespace
from unittest.mock import AsyncMock

from core.llm_client import get_llm_if_enabled


def _settings(copilote_ia_enabled: bool):
    return SimpleNamespace(copilote_ia_enabled=copilote_ia_enabled, llm_provider="openai")


def test_returns_none_when_disabled_and_no_client_injected(monkeypatch):
    import core.llm_client as mod
    monkeypatch.setattr(mod, "get_llm_client", lambda settings: (_ for _ in ()).throw(
        AssertionError("ne doit jamais être appelé quand désactivé")
    ))
    assert get_llm_if_enabled(_settings(False), None) is None


def test_returns_factory_client_when_enabled(monkeypatch):
    import core.llm_client as mod
    fake = AsyncMock()
    monkeypatch.setattr(mod, "get_llm_client", lambda settings: fake)
    assert get_llm_if_enabled(_settings(True), None) is fake


def test_injected_client_wins_even_when_disabled():
    """Un client explicitement fourni par l'appelant (typiquement les
    tests) doit toujours être utilisé, indépendamment du flag — le flag
    ne gate que la création automatique via la config globale."""
    injected = AsyncMock()
    assert get_llm_if_enabled(_settings(False), injected) is injected


def test_injected_client_wins_when_enabled_too():
    injected = AsyncMock()
    assert get_llm_if_enabled(_settings(True), injected) is injected
