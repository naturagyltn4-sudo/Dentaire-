"""Tests — Bloc 3 : Gestion des salles et fauteuils"""

import pytest
from datetime import datetime
from services.agenda import creer_rdv
from models.database import Salle


@pytest.mark.asyncio
async def test_conflit_salle_fauteuil_meme_creneau(
    db, medecin, assistante, patient, acte
):
    # 1. Créer une salle
    salle = Salle(clinic_id=1, nom="Bloc Opératoire A", capacite_fauteuils=2)
    db.add(salle)
    await db.flush()

    debut = datetime(2026, 8, 10, 14, 0)

    # 2. Créer un premier RDV dans cette salle, fauteuil 1
    await creer_rdv(
        patient_id=patient.id,
        praticien_id=medecin.id,
        acte_id=acte.id,
        date_heure=debut,
        salle_id=salle.id,
        fauteuil_numero=1,
        db=db,
    )

    # 3. Tenter de créer un deuxième RDV même salle, même fauteuil, même créneau, praticien différent
    # Doit être refusé
    with pytest.raises(ValueError, match="[Cc]onflit.*fauteuil"):
        await creer_rdv(
            patient_id=patient.id,
            praticien_id=assistante.id,
            acte_id=acte.id,
            date_heure=debut,
            salle_id=salle.id,
            fauteuil_numero=1,
            db=db,
        )


@pytest.mark.asyncio
async def test_salle_capacite_fauteuils(db, medecin, assistante, patient, acte):
    # 1. Créer une salle avec 1 seul fauteuil
    salle = Salle(clinic_id=1, nom="Petite Salle", capacite_fauteuils=1)
    db.add(salle)
    await db.flush()

    debut = datetime(2026, 8, 10, 15, 0)

    # 2. Réserver le seul fauteuil (sans spécifier le numéro, juste la salle)
    await creer_rdv(
        patient_id=patient.id,
        praticien_id=medecin.id,
        acte_id=acte.id,
        date_heure=debut,
        salle_id=salle.id,
        db=db,
    )

    # 3. Tenter de réserver la salle à nouveau (elle est pleine)
    with pytest.raises(ValueError, match="[Cc]onflit.*salle.*complet"):
        await creer_rdv(
            patient_id=patient.id,
            praticien_id=assistante.id,
            acte_id=acte.id,
            date_heure=debut,
            salle_id=salle.id,
            db=db,
        )


@pytest.mark.asyncio
async def test_meme_salle_fauteuils_differents_ok(
    db, medecin, assistante, patient, acte
):
    # 1. Créer une salle avec 2 fauteuils
    salle = Salle(clinic_id=1, nom="Salle Double", capacite_fauteuils=2)
    db.add(salle)
    await db.flush()

    debut = datetime(2026, 8, 10, 16, 0)

    # 2. Réserver fauteuil 1
    rdv1, _ = await creer_rdv(
        patient_id=patient.id,
        praticien_id=medecin.id,
        acte_id=acte.id,
        date_heure=debut,
        salle_id=salle.id,
        fauteuil_numero=1,
        db=db,
    )

    # 3. Réserver fauteuil 2 (doit passer car fauteuil différent)
    rdv2, _ = await creer_rdv(
        patient_id=patient.id,
        praticien_id=assistante.id,
        acte_id=acte.id,
        date_heure=debut,
        salle_id=salle.id,
        fauteuil_numero=2,
        db=db,
    )

    assert rdv1.id != rdv2.id
    assert rdv2.salle_id == salle.id
    assert rdv2.fauteuil_numero == 2
