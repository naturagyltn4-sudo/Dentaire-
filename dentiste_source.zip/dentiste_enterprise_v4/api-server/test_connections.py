
import asyncio
import redis.asyncio as redis
from sqlalchemy.ext.asyncio import create_async_engine
from config import get_settings

async def test_redis():
    settings = get_settings()
    r = redis.from_url(settings.redis_url)
    await r.set("test_key", "test_value")
    val = await r.get("test_key")
    await r.delete("test_key")
    assert val == b"test_value"
    print("Redis: OK")

async def test_postgres():
    settings = get_settings()
    engine = create_async_engine(settings.database_url)
    from sqlalchemy import text
    async with engine.connect() as conn:
        result = await conn.execute(text("SELECT 1"))
        assert result.scalar() == 1
    print("PostgreSQL: OK")

if __name__ == "__main__":
    asyncio.run(test_redis())
    asyncio.run(test_postgres())
