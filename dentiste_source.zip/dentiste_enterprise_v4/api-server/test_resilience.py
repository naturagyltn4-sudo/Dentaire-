
import requests
import subprocess
import time

def check_readiness():
    try:
        response = requests.get("http://localhost:8000/ready")
        return response.status_code, response.json()
    except Exception as e:
        return 500, str(e)

def test_db_down():
    print("Testing DB down...")
    subprocess.run(["sudo", "service", "postgresql", "stop"])
    time.sleep(2)
    status, body = check_readiness()
    print(f"Status: {status}, Body: {body}")
    subprocess.run(["sudo", "service", "postgresql", "start"])
    time.sleep(2)
    assert status == 503
    assert "DB non disponible" in body.get("detail", "")

def test_redis_down():
    # Since readiness check in main.py only checks DB, 
    # we might need to check another route that uses Redis if available.
    # But let's check if the app handles it gracefully.
    print("Testing Redis down...")
    subprocess.run(["sudo", "service", "redis-server", "stop"])
    time.sleep(2)
    # We don't have a specific redis check in /ready, but let's see if /health still works
    response = requests.get("http://localhost:8000/health")
    print(f"Health status with Redis down: {response.status_code}")
    subprocess.run(["sudo", "service", "redis-server", "start"])
    time.sleep(2)
    assert response.status_code == 200

if __name__ == "__main__":
    test_db_down()
    test_redis_down()
