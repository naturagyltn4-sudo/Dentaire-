# Plan d’action de correction et d’évolution — Dentiste Enterprise

**Périmètre :** correction des constats d’audit et implantation progressive de la nouvelle vision métier.  
**Contrainte directrice :** déploiement sur **un seul VPS**, avec une architecture simple, maîtrisée, sauvegardée et exploitable par une petite équipe.  
**Principe :** ne pas ajouter une deuxième infrastructure, ne pas distribuer prématurément les services et ne pas recréer les modules déjà présents.

> **Décision d’architecture :** conserver Docker Compose sur un seul VPS, avec PostgreSQL, Redis, API privée, API publique, worker Celery, Beat, frontend privé, gateway public et Nginx hôte. La distribution logique des services est utile ; la distribution physique ne l’est pas encore.

## 1. Position de départ

L’audit montre un socle riche : backend FastAPI/SQLAlchemy, frontend React/Vite, authentification JWT avec refresh rotatif, MFA, RBAC par rôle, contexte de clinique, modules patients, agenda, dossiers, radiologie, prothèses, devis, facturation, stock, CRM, omnicanal, téléconsultation, analytics, équipe, RH et rappels. La suite backend compte **542 tests réussis et 6 tests ignorés**, avec une couverture indicative d’environ **73 %**.

Le projet n’est toutefois pas publiable tel quel. Les contrôles fournis bloquent sur la configuration de production et Ruff détecte une redéfinition de route dans le module d’équipe. La première étape n’est donc pas le développement de nouvelles fonctions, mais la sécurisation et la stabilisation du système existant.

| Élément audité | Situation actuelle | Conséquence |
|---|---|---|
| Déploiement | Compose mono-VPS déjà prévu | Bonne base ; il faut le finaliser plutôt que changer de plateforme. |
| Backend | Fonctionnel selon les tests, lint non propre | Correction obligatoire avant release. |
| Frontend | Typecheck, tests et build réussis | Validation navigateur et UX encore nécessaires. |
| Surface publique | API publique dédiée, mais routes publiques également dans l’API principale | Risque de confusion et de mauvaise exposition réseau. |
| Sécurité production | Secrets et TLS non finalisés dans l’état livré | Blocage absolu avant mise en ligne. |
| Vision métier | Plusieurs briques existent déjà partiellement | Il faut enrichir et relier, pas recréer. |

## 2. Architecture cible sur un seul VPS

Le VPS héberge une seule instance Docker Compose. PostgreSQL et Redis ne sont jamais publiés sur Internet. Le Nginx hôte est le seul point d’entrée externe sur les ports 80 et 443. Il termine TLS, redirige HTTP vers HTTPS et distribue les requêtes vers le gateway public ou le frontend privé selon le domaine ou le chemin choisi.

| Couche | Composant | Exposition recommandée |
|---|---|---|
| Internet | Nginx hôte | Ports 80/443 uniquement |
| Frontend public | `public_gateway` | Accessible seulement depuis Nginx hôte |
| API publique | `public_api` | Accessible seulement via `public_gateway` et réseau Docker nécessaire |
| Frontend privé | `private_frontend` | Accessible seulement depuis Nginx hôte, idéalement sur une interface locale |
| API privée | `private_api` | Réseau Docker privé ; aucune publication Internet directe |
| Traitements asynchrones | `worker` et `beat` | Réseau Docker privé uniquement |
| Données | PostgreSQL | Réseau Docker privé, volume persistant |
| File/cache | Redis | Réseau Docker privé, authentification activée |
| Sauvegardes | Service ou timer dédié | Volume local chiffré puis copie hors VPS |

Le mono-VPS devient un **point unique de panne**. Cela est acceptable à ce stade uniquement si les données sont sauvegardées chiffrées hors de la machine, si la restauration est régulièrement testée et si la procédure de reconstruction du VPS est documentée. Une sauvegarde conservée uniquement sur le VPS ne constitue pas une stratégie de continuité suffisante.

### Deux variantes compatibles avec la contrainte mono-VPS

| Approche | Avantages | Limites | Décision proposée |
|---|---|---|---|
| Docker Compose + Nginx hôte | Reproduit l’organisation déjà livrée, isole les services, simplifie les rollback et les healthchecks | Consomme davantage de mémoire qu’un déploiement natif | **Recommandée** pour ce projet. |
| Services Python/Node natifs + systemd + PostgreSQL/Redis système | Plus légère et directe sur un petit VPS | Déploiement, isolation et rollback plus complexes ; divergence avec l’archive actuelle | Alternative seulement si le VPS est très limité ou si Docker est interdit. |

Il ne faut pas introduire Kubernetes, plusieurs VPS, un service de queue externe ou une architecture microservices distribuée avant un besoin réel de montée en charge. Cela augmenterait la complexité opérationnelle sans corriger les défauts actuels.

## 3. Phase P0 — Bloqueurs à corriger avant toute production

Cette phase clôture les problèmes qui ont conduit au statut **À corriger avant mise en production**. Aucun développement métier ne doit être considéré comme livrable production tant que ces points ne sont pas fermés.

| ID | Correction | Travail concret | Preuve attendue |
|---|---|---|---|
| P0-01 | Secrets de production | Générer `SECRET_KEY`, `FERNET_KEY`, `PHOTO_ENCRYPTION_KEY` et `BACKUP_ENCRYPTION_KEY` indépendantes ; définir PostgreSQL, Redis, comptes admin et tokens externes hors du dépôt. | Le script `pre_deploy_security_check.py` passe sans erreur ; aucun secret dans Git, image, bundle ou logs. |
| P0-02 | Fichier d’environnement | Utiliser un fichier `.env` avec permissions `0600`, propriétaire du compte de déploiement, jamais copié dans les images. | Inspection de l’image et du dépôt ; vérification des permissions. |
| P0-03 | TLS et domaine | Remplacer `server_name _`, les certificats placeholders et les chemins de test par le domaine réel ; activer redirection HTTPS et HSTS après validation. | Test Nginx réussi, certificat valide, HTTPS fonctionnel depuis l’extérieur. |
| P0-04 | Pare-feu VPS | Autoriser uniquement SSH contrôlé, HTTP et HTTPS ; interdire les ports PostgreSQL, Redis, API et frontends sur Internet. | Scan externe limité aux ports attendus ; règles documentées. |
| P0-05 | Route dupliquée | Supprimer la seconde définition de `GET /membres` dans `api/v1/equipe.py`. | `ruff check .` retourne zéro erreur. |
| P0-06 | Frontière public/privé | Décider que `public_api` est l’unique surface publique ; retirer ou verrouiller les routes publiques exposées par l’API privée, selon le schéma réseau final. | Test réseau prouvant qu’un accès public ne peut pas atteindre les routes cliniques privées. |
| P0-07 | Readiness | Faire vérifier à l’API publique une dépendance DB minimale, comme le fait déjà l’API privée, sans retourner d’informations sensibles. | Arrêt contrôlé de PostgreSQL : service public marqué non-ready. |
| P0-08 | Cookies et CSRF | Documenter et tester le flux `HttpOnly`, `Secure`, `SameSite`, le chemin du cookie et la protection CSRF des mutations sensibles. | Tests négatifs CSRF et vérification des cookies en HTTPS. |
| P0-09 | Uploads | Uniformiser la taille maximale, le contrôle MIME/signature, le nommage, le stockage hors répertoire public et les réponses d’erreur pour tous les uploads. | Tests de fichiers trop volumineux, malformés, polyglottes et non autorisés. |
| P0-10 | Sauvegarde restaurable | Chiffrer PostgreSQL et fichiers, copier la sauvegarde hors VPS et effectuer une restauration complète sur un environnement isolé. | Procès-verbal de restauration avec durée, résultat et données vérifiées. |

### Critère de sortie P0

La phase est terminée uniquement lorsque le contrôle de sécurité passe, que le lint passe, que les ports externes sont limités à ceux prévus, que TLS est réel et qu’une restauration de sauvegarde a été réussie. Le statut peut alors évoluer de **Non approuvé** vers **Staging autorisé**, mais pas encore vers production définitive.

## 4. Phase P1 — Stabilisation technique de l’existant

Après les bloqueurs, il faut valider les scénarios critiques sans ajouter de nouvelles surfaces fonctionnelles. L’objectif est de transformer les bons résultats unitaires en garantie de fonctionnement intégré.

| Parcours | Vérifications obligatoires |
|---|---|
| Connexion et MFA | Login normal, challenge MFA, OTP invalide, verrouillage, refresh, logout et révocation. |
| Isolation clinique | Utilisateur d’une clinique ne pouvant lire, modifier ou télécharger les données d’une autre clinique. |
| Permissions | Vérification serveur pour chaque rôle ; le masquage frontend ne doit jamais être la seule barrière. |
| Réservation publique | Acte/praticien actif, date future, timezone, doublon, conflit concurrent, approbation et rejet. |
| Dossier patient | Lecture, modification, photos, radiologie, historique et accès refusé selon le rôle. |
| Facturation et devis | Montants, statuts, paiements, exports et contrôle des accès. |
| Stock | Lot, expiration, seuil, QR/barcode, permissions et transaction concurrente. |
| Omnicanal | Timeout fournisseur, réponse d’erreur, reprise, idempotence et absence de données médicales dans les logs. |
| IA | Fonction désactivée par défaut, pseudonymisation, quotas tenant, erreurs fournisseur et traçabilité. |
| Jobs Celery/Beat | Reprise après redémarrage, doublon évité, tâche échouée visible et file Redis protégée. |

Le frontend doit recevoir des tests navigateur sur les parcours login/MFA, réservation, rendez-vous, patient, facture et permissions. Le test frontend actuel est utile mais limité à trois fichiers et seize tests ; il ne constitue pas une preuve suffisante pour une application de cette taille.

## 5. Phase P2 — Vue patient 360° et « À faire aujourd’hui »

C’est la première évolution métier à développer, car elle valorise presque tous les modules déjà présents sans les remplacer. Il ne faut pas créer une nouvelle base patient parallèle. La fiche doit devenir une vue de synthèse composée à partir des patients, rendez-vous, dossiers, devis, factures, paiements, radiologies, photos, odontogrammes, prothèses et suivis post-opératoires existants.

| Bloc | Contenu proposé | Réutilisation attendue |
|---|---|---|
| Identité | Coordonnées, contact d’urgence, préférences de communication | Modèle patient et consentements existants |
| Parcours | Dernier rendez-vous, prochain rendez-vous, absences, praticien | Agenda existant |
| Médical | Antécédents, allergies, notes autorisées par rôle | Dossier médical chiffré et RBAC |
| Financier | Devis, factures, paiements, reste à payer | Modules devis/facturation |
| Traitements | Actes réalisés, prothèses, radiologie, postopératoire | Modules dentaires existants |
| Actions | Contrôle à planifier, traitement à poursuivre, devis à relancer, paiement restant | Rappels et workflow existants |

La zone « À faire aujourd’hui » doit être calculée côté serveur avec des règles explicites, filtrée selon le rôle et ordonnée par criticité. Elle ne doit pas exposer à une assistante ou à un commercial les contenus médicaux auxquels leur rôle ne donne pas accès.

### Critères de sortie P2

La fiche patient doit afficher une synthèse cohérente en moins de quelques appels API, ne pas dupliquer les données sources, appliquer le RBAC serveur, afficher des dates dans le fuseau configuré et fournir un lien direct vers chaque module détaillé. Les tests doivent couvrir patient sans dossier, patient avec plusieurs devis, paiement partiel, suivi postopératoire manquant et permissions différenciées.

## 6. Phase P3 — Plans de traitement

Le plan de traitement est l’évolution métier la plus différenciante. Il doit être conçu comme une couche d’orchestration au-dessus des rendez-vous, actes, devis et suivis, pas comme un remplacement de l’agenda.

| Objet métier | Rôle |
|---|---|
| Plan de traitement | Regroupe une prise en charge pour un patient, avec titre, diagnostic ou objectif, praticien responsable, statut et dates. |
| Étape | Représente consultation, radio, chirurgie, prothèse, contrôle ou autre action. |
| Lien opérationnel | Référence vers un rendez-vous, un acte, un devis, une prothèse ou un suivi existant. |
| Statut | À faire, planifiée, en cours, terminée, annulée ou bloquée. |
| Progression | Pourcentage et résumé calculés à partir des étapes, sans saisie incohérente parallèle. |
| Échéance | Date cible et rappel éventuel, soumis aux règles de notification. |

Pour l’orthodontie, le modèle doit pouvoir représenter un nombre de séances prévues, réalisées et restantes, mais il ne faut pas créer un module orthodontique isolé si les données existantes peuvent être rattachées aux étapes du plan.

### Critères de sortie P3

Un utilisateur autorisé peut créer un plan, ajouter des étapes, rattacher un rendez-vous ou un devis, changer le statut et consulter une progression. Une mise à jour doit être transactionnelle, historisée et protégée contre les modifications inter-cliniques. Les tests doivent vérifier suppression ou annulation d’une étape, rendez-vous déplacé, devis refusé, étape terminée et conflit de droits.

## 7. Phase P4 — Fiche personnel et rattachement du pointage

La fiche personnel doit compléter `Utilisateur` sans surcharger le modèle d’authentification. Les informations d’identité et d’accès restent dans `Utilisateur`. Les informations professionnelles et RH légères peuvent être placées dans une table `PersonnelProfile` liée par `user_id` et `clinic_id`.

| Domaine | Données | Règle de sécurité |
|---|---|---|
| Profil | Photo, téléphone, adresse, fonction, spécialité | Visible selon rôle ; ne pas exposer publiquement l’adresse. |
| Parcours | Date d’embauche, diplômes, spécialisations, certifications | Accès direction/admin uniquement pour les documents sensibles. |
| Documents | Métadonnées, fichier chiffré, date d’expiration | Stockage privé, contrôle MIME et journal d’accès. |
| Notes | Notes internes et statut actif/inactif | Jamais inclus dans les réponses publiques ou listes minimales. |
| Présence | Heures, présence, corrections, historique mensuel | Rattachement obligatoire à l’utilisateur et à la clinique. |

Le pointage existe déjà dans le parcours frontend. Le travail doit donc commencer par une cartographie de ses tables et endpoints, puis par la vérification de l’intégrité du rattachement personnel. Il ne faut pas reconstruire un second système de pointage.

### Critères de sortie P4

La direction peut gérer une fiche personnel légère, le pointage affiche des historiques cohérents, les corrections sont historisées, et les documents ne sont jamais accessibles aux rôles non autorisés. Les tests doivent couvrir départ d’un collaborateur, désactivation, changement de rôle, correction d’heure et séparation inter-clinique.

## 8. Phase P5 — Rappels dentaires intelligents sans nouveau CRM

Les rappels et le CRM existent déjà. L’objectif est de les consolider dans un moteur de règles explicite qui utilise Celery/Beat déjà présents sur le mono-VPS. Aucun nouveau CRM ne doit être créé.

| Règle | Déclencheur | Garde-fou |
|---|---|---|
| Contrôle périodique | Dernier acte ou dernière visite | Consentement et préférence de contact. |
| Détartrage | Échéance configurable | Déduplication et plage horaire d’envoi. |
| Post-chirurgie | Suivi planifié non effectué | Escalade vers équipe, pas d’automatisation médicale non validée. |
| Implant | Contrôle attendu | Validation du praticien si contenu sensible. |
| Prothèse | Vérification à échéance | Rattachement au plan de traitement. |
| Traitement incomplet | Étape non terminée après délai | Ne pas envoyer si patient opt-out. |
| Devis non accepté | Devis envoyé sans réponse | Limite de fréquence et journalisation. |
| Rendez-vous manqué | Statut no-show | Pas de relance multiple accidentelle. |

Chaque règle doit produire un événement traçable : patient ciblé, clinique, règle, canal, résultat, erreur éventuelle et prochaine tentative. Les messages ne doivent jamais contenir plus d’informations que nécessaire. La répétition doit être contrôlée par une clé d’idempotence.

### Critères de sortie P5

Une règle peut être activée ou désactivée par clinique, possède une fréquence maximale, respecte les consentements et ne crée pas de doublon après redémarrage du worker. Un échec fournisseur est visible dans l’interface et peut être repris sans renvoyer indûment les messages déjà délivrés.

## 9. Exploitation quotidienne du mono-VPS

Un seul VPS exige une discipline d’exploitation plus stricte qu’une architecture distribuée, car une panne de la machine affecte l’ensemble du service. La simplicité doit être compensée par la visibilité et la restaurabilité.

| Contrôle | Mise en œuvre recommandée |
|---|---|
| Redémarrage | `restart: unless-stopped`, healthchecks et ordre de démarrage Compose. |
| Disque | Alerte sur espace disponible, croissance PostgreSQL, volumes et backups. |
| Mémoire | Limites par conteneur, surveillance OOM et réduction des workers si nécessaire. |
| Logs | Rotation, durée limitée, absence de données médicales et conservation séparée des audits. |
| Mises à jour | Fenêtre de maintenance, snapshot ou backup avant mise à jour, rollback documenté. |
| SSH | Clés uniquement, compte non-root, restriction IP si possible, protection contre bruteforce. |
| Sauvegardes | Base, fichiers et configuration chiffrés ; copie hors VPS ; test de restauration périodique. |
| Monitoring | `/health`, `/ready`, métriques locales, alertes disque/mémoire/HTTP 5xx/worker. |
| Déploiement | Build immuable, migration Alembic contrôlée, smoke tests et retour à la version précédente. |

Le timer de backup ne doit pas être le seul mécanisme de confiance. Une alerte doit être déclenchée si aucune sauvegarde récente n’est disponible ou si la taille du backup devient anormale. La copie hors VPS peut être un stockage objet compatible S3 ou un autre espace de sauvegarde, mais elle doit être indépendante de la machine principale.

## 10. Pipeline de livraison et portes de sortie

Chaque livraison doit passer par des portes simples et répétables. La pipeline ne doit pas seulement lancer les tests ; elle doit empêcher un déploiement avec configuration dangereuse.

| Porte | Conditions |
|---|---|
| Qualité | Compilation Python, `ruff check .`, TypeScript strict et formatage. |
| Tests | Suite Pytest, tests frontend, tests navigateur critiques et tests négatifs de sécurité. |
| Build | Build frontend et images Docker reproductibles. |
| Configuration | Aucun secret par défaut, `ENV=production`, CORS réel, domaine réel et TLS validé. |
| Base | Une seule tête Alembic et migration testée sur copie de staging. |
| Sécurité | Ports, headers, cookies, CSRF, uploads, RBAC et isolation tenant vérifiés. |
| Exploitation | Healthchecks, logs, métriques, backup récent et restauration validée. |
| Validation métier | Scénarios patient, rendez-vous, traitement, facture, rappel et rôles approuvés. |

## 11. Ordre global recommandé

| Phase | Objectif | Ne pas commencer avant |
|---:|---|---|
| **0** | Secrets, TLS, firewall, frontière public/privé, Ruff et backup restaurable | Rien ; c’est le socle obligatoire. |
| **1** | Tests intégrés et validation des flux existants | Phase 0 clôturée. |
| **2** | Vue patient 360° et « À faire aujourd’hui » | Flux patient et RBAC validés. |
| **3** | Plans de traitement | Données rendez-vous, actes, devis et suivis stabilisées. |
| **4** | Fiche personnel légère et liaison pointage | Modèle utilisateur et permissions confirmés. |
| **5** | Rappels dentaires configurables | Consentements, canaux et jobs Celery/Beat validés. |
| **6** | UAT, accessibilité, performance, restauration et production progressive | Toutes les phases fonctionnelles terminées. |

## 12. Décision finale de pilotage

Je recommande de **geler l’ajout de nouveaux modules pendant la phase 0 et la phase 1**. Le mono-VPS n’est pas un problème pour ce niveau de produit si PostgreSQL et Redis restent privés, si Nginx est le seul point d’entrée, si les limites de ressources sont surveillées et si les sauvegardes sont externalisées.

La nouvelle vision doit ensuite être implantée sous forme de trois extensions prioritaires : **patient 360°**, **plans de traitement**, puis **personnel/pointage**. Les rappels doivent être traités comme une consolidation du moteur existant. Le projet ne doit pas recevoir une nouvelle comptabilité, un nouveau CRM, une nouvelle gestion de stock, une paie complète ou une nouvelle IA médicale sans justification métier et validation de sécurité.

> **Critère de réussite global :** le produit est prêt lorsque le mono-VPS peut être reconstruit, sécurisé, restauré et surveillé ; lorsque les parcours critiques sont validés avec les dépendances réelles ; et lorsque les nouvelles fonctions réutilisent les données existantes sans créer de doublons fonctionnels ou de fuites de permissions.

## Références internes

[1]: ./docker-compose.production.yml "Services et réseaux de production"
[2]: ./api-server/config.py "Configuration, secrets et paramètres métier"
[3]: ./api-server/scripts/pre_deploy_security_check.py "Contrôle pré-déploiement"
[4]: ./infrastructure/nginx/production.conf "Configuration Nginx de production"
[5]: ./api-server/api/v1/equipe.py "Route d’équipe dupliquée"
[6]: ./api-server/main.py "API privée, readiness et métriques"
[7]: ./api-server/public_main.py "API publique"
[8]: ./api-server/middleware/auth.py "JWT, sessions et rotation des refresh tokens"
[9]: ./api-server/middleware/clinic_rbac.py "Matrice des rôles et permissions"
[10]: ./api-server/services/reservation_publique.py "Workflow de réservation publique"
[11]: ./validation-private-frontend/client/src/App.tsx "Routes frontend et modules existants"
[12]: ./validation-private-frontend/client/src/lib/api.ts "Client API, cookies et rafraîchissement"
[13]: ./api-server/models/database.py "Modèle utilisateur et structures métier"
