# Dentiste Enterprise V4 — Déploiement mono-VPS

## Statut et précondition

Cette release est une **release candidate corrigée et vérifiée localement** pour un déploiement Docker Compose sur un seul VPS. Elle ne contient aucun secret, certificat ou domaine réel. Elle n’est donc pas une preuve de production live : le VPS opérateur doit encore exécuter les migrations PostgreSQL, les tests réseau/TLS, le test de restauration et les parcours navigateur avec des comptes de test.

L’architecture reste volontairement mono-VPS : Nginx hôte, frontend privé, API, PostgreSQL, Redis, worker Celery et scheduler. Les sauvegardes doivent être copiées vers un stockage hors VPS ; cela ne transforme pas l’application en architecture distribuée.

## Installation initiale

```bash
sudo mkdir -p /opt/dentiste-enterprise
sudo chown -R "$USER":"$USER" /opt/dentiste-enterprise
unzip dentiste_final_v4.zip -d /opt/dentiste-enterprise
cd /opt/dentiste-enterprise/dentiste_production_v2
sudo install -m 600 .env.example /etc/dentiste.env
```

Remplacer toutes les valeurs `CHANGE_ME` dans `/etc/dentiste.env`. Ce fichier doit rester hors Git et hors des images Docker. Les clés `SECRET_KEY`, `FERNET_KEY`, `PHOTO_ENCRYPTION_KEY` et `BACKUP_ENCRYPTION_KEY` doivent être indépendantes ; les clés Fernet doivent être générées avec un outil de confiance et validées avant déploiement.

## Choix explicite des fonctionnalités P02

La téléconsultation et l’agent médecin sont **désactivés par défaut**. Ne les activer qu’après validation du fournisseur, du compte Meta, des autorisations, du consentement et des procédures cliniques.

| Variable | Valeur de sécurité initiale | Effet |
|---|---:|---|
| `TELECONSULTATION_ENABLED` | `false` | Bloque la création de nouvelles téléconsultations lorsqu’elle est désactivée. |
| `DAILY_REQUIRED_IN_PRODUCTION` | `true` | Interdit le démarrage fonctionnel sans Daily.co quand la téléconsultation est activée. |
| `PRACTITIONER_AGENT_ENABLED` | `false` | N’active pas le routage WhatsApp vers l’agent médecin. |
| `DAILY_ENABLE_RECORDING` | `false` | Empêche l’enregistrement par défaut. |

Si `TELECONSULTATION_ENABLED=true`, renseigner `DAILY_API_KEY`, conserver `DAILY_API_BASE` en HTTPS et vérifier les engagements contractuels et réglementaires du fournisseur avant d’utiliser des données de santé. Si `PRACTITIONER_AGENT_ENABLED=true`, renseigner ensemble `WA_BUSINESS_TOKEN_PRATICIEN`, `WA_PHONE_ID_PRATICIEN` et `WA_WEBHOOK_VERIFY_TOKEN_PRATICIEN`, activer la téléconsultation et fournir Daily.co.

La ligne praticien est distincte de la ligne WhatsApp cabinet. Le webhook vérifie le tenant mono-VPS, la whitelist praticien active et non expirée, le praticien associé, puis une téléconsultation active avec `consent_url` HTTPS. Sans ces conditions, aucun appel à l’agent médecin n’est effectué. Le routage agent médecin reste désactivé en production tant que `PRACTITIONER_AGENT_ENABLED=false`.

## Préflight obligatoire

```bash
export DEPLOY_ENV_FILE=/etc/dentiste.env
./scripts/production_preflight.sh
```

Le préflight vérifie le fichier privé, les secrets critiques, `ENV=production`, le domaine, CORS, l’indépendance des clés, la présence du script de backup hors VPS, la configuration Compose et les dépendances P02 conditionnelles. Un échec doit être corrigé ; il ne faut pas contourner le script avec des valeurs fictives.

## TLS, Nginx et démarrage

Après validation DNS, installer le certificat avec le script fourni, puis vérifier Nginx :

```bash
sudo DOMAIN=clinic.example.tld EMAIL=ops@example.tld \
  ./infrastructure/scripts/provision_nginx.sh
sudo nginx -t
sudo systemctl reload nginx
```

Les ports internes doivent rester liés à `127.0.0.1` et ne doivent pas être ouverts au pare-feu. Démarrer ensuite la stack :

```bash
export DEPLOY_ENV_FILE=/etc/dentiste.env
docker compose --env-file "$DEPLOY_ENV_FILE" -f docker-compose.production.yml config
docker compose --env-file "$DEPLOY_ENV_FILE" -f docker-compose.production.yml build
docker compose --env-file "$DEPLOY_ENV_FILE" -f docker-compose.production.yml up -d
docker compose --env-file "$DEPLOY_ENV_FILE" -f docker-compose.production.yml ps
```

Attendre la fin réussie du service de migration avant de considérer l’API disponible. Vérifier les healthchecks internes puis l’URL HTTPS publique. Ne pas déclarer la migration réussie sur la seule base d’un `compose config`.

## Sauvegarde et restauration

Configurer `BACKUP_OFFSITE_SCRIPT` vers un script administrateur qui chiffre et copie réellement les sauvegardes vers un stockage hors VPS. Exécuter au minimum une sauvegarde manuelle et une restauration dans un environnement isolé avant l’ouverture publique, puis planifier des exercices périodiques. La présence d’un fichier de backup ne prouve pas sa restaurabilité.

```bash
docker compose --env-file "$DEPLOY_ENV_FILE" --profile backup \
  -f docker-compose.production.yml run --rm backup_init
docker compose --env-file "$DEPLOY_ENV_FILE" --profile backup \
  -f docker-compose.production.yml run --rm backup
```

## Smoke test et contrôle RBAC

Tester depuis l’extérieur le domaine HTTPS, la landing, les routes publiques, le refus des routes privées par le gateway public et le login privé. Avec des comptes de test séparés, vérifier les rôles admin, médecin, assistante et personnel, ainsi que MFA, patient 360°, plans de traitement, omnicanal assigné et téléconsultation consentie.

Inspecter les logs après chaque scénario. Ils ne doivent pas contenir de tokens, secrets ou données médicales en clair. Vérifier aussi l’expiration/révocation des whitelists et l’impossibilité d’utiliser une téléconsultation ou un tenant étranger.

## Rollback et limites

Avant chaque release, conserver l’image précédente, la version déployée et une sauvegarde récente. En cas d’échec, arrêter la version courante, revenir à l’image précédente, restaurer uniquement selon la procédure approuvée et rejouer les healthchecks. Les migrations destructives exigent une sauvegarde et une stratégie de retour séparée.

La validation locale V4 ne couvre pas Docker, PostgreSQL live, Redis live, TLS réel, Meta/WhatsApp, Daily.co, la restauration hors VPS, la charge ou la conformité contractuelle. Le statut honnête est donc **Ready to Go après configuration et gates live**, et non « production immédiatement certifiée ».
