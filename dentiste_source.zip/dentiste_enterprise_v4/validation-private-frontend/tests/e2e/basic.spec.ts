
import { test, expect } from '@playwright/test';

test('landing page shows the clinic heading', async ({ page }) => {
  await page.goto('/');
  const heading = page.locator('h1').first();
  await expect(heading).toBeVisible();
  await expect(heading).not.toBeEmpty();
});

test('login page is accessible', async ({ page }) => {
  await page.goto('/login');
  await expect(page.locator('form')).toBeVisible();
});
