import { test, expect } from "@playwright/test";

test("public booking form loads options and submits a synthetic request", async ({ page }) => {
  test.setTimeout(60_000);
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /Demander un rendez-vous/i })).toBeVisible();
  await expect(page.locator("#praticien-select option")).toHaveCount(2);
  await expect(page.locator("#acte-select option")).toHaveCount(2);
  await page.locator('input[name="nom"]').fill("E2E");
  await page.locator('input[name="prenom"]').fill("Public");
  await page.locator('input[name="telephone"]').fill(`+216${String(Date.now()).slice(-8)}`);
  await page.locator("#praticien-select").selectOption({ index: 1 });
  await page.locator("#acte-select").selectOption({ index: 1 });
  const date = new Date(Date.now() + 24 * 60 * 60 * 1000);
  const localDate = new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
  await page.locator('input[name="date_heure"]').fill(localDate);
  const responsePromise = page.waitForResponse(
    (response) => response.url().endsWith("/api/v1/public/reservation") && response.request().method() === "POST",
  );
  await page.getByRole("button", { name: /Envoyer la demande/i }).click();
  const response = await responsePromise;
  expect(response.ok()).toBeTruthy();
  await expect(page.locator("#booking-status")).toContainText(/Demande reçue/i);
});
