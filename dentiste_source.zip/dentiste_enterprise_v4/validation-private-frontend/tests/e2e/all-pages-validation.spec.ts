import { createHmac } from "node:crypto";
import { test, expect, type Page } from "@playwright/test";

const E2E_EMAIL = process.env.E2E_PRIVATE_EMAIL || "e2e.directrice@validation.example.com";
const E2E_PASSWORD = process.env.E2E_PRIVATE_PASSWORD || "Validation-Pass-2026!Secure";
const TOTP_SECRET = process.env.E2E_PRIVATE_TOTP_SECRET || "JBSWY3DPEHPK3PXP";

function base32Decode(value: string): Buffer {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const normalized = value.replace(/=+$/g, "").toUpperCase();
  let bits = "";
  for (const character of normalized) {
    const index = alphabet.indexOf(character);
    if (index < 0) throw new Error(`Invalid base32 character: ${character}`);
    bits += index.toString(2).padStart(5, "0");
  }
  const bytes: number[] = [];
  for (let offset = 0; offset + 8 <= bits.length; offset += 8) {
    bytes.push(Number.parseInt(bits.slice(offset, offset + 8), 2));
  }
  return Buffer.from(bytes);
}

function currentTotp(secret: string): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 1000 / 30)));
  const digest = createHmac("sha1", base32Decode(secret)).update(counter).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binary =
    ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff);
  return String(binary % 1_000_000).padStart(6, "0");
}

async function login(page: Page): Promise<void> {
  await page.goto("/login");
  await page.locator("#email").fill(E2E_EMAIL);
  await page.locator("#password").fill(E2E_PASSWORD);
  await page.locator('button[type="submit"]').click();
  await expect(page).toHaveURL(/\/mfa-verify$/);
  await page.locator('input[inputmode="numeric"], input[autocomplete="one-time-code"]').first().fill(currentTotp(TOTP_SECRET));
  await page.getByRole("button", { name: "Vérifier", exact: true }).click();
  await expect(page).toHaveURL(/\/dashboard$/);
}

test("private frontend route matrix has no visible application error", async ({ page }) => {
  test.setTimeout(240_000);
  await login(page);
  const routes = [
    "/dashboard", "/dashboard-ia", "/workflows", "/copilote-crm", "/analytics", "/agenda",
    "/patients", "/patients/1", "/patients/1/360", "/patients/1/radiologie", "/patients/1/suivi-post-op",
    "/protheses", "/devis-dentaires", "/delegues", "/cephalometries", "/stock", "/invoices",
    "/commissions", "/loyalty", "/teleconsultation/1", "/recruitment", "/social", "/equipe",
    "/rh/pointage", "/personnel", "/settings/mfa", "/settings", "/super-admin", "/404",
  ];
  const failures: string[] = [];
  for (const route of routes) {
    const pageErrors: string[] = [];
    const onPageError = (error: Error) => pageErrors.push(error.message);
    page.on("pageerror", onPageError);
    try {
      await page.goto(route, { waitUntil: "domcontentloaded" });
      await expect(page.locator("body")).toBeVisible({ timeout: 15_000 });
      await page.waitForTimeout(500);
      const bodyText = await page.locator("body").innerText();
      if (/Application error|Unexpected Application Error|Cannot read properties of undefined/i.test(bodyText)) {
        failures.push(`${route}: visible application error`);
      }
      if (pageErrors.length > 0) failures.push(`${route}: ${pageErrors.join(" | ")}`);
    } catch (error) {
      failures.push(`${route}: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      page.off("pageerror", onPageError);
    }
  }
  expect(failures, failures.join("\n")).toEqual([]);
});
