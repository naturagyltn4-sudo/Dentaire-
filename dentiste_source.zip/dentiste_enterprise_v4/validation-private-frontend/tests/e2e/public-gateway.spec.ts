import { expect, test } from "@playwright/test";

test.describe("Public Gateway", () => {
  test("serves the public booking surface", async ({ page }) => {
    await page.goto("/");
    await expect(page).toHaveTitle(/Clinique dentaire/i);
    await expect(page.getByRole("heading", { name: /Votre sourire/i })).toBeVisible();
    await expect(page.getByRole("heading", { name: /Demander un rendez-vous/i })).toBeVisible();
    await expect(page.getByRole("textbox", { name: "Nom", exact: true })).toBeVisible();
    await expect(page.getByRole("button", { name: /Envoyer la demande/i })).toBeVisible();
  });

  test("exposes only public API paths", async ({ request }) => {
    const branding = await request.get("/api/v1/settings/branding");
    expect(branding.status()).toBe(200);

    const practitioners = await request.get("/api/v1/public/praticiens");
    expect(practitioners.status()).toBe(200);

    const privatePatients = await request.get("/api/v1/patients");
    expect(privatePatients.status()).toBe(404);

    const privateAdmin = await request.get("/api/v1/admin/users");
    expect(privateAdmin.status()).toBe(404);
  });
});
