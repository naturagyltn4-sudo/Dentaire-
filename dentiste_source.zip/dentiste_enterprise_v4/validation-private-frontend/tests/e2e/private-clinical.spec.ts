import { createHmac } from "node:crypto";
import { test, expect } from "@playwright/test";

const E2E_EMAIL = process.env.E2E_PRIVATE_EMAIL || "e2e.directrice@validation.example.com";
const E2E_PASSWORD = process.env.E2E_PRIVATE_PASSWORD || "Validation-Pass-2026!Secure";
const TOTP_SECRET = process.env.E2E_PRIVATE_TOTP_SECRET || "JBSWY3DPEHPK3PXP";

function base32Decode(value: string): Buffer {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const normalized = value.replace(/=+$/g, "").toUpperCase();
  let bits = "";
  for (const character of normalized) {
    const index = alphabet.indexOf(character);
    if (index < 0) throw new Error(`Invalid base32 character: ${character}`);
    bits += index.toString(2).padStart(5, "0");
  }
  const bytes: number[] = [];
  for (let offset = 0; offset + 8 <= bits.length; offset += 8) {
    bytes.push(Number.parseInt(bits.slice(offset, offset + 8), 2));
  }
  return Buffer.from(bytes);
}

async function navigateSpa(page: import("@playwright/test").Page, route: string): Promise<void> {
  await page.evaluate((nextRoute) => {
    window.history.pushState({}, "", nextRoute);
    window.dispatchEvent(new PopStateEvent("popstate"));
  }, route);
  await expect(page).toHaveURL(new RegExp(`${route}$`));
}

function currentTotp(secret: string): string {
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(Date.now() / 1000 / 30)));
  const digest = createHmac("sha1", base32Decode(secret)).update(counter).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binary =
    ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff);
  return String(binary % 1_000_000).padStart(6, "0");
}

test.describe("Private Clinical Core", () => {
  test("login MFA, clinical modules, patient dossier and logout", async ({ page, context }) => {
    test.setTimeout(180_000);

    await page.goto("/login");
    await expect(page.locator("#email")).toBeVisible();
    await page.locator("#email").fill(E2E_EMAIL);
    await page.locator("#password").fill(E2E_PASSWORD);
    await page.locator('button[type="submit"]').click();

    await expect(page).toHaveURL(/\/mfa-verify$/);
    await expect(page.getByText("Vérification en deux étapes")).toBeVisible();
    const otp = currentTotp(TOTP_SECRET);
    const otpInput = page.locator('input[inputmode="numeric"], input[autocomplete="one-time-code"]').first();
    await otpInput.fill(otp);
    await page.getByRole("button", { name: "Vérifier", exact: true }).click();

    await expect(page).toHaveURL(/\/dashboard$/);
    await expect(page.locator("main")).toBeVisible();

    const cookies = await context.cookies();
    expect(cookies.some((cookie) => cookie.name === "refresh_token")).toBeTruthy();
    const browserStorage = await page.evaluate(() => ({
      local: Object.keys(localStorage).join(" "),
      session: Object.keys(sessionStorage).join(" "),
    }));
    expect(`${browserStorage.local} ${browserStorage.session}`).not.toMatch(/refresh_token|access_token/i);

    await page.goto("/patients");
    await expect(page.locator("main")).toBeVisible({ timeout: 30_000 });
    await expect(page.getByRole("button", { name: /patients\.new_patient|Nouveau patient/i })).toBeVisible({ timeout: 30_000 });
    await page.getByRole("button", { name: /patients\.new_patient|Nouveau patient/i }).click();
    const uniquePhone = `+216${String(Date.now()).slice(-8)}`;
    const uniqueEmail = `patient.e2e+${Date.now()}@validation.example.com`;
    await page.locator("#nom").fill("Validation");
    await page.locator("#prenom").fill("E2E");
    await page.locator("#telephone").fill(uniquePhone);
    await page.locator("#email").fill(uniqueEmail);
    await page.locator("#allergies").fill("Aucune allergie connue");
    await page.getByRole("button", { name: "Créer", exact: true }).click();

    const patientRow = page.locator("tr").filter({ hasText: uniqueEmail }).last();
    await expect(patientRow).toBeVisible();
    await patientRow.getByRole("button", { name: "Voir", exact: true }).click();
    await expect(page).toHaveURL(/\/patients\/\d+$/);
    await expect(page.getByText(/Validation/).first()).toBeVisible();
    const patientPath = new URL(page.url()).pathname;
    await navigateSpa(page, `${patientPath}/radiologie`);
    await expect(page.locator("main")).toBeVisible({ timeout: 30_000 });
    await expect(page.locator("body")).not.toContainText("Application error");

    const moduleChecks: Array<[string, RegExp]> = [
      ["/agenda", /Agenda/i],
      ["/protheses", /Proth|Labo/i],
      ["/devis-dentaires", /Devis/i],
      ["/workflows", /Automatisation|Workflow/i],
      ["/copilote-crm", /CRM|Copilote/i],
      ["/stock", /Stock/i],
      ["/invoices", /Factur|Invoice/i],
      ["/dashboard-ia", /IA|Intelligence/i],
      ["/analytics", /Business Intelligence|Analyt/i],
    ];
    for (const [route] of moduleChecks) {
      await navigateSpa(page, route);
      await expect(page.locator("main")).toBeVisible({ timeout: 30_000 });
      await expect(page.locator("body")).not.toContainText("Application error");
    }

    await navigateSpa(page, "/dashboard");
    await page.getByRole("button", { name: new RegExp(E2E_EMAIL, "i") }).click();
    const logoutResponse = page.waitForResponse(
      (response) => response.url().includes("/api/v1/auth/logout") && response.request().method() === "POST",
    );
    await page.getByRole("menuitem", { name: /Déconnexion|Logout/i }).click();
    await logoutResponse;
    await expect(page).toHaveURL(/\/login$/);
    await expect.poll(async () => {
      const cookies = await context.cookies();
      return cookies.some((cookie) => cookie.name === "refresh_token");
    }, { timeout: 30_000 }).toBeFalsy();
  });
});
