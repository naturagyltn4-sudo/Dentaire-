import React, { useEffect, useMemo, useState } from 'react';
import { useBranding } from '@/contexts/BrandingContext';
import {
  publicApi,
  type PublicActe,
  type PublicDisponibilite,
  type PublicPraticien,
} from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';
import { Calendar, Phone, MapPin, Clock, Stethoscope, UserRound, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';
import { useTranslation } from 'react-i18next';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';

const todayLocalDate = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export default function LandingPage() {
  const { branding } = useBranding();
  const { t } = useTranslation();

  const [isBootstrapLoading, setIsBootstrapLoading] = useState(true);
  const [bootstrapError, setBootstrapError] = useState(false);
  const [isSlotsLoading, setIsSlotsLoading] = useState(false);
  const [praticiens, setPraticiens] = useState<PublicPraticien[]>([]);
  const [actes, setActes] = useState<PublicActe[]>([]);
  const [availabilities, setAvailabilities] = useState<PublicDisponibilite[]>([]);

  const [formData, setFormData] = useState({
    nom: '',
    prenom: '',
    telephone: '',
    praticien_id: '',
    acte_id: '',
    date: todayLocalDate(),
    date_heure: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const [callbackData, setCallbackData] = useState({ nom: '', telephone: '', email: '', message: '' });
  const [isCallbackSubmitting, setIsCallbackSubmitting] = useState(false);
  const [callbackConfirmation, setCallbackConfirmation] = useState<number | null>(null);
  const [confirmation, setConfirmation] = useState<{ id: number; status: string } | null>(null);

  useEffect(() => {
    const bootstrap = async () => {
      try {
        setIsBootstrapLoading(true);
        const [praticiensResponse, actesResponse] = await Promise.all([
          publicApi.getPraticiens(),
          publicApi.getActes(),
        ]);

        setPraticiens(praticiensResponse.data);
        setActes(actesResponse.data);
        setBootstrapError(false);
      } catch (err) {
        console.error('Failed to bootstrap landing page:', err);
        setBootstrapError(true);
        toast.error('Impossible de charger les données de réservation');
      } finally {
        setIsBootstrapLoading(false);
      }
    };

    bootstrap();
  }, []);

  useEffect(() => {
    const loadDisponibilites = async () => {
      if (!formData.praticien_id || !formData.date) {
        setAvailabilities([]);
        setFormData((current) => ({ ...current, date_heure: '' }));
        return;
      }

      try {
        setIsSlotsLoading(true);
        const response = await publicApi.getDisponibilites(Number(formData.praticien_id), {
          date: formData.date,
          acte_id: formData.acte_id ? Number(formData.acte_id) : undefined,
        });
        setAvailabilities(response.data.creneaux || []);

        setFormData((current) => {
          const stillExists = (response.data.creneaux || []).some(
            (slot) => slot.datetime === current.date_heure
          );
          return stillExists ? current : { ...current, date_heure: '' };
        });
      } catch (err: any) {
        console.error('Failed to load availabilities:', err);
        setAvailabilities([]);
        setFormData((current) => ({ ...current, date_heure: '' }));
        const message = err.response?.data?.detail || 'Impossible de charger les disponibilités';
        toast.error(message);
      } finally {
        setIsSlotsLoading(false);
      }
    };

    loadDisponibilites();
  }, [formData.praticien_id, formData.acte_id, formData.date]);

  const featuredServices = useMemo(() => {
    const fromBranding = branding?.contenu_landing?.services_mis_en_avant || [];
    if (fromBranding.length > 0) return fromBranding;
    return actes.slice(0, 3).map((acte) => acte.nom);
  }, [branding?.contenu_landing?.services_mis_en_avant, actes]);

  const selectedActe = useMemo(
    () => actes.find((acte) => acte.id === Number(formData.acte_id)),
    [actes, formData.acte_id]
  );

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((current) => ({
      ...current,
      [name]: value,
      ...(name === 'praticien_id' || name === 'acte_id' || name === 'date'
        ? { date_heure: '' }
        : {}),
    }));
  };


  const handleCallbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (callbackData.nom.trim().length < 2 || !callbackData.telephone.match(/^\+?[0-9 ]{8,15}$/)) {
      toast.error('Veuillez renseigner un nom et un téléphone valides');
      return;
    }
    try {
      setIsCallbackSubmitting(true);
      const response = await publicApi.submitCallback({ ...callbackData, nom: callbackData.nom.trim(), telephone: callbackData.telephone.trim() });
      setCallbackConfirmation(response.data.lead_id);
      setCallbackData({ nom: '', telephone: '', email: '', message: '' });
      toast.success('Votre demande de rappel a bien été transmise à la clinique.');
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Impossible d’enregistrer votre demande de rappel');
    } finally {
      setIsCallbackSubmitting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.telephone.match(/^\+?[0-9 ]{8,15}$/)) {
      toast.error('Format de téléphone invalide');
      return;
    }

    if (!formData.date_heure) {
      toast.error('Veuillez sélectionner un créneau disponible');
      return;
    }

    try {
      setIsSubmitting(true);

      const response = await publicApi.reserveRdv({
        nom: formData.nom,
        prenom: formData.prenom,
        telephone: formData.telephone,
        praticien_id: Number(formData.praticien_id),
        acte_id: Number(formData.acte_id),
        date_heure: formData.date_heure,
      });

      setConfirmation({
        id: response.data.booking_request_id,
        status: response.data.statut,
      });
      toast.success('Demande de rendez-vous reçue — confirmation par la clinique à venir.');
      setFormData({
        nom: '',
        prenom: '',
        telephone: '',
        praticien_id: '',
        acte_id: '',
        date: todayLocalDate(),
        date_heure: '',
      });
      setAvailabilities([]);
    } catch (err: any) {
      if (err.response?.status === 429) {
        toast.error('Trop de tentatives. Réessayez dans une minute.');
      } else {
        const message = err.response?.data?.detail || 'Erreur lors de la réservation';
        toast.error(message);
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <header className="border-b bg-white/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            {branding?.logo_url && (
              <img src={branding.logo_url} alt="Logo" className="h-10 w-10 object-contain shrink-0" />
            )}
            <h1 className="text-xl font-bold truncate">
              {branding?.nom_clinique || 'Clinique'}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <LanguageSwitcher />
            {branding?.contenu_landing?.telephone && <a href={`tel:${branding.contenu_landing.telephone}`} className="hidden rounded-full bg-primary px-3 py-2 text-xs font-semibold text-primary-foreground sm:inline-flex"><Phone className="mr-1 h-3.5 w-3.5" />Appeler</a>}
            {branding?.contenu_landing?.whatsapp && <a href={`https://wa.me/${branding.contenu_landing.whatsapp.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" className="hidden rounded-full bg-[#25D366] px-3 py-2 text-xs font-semibold text-white sm:inline-flex"><MessageCircle className="mr-1 h-3.5 w-3.5" />WhatsApp</a>}
            <a href="/login" className="text-sm text-muted-foreground hover:text-foreground shrink-0">
              {t('nav.pro_access')}
            </a>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden py-16 px-4" style={branding?.contenu_landing?.photo_hero_url ? { backgroundImage: `linear-gradient(120deg, rgba(255,255,255,0.96), rgba(255,255,255,0.75)), url("${branding.contenu_landing.photo_hero_url}")`, backgroundSize: 'cover', backgroundPosition: 'center' } : undefined}>
        <div className="max-w-5xl mx-auto grid lg:grid-cols-[1.15fr_0.85fr] gap-10 items-start">
          <div>
              <h2 className="text-4xl font-bold mb-4">
              {branding?.contenu_landing?.titre || t('landing.welcome')}
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              {branding?.contenu_landing?.sous_titre || t('landing.subtitle')}
            </p>

            <div className="mb-6 flex flex-wrap gap-3"><a href="#rappel" className="inline-flex items-center rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground">Être rappelé</a>{branding?.contenu_landing?.telephone && <a href={`tel:${branding.contenu_landing.telephone}`} className="inline-flex items-center rounded-full border px-5 py-3 text-sm font-semibold"><Phone className="mr-2 h-4 w-4" />Téléphoner</a>}{branding?.contenu_landing?.whatsapp && <a href={`https://wa.me/${branding.contenu_landing.whatsapp.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" className="inline-flex items-center rounded-full bg-[#25D366] px-5 py-3 text-sm font-semibold text-white"><MessageCircle className="mr-2 h-4 w-4" />WhatsApp</a>}</div>

            {featuredServices.length > 0 && (
              <div className="space-y-3">
                <p className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Services mis en avant
                </p>
                <div className="flex flex-wrap gap-2">
                  {featuredServices.map((service) => (
                    <span
                      key={service}
                      className="inline-flex items-center rounded-full border bg-white px-3 py-1 text-sm shadow-sm"
                    >
                      <Stethoscope className="w-4 h-4 mr-2 text-primary" />
                      {service}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                {t('landing.reserve_title')}
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                {t('landing.request_note', 'Cette réservation crée une demande auprès de la clinique. L’accueil vérifiera le créneau puis vous confirmera le rendez-vous.')}
              </p>
            </CardHeader>
            <CardContent>
              {confirmation && (
                <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900" role="status">
                  <p className="font-semibold">Demande reçue — référence #{confirmation.id}</p>
                  <p>La clinique doit encore confirmer ce créneau.</p>
                </div>
              )}
              {isBootstrapLoading ? (
                <div className="flex items-center justify-center py-12" role="status" aria-live="polite">
                  <Spinner className="h-5 w-5" />
                  <span className="sr-only">Chargement des disponibilités</span>
                </div>
              ) : bootstrapError ? (
                <div className="space-y-4 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950" role="alert">
                  <p className="font-semibold">La réservation en ligne est momentanément indisponible.</p>
                  <p>Vous pouvez demander un rappel ou contacter directement la clinique. Aucun formulaire incomplet ne sera envoyé.</p>
                  {branding?.contenu_landing?.telephone && (
                    <a className="inline-flex rounded-md bg-primary px-4 py-2 font-semibold text-primary-foreground" href={`tel:${branding.contenu_landing.telephone}`}>
                      Appeler la clinique
                    </a>
                  )}
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="prenom">{t('landing.firstname')}</Label>
                      <Input id="prenom" name="prenom" value={formData.prenom} onChange={handleInputChange} required />
                    </div>
                    <div>
                      <Label htmlFor="nom">{t('landing.lastname')}</Label>
                      <Input id="nom" name="nom" value={formData.nom} onChange={handleInputChange} required />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="telephone">{t('landing.phone')}</Label>
                    <Input
                      id="telephone"
                      name="telephone"
                      type="tel"
                      value={formData.telephone}
                      onChange={handleInputChange}
                      placeholder="+216 XX XXX XXX"
                      required
                    />
                    <p className="text-xs text-muted-foreground mt-1">Format international ou local, 8 chiffres minimum</p>
                  </div>

                  <div>
                    <Label htmlFor="praticien_id">{t('landing.practitioner')}</Label>
                    <select
                      id="praticien_id"
                      name="praticien_id"
                      value={formData.praticien_id}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md bg-background"
                      required
                    >
                      <option value="">{t('landing.select_practitioner')}</option>
                      {praticiens.map((praticien) => (
                        <option key={praticien.id} value={praticien.id}>
                          {praticien.nom_complet}
                          {praticien.specialite ? ` — ${praticien.specialite}` : ''}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <Label htmlFor="acte">{t('landing.procedure')}</Label>
                    <select
                      id="acte_id"
                      name="acte_id"
                      value={formData.acte_id}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md bg-background"
                      required
                    >
                      <option value="">{t('landing.select_procedure')}</option>
                      {actes.map((acte) => (
                        <option key={acte.id} value={acte.id}>
                          {acte.nom}
                          {acte.duree_minutes ? ` — ${acte.duree_minutes} min` : ''}
                        </option>
                      ))}
                    </select>
                    {selectedActe?.description && (
                      <p className="text-xs text-muted-foreground mt-1">{selectedActe.description}</p>
                    )}
                  </div>

                  <div>
                    <Label htmlFor="date">{t('landing.desired_date')}</Label>
                    <Input
                      id="date"
                      name="date"
                      type="date"
                      min={todayLocalDate()}
                      value={formData.date}
                      onChange={handleInputChange}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="date_heure">{t('landing.available_slot')}</Label>
                    <select
                      id="date_heure"
                      name="date_heure"
                      value={formData.date_heure}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border rounded-md bg-background"
                      required
                      disabled={!formData.praticien_id || isSlotsLoading}
                    >
                      <option value="">
                        {isSlotsLoading
                          ? t('landing.loading_slots')
                          : t('landing.select_slot')}
                      </option>
                      {availabilities.map((slot) => (
                        <option key={slot.datetime} value={slot.datetime}>
                          {slot.heure}
                        </option>
                      ))}
                    </select>
                    {isSlotsLoading && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-2">
                        <Spinner className="h-3.5 w-3.5" />
                        Chargement des disponibilités
                      </div>
                    )}
                    {!isSlotsLoading && formData.praticien_id && availabilities.length === 0 && (
                      <p className="text-xs text-muted-foreground mt-2">
                        Aucun créneau disponible pour cette date.
                      </p>
                    )}
                  </div>

                  <Button type="submit" className="w-full" disabled={isSubmitting || isBootstrapLoading}>
                    {isSubmitting ? (
                      <>
                        <Spinner className="mr-2 h-4 w-4" />
                        {t('landing.reserving')}
                      </>
                    ) : (
                      t('landing.reserve_button')
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </section>


      <section id="rappel" className="bg-muted/50 py-12 px-4"><div className="max-w-6xl mx-auto grid gap-8 lg:grid-cols-2 lg:items-center"><div><h3 className="text-3xl font-bold">Vous préférez être contacté ?</h3><p className="mt-3 text-muted-foreground">Laissez vos coordonnées, l’accueil de la clinique vous rappelle rapidement.</p></div><Card><CardContent className="pt-6">{callbackConfirmation && <div className="mb-4 rounded-md border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-900">Demande reçue — référence #{callbackConfirmation}.</div>}<form onSubmit={handleCallbackSubmit} className="space-y-4"><div className="grid grid-cols-2 gap-4"><div><Label htmlFor="callback_nom">Nom</Label><Input id="callback_nom" value={callbackData.nom} onChange={(e) => setCallbackData({ ...callbackData, nom: e.target.value })} required /></div><div><Label htmlFor="callback_telephone">Téléphone</Label><Input id="callback_telephone" type="tel" value={callbackData.telephone} onChange={(e) => setCallbackData({ ...callbackData, telephone: e.target.value })} required /></div></div><div><Label htmlFor="callback_email">Email (facultatif)</Label><Input id="callback_email" type="email" value={callbackData.email} onChange={(e) => setCallbackData({ ...callbackData, email: e.target.value })} /></div><div><Label htmlFor="callback_message">Votre besoin (facultatif)</Label><Input id="callback_message" value={callbackData.message} onChange={(e) => setCallbackData({ ...callbackData, message: e.target.value })} /></div><Button type="submit" className="w-full" disabled={isCallbackSubmitting}>{isCallbackSubmitting ? 'Envoi…' : 'Demander un rappel'}</Button></form></CardContent></Card></div></section>

      <section className="py-12 px-4 bg-white/50">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
          {branding?.contenu_landing?.adresse && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-sm">Adresse</p>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">
                      {branding.contenu_landing.adresse}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {branding?.contenu_landing?.telephone && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-sm">Téléphone</p>
                    <a href={`tel:${branding.contenu_landing.telephone}`} className="text-sm text-primary hover:underline">
                      {branding.contenu_landing.telephone}
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {branding?.contenu_landing?.horaires && (
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-sm">Horaires</p>
                    <p className="text-sm text-muted-foreground whitespace-pre-line">
                      {branding.contenu_landing.horaires}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {praticiens.length > 0 && (
        <section className="py-12 px-4">
          <div className="max-w-6xl mx-auto">
            <div className="mb-6">
              <h3 className="text-2xl font-bold">Nos praticiens</h3>
              <p className="text-muted-foreground">Des professionnels sélectionnés pour votre prise en charge.</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {praticiens.map((praticien) => (
                <Card key={praticien.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-3">
                      <UserRound className="w-5 h-5 text-primary mt-1" />
                      <div>
                        <p className="font-semibold">{praticien.nom_complet}</p>
                        {praticien.specialite && (
                          <p className="text-sm text-muted-foreground">{praticien.specialite}</p>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      )}

      <footer className="border-t bg-muted/50 py-8 px-4 mt-8">
        <div className="max-w-6xl mx-auto text-center text-sm text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} {branding?.nom_clinique || 'Clinique'}. Tous droits réservés.</p><div className="mt-3 flex justify-center gap-4 text-xs"><a href={branding?.contenu_landing?.instagram || '#'} target="_blank" rel="noreferrer">Instagram</a><a href={branding?.contenu_landing?.facebook || '#'} target="_blank" rel="noreferrer">Facebook</a><a href={branding?.contenu_landing?.tiktok || '#'} target="_blank" rel="noreferrer">TikTok</a>{branding?.contenu_landing?.email && <a href={`mailto:${branding.contenu_landing.email}`}>Email</a>}</div>
        </div>
      </footer>
    </div>
  );
}
