import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { api } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';
import { DetectionCariesView } from '@/components/patients/DetectionCariesView';
import { Spinner } from '@/components/ui/spinner';
import { toast } from 'sonner';
import { FileUp, Download, Eye, Maximize2, Columns, Trash2 } from 'lucide-react';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';

export interface Radio {
  id: number;
  patient_id: number;
  type_radio: string;
  dent_associee?: string;
  date_prise: string;
  dicom_metadata?: any;
  notes?: string;
  taille_octets: number;
}

export function normalizeRadioList(payload: unknown): Radio[] {
  return Array.isArray(payload) ? (payload as Radio[]) : [];
}

export default function RadiologiePage({ params }: { params: { id: string } }) {
  const patientId = params.id;
  const { user } = useAuth();
  const [radios, setRadios] = useState<Radio[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [compareOpen, setCompareOpen] = useState(false);
  const [selectedRadio, setSelectedRadio] = useState<Radio | null>(null);
  const [compareRadios, setCompareRadios] = useState<[Radio | null, Radio | null]>([null, null]);
  
  // Upload states
  const [file, setFile] = useState<File | null>(null);
  const [typeRadio, setTypeRadio] = useState('panoramique');
  const [dent, setDent] = useState('');
  const [notes, setNotes] = useState('');
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    loadRadios();
  }, [patientId]);

  const loadRadios = async () => {
    try {
      setIsLoading(true);
      const response = await api.get(`/radiologie/patient/${patientId}`);
      setRadios(normalizeRadioList(response.data));
    } catch (err) {
      toast.error("Erreur lors du chargement des radios");
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('patient_id', patientId);
    formData.append('type_radio', typeRadio);
    if (dent) formData.append('dent_associee', dent);
    if (notes) formData.append('notes', notes);

    try {
      await api.post('/radiologie/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      toast.success("Radio importée avec succès");
      setUploadOpen(false);
      loadRadios();
      // Reset form
      setFile(null); setDent(''); setNotes('');
    } catch (err) {
      toast.error("Erreur lors de l'import");
    } finally {
      setIsUploading(false);
    }
  };

  const openViewer = (radio: Radio) => {
    setSelectedRadio(radio);
    setViewOpen(true);
  };

  const addToCompare = (radio: Radio) => {
    if (!compareRadios[0]) {
      setCompareRadios([radio, null]);
      toast.info("Première radio sélectionnée pour comparaison");
    } else if (!compareRadios[1]) {
      setCompareRadios([compareRadios[0], radio]);
      setCompareOpen(true);
    } else {
      setCompareRadios([radio, null]);
      toast.info("Comparaison réinitialisée. Première radio sélectionnée.");
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Radiologie & Imagerie</h1>
            <p className="text-muted-foreground">Gestion des clichés DICOM et radiographies</p>
          </div>
          <Button onClick={() => setUploadOpen(true)}>
            <FileUp className="w-4 h-4 mr-2" />
            Importer une radio
          </Button>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12"><Spinner /></div>
        ) : radios.length === 0 ? (
          <Card><CardContent className="py-12 text-center text-muted-foreground">Aucune radio pour ce patient</CardContent></Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {radios.map((radio) => (
              <Card key={radio.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video bg-slate-900 flex items-center justify-center relative group">
                  <div className="text-slate-500 flex flex-col items-center">
                    <Eye className="w-12 h-12 mb-2" />
                    <span className="text-xs uppercase font-bold tracking-wider">{radio.type_radio}</span>
                  </div>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button size="sm" variant="secondary" onClick={() => openViewer(radio)}>
                      <Maximize2 className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="secondary" onClick={() => addToCompare(radio)}>
                      <Columns className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold capitalize">{radio.type_radio}</h3>
                    <span className="text-xs text-muted-foreground">
                      {new Date(radio.date_prise).toLocaleDateString()}
                    </span>
                  </div>
                  {radio.dent_associee && (
                    <p className="text-sm text-blue-600 font-medium mb-1">Dent: {radio.dent_associee}</p>
                  )}
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-4">{radio.notes || 'Pas de notes'}</p>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="w-full" asChild>
                      <a href={`${api.defaults.baseURL}/radiologie/${radio.id}/download`} target="_blank" rel="noopener noreferrer">
                        <Download className="w-4 h-4 mr-2" />
                        DICOM
                      </a>
                    </Button>
                  </div>
                  <DetectionCariesView radioId={radio.id} userRole={user?.role} practitionerId={user?.id} />
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Dialog Import */}
      <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Importer une radio</DialogTitle>
            <DialogDescription>Sélectionnez un fichier DICOM ou image chiffré.</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpload} className="space-y-4">
            <div>
              <Label>Fichier (DICOM/JPG/PNG)</Label>
              <Input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Type</Label>
                <select className="w-full border rounded-md h-10 px-3" value={typeRadio} onChange={(e) => setTypeRadio(e.target.value)}>
                  <option value="panoramique">Panoramique</option>
                  <option value="CBCT">CBCT</option>
                  <option value="retro-alveolaire">Rétro-alvéolaire</option>
                </select>
              </div>
              <div>
                <Label>Dent (FDI)</Label>
                <Input placeholder="ex: 16" value={dent} onChange={(e) => setDent(e.target.value)} />
              </div>
            </div>
            <div>
              <Label>Notes</Label>
              <Input placeholder="Observations..." value={notes} onChange={(e) => setNotes(e.target.value)} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setUploadOpen(false)}>Annuler</Button>
              <Button type="submit" disabled={isUploading}>{isUploading ? <Spinner className="w-4 h-4" /> : 'Importer'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Viewer Dialog */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Visualisation Radio - {selectedRadio?.type_radio}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 bg-black rounded-lg flex items-center justify-center overflow-hidden relative">
            {selectedRadio && (
              <img 
                src={`${api.defaults.baseURL}/radiologie/${selectedRadio.id}/view`} 
                alt="Radiographie" 
                className="max-w-full max-h-full object-contain"
              />
            )}
            {selectedRadio?.type_radio === 'CBCT' && (
              <div className="absolute bottom-4 left-4 right-4 bg-black/60 text-white p-2 text-xs rounded">
                Note: Pour le CBCT, utilisez le téléchargement DICOM pour une visualisation 3D complète dans un viewer externe (Horos/Osirix).
              </div>
            )}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
            <div>
              <h4 className="font-bold">Métadonnées DICOM</h4>
              <pre className="text-[10px] bg-slate-100 p-2 rounded mt-1 overflow-auto max-h-32">
                {JSON.stringify(selectedRadio?.dicom_metadata, null, 2)}
              </pre>
            </div>
            <div>
              <h4 className="font-bold">Notes</h4>
              <p className="mt-1">{selectedRadio?.notes || 'Aucune note'}</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Comparison Dialog */}
      <Dialog open={compareOpen} onOpenChange={setCompareOpen}>
        <DialogContent className="max-w-6xl h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Comparaison de Radios</DialogTitle>
          </DialogHeader>
          <div className="flex-1 grid grid-cols-2 gap-4">
            {[0, 1].map(i => (
              <div key={i} className="bg-black rounded-lg flex flex-col items-center justify-center relative overflow-hidden">
                {compareRadios[i] ? (
                  <>
                    <img 
                      src={`${api.defaults.baseURL}/radiologie/${compareRadios[i]?.id}/view`} 
                      className="max-w-full max-h-full object-contain"
                    />
                    <div className="absolute top-2 left-2 bg-black/50 text-white px-2 py-1 text-xs rounded">
                      {new Date(compareRadios[i]!.date_prise).toLocaleDateString()}
                    </div>
                  </>
                ) : (
                  <span className="text-slate-500">Sélectionnez une radio</span>
                )}
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
