import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, CalendarDays, ClipboardList, CreditCard, FileText, ListChecks, RefreshCw, Stethoscope } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import { api } from '@/lib/api';
import { toast } from 'sonner';

interface Patient360Data {
  patient: { id: number; nom: string; prenom: string; telephone: string; email?: string | null; statut?: string | null };
  actions_aujourdhui: { type: string; priorite: string; libelle: string }[];
  rendez_vous: { id: number; date_heure_debut: string; statut: string; praticien_id: number; acte_id?: number | null }[];
  dossiers: { id: number; date_acte: string; acte_id?: number | null; suivi_requis: boolean; date_suivi_recommandee?: string | null }[];
  devis: { id: number; prix: number | string; statut: string; date_validite?: string | null }[];
  factures: { id: number; numero_facture: string; total_ttc: number | string; statut: string; date_echeance?: string | null }[];
  suivis_post_op: { id: number; date_prevue: string; statut: string; acte_id: number }[];
  plans_traitement: { id: number; titre: string; statut: string; date_cible?: string | null; etapes_total: number }[];
}

const formatDate = (value?: string | null) => value ? new Date(value).toLocaleDateString('fr-FR') : '—';
const formatDateTime = (value?: string | null) => value ? new Date(value).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '—';

export default function Patient360Page({ patientId }: { patientId: number }) {
  const [, setLocation] = useLocation();
  const [data, setData] = useState<Patient360Data | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      setLoading(true);
      const response = await api.get<Patient360Data>(`/patients/${patientId}/360`);
      setData(response.data);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger la synthèse patient');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [patientId]);

  const totals = useMemo(() => ({
    rdv: data?.rendez_vous.length ?? 0,
    devis: data?.devis.length ?? 0,
    factures: data?.factures.length ?? 0,
    suivis: data?.suivis_post_op.length ?? 0,
    plans: data?.plans_traitement.length ?? 0,
  }), [data]);

  if (loading) {
    return <DashboardLayout><div className="flex h-96 items-center justify-center"><Spinner /></div></DashboardLayout>;
  }
  if (!data) {
    return <DashboardLayout><div className="space-y-4"><Button variant="outline" onClick={() => setLocation('/patients')}><ArrowLeft className="mr-2 h-4 w-4" />Retour aux patients</Button><Card><CardContent className="py-10 text-center text-muted-foreground">Patient indisponible.</CardContent></Card></div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={() => setLocation('/patients')} aria-label="Retour aux patients"><ArrowLeft className="h-4 w-4" /></Button>
            <div><p className="text-sm text-muted-foreground">Vue patient 360°</p><h1 className="text-3xl font-bold">{data.patient.prenom} {data.patient.nom}</h1><p className="text-muted-foreground">{data.patient.telephone}{data.patient.email ? ` · ${data.patient.email}` : ''}</p></div>
          </div>
          <Button variant="outline" onClick={load}><RefreshCw className="mr-2 h-4 w-4" />Actualiser</Button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[['Rendez-vous', totals.rdv, CalendarDays], ['Devis', totals.devis, FileText], ['Factures', totals.factures, CreditCard], ['Suivis post-op', totals.suivis, Stethoscope], ['Plans', totals.plans, ClipboardList]].map(([label, value, Icon]: any) => <Card key={label as string}><CardContent className="flex items-center gap-3 pt-6"><Icon className="h-5 w-5 text-primary" /><div><p className="text-sm text-muted-foreground">{label}</p><p className="text-2xl font-bold">{value}</p></div></CardContent></Card>)}
        </div>

        <Card className="border-primary/20">
          <CardHeader><CardTitle className="flex items-center gap-2"><ListChecks className="h-5 w-5" />À faire aujourd’hui</CardTitle></CardHeader>
          <CardContent>{data.actions_aujourdhui.length === 0 ? <p className="text-sm text-muted-foreground">Aucune action prioritaire détectée.</p> : <div className="grid gap-3 md:grid-cols-2">{data.actions_aujourdhui.map((action, index) => <div key={`${action.type}-${index}`} className="flex items-center justify-between rounded-lg border p-3"><span className="text-sm">{action.libelle}</span><Badge variant={action.priorite === 'haute' ? 'destructive' : 'secondary'}>{action.priorite}</Badge></div>)}</div>}</CardContent>
        </Card>

        <div className="grid gap-6 lg:grid-cols-2">
          <Card><CardHeader><CardTitle className="flex items-center gap-2"><CalendarDays className="h-5 w-5" />Historique des rendez-vous</CardTitle></CardHeader><CardContent>{data.rendez_vous.length === 0 ? <p className="text-sm text-muted-foreground">Aucun rendez-vous.</p> : <div className="space-y-3">{data.rendez_vous.slice(0, 8).map(item => <div key={item.id} className="flex items-center justify-between border-b pb-2 text-sm"><span>{formatDateTime(item.date_heure_debut)}</span><Badge variant="outline">{item.statut}</Badge></div>)}</div>}</CardContent></Card>
          <Card><CardHeader><CardTitle className="flex items-center gap-2"><ClipboardList className="h-5 w-5" />Suivis et dossiers</CardTitle></CardHeader><CardContent>{data.dossiers.length === 0 && data.suivis_post_op.length === 0 ? <p className="text-sm text-muted-foreground">Aucun suivi enregistré.</p> : <div className="space-y-3">{data.dossiers.slice(0, 6).map(item => <div key={`d-${item.id}`} className="flex items-center justify-between border-b pb-2 text-sm"><span>Acte du {formatDate(item.date_acte)}</span><Badge variant={item.suivi_requis ? 'destructive' : 'outline'}>{item.suivi_requis ? 'Suivi requis' : 'Archivé'}</Badge></div>)}{data.suivis_post_op.slice(0, 6).map(item => <div key={`s-${item.id}`} className="flex items-center justify-between border-b pb-2 text-sm"><span>Contrôle du {formatDate(item.date_prevue)}</span><Badge variant="outline">{item.statut}</Badge></div>)}</div>}</CardContent></Card>
          <Card><CardHeader><CardTitle className="flex items-center gap-2"><ClipboardList className="h-5 w-5" />Plans de traitement</CardTitle></CardHeader><CardContent>{data.plans_traitement.length === 0 ? <p className="text-sm text-muted-foreground">Aucun plan.</p> : <div className="space-y-3">{data.plans_traitement.map(item => <div key={item.id} className="flex items-center justify-between border-b pb-2 text-sm"><span>{item.titre} · {item.etapes_total} étape(s)</span><Badge variant="outline">{item.statut}</Badge></div>)}</div>}</CardContent></Card>
          <Card><CardHeader><CardTitle className="flex items-center gap-2"><FileText className="h-5 w-5" />Devis</CardTitle></CardHeader><CardContent>{data.devis.length === 0 ? <p className="text-sm text-muted-foreground">Aucun devis.</p> : <div className="space-y-3">{data.devis.map(item => <div key={item.id} className="flex items-center justify-between border-b pb-2 text-sm"><span>{Number(item.prix).toFixed(2)} DT</span><Badge variant="outline">{item.statut}</Badge></div>)}</div>}</CardContent></Card>
          <Card><CardHeader><CardTitle className="flex items-center gap-2"><CreditCard className="h-5 w-5" />Factures</CardTitle></CardHeader><CardContent>{data.factures.length === 0 ? <p className="text-sm text-muted-foreground">Aucune facture.</p> : <div className="space-y-3">{data.factures.map(item => <div key={item.id} className="flex items-center justify-between border-b pb-2 text-sm"><span>{item.numero_facture} · {Number(item.total_ttc).toFixed(2)} DT</span><Badge variant="outline">{item.statut}</Badge></div>)}</div>}</CardContent></Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
