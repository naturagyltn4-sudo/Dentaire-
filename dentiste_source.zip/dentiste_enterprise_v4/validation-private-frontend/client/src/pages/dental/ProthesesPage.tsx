import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Spinner } from '@/components/ui/spinner';
import { dentalApi } from '@/lib/api';
import { Zap } from 'lucide-react';

interface CommandeProthese {
  id: number;
  patient_id: number;
  patient_nom?: string;
  patient_prenom?: string;
  type: string;
  laboratoire: string;
  date_reception_prevue: string;
  statut: string;
  cout: number;
}

export default function ProthesesPage() {
  const [protheses, setProtheses] = useState<CommandeProthese[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProtheses = async () => {
      try {
        const response = await dentalApi.getProtheses(); 
        setProtheses(response.data);
      } catch (error) {
        console.error('Erreur lors du chargement des prothèses:', error);
      } finally {
        setLoading(false);
      }
    };
    loadProtheses();
  }, []);

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Zap className="w-8 h-8 text-blue-600" />
          Suivi Prothèses & Laboratoire
        </h1>

        <Card>
          <CardHeader>
            <CardTitle>Commandes en cours</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8"><Spinner /></div>
            ) : protheses.length === 0 ? (
              <p className="text-center py-8 text-muted-foreground">Aucune commande de prothèse en cours.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Laboratoire</TableHead>
                    <TableHead>Réception Prévue</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead className="text-right">Coût</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {protheses.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.type}</TableCell>
                      <TableCell>{p.laboratoire}</TableCell>
                      <TableCell>{new Date(p.date_reception_prevue).toLocaleDateString('fr-FR')}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{p.statut}</Badge>
                      </TableCell>
                      <TableCell className="text-right">{p.cout} €</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
