import { useCallback, useEffect, useState } from 'react';
import { Building2, Mail, Pencil, Phone, Plus, Search, Trash2, UserRound } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { deleguesApi, type Delegue } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';

interface DelegueForm {
  nom: string;
  prenom: string;
  laboratoire_ou_societe: string;
  telephone: string;
  email: string;
  specialite_produits: string;
  notes: string;
}

const EMPTY_FORM: DelegueForm = {
  nom: '',
  prenom: '',
  laboratoire_ou_societe: '',
  telephone: '',
  email: '',
  specialite_produits: '',
  notes: '',
};

export default function DeleguesPage() {
  const { user } = useAuth();
  const canManageDelegues = user?.role === 'medecin' || user?.role === 'directrice' || user?.role === 'admin';
  const [delegues, setDelegues] = useState<Delegue[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Delegue | null>(null);
  const [form, setForm] = useState<DelegueForm>(EMPTY_FORM);

  const loadDelegues = useCallback(async () => {
    setLoading(true);
    try {
      const response = await deleguesApi.list();
      setDelegues(response.data);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger les délégués');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDelegues();
  }, [loadDelegues]);

  const openCreate = () => {
    setEditing(null);
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  };

  const openEdit = (delegue: Delegue) => {
    setEditing(delegue);
    setForm({
      nom: delegue.nom,
      prenom: delegue.prenom,
      laboratoire_ou_societe: delegue.laboratoire_ou_societe,
      telephone: delegue.telephone,
      email: delegue.email || '',
      specialite_produits: delegue.specialite_produits || '',
      notes: delegue.notes || '',
    });
    setDialogOpen(true);
  };

  const updateField = (field: keyof DelegueForm, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const submit = async () => {
    if (!form.nom.trim() || !form.prenom.trim() || !form.laboratoire_ou_societe.trim() || !form.telephone.trim()) {
      toast.error('Veuillez remplir les champs obligatoires');
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        await deleguesApi.update(editing.id, form);
        toast.success('Délégué mis à jour');
      } else {
        await deleguesApi.create(form);
        toast.success('Délégué ajouté');
      }
      setDialogOpen(false);
      await loadDelegues();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible d’enregistrer le délégué');
    } finally {
      setSaving(false);
    }
  };

  const remove = async (delegue: Delegue) => {
    if (!window.confirm(`Supprimer ${delegue.prenom} ${delegue.nom} ?`)) return;
    try {
      await deleguesApi.remove(delegue.id);
      setDelegues((current) => current.filter((item) => item.id !== delegue.id));
      toast.success('Délégué supprimé');
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de supprimer le délégué');
    }
  };

  const filtered = delegues.filter((delegue) => {
    const haystack = [
      delegue.nom,
      delegue.prenom,
      delegue.laboratoire_ou_societe,
      delegue.specialite_produits || '',
    ].join(' ').toLowerCase();
    return haystack.includes(search.toLowerCase());
  });

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Réseau professionnel</p>
            <h1 className="text-3xl font-bold tracking-tight">Délégués médicaux</h1>
            <p className="mt-1 text-muted-foreground">Centralisez les contacts des laboratoires, fournisseurs et partenaires dentaires.</p>
          </div>
          {canManageDelegues && <Button onClick={openCreate}><Plus className="mr-2 h-4 w-4" />Nouveau délégué</Button>}
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="relative max-w-xl">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Rechercher par nom, société ou spécialité..." className="pl-9" />
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex justify-center py-16"><Spinner className="h-8 w-8" /></div>
        ) : filtered.length === 0 ? (
          <Card><CardContent className="py-16 text-center text-muted-foreground">Aucun délégué trouvé.</CardContent></Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((delegue) => (
              <Card key={delegue.id} className="transition-shadow hover:shadow-md">
                <CardHeader className="flex-row items-start justify-between space-y-0">
                  <div className="flex items-center gap-3">
                    <div className="rounded-full bg-primary/10 p-3 text-primary"><UserRound className="h-5 w-5" /></div>
                    <div>
                      <CardTitle className="text-base">{delegue.prenom} {delegue.nom}</CardTitle>
                      <p className="text-sm text-muted-foreground">{delegue.laboratoire_ou_societe}</p>
                    </div>
                  </div>
                  <Badge variant={delegue.is_active ? 'default' : 'secondary'}>{delegue.is_active ? 'Actif' : 'Inactif'}</Badge>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex items-center gap-2"><Building2 className="h-4 w-4 text-muted-foreground" /><span>{delegue.specialite_produits || 'Spécialité non renseignée'}</span></div>
                  <a href={`tel:${delegue.telephone}`} className="flex items-center gap-2 hover:underline"><Phone className="h-4 w-4 text-muted-foreground" />{delegue.telephone}</a>
                  {delegue.email && <a href={`mailto:${delegue.email}`} className="flex items-center gap-2 hover:underline"><Mail className="h-4 w-4 text-muted-foreground" />{delegue.email}</a>}
                  {delegue.notes && <p className="rounded-md bg-muted p-3 text-muted-foreground">{delegue.notes}</p>}
                  {canManageDelegues && (
                    <div className="flex justify-end gap-2 border-t pt-3">
                      <Button variant="outline" size="sm" onClick={() => openEdit(delegue)}><Pencil className="mr-1 h-4 w-4" />Modifier</Button>
                      <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => remove(delegue)}><Trash2 className="mr-1 h-4 w-4" />Supprimer</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader><DialogTitle>{editing ? 'Modifier le délégué' : 'Ajouter un délégué médical'}</DialogTitle></DialogHeader>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label htmlFor="delegue-prenom">Prénom *</Label><Input id="delegue-prenom" value={form.prenom} onChange={(event) => updateField('prenom', event.target.value)} /></div>
            <div><Label htmlFor="delegue-nom">Nom *</Label><Input id="delegue-nom" value={form.nom} onChange={(event) => updateField('nom', event.target.value)} /></div>
            <div className="sm:col-span-2"><Label htmlFor="delegue-societe">Laboratoire / société *</Label><Input id="delegue-societe" value={form.laboratoire_ou_societe} onChange={(event) => updateField('laboratoire_ou_societe', event.target.value)} /></div>
            <div><Label htmlFor="delegue-telephone">Téléphone *</Label><Input id="delegue-telephone" type="tel" value={form.telephone} onChange={(event) => updateField('telephone', event.target.value)} /></div>
            <div><Label htmlFor="delegue-email">E-mail</Label><Input id="delegue-email" type="email" value={form.email} onChange={(event) => updateField('email', event.target.value)} /></div>
            <div className="sm:col-span-2"><Label htmlFor="delegue-specialite">Produits / spécialité</Label><Input id="delegue-specialite" value={form.specialite_produits} onChange={(event) => updateField('specialite_produits', event.target.value)} placeholder="Implantologie, biomatériaux, orthodontie..." /></div>
            <div className="sm:col-span-2"><Label htmlFor="delegue-notes">Notes</Label><Textarea id="delegue-notes" value={form.notes} onChange={(event) => updateField('notes', event.target.value)} rows={4} /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button><Button onClick={submit} disabled={saving}>{saving && <Spinner className="mr-2 h-4 w-4" />}{editing ? 'Enregistrer' : 'Ajouter'}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}

export { DeleguesPage };
