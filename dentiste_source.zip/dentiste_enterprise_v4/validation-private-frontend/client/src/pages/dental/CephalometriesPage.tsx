import { useCallback, useEffect, useState } from 'react';
import { FileImage, Plus, Search, Upload } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { cephalometriesApi, resolveApiUrl, type Cephalometrie } from '@/lib/api';

export default function CephalometriesPage() {
  const [items, setItems] = useState<Cephalometrie[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [patientId, setPatientId] = useState('');
  const [titre, setTitre] = useState('');
  const [conclusions, setConclusions] = useState('');
  const [file, setFile] = useState<File | null>(null);

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const response = await cephalometriesApi.list();
      setItems(response.data);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger les céphalométries');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const submit = async () => {
    const numericPatientId = Number(patientId);
    if (!numericPatientId || !titre.trim() || !file) {
      toast.error('Patient, titre et fichier sont obligatoires');
      return;
    }
    if (!file.type.startsWith('image/') && file.type !== 'application/dicom') {
      toast.error('Veuillez sélectionner une image ou un fichier DICOM');
      return;
    }
    setSaving(true);
    try {
      await cephalometriesApi.upload({
        patient_id: numericPatientId,
        titre,
        conclusions,
        file,
      });
      toast.success('Cliché céphalométrique enregistré');
      setDialogOpen(false);
      setPatientId('');
      setTitre('');
      setConclusions('');
      setFile(null);
      await loadItems();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible d’enregistrer le cliché');
    } finally {
      setSaving(false);
    }
  };

  const filteredItems = items.filter((item) => {
    const value = `${item.titre} ${item.patient_id} ${item.conclusions || ''}`.toLowerCase();
    return value.includes(search.toLowerCase());
  });

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Imagerie orthodontique</p>
            <h1 className="text-3xl font-bold tracking-tight">Céphalométrie</h1>
            <p className="mt-1 text-muted-foreground">Archivez les clichés, les mesures et les conclusions de vos analyses orthodontiques.</p>
          </div>
          <Button onClick={() => setDialogOpen(true)}><Plus className="mr-2 h-4 w-4" />Nouvelle analyse</Button>
        </div>

        <Card>
          <CardContent className="pt-6">
            <div className="relative max-w-xl">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Rechercher par titre, patient ou conclusion..." className="pl-9" />
            </div>
          </CardContent>
        </Card>

        {loading ? (
          <div className="flex justify-center py-16"><Spinner className="h-8 w-8" /></div>
        ) : filteredItems.length === 0 ? (
          <Card><CardContent className="py-16 text-center text-muted-foreground">Aucune analyse céphalométrique trouvée.</CardContent></Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {filteredItems.map((item) => (
              <Card key={item.id} className="overflow-hidden">
                <div className="flex h-52 items-center justify-center bg-muted">
                  {item.image_url ? (
                    <img src={resolveApiUrl(item.image_url)} alt={item.titre} className="h-full w-full object-contain" />
                  ) : (
                    <FileImage className="h-12 w-12 text-muted-foreground" />
                  )}
                </div>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">{item.titre}</CardTitle>
                  <p className="text-sm text-muted-foreground">Patient #{item.patient_id} · {new Date(item.created_at).toLocaleDateString('fr-FR')}</p>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  {item.analyse_data && (
                    <div className="grid grid-cols-2 gap-2 rounded-md bg-muted p-3">
                      {Object.entries(item.analyse_data).slice(0, 4).map(([key, value]) => (
                        <div key={key}><span className="text-xs text-muted-foreground">{key}</span><p className="font-medium">{String(value)}</p></div>
                      ))}
                    </div>
                  )}
                  {item.conclusions && <p className="text-muted-foreground">{item.conclusions}</p>}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader><DialogTitle>Nouvelle analyse céphalométrique</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div><Label htmlFor="ceph-patient">Identifiant du patient *</Label><Input id="ceph-patient" type="number" min="1" value={patientId} onChange={(event) => setPatientId(event.target.value)} placeholder="Ex. 42" /></div>
            <div><Label htmlFor="ceph-titre">Titre de l’analyse *</Label><Input id="ceph-titre" value={titre} onChange={(event) => setTitre(event.target.value)} placeholder="Téléradiographie de profil — bilan initial" /></div>
            <div><Label htmlFor="ceph-file">Cliché radiographique *</Label><Input id="ceph-file" type="file" accept="image/*,.dcm,application/dicom" onChange={(event) => setFile(event.target.files?.[0] || null)} /></div>
            <div><Label htmlFor="ceph-conclusions">Conclusions / observations</Label><Textarea id="ceph-conclusions" value={conclusions} onChange={(event) => setConclusions(event.target.value)} rows={5} placeholder="Mesures, interprétation et recommandations du praticien..." /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setDialogOpen(false)}>Annuler</Button><Button onClick={submit} disabled={saving}>{saving ? <Spinner className="mr-2 h-4 w-4" /> : <Upload className="mr-2 h-4 w-4" />}Enregistrer</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}

export { CephalometriesPage };
