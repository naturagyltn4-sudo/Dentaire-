import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Spinner } from '@/components/ui/spinner';
import { dentalApi } from '@/lib/api';
import { FileText } from 'lucide-react';
import { toast } from 'sonner';

interface Devis { id: number; patient_id: number; date_validite?: string | null; statut: string; prix: string; facture_id?: number | null; }
interface RestePatient { total_ttc: string; prise_en_charge_mutuelle: string; reste_patient: string; }

export default function DevisDentairePage() {
  const [devis, setDevis] = useState<Devis[]>([]);
  const [loading, setLoading] = useState(true);
  const [pec, setPec] = useState<Record<number, RestePatient>>({});
  const [organisme, setOrganisme] = useState('');
  const [montant, setMontant] = useState('');
  const [savingId, setSavingId] = useState<number | null>(null);

  useEffect(() => { void (async () => { try { const response = await dentalApi.getDevis(); setDevis(response.data); } catch { toast.error('Erreur lors du chargement des devis.'); } finally { setLoading(false); } })(); }, []);

  const loadPec = async (factureId: number) => { try { const response = await dentalApi.getPriseEnCharge(factureId); setPec((current) => ({ ...current, [factureId]: response.data })); } catch { toast.error('Impossible de charger la prise en charge.'); } };
  const savePec = async (factureId: number) => { if (!organisme || !montant) return; try { setSavingId(factureId); await dentalApi.creerPriseEnCharge(factureId, { organisme, montant_pris_en_charge: montant }); await loadPec(factureId); setOrganisme(''); setMontant(''); toast.success('Prise en charge enregistrée.'); } catch { toast.error("L'enregistrement de la prise en charge a échoué."); } finally { setSavingId(null); } };

  return <DashboardLayout><div className="space-y-6"><h1 className="flex items-center gap-2 text-3xl font-bold"><FileText className="h-8 w-8 text-purple-600" />Devis & Plans de Traitement</h1><Card><CardHeader><CardTitle>Liste des devis</CardTitle></CardHeader><CardContent>{loading ? <div className="flex justify-center py-8"><Spinner /></div> : devis.length === 0 ? <p className="py-8 text-center text-muted-foreground">Aucun devis enregistré.</p> : <Table><TableHeader><TableRow><TableHead>ID</TableHead><TableHead>Patient</TableHead><TableHead>Date validité</TableHead><TableHead>Statut</TableHead><TableHead className="text-right">Prix</TableHead><TableHead>Mutuelle / reste patient</TableHead></TableRow></TableHeader><TableBody>{devis.map((d) => { const details = d.facture_id ? pec[d.facture_id] : undefined; return <TableRow key={d.id}><TableCell>#{d.id}</TableCell><TableCell>#{d.patient_id}</TableCell><TableCell>{d.date_validite ? new Date(d.date_validite).toLocaleDateString('fr-FR') : '—'}</TableCell><TableCell><Badge variant="outline">{d.statut}</Badge></TableCell><TableCell className="text-right">{d.prix} DT</TableCell><TableCell>{d.facture_id ? <div className="space-y-2 min-w-[260px]"><div className="flex gap-2"><Input placeholder="Organisme" value={organisme} onChange={(e) => setOrganisme(e.target.value)} /><Input className="w-28" inputMode="decimal" placeholder="Montant" value={montant} onChange={(e) => setMontant(e.target.value)} /><Button size="sm" disabled={savingId === d.facture_id} onClick={() => void savePec(d.facture_id!)}>Ajouter</Button></div><Button variant="ghost" size="sm" onClick={() => void loadPec(d.facture_id!)}>Actualiser</Button>{details && <p className="text-sm">Prise en charge : <strong>{details.prise_en_charge_mutuelle}</strong> DT · Reste patient : <strong>{details.reste_patient}</strong> DT</p>}</div> : <span className="text-xs text-muted-foreground">Disponible après rattachement à une facture.</span>}</TableCell></TableRow>; })}</TableBody></Table>}</CardContent></Card></div></DashboardLayout>;
}
