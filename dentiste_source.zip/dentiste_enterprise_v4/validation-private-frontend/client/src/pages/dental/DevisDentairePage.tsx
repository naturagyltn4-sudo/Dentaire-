import { FormEvent, useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { PatientAutocomplete, PatientOption } from '@/components/patients/PatientAutocomplete';
import { dentalApi } from '@/lib/api';
import { CheckCircle2, FileText, Plus } from 'lucide-react';
import { toast } from 'sonner';

interface Devis {
  id: number;
  patient_id: number;
  date_validite?: string | null;
  statut: string;
  prix: string;
  facture_id?: number | null;
}

interface RestePatient {
  total_ttc: string;
  prise_en_charge_mutuelle: string;
  reste_patient: string;
}

function formatDate(value?: string | null) {
  return value ? new Date(value).toLocaleDateString('fr-FR') : '—';
}

export default function DevisDentairePage() {
  const [devis, setDevis] = useState<Devis[]>([]);
  const [loading, setLoading] = useState(true);
  const [pec, setPec] = useState<Record<number, RestePatient>>({});
  const [organisme, setOrganisme] = useState('');
  const [montant, setMontant] = useState('');
  const [savingId, setSavingId] = useState<number | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<PatientOption | null>(null);
  const [prix, setPrix] = useState('');
  const [dent, setDent] = useState('');
  const [dateValidite, setDateValidite] = useState('');
  const [description, setDescription] = useState('');
  const [creating, setCreating] = useState(false);
  const [acceptingId, setAcceptingId] = useState<number | null>(null);

  const loadDevis = async () => {
    try {
      setLoading(true);
      const response = await dentalApi.getDevis();
      setDevis(response.data);
    } catch {
      toast.error('Erreur lors du chargement des devis.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadDevis();
  }, []);

  const resetCreateForm = () => {
    setSelectedPatient(null);
    setPrix('');
    setDent('');
    setDateValidite('');
    setDescription('');
  };

  const closeCreateDialog = (open: boolean) => {
    setCreateOpen(open);
    if (!open) resetCreateForm();
  };

  const createDevis = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const montantNumerique = Number(prix);
    if (!selectedPatient) {
      toast.error('Sélectionnez un patient.');
      return;
    }
    if (!Number.isFinite(montantNumerique) || montantNumerique <= 0) {
      toast.error('Saisissez un montant strictement positif.');
      return;
    }

    try {
      setCreating(true);
      await dentalApi.createDevis({
        patient_id: selectedPatient.id,
        prix: montantNumerique,
        dent: dent.trim() || undefined,
        date_validite: dateValidite || undefined,
        lignes: [{
          nom: description.trim() || 'Soin dentaire',
          prix: montantNumerique,
          quantite: 1,
        }],
      });
      toast.success('Devis créé en brouillon.');
      closeCreateDialog(false);
      await loadDevis();
    } catch {
      toast.error('La création du devis a échoué.');
    } finally {
      setCreating(false);
    }
  };

  const accepterDevis = async (devisId: number) => {
    try {
      setAcceptingId(devisId);
      await dentalApi.accepterDevis(devisId);
      toast.success('Devis accepté et facture créée.');
      await loadDevis();
    } catch {
      toast.error("L'acceptation du devis a échoué.");
    } finally {
      setAcceptingId(null);
    }
  };

  const loadPec = async (factureId: number) => {
    try {
      const response = await dentalApi.getPriseEnCharge(factureId);
      setPec((current) => ({ ...current, [factureId]: response.data }));
    } catch {
      toast.error('Impossible de charger la prise en charge.');
    }
  };

  const savePec = async (factureId: number) => {
    if (!organisme || !montant) return;
    try {
      setSavingId(factureId);
      await dentalApi.creerPriseEnCharge(factureId, {
        organisme,
        montant_pris_en_charge: montant,
      });
      await loadPec(factureId);
      setOrganisme('');
      setMontant('');
      toast.success('Prise en charge enregistrée.');
    } catch {
      toast.error("L'enregistrement de la prise en charge a échoué.");
    } finally {
      setSavingId(null);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="flex items-center gap-2 text-3xl font-bold">
              <FileText className="h-8 w-8 text-purple-600" />
              Devis & Plans de Traitement
            </h1>
            <p className="mt-1 text-muted-foreground">
              Préparez un devis, puis transformez-le en facture après validation.
            </p>
          </div>
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Nouveau devis
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Liste des devis</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8"><Spinner /></div>
            ) : devis.length === 0 ? (
              <div className="py-8 text-center">
                <p className="text-muted-foreground">Aucun devis enregistré.</p>
                <Button className="mt-4" variant="outline" onClick={() => setCreateOpen(true)}>
                  Créer le premier devis
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Patient</TableHead>
                      <TableHead>Date validité</TableHead>
                      <TableHead>Statut</TableHead>
                      <TableHead className="text-right">Prix</TableHead>
                      <TableHead>Actions</TableHead>
                      <TableHead>Mutuelle / reste patient</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {devis.map((item) => {
                      const details = item.facture_id ? pec[item.facture_id] : undefined;
                      const canAccept = item.statut === 'brouillon';
                      return (
                        <TableRow key={item.id}>
                          <TableCell>#{item.id}</TableCell>
                          <TableCell>#{item.patient_id}</TableCell>
                          <TableCell>{formatDate(item.date_validite)}</TableCell>
                          <TableCell><Badge variant="outline">{item.statut}</Badge></TableCell>
                          <TableCell className="text-right">{item.prix} DT</TableCell>
                          <TableCell>
                            {canAccept ? (
                              <Button
                                size="sm"
                                variant="outline"
                                disabled={acceptingId === item.id}
                                onClick={() => void accepterDevis(item.id)}
                              >
                                {acceptingId === item.id ? <Spinner className="h-4 w-4" /> : <><CheckCircle2 className="mr-1 h-4 w-4" />Accepter</>}
                              </Button>
                            ) : (
                              <span className="text-xs text-muted-foreground">Déjà traité</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {item.facture_id ? (
                              <div className="min-w-[260px] space-y-2">
                                <div className="flex gap-2">
                                  <Input placeholder="Organisme" value={organisme} onChange={(e) => setOrganisme(e.target.value)} />
                                  <Input className="w-28" inputMode="decimal" placeholder="Montant" value={montant} onChange={(e) => setMontant(e.target.value)} />
                                  <Button size="sm" disabled={savingId === item.facture_id} onClick={() => void savePec(item.facture_id!)}>Ajouter</Button>
                                </div>
                                <Button variant="ghost" size="sm" onClick={() => void loadPec(item.facture_id!)}>Actualiser</Button>
                                {details && <p className="text-sm">Prise en charge : <strong>{details.prise_en_charge_mutuelle}</strong> DT · Reste patient : <strong>{details.reste_patient}</strong> DT</p>}
                              </div>
                            ) : (
                              <span className="text-xs text-muted-foreground">Disponible après rattachement à une facture.</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={createOpen} onOpenChange={closeCreateDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Nouveau devis</DialogTitle>
            <DialogDescription>
              Le devis est enregistré en brouillon ; aucune facture ni communication n’est créée avant l’acceptation explicite.
            </DialogDescription>
          </DialogHeader>
          <form className="space-y-4" onSubmit={createDevis}>
            <PatientAutocomplete selectedPatient={selectedPatient} onSelect={setSelectedPatient} />
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="devis-prix">Montant (DT) *</Label>
                <Input id="devis-prix" type="number" inputMode="decimal" min="0.01" step="0.01" value={prix} onChange={(e) => setPrix(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label htmlFor="devis-dent">Dent concernée</Label>
                <Input id="devis-dent" placeholder="Ex. 26" value={dent} onChange={(e) => setDent(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="devis-description">Libellé du soin</Label>
              <Input id="devis-description" placeholder="Ex. Consultation et soin de contrôle" value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="devis-validite">Date de validité</Label>
              <Input id="devis-validite" type="date" value={dateValidite} onChange={(e) => setDateValidite(e.target.value)} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => closeCreateDialog(false)}>Annuler</Button>
              <Button type="submit" disabled={creating}>{creating ? <Spinner className="h-4 w-4" /> : 'Créer le devis'}</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
}
