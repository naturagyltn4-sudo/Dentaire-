import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { suiviPostOpApi } from '@/lib/api';
import { toast } from 'sonner';
import { CalendarCheck, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface SuiviPostOp {
  id: number;
  patient_id: number;
  date_controle_prevue: string;
  date_controle_reelle?: string | null;
  statut: string;
  observations?: string | null;
  complication?: string | null;
}

const statusLabel: Record<string, string> = {
  planifie: 'Planifié',
  effectue: 'Effectué',
  manque: 'Manqué',
};

export default function SuiviPostOpPage({ params }: { params: { id: string } }) {
  const { user } = useAuth();
  const canCloseSuivi = user?.role === 'medecin' || user?.role === 'directrice';
  const patientId = Number(params.id);
  const [suivis, setSuivis] = useState<SuiviPostOp[]>([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState<number | null>(null);

  const load = async () => {
    try {
      setLoading(true);
      const response = await suiviPostOpApi.listPatient(patientId);
      setSuivis(response.data);
    } catch {
      toast.error('Impossible de charger les suivis post-opératoires.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, [patientId]);

  const close = async (suiviId: number, statut: 'effectue' | 'manque') => {
    try {
      setUpdatingId(suiviId);
      await suiviPostOpApi.cloturer(suiviId, { statut });
      toast.success(statut === 'effectue' ? 'Contrôle marqué effectué.' : 'Contrôle marqué manqué.');
      await load();
    } catch {
      toast.error('La mise à jour du contrôle a échoué.');
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <CalendarCheck className="h-8 w-8 text-teal-600" />
          <div><h1 className="text-3xl font-bold">Suivi post-opératoire</h1><p className="text-muted-foreground">Contrôles à venir et contrôles en retard du patient #{patientId}</p></div>
        </div>
        <Card>
          <CardHeader><CardTitle>Contrôles</CardTitle></CardHeader>
          <CardContent>
            {loading ? <div className="flex justify-center py-8"><Spinner /></div> : suivis.length === 0 ? <p className="py-8 text-center text-muted-foreground">Aucun contrôle enregistré.</p> : (
              <Table>
                <TableHeader><TableRow><TableHead>Date prévue</TableHead><TableHead>Statut</TableHead><TableHead>Observations</TableHead><TableHead className="text-right">Actions</TableHead></TableRow></TableHeader>
                <TableBody>{suivis.map((suivi) => {
                  const overdue = suivi.statut === 'planifie' && new Date(suivi.date_controle_prevue).getTime() < Date.now();
                  return <TableRow key={suivi.id} className={overdue ? 'bg-red-50' : undefined}>
                    <TableCell><div className="flex items-center gap-2">{overdue && <AlertTriangle className="h-4 w-4 text-red-600" />}{new Date(suivi.date_controle_prevue).toLocaleDateString('fr-FR')}</div>{overdue && <span className="text-xs text-red-700">Date dépassée</span>}</TableCell>
                    <TableCell><Badge variant={overdue ? 'destructive' : 'outline'}>{statusLabel[suivi.statut] ?? suivi.statut}</Badge></TableCell>
                    <TableCell className="max-w-xs truncate">{suivi.observations || suivi.complication || '—'}</TableCell>
                    <TableCell className="text-right">{canCloseSuivi && <div className="flex justify-end gap-2">{suivi.statut === 'planifie' && <><Button size="sm" disabled={updatingId === suivi.id} onClick={() => void close(suivi.id, 'effectue')}>Effectué</Button><Button size="sm" variant="outline" disabled={updatingId === suivi.id} onClick={() => void close(suivi.id, 'manque')}>Manqué</Button></>}</div>}</TableCell>
                  </TableRow>;
                })}</TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
