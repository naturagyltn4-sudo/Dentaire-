import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Building2, Database, RefreshCw, ShieldCheck, Users, Activity, CreditCard } from 'lucide-react';
import { toast } from 'sonner';
import { superAdminApi, type SuperAdminClinic, type SuperAdminHealth, type SuperAdminOverview, type SuperAdminUser } from '@/lib/api';

const statusClass = (status: string) => {
  if (['active', 'ok'].includes(status)) return 'bg-emerald-100 text-emerald-800';
  if (['suspended', 'past_due', 'degraded'].includes(status)) return 'bg-amber-100 text-amber-800';
  if (['cancelled', 'archived', 'error'].includes(status)) return 'bg-red-100 text-red-800';
  return 'bg-slate-100 text-slate-700';
};

export default function SuperAdminDashboard() {
  const [overview, setOverview] = useState<SuperAdminOverview | null>(null);
  const [health, setHealth] = useState<SuperAdminHealth | null>(null);
  const [clinics, setClinics] = useState<SuperAdminClinic[]>([]);
  const [users, setUsers] = useState<SuperAdminUser[]>([]);
  const [audit, setAudit] = useState<Array<{ id: number; clinic_id: number; action: string; resource_type: string; utilisateur_nom: string; created_at?: string | null }>>([]);
  const [selectedClinicId, setSelectedClinicId] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(true);

  const load = async () => {
    try {
      setIsLoading(true);
      const [overviewResponse, healthResponse, clinicsResponse, usersResponse, auditResponse] = await Promise.all([
        superAdminApi.overview(),
        superAdminApi.health(),
        superAdminApi.clinics(),
        superAdminApi.users(),
        superAdminApi.audit(),
      ]);
      setOverview(overviewResponse.data);
      setHealth(healthResponse.data);
      setClinics(clinicsResponse.data);
      setUsers(usersResponse.data);
      setAudit(auditResponse.data);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger le pilotage global');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const filteredUsers = selectedClinicId === 'all'
    ? users
    : users.filter((user) => String(user.clinic_id) === selectedClinicId);

  const updateUserStatus = async (user: SuperAdminUser) => {
    try {
      await superAdminApi.updateUser(user.id, { is_active: !user.is_active });
      toast.success(user.is_active ? 'Compte désactivé' : 'Compte activé');
      await load();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de modifier le compte');
    }
  };

  const updateSubscription = async (clinic: SuperAdminClinic, statut: string) => {
    try {
      await superAdminApi.updateSubscription(clinic.id, { statut });
      toast.success('Abonnement mis à jour');
      await load();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de modifier l’abonnement');
    }
  };

  if (isLoading && !overview) {
    return <DashboardLayout><div className="flex h-96 items-center justify-center"><Spinner /></div></DashboardLayout>;
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-medium uppercase tracking-wide text-primary">Gouvernance globale</p>
            <h1 className="text-3xl font-bold">Super Admin</h1>
            <p className="mt-1 text-muted-foreground">Vue consolidée des cliniques, comptes, abonnements et signaux techniques.</p>
          </div>
          <Button variant="outline" onClick={() => void load()}><RefreshCw className="mr-2 h-4 w-4" />Actualiser</Button>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <MetricCard icon={<Building2 className="h-4 w-4" />} label="Cliniques" value={overview?.clinics_count ?? 0} />
          <MetricCard icon={<Users className="h-4 w-4" />} label="Comptes actifs" value={`${overview?.active_users_count ?? 0}/${overview?.users_count ?? 0}`} />
          <MetricCard icon={<Activity className="h-4 w-4" />} label="Patients" value={overview?.patients_count ?? 0} />
          <MetricCard icon={<CreditCard className="h-4 w-4" />} label="Factures" value={overview?.invoices_count ?? 0} />
        </div>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><ShieldCheck className="h-5 w-5" />Santé technique</CardTitle></CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-4">
            <HealthItem label="API" value={health?.checks.api || 'unknown'} />
            <HealthItem label="Base de données" value={health?.checks.database || 'unknown'} />
            <HealthItem label="Redis" value={health?.checks.redis || 'unknown'} />
            <HealthItem label="Environnement" value={health?.environment || 'unknown'} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Cliniques et abonnements</CardTitle></CardHeader>
          <CardContent className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-sm">
              <thead><tr className="border-b text-left"><th className="p-3">Clinique</th><th className="p-3">Utilisateurs</th><th className="p-3">Patients</th><th className="p-3">Activité</th><th className="p-3">Abonnement</th><th className="p-3">État</th></tr></thead>
              <tbody>
                {clinics.map((clinic) => (
                  <tr key={clinic.id} className="border-b last:border-0">
                    <td className="p-3"><div className="font-medium">{clinic.nom}</div><div className="text-xs text-muted-foreground">#{clinic.id} · {clinic.slug}</div></td>
                    <td className="p-3">{clinic.active_users_count}/{clinic.users_count}</td>
                    <td className="p-3">{clinic.patients_count}</td>
                    <td className="p-3">{clinic.appointments_count} RDV · {clinic.invoices_count} factures</td>
                    <td className="p-3"><div className="font-medium">{clinic.subscription.plan}</div><div className="text-xs text-muted-foreground">{clinic.subscription.user_limit ?? '—'} comptes · {clinic.subscription.storage_limit_gb ?? '—'} Go</div></td>
                    <td className="p-3"><Select value={clinic.subscription.statut} onValueChange={(value) => void updateSubscription(clinic, value)}><SelectTrigger className="w-36"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="trial">Essai</SelectItem><SelectItem value="active">Actif</SelectItem><SelectItem value="past_due">Impayé</SelectItem><SelectItem value="suspended">Suspendu</SelectItem><SelectItem value="cancelled">Annulé</SelectItem><SelectItem value="non_configure">Non configuré</SelectItem></SelectContent></Select></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {clinics.length === 0 && <p className="py-6 text-center text-muted-foreground">Aucune clinique enregistrée.</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between"><CardTitle>Comptes et accès</CardTitle><Select value={selectedClinicId} onValueChange={setSelectedClinicId}><SelectTrigger className="w-48"><SelectValue placeholder="Toutes les cliniques" /></SelectTrigger><SelectContent><SelectItem value="all">Toutes les cliniques</SelectItem>{clinics.map((clinic) => <SelectItem key={clinic.id} value={String(clinic.id)}>{clinic.nom}</SelectItem>)}</SelectContent></Select></CardHeader>
          <CardContent className="overflow-x-auto"><table className="w-full min-w-[760px] text-sm"><thead><tr className="border-b text-left"><th className="p-3">Compte</th><th className="p-3">Clinique</th><th className="p-3">Rôle</th><th className="p-3">MFA</th><th className="p-3">État</th><th className="p-3">Action</th></tr></thead><tbody>{filteredUsers.map((user) => <tr key={user.id} className="border-b last:border-0"><td className="p-3"><div className="font-medium">{user.prenom} {user.nom}</div><div className="text-xs text-muted-foreground">{user.email}</div></td><td className="p-3">#{user.clinic_id}</td><td className="p-3"><Badge variant="outline">{user.role}</Badge></td><td className="p-3">{user.mfa_enabled ? 'Activée' : 'Non activée'}</td><td className="p-3"><Badge className={statusClass(user.is_active ? 'active' : 'suspended')}>{user.is_active ? 'Actif' : 'Désactivé'}</Badge></td><td className="p-3"><Button size="sm" variant="outline" onClick={() => void updateUserStatus(user)}>{user.is_active ? 'Désactiver' : 'Activer'}</Button></td></tr>)}</tbody></table></CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><Database className="h-5 w-5" />Journal global récent</CardTitle></CardHeader>
          <CardContent className="space-y-2">{audit.length === 0 ? <p className="text-sm text-muted-foreground">Aucun événement d’administration global.</p> : audit.slice(0, 12).map((event) => <div key={event.id} className="flex flex-col gap-1 border-b pb-2 text-sm last:border-0"><span className="font-medium">{event.action} · {event.resource_type}</span><span className="text-xs text-muted-foreground">Clinique #{event.clinic_id} · {event.utilisateur_nom} · {event.created_at ? new Date(event.created_at).toLocaleString('fr-FR') : 'date inconnue'}</span></div>)}</CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}

function MetricCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) {
  return <Card><CardContent className="flex items-center gap-3 pt-6"><div className="rounded-lg bg-primary/10 p-2 text-primary">{icon}</div><div><p className="text-sm text-muted-foreground">{label}</p><p className="text-2xl font-bold">{value}</p></div></CardContent></Card>;
}

function HealthItem({ label, value }: { label: string; value: string }) {
  return <div className="rounded-lg border p-3"><p className="text-xs text-muted-foreground">{label}</p><Badge className={`mt-2 ${statusClass(value)}`}>{value}</Badge></div>;
}
