import { useEffect, useMemo, useState } from 'react';
import { CalendarDays, Clock3, RefreshCcw, Users } from 'lucide-react';
import { toast } from 'sonner';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Spinner } from '@/components/ui/spinner';
import { api, adminTeamApi, type TeamMember } from '@/lib/api';

interface ReportItem {
  date: string;
  debut: string;
  fin?: string | null;
  duree_minutes: number;
}

interface UserReport {
  utilisateur_id: number;
  nom_complet: string;
  total_minutes: number;
  details: ReportItem[];
}

function monthBounds() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const lastDay = new Date(year, now.getMonth() + 1, 0).getDate();
  return {
    start: `${year}-${month}-01`,
    end: `${year}-${month}-${String(lastDay).padStart(2, '0')}`,
  };
}

function formatMinutes(total: number) {
  return `${Math.floor(total / 60)} h ${String(total % 60).padStart(2, '0')} min`;
}

export default function PointagePage() {
  const bounds = useMemo(() => monthBounds(), []);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [selectedUserId, setSelectedUserId] = useState('');
  const [dateDebut, setDateDebut] = useState(bounds.start);
  const [dateFin, setDateFin] = useState(bounds.end);
  const [report, setReport] = useState<UserReport | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);

  const loadTeam = async () => {
    try {
      setIsLoading(true);
      const response = await adminTeamApi.list();
      setTeam(response.data);
      if (!selectedUserId && response.data.length > 0) {
        setSelectedUserId(String(response.data[0].id));
      }
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger le personnel');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    void loadTeam();
  }, []);

  const generateReport = async () => {
    if (!selectedUserId || !dateDebut || !dateFin) {
      toast.error('Sélectionnez un membre et une période');
      return;
    }
    if (dateFin < dateDebut) {
      toast.error('La date de fin doit être postérieure à la date de début');
      return;
    }
    try {
      setIsGenerating(true);
      const response = await api.get<UserReport>('/pointage/admin/rapport', {
        params: {
          utilisateur_id: Number(selectedUserId),
          date_debut: dateDebut,
          date_fin: dateFin,
        },
      });
      setReport(response.data);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de générer le rapport RH');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-6xl">
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">Pointage & reporting RH</h1>
            <p className="text-muted-foreground mt-1">Suivez les présences et les heures clôturées du personnel dentaire.</p>
          </div>
          <Button variant="outline" onClick={() => void loadTeam()} disabled={isLoading}>
            <RefreshCcw className="mr-2 h-4 w-4" /> Actualiser
          </Button>
        </div>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><CalendarDays className="h-5 w-5" /> Période du rapport</CardTitle></CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-4 items-end">
            <div>
              <label htmlFor="rh-user" className="text-sm font-medium">Membre du personnel</label>
              <select id="rh-user" className="mt-1 h-10 w-full rounded-md border bg-background px-3 text-sm" value={selectedUserId} onChange={(e) => setSelectedUserId(e.target.value)} disabled={isLoading}>
                <option value="">Sélectionner</option>
                {team.map((member) => <option key={member.id} value={member.id}>{member.prenom} {member.nom} — {member.role}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor="rh-start" className="text-sm font-medium">Du</label>
              <input id="rh-start" type="date" className="mt-1 h-10 w-full rounded-md border bg-background px-3 text-sm" value={dateDebut} onChange={(e) => setDateDebut(e.target.value)} />
            </div>
            <div>
              <label htmlFor="rh-end" className="text-sm font-medium">Au</label>
              <input id="rh-end" type="date" className="mt-1 h-10 w-full rounded-md border bg-background px-3 text-sm" value={dateFin} onChange={(e) => setDateFin(e.target.value)} />
            </div>
            <Button onClick={() => void generateReport()} disabled={isGenerating || isLoading || !selectedUserId}>
              {isGenerating ? <Spinner className="h-4 w-4" /> : <Clock3 className="mr-2 h-4 w-4" />} Générer le rapport
            </Button>
          </CardContent>
        </Card>

        {!report ? (
          <Card><CardContent className="py-12 text-center text-muted-foreground"><Users className="mx-auto mb-3 h-8 w-8" /><p>Sélectionnez un membre puis générez son rapport de présence.</p></CardContent></Card>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-3">
              <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Membre</CardTitle></CardHeader><CardContent><div className="text-lg font-semibold">{report.nom_complet}</div><p className="text-xs text-muted-foreground">{dateDebut} → {dateFin}</p></CardContent></Card>
              <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Total clôturé</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{formatMinutes(report.total_minutes)}</div><p className="text-xs text-muted-foreground">Toutes les sessions terminées</p></CardContent></Card>
              <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Sessions</CardTitle></CardHeader><CardContent><div className="text-2xl font-bold">{report.details.length}</div><p className="text-xs text-muted-foreground">Pointages clôturés</p></CardContent></Card>
            </div>

            <Card>
              <CardHeader><CardTitle>Détail des présences</CardTitle></CardHeader>
              <CardContent>
                {report.details.length === 0 ? <p className="py-8 text-center text-muted-foreground">Aucun pointage clôturé sur cette période.</p> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b text-left"><th className="p-2">Date</th><th className="p-2">Arrivée</th><th className="p-2">Départ</th><th className="p-2">Durée</th></tr></thead><tbody>{report.details.map((item, index) => <tr key={`${item.debut}-${index}`} className="border-b"><td className="p-2">{new Date(`${item.date}T12:00:00`).toLocaleDateString('fr-FR')}</td><td className="p-2">{new Date(item.debut).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</td><td className="p-2">{item.fin ? new Date(item.fin).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : 'En cours'}</td><td className="p-2 font-medium">{formatMinutes(item.duree_minutes)}</td></tr>)}</tbody></table></div>}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </DashboardLayout>
  );
}
