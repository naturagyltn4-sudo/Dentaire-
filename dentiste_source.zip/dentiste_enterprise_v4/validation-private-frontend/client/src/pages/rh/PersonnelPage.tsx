import { useEffect, useState } from 'react';
import { BriefcaseBusiness, Save, UserRound } from 'lucide-react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Spinner } from '@/components/ui/spinner';
import { api } from '@/lib/api';
import { toast } from 'sonner';

type Profile = {
  user_id: number; nom: string; prenom: string; email: string; telephone?: string | null;
  role: string; is_active: boolean; fonction?: string | null; adresse?: string | null;
  date_embauche?: string | null; diplomes?: string | null; specialisations?: string | null;
  certifications?: string | null; notes_internes?: string | null;
};

export default function PersonnelPage() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [selected, setSelected] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      setLoading(true);
      const response = await api.get<Profile[]>('/personnel');
      setProfiles(response.data);
      setSelected(current => current ? response.data.find(item => item.user_id === current.user_id) || current : response.data[0] || null);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de charger le personnel');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const update = (field: keyof Profile, value: string) => setSelected(current => current ? { ...current, [field]: value } : current);
  const save = async () => {
    if (!selected) return;
    try {
      setSaving(true);
      const response = await api.patch<Profile>(`/personnel/${selected.user_id}`, {
        adresse: selected.adresse || null, fonction: selected.fonction || null,
        date_embauche: selected.date_embauche || null, diplomes: selected.diplomes || null,
        specialisations: selected.specialisations || null, certifications: selected.certifications || null,
        notes_internes: selected.notes_internes || null,
      });
      setSelected(response.data);
      setProfiles(items => items.map(item => item.user_id === response.data.user_id ? response.data : item));
      toast.success('Fiche personnel enregistrée');
    } catch (error: any) { toast.error(error.response?.data?.detail || 'Impossible d’enregistrer la fiche'); }
    finally { setSaving(false); }
  };

  if (loading) return <DashboardLayout><div className="flex h-96 items-center justify-center"><Spinner /></div></DashboardLayout>;

  return <DashboardLayout><div className="space-y-6"><div><p className="text-sm text-muted-foreground">Ressources humaines légères</p><h1 className="text-3xl font-bold">Personnel et équipe</h1><p className="mt-1 text-muted-foreground">Profils professionnels, documents et informations utiles — sans paie ni RH lourd.</p></div><div className="grid gap-6 lg:grid-cols-[minmax(220px,0.7fr)_minmax(0,1.3fr)]"><Card><CardHeader><CardTitle className="flex items-center gap-2"><UserRound className="h-5 w-5" />Membres</CardTitle></CardHeader><CardContent className="space-y-2">{profiles.map(profile => <button type="button" key={profile.user_id} onClick={() => setSelected(profile)} className={`w-full rounded-lg border p-3 text-left transition-colors ${selected?.user_id === profile.user_id ? 'border-primary bg-primary/5' : 'hover:bg-muted'}`}><div className="flex items-center justify-between gap-2"><span className="font-medium">{profile.prenom} {profile.nom}</span><span className={`text-xs ${profile.is_active ? 'text-emerald-700' : 'text-muted-foreground'}`}>{profile.is_active ? 'Actif' : 'Inactif'}</span></div><p className="text-xs text-muted-foreground">{profile.fonction || profile.role}</p></button>)}{profiles.length === 0 && <p className="text-sm text-muted-foreground">Aucun membre.</p>}</CardContent></Card><Card><CardHeader><CardTitle className="flex items-center gap-2"><BriefcaseBusiness className="h-5 w-5" />Fiche professionnelle</CardTitle></CardHeader><CardContent>{selected ? <div className="grid gap-4 md:grid-cols-2"><div><Label>Nom</Label><Input value={`${selected.prenom} ${selected.nom}`} disabled /></div><div><Label>Rôle applicatif</Label><Input value={selected.role} disabled /></div><div><Label htmlFor="fonction">Fonction</Label><Input id="fonction" value={selected.fonction || ''} onChange={event => update('fonction', event.target.value)} /></div><div><Label htmlFor="date_embauche">Date d’embauche</Label><Input id="date_embauche" type="date" value={selected.date_embauche || ''} onChange={event => update('date_embauche', event.target.value)} /></div><div className="md:col-span-2"><Label htmlFor="adresse">Adresse professionnelle</Label><Input id="adresse" value={selected.adresse || ''} onChange={event => update('adresse', event.target.value)} /></div><div><Label htmlFor="diplomes">Diplômes</Label><Textarea id="diplomes" value={selected.diplomes || ''} onChange={event => update('diplomes', event.target.value)} /></div><div><Label htmlFor="specialisations">Spécialisations</Label><Textarea id="specialisations" value={selected.specialisations || ''} onChange={event => update('specialisations', event.target.value)} /></div><div><Label htmlFor="certifications">Certifications</Label><Textarea id="certifications" value={selected.certifications || ''} onChange={event => update('certifications', event.target.value)} /></div><div><Label htmlFor="notes_internes">Notes internes</Label><Textarea id="notes_internes" value={selected.notes_internes || ''} onChange={event => update('notes_internes', event.target.value)} /></div><div className="md:col-span-2"><Button onClick={save} disabled={saving}>{saving ? <Spinner className="mr-2 h-4 w-4" /> : <Save className="mr-2 h-4 w-4" />}Enregistrer la fiche</Button></div></div> : <p className="text-sm text-muted-foreground">Sélectionnez un membre.</p>}</CardContent></Card></div></div></DashboardLayout>;
}
