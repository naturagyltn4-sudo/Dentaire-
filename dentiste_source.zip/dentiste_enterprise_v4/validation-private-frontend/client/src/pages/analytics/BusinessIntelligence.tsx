import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { api } from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import { toast } from 'sonner';
import {
  TrendingUp,
  Users,
  Zap,
  AlertCircle,
  Download,
  BarChart3,
  DollarSign,
  Calendar,
} from 'lucide-react';

interface RevenueBreakdown {
  nom: string;
  revenue: number;
}

interface RevenueSummary {
  total_revenue: number;
  total_invoices: number;
  avg_invoice: number;
  currency: string;
  revenue_by_practitioner: RevenueBreakdown[];
  revenue_by_acte: RevenueBreakdown[];
}

interface TopPractitioner {
  name: string;
  revenue: number;
  invoices: number;
}

interface TopTreatment {
  name: string;
  revenue: number;
  invoices: number;
}

interface LoyalPatient {
  id: number;
  name: string;
  lifetime_spend: number;
  invoices: number;
}

interface Forecast {
  total_forecast: number;
  avg_daily_revenue: number;
  forecast_by_day: number[];
}

interface Kpis {
  revenue_today: number;
  revenue_month: number;
  rdv_today: number;
}

export default function BusinessIntelligence() {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'practitioners' | 'treatments' | 'patients' | 'forecast'>('overview');

  const [revenueSummary, setRevenueSummary] = useState<RevenueSummary | null>(null);
  const [topPractitioners, setTopPractitioners] = useState<TopPractitioner[]>([]);
  const [topTreatments, setTopTreatments] = useState<TopTreatment[]>([]);
  const [topPatients, setTopPatients] = useState<LoyalPatient[]>([]);
  const [forecast, setForecast] = useState<Forecast | null>(null);
  const [kpis, setKpis] = useState<Kpis | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  const currency = revenueSummary?.currency || 'DT';

  useEffect(() => {
    const loadData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const [revRes, practRes, treatRes, patRes, foreRes, kpiRes] = await Promise.all([
          api.get('/business-intelligence/revenue-summary'),
          api.get('/business-intelligence/top-practitioners'),
          api.get('/business-intelligence/top-treatments'),
          api.get('/business-intelligence/top-loyal-patients'),
          api.get('/business-intelligence/revenue-forecast'),
          api.get('/business-intelligence/kpi-dashboard'),
        ]);

        if (revRes.data?.data) setRevenueSummary(revRes.data.data);
        if (practRes.data?.data) setTopPractitioners(practRes.data.data.top_practitioners || []);
        if (treatRes.data?.data) setTopTreatments(treatRes.data.data.top_treatments || []);
        if (patRes.data?.data) setTopPatients(patRes.data.data.top_patients || []);
        if (foreRes.data?.data) setForecast(foreRes.data.data);
        if (kpiRes.data?.data) setKpis(kpiRes.data.data.kpis);
      } catch (err: any) {
        setError(err.message || 'Erreur lors du chargement des données');
      } finally {
        setIsLoading(false);
      }
    };

    loadData();
  }, []);

  const formatAmount = (amount: number) => `${Number(amount || 0).toFixed(2)} ${currency}`;

  const exportReport = async () => {
    try {
      setIsExporting(true);
      const response = await api.get('/business-intelligence/business-report');
      const report = response.data?.data;
      if (!report?.summary) throw new Error('Rapport indisponible');

      const escapeCsv = (value: unknown) => `"${String(value ?? '').replaceAll('"', '""')}"`;
      const rows: unknown[][] = [
        ['Rapport', report.title || 'Rapport Business Intelligence'],
        ['Période', `${report.period_days || 30} jours`],
        ['Généré le', new Date(report.date_generated || Date.now()).toLocaleString('fr-FR')],
        [],
        ['Indicateur', 'Valeur'],
        ['Revenu total', formatAmount(report.summary.total_revenue)],
        ['Factures', report.summary.total_invoices],
        ['Facture moyenne', formatAmount(report.summary.avg_invoice)],
        ['Praticien principal', report.summary.top_practitioner || '—'],
        ['Acte principal', report.summary.top_treatment || '—'],
        ['Prévision à 30 jours', formatAmount(report.summary.forecast_30_days)],
      ];
      const csv = `\uFEFF${rows.map((row) => row.map(escapeCsv).join(';')).join('\n')}`;
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `rapport-bi-${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      toast.success('Rapport CSV téléchargé');
    } catch {
      toast.error('Le rapport Business Intelligence est temporairement indisponible.');
    } finally {
      setIsExporting(false);
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-screen">
          <Spinner />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Titre */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Business Intelligence</h1>
            <p className="text-gray-600 mt-2">Analyses et rapports détaillés</p>
          </div>
          <button
            type="button"
            onClick={exportReport}
            disabled={isExporting}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-60"
          >
            <Download className="w-5 h-5" />
            {isExporting ? 'Export en cours…' : 'Exporter Rapport'}
          </button>
        </div>

        {/* Erreur */}
        {error && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                <span>{error}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* KPIs */}
        {kpis && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Revenus Aujourd'hui</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{formatAmount(kpis.revenue_today)}</div>
                <p className="text-xs text-gray-500 mt-2">Factures payées</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Revenus du Mois</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{formatAmount(kpis.revenue_month)}</div>
                <p className="text-xs text-gray-500 mt-2">Cumul mensuel</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">RDV Aujourd'hui</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{kpis.rdv_today}</div>
                <p className="text-xs text-gray-500 mt-2">Rendez-vous planifiés</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">Revenu total (30 jours)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{formatAmount(revenueSummary?.total_revenue || 0)}</div>
                <p className="text-xs text-gray-500 mt-2">Factures payées ou partiellement payées</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Onglets */}
        <div className="flex gap-2 border-b overflow-x-auto">
          {[
            { id: 'overview', label: 'Vue d\'ensemble', icon: BarChart3 },
            { id: 'practitioners', label: 'Praticiens', icon: Users },
            { id: 'treatments', label: 'Soins', icon: Zap },
            { id: 'patients', label: 'Patients', icon: Users },
            { id: 'forecast', label: 'Prévisions', icon: TrendingUp },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 font-medium border-b-2 transition whitespace-nowrap flex items-center gap-2 ${
                  activeTab === tab.id
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Vue d'ensemble */}
        {activeTab === 'overview' && revenueSummary && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Résumé des Revenus (30 derniers jours)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div>
                    <p className="text-sm text-gray-600">Revenu Total</p>
                    <p className="text-3xl font-bold text-green-600">{revenueSummary.total_revenue.toFixed(2)} DT</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Nombre de Factures</p>
                    <p className="text-3xl font-bold">{revenueSummary.total_invoices}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Facture Moyenne</p>
                    <p className="text-3xl font-bold">{revenueSummary.avg_invoice.toFixed(2)} DT</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top 5 Actes par Revenu</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                    {revenueSummary.revenue_by_acte.slice(0, 5).map((acte) => (
                      <div key={acte.nom} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div>
                          <p className="font-medium">{acte.nom}</p>
                        </div>
                        <p className="font-bold">{formatAmount(acte.revenue)}</p>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Praticiens */}
        {activeTab === 'practitioners' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {topPractitioners.map((practitioner, idx) => (
              <Card key={idx}>
                <CardHeader>
                  <CardTitle>{practitioner.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Revenu</span>
                      <span className="font-bold">{formatAmount(practitioner.revenue)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Factures</span>
                      <span className="font-bold">{practitioner.invoices}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Soins */}
        {activeTab === 'treatments' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {topTreatments.map((treatment, idx) => (
              <Card key={idx}>
                <CardHeader>
                  <CardTitle>{treatment.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Revenu Total</span>
                      <span className="font-bold">{formatAmount(treatment.revenue)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Factures</span>
                      <span className="font-bold">{treatment.invoices}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Patients */}
        {activeTab === 'patients' && (
          <Card>
            <CardHeader>
              <CardTitle>Top Patients Fidèles</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {topPatients.map((patient) => (
                  <div key={patient.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div>
                      <p className="font-medium">{patient.name}</p>
                      <p className="text-sm text-gray-600">{patient.invoices} facture(s)</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">{formatAmount(patient.lifetime_spend)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Prévisions */}
        {activeTab === 'forecast' && forecast && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Prévision des Revenus (30 jours)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Total prévu</p>
                    <p className="text-3xl font-bold text-blue-600">{formatAmount(forecast.total_forecast)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Moyenne quotidienne</p>
                    <p className="text-3xl font-bold">{formatAmount(forecast.avg_daily_revenue)}</p>
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-2">Répartition par jour</p>
                  <div className="space-y-1 max-h-64 overflow-y-auto">
                    {forecast.forecast_by_day.slice(-7).map((revenue, index, days) => {
                      const maxRevenue = Math.max(...forecast.forecast_by_day, 1);
                      const day = new Date();
                      day.setDate(day.getDate() + forecast.forecast_by_day.length - days.length + index + 1);
                      return (
                        <div key={day.toISOString()} className="flex items-center justify-between text-sm">
                          <span>{day.toLocaleDateString('fr-FR')}</span>
                          <div className="flex items-center gap-2">
                            <div className="w-32 bg-gray-200 rounded h-2">
                              <div className="bg-blue-600 h-2 rounded" style={{ width: `${(revenue / maxRevenue) * 100}%` }} />
                            </div>
                            <span className="font-medium">{formatAmount(revenue)}</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
