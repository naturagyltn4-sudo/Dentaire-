import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { api } from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import { AlertCircle, ArrowUpRight, Calendar, CheckCircle2, Clock3, DollarSign, FileText, Plus, Sparkles, Users } from 'lucide-react';
import { Link } from 'wouter';
import { PointageWidget } from '@/components/dashboard/PointageWidget';
import { useTranslation } from 'react-i18next';

interface DashboardStats { todayAppointments: number; stockAlerts: number; unpaidInvoices: number; socialMessages: number; }
function todayLocalDate(): string { const now = new Date(); return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`; }

export default function Dashboard() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<DashboardStats>({ todayAppointments: 0, stockAlerts: 0, unpaidInvoices: 0, socialMessages: 0 });

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true);
        const today = todayLocalDate();
        const [agendaRes, stockRes, facturesRes, socialRes] = await Promise.allSettled([
          api.get(`/agenda?date_debut=${today}T00:00:00&date_fin=${today}T23:59:59&vue=jour`),
          api.get('/injectables/stock'), api.get('/factures'), api.get('/social/analytics'),
        ]);
        const todayAppointments = agendaRes.status === 'fulfilled' && Array.isArray(agendaRes.value.data) ? agendaRes.value.data.length : 0;
        const stockAlerts = stockRes.status === 'fulfilled' && stockRes.value.data?.total_alertes !== undefined ? stockRes.value.data.total_alertes : 0;
        const unpaidInvoices = facturesRes.status === 'fulfilled' && Array.isArray(facturesRes.value.data) ? facturesRes.value.data.filter((f: { statut: string }) => ['envoyee', 'partiellement_payee'].includes(f.statut)).length : 0;
        let socialMessages = 0;
        if (socialRes.status === 'fulfilled' && socialRes.value.data?.messages) socialMessages = Object.values(socialRes.value.data.messages).reduce((total: number, item: any) => total + (item.nouveau || 0), 0);
        setStats({ todayAppointments, stockAlerts, unpaidInvoices, socialMessages });
      } catch (err) { console.error('Failed to load dashboard data:', err); } finally { setIsLoading(false); }
    };
    loadDashboardData();
  }, []);

  if (isLoading) return <DashboardLayout><div className="flex h-96 items-center justify-center"><Spinner /></div></DashboardLayout>;

  const cards = [
    { label: t('dashboard.stats_appointments'), value: stats.todayAppointments, detail: 'rendez-vous aujourd’hui', icon: Calendar, tone: 'text-primary', bg: 'bg-primary/10' },
    { label: t('dashboard.stock_alerts', 'Alertes stock'), value: stats.stockAlerts, detail: 'produits à surveiller', icon: AlertCircle, tone: stats.stockAlerts ? 'text-rose-600' : 'text-emerald-600', bg: stats.stockAlerts ? 'bg-rose-500/10' : 'bg-emerald-500/10' },
    { label: t('dashboard.unpaid_invoices', 'Factures impayées'), value: stats.unpaidInvoices, detail: 'en attente de règlement', icon: DollarSign, tone: 'text-amber-600', bg: 'bg-amber-500/10' },
    { label: t('dashboard.social_messages', 'Messages sociaux'), value: stats.socialMessages, detail: 'à traiter par l’équipe', icon: FileText, tone: 'text-sky-600', bg: 'bg-sky-500/10' },
  ];
  const actions = [{ href: '/agenda', label: 'Ouvrir l’agenda', caption: 'Piloter les rendez-vous', icon: Calendar }, { href: '/patients', label: 'Nouveau patient', caption: 'Créer un dossier', icon: Users }, { href: '/invoices', label: 'Émettre une facture', caption: 'Suivre les règlements', icon: DollarSign }, { href: '/stock', label: 'Contrôler le stock', caption: 'Scanner un lot', icon: AlertCircle }];

  return <DashboardLayout>
    <div className="space-y-8">
      <section className="relative overflow-hidden rounded-[1.75rem] bg-primary px-6 py-7 text-primary-foreground shadow-[0_24px_70px_oklch(0.25_0.05_188_/_18%)] lg:px-9 lg:py-9">
        <div className="absolute -right-16 -top-24 h-72 w-72 rounded-full border border-primary-foreground/10" /><div className="absolute -bottom-32 right-24 h-64 w-64 rounded-full border border-primary-foreground/10" />
        <div className="relative max-w-3xl"><div className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase tracking-[.18em] text-sidebar-primary"><Sparkles className="h-4 w-4" /> Cabinet cockpit</div><h1 className="max-w-2xl text-3xl font-semibold tracking-[-.04em] lg:text-5xl">Bonjour {user?.prenom},<br /><span className="text-sidebar-primary">votre cabinet avance.</span></h1><p className="mt-4 max-w-xl text-sm leading-6 text-primary-foreground/70">Une vue calme et précise de votre activité, pour prendre les bonnes décisions avant même le premier patient.</p><div className="mt-7 flex flex-wrap gap-3"><Link href="/agenda" className="inline-flex items-center gap-2 rounded-full bg-sidebar-primary px-4 py-2.5 text-sm font-bold text-sidebar-primary-foreground shadow-lg transition hover:-translate-y-0.5"><Plus className="h-4 w-4" /> Planifier un rendez-vous</Link><Link href="/patients" className="inline-flex items-center gap-2 rounded-full border border-primary-foreground/20 px-4 py-2.5 text-sm font-semibold transition hover:bg-primary-foreground/10">Voir les patients <ArrowUpRight className="h-4 w-4" /></Link></div></div>
      </section>
      <section><div className="mb-4 flex items-end justify-between"><div><p className="premium-kicker">Vue opérationnelle</p><h2 className="mt-1 text-2xl font-semibold tracking-tight">Aujourd’hui au cabinet</h2></div><div className="hidden items-center gap-2 text-xs text-muted-foreground sm:flex"><Clock3 className="h-4 w-4" /> Mise à jour en temps réel</div></div><div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">{cards.map(({ label, value, detail, icon: Icon, tone, bg }) => <Card key={label} className="premium-card rounded-2xl"><CardContent className="p-5"><div className="flex items-start justify-between"><div className={`rounded-xl p-2.5 ${bg}`}><Icon className={`h-5 w-5 ${tone}`} /></div><span className="text-[10px] font-bold uppercase tracking-widest text-muted-foreground">Live</span></div><div className="premium-number mt-6 text-4xl font-semibold">{value}</div><p className="mt-1 text-sm font-medium">{label}</p><p className="mt-1 text-xs text-muted-foreground">{detail}</p></CardContent></Card>)}</div></section>
      <PointageWidget />
      <section><div className="mb-4 flex items-end justify-between"><div><p className="premium-kicker">Accès express</p><h2 className="mt-1 text-2xl font-semibold tracking-tight">Les gestes du quotidien</h2></div><CheckCircle2 className="h-5 w-5 text-emerald-600" /></div><div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">{actions.map(({ href, label, caption, icon: Icon }) => <Link key={href} href={href} className="premium-action group flex items-center gap-4 rounded-2xl p-4"><div className="rounded-xl bg-primary/10 p-3 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground"><Icon className="h-5 w-5" /></div><div className="min-w-0 flex-1"><p className="font-semibold tracking-tight">{label}</p><p className="mt-0.5 text-xs text-muted-foreground">{caption}</p></div><ArrowUpRight className="h-4 w-4 text-muted-foreground transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary" /></Link>)}</div></section>
    </div>
  </DashboardLayout>;
}
