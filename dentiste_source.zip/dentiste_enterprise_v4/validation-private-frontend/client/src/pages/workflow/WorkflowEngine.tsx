import { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { api } from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import { AlertCircle, BarChart3, CheckCircle, Edit2, Pause, Play, Plus, Save, Trash2, X } from 'lucide-react';

type TriggerType = 'manual' | 'event_based' | 'condition_based' | 'scheduled';
type ActionType = 'send_email' | 'send_sms' | 'send_whatsapp';

interface Workflow {
  id: number;
  nom: string;
  description?: string;
  trigger_type: TriggerType;
  enabled: boolean;
  status: string;
  created_at: string;
}

interface Stats {
  total_executions: number;
  completed: number;
  failed: number;
  pending: number;
  success_rate: number;
}

interface WorkflowForm {
  nom: string;
  description: string;
  trigger_type: TriggerType;
  action_type: ActionType;
  template: string;
}

const emptyForm: WorkflowForm = {
  nom: '', description: '', trigger_type: 'manual', action_type: 'send_email',
  template: 'Brouillon à valider par l’équipe de la clinique',
};

const triggerLabels: Record<TriggerType, string> = {
  manual: 'Manuel', event_based: 'Événement clinique', condition_based: 'Condition', scheduled: 'Planifié',
};

const templates: Array<WorkflowForm & { color: string }> = [
  { nom: 'Rappel de contrôle annuel', description: 'Préparer un rappel pour les patients dont le contrôle annuel approche.', trigger_type: 'scheduled', action_type: 'send_email', template: 'Rappel de contrôle annuel – brouillon à valider', color: 'bg-sky-50 border-sky-200' },
  { nom: 'Suivi post-soin', description: 'Préparer un message de suivi après un soin terminé.', trigger_type: 'event_based', action_type: 'send_sms', template: 'Suivi post-soin – brouillon à valider', color: 'bg-emerald-50 border-emerald-200' },
  { nom: 'Relance de devis', description: 'Préparer une relance lorsqu’un devis reste en attente.', trigger_type: 'condition_based', action_type: 'send_email', template: 'Relance de devis – brouillon à valider', color: 'bg-violet-50 border-violet-200' },
  { nom: 'Rappel orthodontie', description: 'Préparer un rappel pour un suivi orthodontique.', trigger_type: 'scheduled', action_type: 'send_sms', template: 'Rappel de suivi orthodontique – brouillon à valider', color: 'bg-amber-50 border-amber-200' },
  { nom: 'Suivi prothèse', description: 'Préparer un suivi après pose ou ajustement de prothèse.', trigger_type: 'event_based', action_type: 'send_email', template: 'Suivi prothèse – brouillon à valider', color: 'bg-rose-50 border-rose-200' },
  { nom: 'Patient inactif', description: 'Préparer une relance pour les patients inactifs.', trigger_type: 'condition_based', action_type: 'send_whatsapp', template: 'Relance patient inactif – brouillon à valider', color: 'bg-orange-50 border-orange-200' },
];

const errorMessage = (error: any, fallback: string) => error?.response?.data?.detail || error?.message || fallback;

export default function WorkflowEngine() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [workflows, setWorkflows] = useState<Workflow[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Workflow | null>(null);
  const [form, setForm] = useState<WorkflowForm>(emptyForm);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      // Le routeur FastAPI expose /workflows/ : la barre finale évite une redirection HTTP 307.
      const [workflowResponse, statsResponse] = await Promise.all([
        api.get('/workflows/'),
        api.get('/workflows/statistics/summary'),
      ]);
      setWorkflows(Array.isArray(workflowResponse.data?.data) ? workflowResponse.data.data : []);
      const data = statsResponse.data?.data;
      setStats(data ? {
        total_executions: data.total_executions ?? 0,
        completed: data.completed ?? 0,
        failed: data.failed ?? 0,
        pending: data.pending ?? 0,
        success_rate: data.success_rate ?? 0,
      } : null);
    } catch (err: any) {
      setError(errorMessage(err, 'Erreur lors du chargement des workflows.'));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void loadData(); }, []);

  const openCreate = (template?: WorkflowForm) => {
    setError(null); setNotice(null); setEditing(null); setForm(template ? { ...template } : { ...emptyForm }); setModalOpen(true);
  };

  const openEdit = (workflow: Workflow) => {
    setError(null); setNotice(null); setEditing(workflow);
    setForm({ nom: workflow.nom, description: workflow.description || '', trigger_type: workflow.trigger_type, action_type: 'send_email', template: '' });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.nom.trim()) { setError('Le nom du workflow est requis.'); return; }
    try {
      setSaving(true); setError(null);
      if (editing) {
        await api.put(`/workflows/${editing.id}`, { nom: form.nom.trim(), description: form.description.trim() || null });
        setNotice('Workflow mis à jour avec succès.');
      } else {
        await api.post('/workflows/', {
          nom: form.nom.trim(),
          description: form.description.trim() || null,
          trigger_type: form.trigger_type,
          trigger_config: { type: form.trigger_type },
          // Les canaux sortants restent des brouillons exigeant une validation humaine.
          actions: [{ type: form.action_type, config: { template: form.template.trim() || 'Brouillon à valider par l’équipe' } }],
        });
        setNotice('Workflow créé avec succès.');
      }
      setModalOpen(false);
      await loadData();
    } catch (err: any) {
      setError(errorMessage(err, 'Impossible d’enregistrer le workflow.'));
    } finally { setSaving(false); }
  };

  const execute = async (workflowId: number) => {
    try {
      setError(null); setNotice(null);
      await api.post(`/workflows/${workflowId}/execute`);
      setNotice('Exécution enregistrée. Les communications restent en brouillon jusqu’à validation humaine.');
      await loadData();
    } catch (err: any) { setError(errorMessage(err, 'Erreur lors de l’exécution du workflow.')); }
  };

  const toggle = async (workflow: Workflow) => {
    try {
      setError(null);
      const enabled = !workflow.enabled;
      await api.put(`/workflows/${workflow.id}`, { enabled, status: enabled ? 'active' : 'paused' });
      setNotice(enabled ? 'Workflow activé.' : 'Workflow mis en pause.');
      await loadData();
    } catch (err: any) { setError(errorMessage(err, 'Impossible de modifier le statut du workflow.')); }
  };

  const remove = async (workflowId: number) => {
    if (!window.confirm('Supprimer définitivement ce workflow ?')) return;
    try {
      setError(null);
      await api.delete(`/workflows/${workflowId}`);
      setNotice('Workflow supprimé.');
      await loadData();
    } catch (err: any) { setError(errorMessage(err, 'Erreur lors de la suppression du workflow.')); }
  };

  if (loading) return <DashboardLayout><div className="flex h-screen items-center justify-center"><Spinner /></div></DashboardLayout>;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div><h1 className="text-3xl font-bold text-gray-900">Automatisations</h1><p className="mt-2 text-gray-600">Scénarios cliniques avec validation humaine des communications.</p></div>
          <button onClick={() => openCreate()} className="inline-flex items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700"><Plus className="h-5 w-5" />Nouveau workflow</button>
        </div>

        {error && <Card className="border-red-200 bg-red-50"><CardContent className="pt-6"><div className="flex gap-2 text-red-700"><AlertCircle className="mt-0.5 h-5 w-5 shrink-0" /><span>{error}</span></div></CardContent></Card>}
        {notice && <Card className="border-emerald-200 bg-emerald-50"><CardContent className="pt-6"><div className="flex gap-2 text-emerald-800"><CheckCircle className="mt-0.5 h-5 w-5 shrink-0" /><span>{notice}</span></div></CardContent></Card>}

        {stats && <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {[
            ['Total', stats.total_executions, 'Exécutions (30 jours)'], ['Réussies', stats.completed, 'Complétées'], ['Échouées', stats.failed, 'À analyser'], ['En attente', stats.pending, 'Validation requise'], ['Taux de réussite', `${stats.success_rate.toFixed(1)}%`, 'Exécutions clôturées'],
          ].map(([label, value, hint]) => <Card key={String(label)}><CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-gray-600">{label}</CardTitle></CardHeader><CardContent><div className="text-3xl font-bold text-gray-900">{value}</div><p className="mt-2 text-xs text-gray-500">{hint}</p></CardContent></Card>)}
        </div>}

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
          {workflows.length === 0 ? <Card className="lg:col-span-2"><CardContent className="py-12 text-center text-gray-600">Aucun workflow créé. Utilisez un modèle ci-dessous ou créez votre premier scénario.</CardContent></Card> : workflows.map((workflow) => (
            <Card key={workflow.id} className={workflow.enabled ? '' : 'opacity-70'}>
              <CardHeader><div className="flex items-start justify-between gap-3"><div><CardTitle className="text-lg text-gray-900">{workflow.nom}</CardTitle>{workflow.description && <p className="mt-1 text-sm text-gray-600">{workflow.description}</p>}</div><span className={`rounded-full px-2.5 py-1 text-xs font-medium ${workflow.status === 'active' ? 'bg-emerald-100 text-emerald-700' : workflow.status === 'paused' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-700'}`}>{workflow.status === 'active' ? 'Actif' : workflow.status === 'paused' ? 'En pause' : 'Brouillon'}</span></div></CardHeader>
              <CardContent><dl className="grid grid-cols-2 gap-3 text-sm"><div><dt className="text-xs text-gray-500">Déclencheur</dt><dd className="mt-1 font-medium text-gray-800">{triggerLabels[workflow.trigger_type] || workflow.trigger_type}</dd></div><div><dt className="text-xs text-gray-500">Créé le</dt><dd className="mt-1 font-medium text-gray-800">{new Date(workflow.created_at).toLocaleDateString('fr-FR')}</dd></div></dl><div className="mt-5 grid grid-cols-2 gap-2 border-t pt-4 sm:grid-cols-4"><button onClick={() => void execute(workflow.id)} className="inline-flex items-center justify-center gap-1.5 rounded-md bg-blue-50 px-2 py-2 text-sm font-medium text-blue-700 hover:bg-blue-100"><Play className="h-4 w-4" />Essayer</button><button onClick={() => void toggle(workflow)} className="inline-flex items-center justify-center gap-1.5 rounded-md bg-amber-50 px-2 py-2 text-sm font-medium text-amber-800 hover:bg-amber-100">{workflow.enabled ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}{workflow.enabled ? 'Pause' : 'Activer'}</button><button onClick={() => openEdit(workflow)} className="inline-flex items-center justify-center gap-1.5 rounded-md bg-gray-50 px-2 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100"><Edit2 className="h-4 w-4" />Éditer</button><button onClick={() => void remove(workflow.id)} className="inline-flex items-center justify-center gap-1.5 rounded-md bg-red-50 px-2 py-2 text-sm font-medium text-red-700 hover:bg-red-100"><Trash2 className="h-4 w-4" />Supprimer</button></div></CardContent>
            </Card>
          ))}
        </div>

        <Card><CardHeader><CardTitle className="flex items-center gap-2"><BarChart3 className="h-5 w-5" />Modèles dentaires</CardTitle></CardHeader><CardContent><p className="mb-4 text-sm text-gray-600">Un clic préremplit un workflow ; la configuration reste modifiable avant enregistrement.</p><div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">{templates.map((template) => <button key={template.nom} onClick={() => openCreate(template)} className={`rounded-lg border p-4 text-left hover:shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${template.color}`}><p className="font-semibold text-gray-900">{template.nom}</p><p className="mt-1 text-sm text-gray-600">{template.description}</p><span className="mt-3 inline-block text-xs font-medium text-blue-700">Utiliser ce modèle</span></button>)}</div></CardContent></Card>
      </div>

      {modalOpen && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" role="dialog" aria-modal="true" aria-labelledby="workflow-modal-title"><div className="max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-xl bg-white p-6 shadow-xl"><div className="flex items-start justify-between gap-4"><div><h2 id="workflow-modal-title" className="text-xl font-bold text-gray-900">{editing ? 'Modifier le workflow' : 'Créer un workflow'}</h2>{!editing && <p className="mt-1 text-sm text-gray-600">Les messages sont enregistrés comme brouillons à valider par un membre autorisé.</p>}</div><button onClick={() => setModalOpen(false)} aria-label="Fermer" className="rounded-md p-1 text-gray-500 hover:bg-gray-100"><X className="h-5 w-5" /></button></div><div className="mt-6 space-y-4"><label className="block text-sm font-medium text-gray-700">Nom<input value={form.nom} onChange={(event) => setForm({ ...form, nom: event.target.value })} maxLength={200} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm" /></label><label className="block text-sm font-medium text-gray-700">Description<textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} rows={3} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm" /></label><label className="block text-sm font-medium text-gray-700">Déclencheur<select value={form.trigger_type} onChange={(event) => setForm({ ...form, trigger_type: event.target.value as TriggerType })} disabled={Boolean(editing)} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm disabled:bg-gray-50">{Object.entries(triggerLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>{!editing && <><label className="block text-sm font-medium text-gray-700">Canal du brouillon<select value={form.action_type} onChange={(event) => setForm({ ...form, action_type: event.target.value as ActionType })} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm"><option value="send_email">E-mail (brouillon)</option><option value="send_sms">SMS (brouillon)</option><option value="send_whatsapp">Messagerie (brouillon)</option></select></label><label className="block text-sm font-medium text-gray-700">Texte de référence<textarea value={form.template} onChange={(event) => setForm({ ...form, template: event.target.value })} rows={3} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 shadow-sm" /></label></>}</div><div className="mt-6 flex justify-end gap-3"><button onClick={() => setModalOpen(false)} disabled={saving} className="rounded-md border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">Annuler</button><button onClick={() => void save()} disabled={saving} className="inline-flex items-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60"><Save className="h-4 w-4" />{saving ? 'Enregistrement…' : 'Enregistrer'}</button></div></div></div>}
    </DashboardLayout>
  );
}
