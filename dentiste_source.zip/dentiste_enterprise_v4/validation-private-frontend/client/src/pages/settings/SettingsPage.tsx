import { FormEvent, useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useBranding } from '@/contexts/BrandingContext';
import { useAuth } from '@/contexts/AuthContext';
import {
  adminTeamApi,
  AuditEvent,
  BrandingResponse,
  settingsApi,
  TeamMember,
} from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import { History, RefreshCcw, ShieldCheck, Upload, UserPlus } from 'lucide-react';
import { toast } from 'sonner';

const ROLE_OPTIONS = [
  { value: 'assistante', label: 'Assistante' },
  { value: 'medecin', label: 'Médecin / praticien' },
  { value: 'orthodontiste', label: 'Orthodontiste' },
  { value: 'estheticienne', label: 'Esthéticienne' },
  { value: 'commercial', label: 'Commercial' },
  { value: 'directrice', label: 'Directrice' },
  { value: 'admin', label: 'Administrateur' },
];

const roleLabel = (role: string) => ROLE_OPTIONS.find((item) => item.value === role)?.label || role;

const getErrorMessage = (error: unknown, fallback: string) => {
  const detail = (error as { response?: { data?: { detail?: unknown } } })?.response?.data?.detail;
  if (typeof detail === 'string' && detail.trim()) return detail;
  if (Array.isArray(detail)) {
    const messages = detail
      .map((item) => (typeof item === 'object' && item && 'msg' in item && typeof item.msg === 'string' ? item.msg : null))
      .filter((message): message is string => Boolean(message));
    if (messages.length) return messages.join(' ');
  }
  return fallback;
};

export default function SettingsPage() {
  const { branding, applyTheme } = useBranding();
  const { user } = useAuth();
  const visibleRoleOptions = user?.role === 'admin'
    ? ROLE_OPTIONS
    : ROLE_OPTIONS.filter((role) => role.value !== 'admin');
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState<Partial<BrandingResponse>>({});
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [heroFile, setHeroFile] = useState<File | null>(null);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [audit, setAudit] = useState<AuditEvent[]>([]);
  const [teamLoading, setTeamLoading] = useState(false);
  const [teamSaving, setTeamSaving] = useState(false);
  const [teamForm, setTeamForm] = useState({
    email: '',
    nom: '',
    prenom: '',
    role: 'assistante',
    mot_de_passe: '',
    telephone: '',
    specialite: '',
    agenda_color: '#2563EB',
  });

  useEffect(() => {
    if (branding) {
      setFormData({
        nom_clinique: branding.nom_clinique,
        couleur_primaire: branding.couleur_primaire,
        couleur_secondaire: branding.couleur_secondaire,
        contenu_landing: branding.contenu_landing,
      });
    }
  }, [branding]);

  const loadTeam = async () => {
    try {
      setTeamLoading(true);
      const [teamResponse, auditResponse] = await Promise.all([
        adminTeamApi.list(),
        adminTeamApi.audit({ limit: 100 }),
      ]);
      setTeam(teamResponse.data);
      setAudit(auditResponse.data);
    } catch (error: any) {
      toast.error(getErrorMessage(error, 'Impossible de charger l’équipe médicale'));
    } finally {
      setTeamLoading(false);
    }
  };

  useEffect(() => {
    void loadTeam();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name.startsWith('contenu_')) {
      const key = name.replace('contenu_', '');
      setFormData({
        ...formData,
        contenu_landing: {
          ...formData.contenu_landing,
          [key]: value,
        },
      });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) setLogoFile(e.target.files[0]);
  };

  const handleHeroChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) setHeroFile(e.target.files[0]);
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);
      const response = await settingsApi.updateBranding(formData);
      applyTheme(response.data);
      toast.success('Paramètres sauvegardés');
      if (logoFile) {
        await settingsApi.uploadLogo(logoFile);
        toast.success('Logo téléchargé');
        setLogoFile(null);
      }
      if (heroFile) {
        await settingsApi.uploadHero(heroFile);
        toast.success('Photo de présentation téléchargée');
        setHeroFile(null);
      }
    } catch (err: any) {
      toast.error(getErrorMessage(err, 'Erreur lors de la sauvegarde'));
    } finally {
      setIsSaving(false);
    }
  };

  const handleCreateMember = async (event: FormEvent) => {
    event.preventDefault();
    try {
      setTeamSaving(true);
      await adminTeamApi.create({
        ...teamForm,
        taux_commission: 0,
      });
      toast.success(`${teamForm.prenom} ${teamForm.nom} dispose maintenant de son compte utilisateur.`);
      setTeamForm({
        email: '',
        nom: '',
        prenom: '',
        role: 'assistante',
        mot_de_passe: '',
        telephone: '',
        specialite: '',
        agenda_color: '#2563EB',
      });
      await loadTeam();
    } catch (error: any) {
      toast.error(getErrorMessage(error, 'Impossible de créer le compte'));
    } finally {
      setTeamSaving(false);
    }
  };

  const toggleMember = async (member: TeamMember) => {
    try {
      await adminTeamApi.update(member.id, { is_active: !member.is_active });
      toast.success(member.is_active ? 'Compte désactivé' : 'Compte réactivé');
      await loadTeam();
    } catch (error: any) {
      toast.error(getErrorMessage(error, 'Impossible de modifier le compte'));
    }
  };

  const resetPassword = async (member: TeamMember) => {
    const password = window.prompt(`Nouveau mot de passe pour ${member.prenom} ${member.nom} (12 caractères minimum)`);
    if (!password) return;
    try {
      await adminTeamApi.resetPassword(member.id, password);
      toast.success('Mot de passe réinitialisé');
      await loadTeam();
    } catch (error: any) {
      toast.error(getErrorMessage(error, 'Impossible de réinitialiser le mot de passe'));
    }
  };

  if (!branding) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96"><Spinner /></div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6 max-w-6xl">
        <div>
          <h1 className="text-3xl font-bold">Paramètres</h1>
          <p className="text-muted-foreground mt-1">Configuration de la clinique et gestion de l’équipe médicale</p>
        </div>

        <Card>
          <CardHeader><CardTitle>Équipe médicale et comptes utilisateurs</CardTitle></CardHeader>
          <CardContent className="space-y-6">
            <div className="rounded-lg border bg-muted/30 p-4 text-sm">
              Chaque membre possède un compte indépendant, un rôle et une interface adaptée. Les accès sont filtrés par rôle et chaque action sur un patient ou un dossier est historisée.
            </div>

            <form onSubmit={handleCreateMember} className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <div><Label htmlFor="team_email">Email de connexion</Label><Input id="team_email" type="email" required value={teamForm.email} onChange={(e) => setTeamForm({ ...teamForm, email: e.target.value })} placeholder="mme.x@clinique.tn" /></div>
              <div><Label htmlFor="team_prenom">Prénom</Label><Input id="team_prenom" required value={teamForm.prenom} onChange={(e) => setTeamForm({ ...teamForm, prenom: e.target.value })} /></div>
              <div><Label htmlFor="team_nom">Nom</Label><Input id="team_nom" required value={teamForm.nom} onChange={(e) => setTeamForm({ ...teamForm, nom: e.target.value })} /></div>
              <div><Label htmlFor="team_role">Rôle</Label><select id="team_role" className="h-10 w-full rounded-md border bg-background px-3 text-sm" value={teamForm.role} onChange={(e) => setTeamForm({ ...teamForm, role: e.target.value })}>{visibleRoleOptions.map((role) => <option key={role.value} value={role.value}>{role.label}</option>)}</select></div>
              <div><Label htmlFor="team_password">Mot de passe initial</Label><Input id="team_password" type="password" minLength={12} required value={teamForm.mot_de_passe} onChange={(e) => setTeamForm({ ...teamForm, mot_de_passe: e.target.value })} placeholder="12 caractères minimum" /></div>
              <div><Label htmlFor="team_phone">Téléphone</Label><Input id="team_phone" value={teamForm.telephone} onChange={(e) => setTeamForm({ ...teamForm, telephone: e.target.value })} /></div>
              <div><Label htmlFor="team_specialite">Spécialité</Label><Input id="team_specialite" value={teamForm.specialite} onChange={(e) => setTeamForm({ ...teamForm, specialite: e.target.value })} placeholder="Implantologie, orthodontie…" /></div>
              <div><Label htmlFor="team_color">Couleur agenda</Label><Input id="team_color" type="color" className="h-10" value={teamForm.agenda_color} onChange={(e) => setTeamForm({ ...teamForm, agenda_color: e.target.value })} /></div>
              <div className="flex items-end"><Button type="submit" disabled={teamSaving}><UserPlus className="mr-2 h-4 w-4" />{teamSaving ? 'Création…' : 'Créer le compte'}</Button></div>
            </form>

            {teamLoading ? <Spinner /> : <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b text-left"><th className="p-2">Membre</th><th className="p-2">Rôle</th><th className="p-2">Spécialité</th><th className="p-2">État</th><th className="p-2">Actions</th></tr></thead><tbody>{team.map((member) => <tr key={member.id} className="border-b"><td className="p-2"><div className="font-medium">{member.prenom} {member.nom}</div><div className="text-xs text-muted-foreground">{member.email}</div></td><td className="p-2">{roleLabel(member.role)}</td><td className="p-2">{member.specialite || '—'}</td><td className="p-2"><span className={member.is_active ? 'text-green-600' : 'text-red-600'}>{member.is_active ? 'Actif' : 'Désactivé'}</span>{member.mfa_enabled && <span className="ml-2 text-xs">MFA</span>}</td><td className="p-2"><div className="flex flex-wrap gap-2"><Button size="sm" variant="outline" onClick={() => void toggleMember(member)}>{member.is_active ? 'Désactiver' : 'Réactiver'}</Button><Button size="sm" variant="outline" onClick={() => void resetPassword(member)}><RefreshCcw className="mr-1 h-3 w-3" />Mot de passe</Button></div></td></tr>)}</tbody></table></div>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="flex items-center gap-2"><History className="h-5 w-5" />Journal des accès et modifications</CardTitle></CardHeader>
          <CardContent>
            <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground"><span>Chaque ligne indique qui a touché un patient ou une ressource.</span><Button size="sm" variant="outline" onClick={() => void loadTeam()}><RefreshCcw className="mr-2 h-4 w-4" />Actualiser</Button></div>
            <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b text-left"><th className="p-2">Date</th><th className="p-2">Utilisateur</th><th className="p-2">Action</th><th className="p-2">Ressource</th><th className="p-2">Patient</th><th className="p-2">Détails</th></tr></thead><tbody>{audit.map((event) => <tr key={event.id} className="border-b align-top"><td className="p-2 whitespace-nowrap">{event.created_at ? new Date(event.created_at).toLocaleString('fr-FR') : '—'}</td><td className="p-2">{event.utilisateur_nom}<div className="text-xs text-muted-foreground">{roleLabel(event.utilisateur_role)}</div></td><td className="p-2 font-medium">{event.action}</td><td className="p-2">{event.resource_type} #{event.resource_id ?? '—'}</td><td className="p-2">{event.patient_id ?? '—'}</td><td className="p-2 text-xs">{Object.keys(event.details || {}).length ? JSON.stringify(event.details) : '—'}</td></tr>)}</tbody></table>{audit.length === 0 && <p className="py-6 text-center text-muted-foreground">Aucun événement enregistré.</p>}</div>
          </CardContent>
        </Card>

        <Card><CardHeader><CardTitle>Informations générales</CardTitle></CardHeader><CardContent className="space-y-4"><div><Label htmlFor="nom_clinique">Nom de la clinique</Label><Input id="nom_clinique" name="nom_clinique" value={formData.nom_clinique || ''} onChange={handleInputChange} placeholder="Nom de votre clinique" /></div><div><Label>Logo</Label><div className="flex items-center gap-4">{branding.logo_url && <img src={branding.logo_url} alt="Logo" className="h-16 w-16 object-contain border rounded" />}<div className="flex-1"><Input type="file" accept="image/*" onChange={handleLogoChange} className="cursor-pointer" /><p className="text-xs text-muted-foreground mt-1">PNG, JPG (max 2 Mo)</p></div></div></div></CardContent></Card>
        <Card><CardHeader><CardTitle>Couleurs</CardTitle></CardHeader><CardContent className="space-y-4"><div><Label htmlFor="couleur_primaire">Couleur primaire</Label><div className="flex items-center gap-2"><Input id="couleur_primaire" name="couleur_primaire" type="color" value={formData.couleur_primaire || '#0066CC'} onChange={handleInputChange} className="w-16 h-10 cursor-pointer" /><Input type="text" value={formData.couleur_primaire || '#0066CC'} onChange={handleInputChange} name="couleur_primaire" className="flex-1" /></div></div><div><Label htmlFor="couleur_secondaire">Couleur secondaire</Label><div className="flex items-center gap-2"><Input id="couleur_secondaire" name="couleur_secondaire" type="color" value={formData.couleur_secondaire || '#6B7280'} onChange={handleInputChange} className="w-16 h-10 cursor-pointer" /><Input type="text" value={formData.couleur_secondaire || '#6B7280'} onChange={handleInputChange} name="couleur_secondaire" className="flex-1" /></div></div></CardContent></Card>
        <Card><CardHeader><CardTitle>Contenu de la landing page</CardTitle></CardHeader><CardContent className="space-y-4"><div><Label htmlFor="contenu_titre">Titre</Label><Input id="contenu_titre" name="contenu_titre" value={formData.contenu_landing?.titre || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_sous_titre">Sous-titre</Label><Input id="contenu_sous_titre" name="contenu_sous_titre" value={formData.contenu_landing?.sous_titre || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_adresse">Adresse</Label><Input id="contenu_adresse" name="contenu_adresse" value={formData.contenu_landing?.adresse || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_telephone">Téléphone</Label><Input id="contenu_telephone" name="contenu_telephone" value={formData.contenu_landing?.telephone || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_horaires">Horaires</Label><Textarea id="contenu_horaires" name="contenu_horaires" value={formData.contenu_landing?.horaires || ''} onChange={handleInputChange} rows={3} /></div></CardContent></Card>

        <Card>
          <CardHeader><CardTitle>Présentation, coordonnées et réseaux sociaux</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div><Label htmlFor="contenu_description_longue">Présentation longue</Label><Textarea id="contenu_description_longue" name="contenu_description_longue" value={formData.contenu_landing?.description_longue || ''} onChange={handleInputChange} rows={5} placeholder="Présentez l’expertise et les engagements de la clinique." /></div>
            <div className="grid gap-4 md:grid-cols-2"><div><Label htmlFor="contenu_ville">Ville</Label><Input id="contenu_ville" name="contenu_ville" value={formData.contenu_landing?.ville || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_email">Email</Label><Input id="contenu_email" name="contenu_email" type="email" value={formData.contenu_landing?.email || ''} onChange={handleInputChange} /></div></div>
            <div className="grid gap-4 md:grid-cols-2"><div><Label htmlFor="contenu_whatsapp">WhatsApp</Label><Input id="contenu_whatsapp" name="contenu_whatsapp" value={formData.contenu_landing?.whatsapp || ''} onChange={handleInputChange} placeholder="216XXXXXXXX" /></div><div><Label htmlFor="contenu_photo_hero_url">URL photo hero (facultatif)</Label><Input id="contenu_photo_hero_url" name="contenu_photo_hero_url" value={formData.contenu_landing?.photo_hero_url || ''} onChange={handleInputChange} /></div></div>
            <div className="grid gap-4 md:grid-cols-3"><div><Label htmlFor="contenu_instagram">Instagram</Label><Input id="contenu_instagram" name="contenu_instagram" value={formData.contenu_landing?.instagram || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_facebook">Facebook</Label><Input id="contenu_facebook" name="contenu_facebook" value={formData.contenu_landing?.facebook || ''} onChange={handleInputChange} /></div><div><Label htmlFor="contenu_tiktok">TikTok</Label><Input id="contenu_tiktok" name="contenu_tiktok" value={formData.contenu_landing?.tiktok || ''} onChange={handleInputChange} /></div></div>
            <div><Label>Photo de présentation</Label><Input type="file" accept="image/*" onChange={handleHeroChange} className="cursor-pointer" /><p className="text-xs text-muted-foreground mt-1">JPG, PNG ou WebP, 2 Mo maximum.</p></div>
          </CardContent>
        </Card>

        <div className="flex gap-2"><Button onClick={() => void handleSave()} disabled={isSaving}><ShieldCheck className="mr-2 h-4 w-4" />{isSaving ? 'Sauvegarde…' : 'Sauvegarder les paramètres'}</Button><span className="hidden"><Upload /></span></div>
      </div>
    </DashboardLayout>
  );
}
