import React, { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { api, publicApi, bookingRequestsApi, type BookingRequest } from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import { useAuth } from '@/contexts/AuthContext';
import { Calendar, Plus, Clock, User, Video, Check, X } from 'lucide-react';
import { Link } from 'wouter';
import { toast } from 'sonner';
import { PatientAutocomplete, type PatientOption } from '@/components/patients/PatientAutocomplete';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';

interface Appointment {
  id: number;
  date_heure_debut: string;
  patient_id: number;
  patient_nom: string;
  praticien_id: number;
  praticien_nom: string;
  acte_nom?: string;
  statut: string;
  consentement_manquant: boolean;
  salle_id?: number;
  fauteuil_numero?: number;
}

interface Salle {
  id: number;
  nom: string;
  capacite_fauteuils: number;
}

const STATUT_LABELS: Record<string, { label: string; color: string }> = {
  planifie: { label: 'Planifié', color: 'bg-blue-100 text-blue-800' },
  confirme: { label: 'Confirmé', color: 'bg-green-100 text-green-800' },
  en_cours: { label: 'En cours', color: 'bg-yellow-100 text-yellow-800' },
  termine: { label: 'Terminé', color: 'bg-gray-200 text-gray-800' },
  annule: { label: 'Annulé', color: 'bg-red-100 text-red-800' },
  no_show: { label: 'Absence', color: 'bg-orange-100 text-orange-800' },
};

export default function AgendaView() {
  const { user } = useAuth();
  const canManage = ['directrice', 'assistante', 'medecin', 'orthodontiste', 'admin'].includes(user?.role || '');
  const canCancel = ['directrice', 'assistante', 'admin'].includes(user?.role || '');
  const [isLoading, setIsLoading] = useState(true);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [createOpen, setCreateOpen] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<Appointment | null>(null);
  const [salles, setSalles] = useState<Salle[]>([]);
  const [selectedSalleId, setSelectedSalleId] = useState<string>('');
  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>([]);
  const canProcessPublicRequests = ['directrice', 'assistante', 'admin'].includes(user?.role || '');

  const dateStr = selectedDate;
  const selectedDateLabel = (() => {
    const parsed = new Date(`${selectedDate}T12:00:00`);
    return Number.isNaN(parsed.getTime())
      ? 'Date invalide'
      : parsed.toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  })();

  useEffect(() => {
    loadSalles();
  }, []);

  useEffect(() => {
    loadAppointments();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateStr, selectedSalleId]);

  useEffect(() => {
    if (canProcessPublicRequests) loadBookingRequests();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canProcessPublicRequests]);

  const loadSalles = async () => {
    try {
      const response = await api.get('/agenda/salles');
      setSalles(response.data);
    } catch (err) {
      console.error('Failed to load salles:', err);
    }
  };

  const loadAppointments = async () => {
    try {
      setIsLoading(true);
      const response = await api.get('/agenda', {
        params: {
          vue: 'jour',
          date_debut: `${dateStr}T00:00:00`,
          date_fin: `${dateStr}T23:59:59`,
          salle_id: selectedSalleId || undefined,
        },
      });
      // GET /agenda renvoie un tableau brut, pas { rdvs: [...] }
      setAppointments(Array.isArray(response.data) ? response.data : []);
    } catch (err: any) {
      console.error('Failed to load appointments:', err);
      toast.error("Erreur lors du chargement de l'agenda");
    } finally {
      setIsLoading(false);
    }
  };

  const loadBookingRequests = async () => {
    try {
      const response = await bookingRequestsApi.list('pending');
      setBookingRequests(response.data);
    } catch (err) {
      console.error('Failed to load public booking requests:', err);
    }
  };

  const handleBookingDecision = async (request: BookingRequest, decision: 'approve' | 'reject') => {
    try {
      if (decision === 'approve') await bookingRequestsApi.approve(request.id);
      else await bookingRequestsApi.reject(request.id);
      toast.success(decision === 'approve' ? 'Demande approuvée et rendez-vous créé' : 'Demande rejetée');
      await Promise.all([loadBookingRequests(), loadAppointments()]);
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Impossible de traiter la demande');
    }
  };

  const handleStatusChange = async (rdv: Appointment, statut: string) => {
    try {
      await api.patch(`/agenda/rdv/${rdv.id}/statut`, { statut });
      toast.success('Statut mis à jour');
      loadAppointments();
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Erreur lors de la mise à jour');
    }
  };

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-96">
          <Spinner />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Agenda</h1>
            <p className="text-muted-foreground mt-1">
              {selectedDateLabel}
            </p>
          </div>
          {canManage && (
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Nouveau RDV
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Sélectionner une date</CardTitle>
            </CardHeader>
            <CardContent>
              <input
                type="date"
                value={dateStr}
                onChange={(e) => {
                  const value = e.target.value;
                  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) setSelectedDate(value);
                }}
                className="px-3 py-2 border rounded-md w-full"
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Filtrer par salle</CardTitle>
            </CardHeader>
            <CardContent>
              <select
                value={selectedSalleId}
                onChange={(e) => setSelectedSalleId(e.target.value)}
                className="px-3 py-2 border rounded-md w-full"
              >
                <option value="">Toutes les salles</option>
                {salles.map((s) => (
                  <option key={s.id} value={s.id}>{s.nom}</option>
                ))}
              </select>
            </CardContent>
          </Card>
        </div>

        {canProcessPublicRequests && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Demandes publiques à traiter</span>
                <span className="rounded-full bg-amber-100 px-2 py-1 text-xs text-amber-800">{bookingRequests.length}</span>
              </CardTitle>
              <p className="text-sm text-muted-foreground">Une demande devient un patient et un rendez-vous interne uniquement après approbation.</p>
            </CardHeader>
            <CardContent className="space-y-3">
              {bookingRequests.length === 0 ? (
                <p className="text-sm text-muted-foreground">Aucune demande publique en attente.</p>
              ) : bookingRequests.map((request) => (
                <div key={request.id} className="flex flex-col gap-3 rounded-lg border p-3 md:flex-row md:items-center md:justify-between">
                  <div>
                    <p className="font-medium">{request.prenom} {request.nom} · {request.telephone}</p>
                    <p className="text-sm text-muted-foreground">{request.acte_nom} · {request.praticien_nom}</p>
                    <p className="text-sm font-medium">{new Date(request.date_heure).toLocaleString('fr-FR')}</p>
                    <p className="text-xs text-muted-foreground">Référence #{request.id}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" onClick={() => handleBookingDecision(request, 'approve')}><Check className="mr-1 h-4 w-4" />Approuver</Button>
                    <Button size="sm" variant="outline" onClick={() => handleBookingDecision(request, 'reject')}><X className="mr-1 h-4 w-4" />Rejeter</Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {appointments.length === 0 ? (
            <Card>
              <CardContent className="pt-6">
                <p className="text-center text-muted-foreground">Aucun rendez-vous prévu pour cette date</p>
              </CardContent>
            </Card>
          ) : (
            appointments.map((appointment) => {
              const statutInfo = STATUT_LABELS[appointment.statut] || { label: appointment.statut, color: 'bg-gray-100 text-gray-800' };
              return (
                <Card key={appointment.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="font-semibold">
                            {new Date(appointment.date_heure_debut).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                          </span>
                          <span className={`inline-block px-2 py-1 rounded text-xs font-medium ${statutInfo.color}`}>
                            {statutInfo.label}
                          </span>
                          {appointment.consentement_manquant && (
                            <span className="inline-block px-2 py-1 rounded text-xs font-medium bg-red-100 text-red-800">
                              Consentement manquant
                            </span>
                          )}
                        </div>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-muted-foreground" />
                            <span className="text-sm">{appointment.patient_nom}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">{appointment.acte_nom || 'Acte non spécifié'}</p>
                          <p className="text-xs text-muted-foreground">Praticien: {appointment.praticien_nom}</p>
                          {(appointment.salle_id || appointment.fauteuil_numero) && (
                            <p className="text-xs font-medium text-blue-600">
                              {appointment.salle_id ? `Salle: ${salles.find(s => s.id === appointment.salle_id)?.nom || appointment.salle_id}` : ''}
                              {appointment.fauteuil_numero ? ` — Fauteuil: ${appointment.fauteuil_numero}` : ''}
                            </p>
                          )}
                          {appointment.statut !== 'annule' && appointment.statut !== 'termine' && (
                            <div className="pt-2">
                              <Link href={`/teleconsultation/${appointment.id}`}>
                                <Button size="sm" variant="outline" className="h-8 text-xs gap-2">
                                  <Video className="w-3.5 h-3.5" />
                                  Démarrer Visio
                                </Button>
                              </Link>
                            </div>
                          )}
                        </div>
                      </div>
                      {canManage && appointment.statut !== 'annule' && (
                        <div className="flex gap-2">
                          <select
                            value={appointment.statut}
                            onChange={(e) => handleStatusChange(appointment, e.target.value)}
                            className="text-sm border rounded-md px-2 py-1"
                          >
                            {Object.entries(STATUT_LABELS).filter(([k]) => k !== 'annule').map(([k, v]) => (
                              <option key={k} value={k}>{v.label}</option>
                            ))}
                          </select>
                          {canCancel && (
                            <Button variant="ghost" size="sm" onClick={() => setCancelTarget(appointment)}>
                              Annuler
                            </Button>
                          )}
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>

      <NewRdvDialog open={createOpen} onOpenChange={setCreateOpen} defaultDate={dateStr} onCreated={loadAppointments} />
      <CancelRdvDialog appointment={cancelTarget} onOpenChange={() => setCancelTarget(null)} onCancelled={loadAppointments} />
    </DashboardLayout>
  );
}

// ─────────────────────────────────────────────────────────

interface Praticien { id: number; nom: string; prenom: string; specialite?: string | null }
interface Acte { id: number; nom: string; duree_minutes: number }

function NewRdvDialog({ open, onOpenChange, defaultDate, onCreated }: {
  open: boolean; onOpenChange: (v: boolean) => void; defaultDate: string; onCreated: () => void;
}) {
  const [patientAutocompleteKey, setPatientAutocompleteKey] = useState(0);
  const [selectedPatient, setSelectedPatient] = useState<PatientOption | null>(null);
  const [patientId, setPatientId] = useState('');
  const [praticiens, setPraticiens] = useState<Praticien[]>([]);
  const [praticienId, setPraticienId] = useState('');
  const [actes, setActes] = useState<Acte[]>([]);
  const [acteId, setActeId] = useState('');
  const [date, setDate] = useState(defaultDate);
  const [creneaux, setCreneaux] = useState<string[]>([]);
  const [creneau, setCreneau] = useState('');
  const [salle, setSalle] = useState('');
  const [salles, setSalles] = useState<Salle[]>([]);
  const [salleId, setSalleId] = useState('');
  const [fauteuilNumero, setFauteuilNumero] = useState('');
  const [isLoadingCreneaux, setIsLoadingCreneaux] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handlePatientSelect = (patient: PatientOption | null) => {
    setSelectedPatient(patient);
    setPatientId(patient ? String(patient.id) : '');
  };

  useEffect(() => {
    if (open) {
      setSelectedPatient(null); setPatientId('');
      setPatientAutocompleteKey((prev) => prev + 1);
      setPraticienId(''); setActeId(''); setDate(defaultDate);
      setCreneaux([]); setCreneau(''); setSalle('');
      setSalleId(''); setFauteuilNumero('');
      publicApi.getPraticiens().then((r) => setPraticiens(r.data)).catch(() => {});
      publicApi.getActes().then((r) => setActes(r.data)).catch(() => {});
      api.get('/agenda/salles').then((r) => setSalles(r.data)).catch(() => {});
    }
  }, [open, defaultDate]);

  useEffect(() => {
    if (!praticienId || !date) { setCreneaux([]); return; }
    setIsLoadingCreneaux(true);
    setCreneau('');
    api.get(`/agenda/disponibilites/${praticienId}`, { 
      params: { 
                date,
        acte_id: acteId ? Number(acteId) : undefined,
        salle_id: salleId || undefined,
        fauteuil_numero: fauteuilNumero || undefined

      } 
    })
      .then((r) => setCreneaux(r.data.creneaux || []))
      .catch(() => setCreneaux([]))
      .finally(() => setIsLoadingCreneaux(false));
  }, [praticienId, acteId, date, salleId, fauteuilNumero]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientId || !praticienId || !acteId || !date || !creneau) {
      toast.error('Merci de compléter tous les champs requis');
      return;
    }
    if (fauteuilNumero && !salleId) {
      toast.error('Sélectionnez une salle avant de choisir un fauteuil');
      return;
    }
    setIsSaving(true);
    try {
      await api.post('/agenda/rdv', {
        patient_id: Number(patientId),
        praticien_id: Number(praticienId),
        acte_id: Number(acteId),
        date_heure: creneau,
        salle: salle || undefined,
        salle_id: salleId ? Number(salleId) : undefined,
        fauteuil_numero: fauteuilNumero ? Number(fauteuilNumero) : undefined,
      });
      toast.success('Rendez-vous créé');
      onOpenChange(false);
      onCreated();
    } catch (err: any) {
      toast.error(err.response?.data?.detail || 'Erreur lors de la création du RDV');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Nouveau rendez-vous</DialogTitle>
          <DialogDescription>Recherchez le patient puis choisissez un créneau libre.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <PatientAutocomplete
            key={patientAutocompleteKey}
            selectedPatient={selectedPatient}
            onSelect={handlePatientSelect}
          />

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="praticien">Praticien *</Label>
              <select id="praticien" value={praticienId} onChange={(e) => setPraticienId(e.target.value)} className="w-full h-9 px-3 border rounded-md text-sm">
                <option value="">Sélectionner</option>
                {praticiens.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.prenom} {p.nom}{p.specialite ? ` — ${p.specialite}` : ''}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label htmlFor="acte">Acte *</Label>
              <select id="acte" value={acteId} onChange={(e) => setActeId(e.target.value)} className="w-full h-9 px-3 border rounded-md text-sm">
                <option value="">Sélectionner</option>
                {actes.map((a) => (
                  <option key={a.id} value={a.id}>{a.nom} — {a.duree_minutes} min</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="rdv-date">Date *</Label>
              <Input id="rdv-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="creneau">Créneau *</Label>
              {isLoadingCreneaux ? (
                <div className="flex items-center gap-2 text-sm text-muted-foreground py-2"><Spinner className="h-4 w-4" /> Recherche...</div>
              ) : (
                <select id="creneau" value={creneau} onChange={(e) => setCreneau(e.target.value)} className="w-full h-9 px-3 border rounded-md text-sm" disabled={creneaux.length === 0}>
                  <option value="">{creneaux.length === 0 ? 'Aucun créneau' : 'Sélectionner'}</option>
                  {creneaux.map((c) => (
                    <option key={c} value={c}>{new Date(c).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</option>
                  ))}
                </select>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="salle-select">Salle</Label>
              <select id="salle-select" value={salleId} onChange={(e) => setSalleId(e.target.value)} className="w-full h-9 px-3 border rounded-md text-sm">
                <option value="">Sélectionner</option>
                {salles.map((s) => <option key={s.id} value={s.id}>{s.nom}</option>)}
              </select>
            </div>
            <div>
              <Label htmlFor="fauteuil">Fauteuil n°</Label>
              <Input id="fauteuil" type="number" value={fauteuilNumero} onChange={(e) => setFauteuilNumero(e.target.value)} placeholder="Ex: 1" />
            </div>
          </div>

          <div>
            <Label htmlFor="salle">Notes salle (ancien)</Label>
            <Input id="salle" value={salle} onChange={(e) => setSalle(e.target.value)} placeholder="Optionnel" />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Annuler</Button>
            <Button type="submit" disabled={isSaving}>{isSaving ? <Spinner className="h-4 w-4" /> : 'Créer le RDV'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function CancelRdvDialog({ appointment, onOpenChange, onCancelled }: {
  appointment: Appointment | null; onOpenChange: () => void; onCancelled: () => void;
}) {
  const [raison, setRaison] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => { setRaison(''); }, [appointment]);

  const handleConfirm = async () => {
    if (!appointment) return;
    if (raison.trim().length < 3) {
      toast.error('Merci de préciser un motif (3 caractères minimum)');
      return;
    }
    setIsSaving(true);
    try {
      await api.delete(`/agenda/rdv/${appointment.id}`, { params: { raison: raison.trim() } });
      toast.success('Rendez-vous annulé');
      onOpenChange();
      onCancelled();
    } catch (err: any) {
      toast.error(err.response?.data?.detail || "Erreur lors de l'annulation");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Dialog open={!!appointment} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Annuler le rendez-vous</DialogTitle>
          <DialogDescription>
            {appointment && `${appointment.patient_nom} — ${new Date(appointment.date_heure_debut).toLocaleString('fr-FR')}`}
          </DialogDescription>
        </DialogHeader>
        <div>
          <Label htmlFor="raison">Motif de l'annulation *</Label>
          <Textarea id="raison" value={raison} onChange={(e) => setRaison(e.target.value)} rows={3} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onOpenChange}>Retour</Button>
          <Button variant="destructive" onClick={handleConfirm} disabled={isSaving}>
            {isSaving ? <Spinner className="h-4 w-4" /> : "Confirmer l'annulation"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
