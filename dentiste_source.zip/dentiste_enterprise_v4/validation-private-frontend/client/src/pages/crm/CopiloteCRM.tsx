import { useState, useEffect } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { api } from '@/lib/api';
import { Spinner } from '@/components/ui/spinner';
import { PatientAutocomplete, type PatientOption } from '@/components/patients/PatientAutocomplete';
import {
  Search,
  FileText,
  AlertCircle,
  MessageSquare,
  Mail,
  TrendingDown,
  CheckCircle,
  Clock,
  Zap,
} from 'lucide-react';

interface ActeSummary {
  count: number;
  last_date: string | null;
  avg_satisfaction: number | null;
}

interface PatientSummary {
  patient_id: number;
  data: {
    patient: { reference: string; age: number | null; niveau_fidelite: string | null };
    actes_summary: Record<string, ActeSummary>;
    rdvs: { total: number; completed: number; cancelled: number; no_show: number; next: any };
    factures: { count: number };
    photos: { series_count: number };
  };
  llm_summary: string | null;
  llm_status: string;
}

interface AtRiskPatient {
  id: number;
  name: string;
  last_visit: string | null;
  phone: string | null;
}

export default function CopiloteCRM() {
  const [selectedPatient, setSelectedPatient] = useState<PatientOption | null>(null);
  const [patientSummary, setPatientSummary] = useState<PatientSummary | null>(null);
  const [atRiskPatients, setAtRiskPatients] = useState<AtRiskPatient[]>([]);
  const [atRiskCommentary, setAtRiskCommentary] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'summary' | 'at-risk' | 'draft'>('summary');

  const loadPatientSummary = async (patientId: number) => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await api.get(`/copilote-crm/patient/${patientId}/summary`);
      if (response.data?.data) {
        setPatientSummary(response.data.data);
      }
    } catch {
      setError('Le résumé du patient est temporairement indisponible.');
    } finally {
      setIsLoading(false);
    }
  };

  const loadAtRiskPatients = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await api.get('/copilote-crm/at-risk-patients');
      if (response.data?.data) {
        setAtRiskPatients(response.data.data.items || []);
        setAtRiskCommentary(response.data.data.llm_commentary || null);
      }
    } catch {
      setError('La détection des patients à risque est temporairement indisponible.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAtRiskPatients();
  }, []);

  if (isLoading && !patientSummary) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center h-screen">
          <Spinner />
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Titre */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Copilote CRM</h1>
          <p className="text-gray-600 mt-2">Assistant intelligent pour la gestion des patients</p>
        </div>

        {/* Erreur */}
        {error && (
          <Card className="border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex items-center gap-2 text-red-700">
                <AlertCircle className="w-5 h-5" />
                <span>{error}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Onglets */}
        <div className="flex gap-2 border-b">
          <button
            onClick={() => setActiveTab('summary')}
            className={`px-4 py-2 font-medium border-b-2 transition ${
              activeTab === 'summary'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <FileText className="w-4 h-4 inline mr-2" />
            Résumé Patient
          </button>
          <button
            onClick={() => setActiveTab('at-risk')}
            className={`px-4 py-2 font-medium border-b-2 transition ${
              activeTab === 'at-risk'
                ? 'border-red-600 text-red-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <AlertCircle className="w-4 h-4 inline mr-2" />
            Patients à Risque ({atRiskPatients.length})
          </button>
          <button
            onClick={() => setActiveTab('draft')}
            className={`px-4 py-2 font-medium border-b-2 transition ${
              activeTab === 'draft'
                ? 'border-green-600 text-green-600'
                : 'border-transparent text-gray-600 hover:text-gray-900'
            }`}
          >
            <MessageSquare className="w-4 h-4 inline mr-2" />
            Brouillons
          </button>
        </div>

        {/* Onglet Résumé Patient */}
        {activeTab === 'summary' && (
          <div className="space-y-6">
            {/* Recherche patient */}
            <Card>
              <CardHeader>
                <CardTitle>Rechercher un patient</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-2 items-end">
                  <div className="flex-1">
                    <PatientAutocomplete
                      selectedPatient={selectedPatient}
                      onSelect={setSelectedPatient}
                      label="Patient"
                      placeholder="Rechercher par nom, prénom ou téléphone..."
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => selectedPatient && loadPatientSummary(selectedPatient.id)}
                    disabled={!selectedPatient || isLoading}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-60"
                    aria-label="Afficher le résumé du patient sélectionné"
                  >
                    <Search className="w-4 h-4" />
                  </button>
                </div>
              </CardContent>
            </Card>

            {/* Résumé du patient */}
            {patientSummary && (
              <div className="space-y-4">
                {/* Infos patient — pseudonymisées côté backend (pas de nom/téléphone) */}
                <Card>
                  <CardHeader>
                    <CardTitle>{patientSummary.data.patient.reference}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Âge</p>
                        <p className="font-medium">{patientSummary.data.patient.age ?? '—'}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Niveau de fidélité</p>
                        <p className="font-medium">{patientSummary.data.patient.niveau_fidelite ?? '—'}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Résumé IA (si disponible) */}
                {patientSummary.llm_summary && (
                  <Card>
                    <CardContent className="pt-6">
                      <p className="text-sm text-gray-700">{patientSummary.llm_summary}</p>
                    </CardContent>
                  </Card>
                )}

                {/* Historique médical */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <FileText className="w-5 h-5" />
                      Historique Médical
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-1">
                      {Object.entries(patientSummary.data.actes_summary ?? {}).map(([acte, data]) => (
                        <div key={acte} className="text-sm">
                          <span className="font-medium">{acte}</span>
                          <span className="text-gray-600"> - {data.count} fois</span>
                          {data.avg_satisfaction != null && (
                            <span className="text-yellow-600"> - ⭐ {data.avg_satisfaction.toFixed(1)}</span>
                          )}
                        </div>
                      ))}
                      {Object.keys(patientSummary.data.actes_summary ?? {}).length === 0 && (
                        <p className="text-sm text-gray-500">Aucun acte enregistré</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Rendez-vous */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-5 h-5" />
                      Rendez-vous
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Total</p>
                        <p className="text-2xl font-bold">{patientSummary.data.rdvs.total ?? 0}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Complétés</p>
                        <p className="text-2xl font-bold text-green-600">{patientSummary.data.rdvs.completed ?? 0}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Annulés</p>
                        <p className="text-2xl font-bold text-orange-600">{patientSummary.data.rdvs.cancelled ?? 0}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">No-show</p>
                        <p className="text-2xl font-bold text-red-600">{patientSummary.data.rdvs.no_show ?? 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Factures */}
                <Card>
                  <CardHeader>
                    <CardTitle>Factures</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-2xl font-bold">{patientSummary.data.factures.count ?? 0}</p>
                    <p className="text-sm text-gray-600">facture(s) au total</p>
                  </CardContent>
                </Card>
              </div>
            )}
          </div>
        )}

        {/* Onglet Patients à Risque */}
        {activeTab === 'at-risk' && (
          <div className="space-y-4">
            {atRiskCommentary && (
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-900">{atRiskCommentary}</p>
                </CardContent>
              </Card>
            )}
            {atRiskPatients.length === 0 ? (
              <Card>
                <CardContent className="pt-12 pb-12 text-center">
                  <p className="text-gray-500">Aucun patient à risque détecté</p>
                </CardContent>
              </Card>
            ) : (
              atRiskPatients.map((patient) => (
                <Card key={patient.id} className="border-orange-200 bg-orange-50">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-bold text-lg">{patient.name}</p>
                        {patient.last_visit && (
                          <p className="text-sm text-gray-600 mt-1">Dernière visite : {patient.last_visit}</p>
                        )}
                        {patient.phone && (
                          <p className="text-sm text-gray-600">{patient.phone}</p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        loadPatientSummary(patient.id);
                        setActiveTab('summary');
                      }}
                      className="mt-4 px-3 py-2 bg-blue-600 text-white text-sm rounded hover:bg-blue-700"
                    >
                      Voir le dossier
                    </button>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}

        {/* Onglet Brouillons */}
        {activeTab === 'draft' && (
          <Card>
            <CardHeader>
              <CardTitle>Brouillons de messages</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Les brouillons de communication externe sont désactivés dans cet environnement de recette.
              </p>
              <p className="mt-2 text-sm text-muted-foreground">
                Aucun message WhatsApp, e-mail ou appel à un service d’IA n’est généré ni transmis depuis cette interface.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
}
