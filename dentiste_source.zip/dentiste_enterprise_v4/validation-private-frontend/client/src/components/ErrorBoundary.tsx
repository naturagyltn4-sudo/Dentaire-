import { cn } from "@/lib/utils";
import { AlertTriangle, RotateCcw } from "lucide-react";
import { Component, ReactNode } from "react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorType: string | null;
}

class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, errorType: null };
  }

  static getDerivedStateFromError(): State {
    return { hasError: true, errorType: null };
  }

  componentDidCatch(error: Error) {
    // Un identifiant de type suffit au diagnostic sans afficher de détail
    // technique, de session ou de donnée utilisateur dans l’interface.
    this.setState({ errorType: error.name || 'ErreurRendu' });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-background p-8">
          <div className="flex w-full max-w-xl flex-col items-center rounded-xl border bg-card p-8 text-center shadow-sm">
            <AlertTriangle
              size={48}
              className="text-destructive mb-6 flex-shrink-0"
            />

            <h2 className="mb-3 text-xl font-semibold">Une erreur est survenue</h2>
            <p className="mb-2 text-sm text-muted-foreground">
              L’écran n’a pas pu être chargé. Réessayez ou contactez l’administrateur de la clinique si le problème persiste.
            </p>
            {this.state.errorType && (
              <p className="mb-4 text-xs text-muted-foreground">
                Référence de diagnostic : {this.state.errorType}
              </p>
            )}

            <button
              onClick={() => window.location.reload()}
              className={cn(
                "flex items-center gap-2 rounded-lg px-4 py-2",
                "bg-primary text-primary-foreground",
                "hover:opacity-90 cursor-pointer"
              )}
            >
              <RotateCcw size={16} />
              Recharger la page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
