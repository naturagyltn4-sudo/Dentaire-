import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { History, Activity, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

interface EtatDentaire {
  id: number;
  patient_id: number;
  numero_dent: string;
  statut: string;
  face?: string;
  praticien_id: number;
  notes?: string;
  date_modification: string;
  created_at: string;
  updated_at: string;
}

interface HistoriqueDentaire {
  id: number;
  patient_id: number;
  numero_dent: string;
  statut_ancien?: string;
  statut_nouveau: string;
  face_ancien?: string;
  face_nouveau?: string;
  praticien_id: number;
  notes?: string;
  created_at: string;
}

interface OdontogrammeViewProps {
  patientId: number;
}

// Couleurs pour les statuts
const STATUT_COLORS: Record<string, { bg: string; text: string; label: string }> = {
  sain: { bg: 'bg-green-100', text: 'text-green-800', label: 'Sain' },
  carie: { bg: 'bg-red-100', text: 'text-red-800', label: 'Carie' },
  obture: { bg: 'bg-blue-100', text: 'text-blue-800', label: 'Obturé' },
  couronne: { bg: 'bg-purple-100', text: 'text-purple-800', label: 'Couronne' },
  bridge: { bg: 'bg-indigo-100', text: 'text-indigo-800', label: 'Bridge' },
  implant: { bg: 'bg-cyan-100', text: 'text-cyan-800', label: 'Implant' },
  absente: { bg: 'bg-gray-100', text: 'text-gray-800', label: 'Absente' },
  devitalisee: { bg: 'bg-yellow-100', text: 'text-yellow-800', label: 'Dévitalisée' },
  a_extraire: { bg: 'bg-orange-100', text: 'text-orange-800', label: 'À extraire' },
  en_traitement: { bg: 'bg-pink-100', text: 'text-pink-800', label: 'En traitement' },
};

// Quadrants dentaires
const QUADRANTS = [
  { id: 1, label: 'Maxillaire droit', dents: ['18', '17', '16', '15', '14', '13', '12', '11'] },
  { id: 2, label: 'Maxillaire gauche', dents: ['21', '22', '23', '24', '25', '26', '27', '28'] },
  { id: 3, label: 'Mandibulaire gauche', dents: ['31', '32', '33', '34', '35', '36', '37', '38'] },
  { id: 4, label: 'Mandibulaire droit', dents: ['48', '47', '46', '45', '44', '43', '42', '41'] },
];

export function OdontogrammeView({ patientId }: OdontogrammeViewProps) {
  const [etats, setEtats] = useState<EtatDentaire[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDent, setSelectedDent] = useState<EtatDentaire | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showHistoriqueDialog, setShowHistoriqueDialog] = useState(false);
  const [historique, setHistorique] = useState<HistoriqueDentaire[]>([]);
  const [editFormData, setEditFormData] = useState({
    statut: '',
    notes: '',
  });

  // Charger l'odontogramme
  useEffect(() => {
    const loadOdontogramme = async () => {
      try {
        setLoading(true);
        const response = await api.get(`/patients/${patientId}/odontogramme`);
        setEtats(response.data.dents || []);
      } catch (error) {
        console.error('Erreur lors du chargement de l\'odontogramme:', error);
        toast.error('Impossible de charger l\'odontogramme');
      } finally {
        setLoading(false);
      }
    };

    loadOdontogramme();
  }, [patientId]);

  // Récupérer l'état d'une dent
  const getEtatDent = (numeroDent: string): EtatDentaire | undefined => {
    return etats.find(e => e.numero_dent === numeroDent);
  };

  // Ouvrir le dialogue d'édition
  const handleEditDent = (etat: EtatDentaire) => {
    setSelectedDent(etat);
    setEditFormData({
      statut: etat.statut,
      notes: etat.notes || '',
    });
    setShowEditDialog(true);
  };

  // Ouvrir le dialogue d'historique
  const handleShowHistorique = async (etat: EtatDentaire) => {
    try {
      setSelectedDent(etat);
      const response = await api.get(
        `/patients/${patientId}/odontogramme/${etat.numero_dent}/historique`,
      );
      setHistorique(response.data || []);
      setShowHistoriqueDialog(true);
    } catch (error) {
      console.error('Erreur lors du chargement de l\'historique:', error);
      toast.error('Impossible de charger l\'historique');
    }
  };

  // Sauvegarder la modification
  const handleSaveDent = async () => {
    if (!selectedDent) return;

    try {
      const response = await api.patch(
        `/patients/${patientId}/odontogramme/${selectedDent.numero_dent}`,
        {
          statut: editFormData.statut,
          notes: editFormData.notes,
        },
      );

      // Mettre à jour la liste locale
      setEtats(etats.map(e => (e.numero_dent === selectedDent.numero_dent ? response.data : e)));
      setShowEditDialog(false);
      toast.success('Dent mise à jour avec succès');
    } catch (error) {
      console.error('Erreur lors de la mise à jour:', error);
      toast.error('Impossible de mettre à jour la dent');
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Spinner />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Odontogramme
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Légende des statuts */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
              {Object.entries(STATUT_COLORS).map(([statut, colors]) => (
                <div key={statut} className="flex items-center gap-2">
                  <div className={`w-4 h-4 rounded ${colors.bg}`} />
                  <span className="text-xs">{colors.label}</span>
                </div>
              ))}
            </div>

            {/* Quadrants */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {QUADRANTS.map(quadrant => (
                <div key={quadrant.id} className="border rounded-lg p-4">
                  <h3 className="font-semibold mb-3 text-sm">{quadrant.label}</h3>
                  <div className="grid grid-cols-8 gap-2">
                    {quadrant.dents.map(numeroDent => {
                      const etat = getEtatDent(numeroDent);
                      const colors = etat ? STATUT_COLORS[etat.statut] : STATUT_COLORS.sain;

                      return (
                        <Tooltip key={numeroDent}>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className={`w-full h-12 p-0 flex flex-col items-center justify-center text-xs font-semibold ${colors.bg} ${colors.text} hover:opacity-80`}
                              onClick={() => {
                                if (etat) {
                                  handleEditDent(etat);
                                } else {
                                  // Créer une dent par défaut
                                  handleEditDent({
                                    id: 0,
                                    patient_id: patientId,
                                    numero_dent: numeroDent,
                                    statut: 'sain',
                                    praticien_id: 0,
                                    date_modification: new Date().toISOString(),
                                    created_at: new Date().toISOString(),
                                    updated_at: new Date().toISOString(),
                                  });
                                }
                              }}
                            >
                              <span>{numeroDent}</span>
                              {etat && <span className="text-xs">{STATUT_COLORS[etat.statut].label}</span>}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <div className="text-xs">
                              <p>
                                <strong>Dent :</strong>
                                {' '}
                                {numeroDent}
                              </p>
                              {etat && (
                                <>
                                  <p>
                                    <strong>Statut :</strong>
                                    {' '}
                                    {STATUT_COLORS[etat.statut].label}
                                  </p>
                                  {etat.notes && (
                                    <p>
                                      <strong>Notes :</strong>
                                      {' '}
                                      {etat.notes}
                                    </p>
                                  )}
                                </>
                              )}
                            </div>
                          </TooltipContent>
                        </Tooltip>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Dialogue d'édition */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Modifier dent
              {' '}
              {selectedDent?.numero_dent}
            </DialogTitle>
            <DialogDescription>
              Mettez à jour l'état de la dent
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="statut">Statut</Label>
              <Select
                value={editFormData.statut}
                onValueChange={(value) => setEditFormData({ ...editFormData, statut: value })}
              >
                <SelectTrigger id="statut">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(STATUT_COLORS).map(([statut, colors]) => (
                    <SelectItem key={statut} value={statut}>
                      {colors.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Ajouter des notes..."
                value={editFormData.notes}
                onChange={(e) => setEditFormData({ ...editFormData, notes: e.target.value })}
                rows={3}
              />
            </div>

            {selectedDent && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleShowHistorique(selectedDent)}
                className="w-full"
              >
                <History className="w-4 h-4 mr-2" />
                Voir l'historique
              </Button>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>
              Annuler
            </Button>
            <Button onClick={handleSaveDent}>
              Sauvegarder
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialogue d'historique */}
      <Dialog open={showHistoriqueDialog} onOpenChange={setShowHistoriqueDialog}>
        <DialogContent className="max-h-96 overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Historique dent
              {' '}
              {selectedDent?.numero_dent}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-2">
            {historique.length === 0 ? (
              <p className="text-sm text-gray-500">Aucun historique disponible</p>
            ) : (
              historique.map((h) => (
                <div key={h.id} className="border rounded p-2 text-xs">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-semibold">
                      {new Date(h.created_at).toLocaleDateString()}
                    </span>
                    <Badge variant="outline">
                      {h.statut_ancien && `${STATUT_COLORS[h.statut_ancien]?.label} → `}
                      {STATUT_COLORS[h.statut_nouveau]?.label}
                    </Badge>
                  </div>
                  {h.notes && <p className="text-gray-600">{h.notes}</p>}
                </div>
              ))
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowHistoriqueDialog(false)}>
              Fermer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
