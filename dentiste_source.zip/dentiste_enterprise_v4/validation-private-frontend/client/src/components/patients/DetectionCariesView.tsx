import { useState } from 'react';
import { AlertTriangle, Brain, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { iaDentaireApi } from '@/lib/api';
import { toast } from 'sonner';

interface DetectionCariesViewProps {
  radioId: number;
  userRole?: string;
  practitionerId?: number;
}

interface DetectionResult {
  id: number;
  resultat?: {
    zones_suspectes?: Array<{ dent_fdi?: string | null; confiance?: number; description?: string }>;
    limites?: string;
  };
  aide_uniquement?: boolean;
  valide_par_praticien_id?: number | null;
  valide_at?: string | null;
}

const practitionerRoles = new Set(['medecin', 'directrice', 'admin']);

export function DetectionCariesView({ radioId, userRole, practitionerId }: DetectionCariesViewProps) {
  const [detection, setDetection] = useState<DetectionResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [validating, setValidating] = useState(false);

  const detect = async () => {
    try {
      setLoading(true);
      const response = await iaDentaireApi.detecter(radioId);
      setDetection(response.data);
      toast.success('Proposition IA générée. Elle doit être revue par un praticien.');
    } catch {
      toast.error("La détection des caries n'a pas pu être effectuée.");
    } finally {
      setLoading(false);
    }
  };

  const validate = async () => {
    if (!detection || !practitionerId) return;
    try {
      setValidating(true);
      const response = await iaDentaireApi.valider(detection.id, practitionerId);
      setDetection((current) => current ? { ...current, ...response.data } : current);
      toast.success('Revue praticien enregistrée.');
    } catch (error: any) {
      toast.error(error?.response?.data?.detail || "La validation de l'analyse a échoué.");
    } finally {
      setValidating(false);
    }
  };

  const isPractitioner = practitionerRoles.has(userRole || '');
  const isValidated = detection?.valide_par_praticien_id != null;

  return (
    <Card className="mt-4 border-amber-300 bg-amber-50/50">
      <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2 text-base"><Brain className="h-4 w-4" />Aide IA — caries</CardTitle></CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-start gap-2 text-sm text-amber-900"><AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /><span>Cette analyse est une aide à la lecture et ne constitue jamais un diagnostic confirmé.</span></div>
        {!detection ? <Button size="sm" variant="outline" onClick={() => void detect()} disabled={loading}>{loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Analyser cette radio</Button> : <div className="space-y-2 text-sm"><div className="flex flex-wrap items-center gap-2">{isValidated ? <Badge variant="outline" className="border-green-600 text-green-700">Revue effectuée par le praticien{detection.valide_at ? ` le ${new Date(detection.valide_at).toLocaleDateString('fr-FR')}` : ''}</Badge> : <><Badge variant="outline" className="border-amber-500 text-amber-800">Proposition IA — à valider</Badge>{isPractitioner && practitionerId && <Button size="sm" onClick={() => void validate()} disabled={validating}>{validating && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Valider cette analyse</Button>}</>}</div><p>{detection.resultat?.zones_suspectes?.length ?? 0} zone(s) suspecte(s) détectée(s).</p><ul className="list-disc pl-5">{detection.resultat?.zones_suspectes?.map((zone, index) => <li key={`${zone.dent_fdi ?? 'zone'}-${index}`}>{zone.dent_fdi ? `Dent ${zone.dent_fdi} : ` : ''}{zone.description || 'zone à examiner'}{typeof zone.confiance === 'number' ? ` (${Math.round(zone.confiance * 100)} %)` : ''}</li>)}</ul><p className="text-xs text-muted-foreground">Limites : {detection.resultat?.limites || 'à préciser par le praticien.'}</p></div>}
      </CardContent>
    </Card>
  );
}
