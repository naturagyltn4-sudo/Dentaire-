import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useBranding } from '@/contexts/BrandingContext';
import { useLocation } from 'wouter';
import { useTranslation } from 'react-i18next';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarTrigger,
  SidebarProvider,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Calendar,
  Users,
  FileText,
  Pill,
  DollarSign,
  Heart,
  Briefcase,
  MessageSquare,
  Settings,
  LogOut,
  ChevronDown,
  Menu,
  Zap,
  Activity,
  Camera,
  Headphones,
  BarChart,
  Mail,
  Building2,
  ScanLine,
  Clock3,
  Sparkles,
  Search,
  Bell,
  ShieldCheck,
} from 'lucide-react';

interface NavItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  roles?: string[];
  children?: NavItem[];
}

const NAV_ITEMS: NavItem[] = [
  {
    label: 'Tableau de bord',
    href: '/dashboard',
    icon: <Menu className="w-4 h-4" />,
  },
  {
    label: 'Odontogramme',
    href: '/patients',
    icon: <Activity className="w-4 h-4" />,
    roles: ['directrice', 'medecin', 'admin'],
  },
  {
    label: 'Radiologie',
    href: '/patients',
    icon: <Camera className="w-4 h-4" />,
    roles: ['directrice', 'medecin', 'admin'],
  },
  {
    label: 'Prothèses & Labo',
    href: '/protheses',
    icon: <Zap className="w-4 h-4" />,
    roles: ['directrice', 'medecin', 'admin', 'assistante'],
  },
  {
    label: 'Devis Dentaires',
    href: '/devis-dentaires',
    icon: <FileText className="w-4 h-4" />,
    roles: ['directrice', 'medecin', 'admin', 'assistante'],
  },
  {
    label: 'Dashboard IA',
    href: '/dashboard-ia',
    icon: <Zap className="w-4 h-4" />,
  },
  {
    label: 'Automatisations IA',
    href: '/workflows',
    icon: <Activity className="w-4 h-4" />,
    roles: ['directrice', 'admin'],
  },
  {
    label: 'Copilote CRM',
    href: '/copilote-crm',
    icon: <Headphones className="w-4 h-4" />,
    roles: ['directrice', 'medecin', 'estheticienne', 'admin'],
  },
  {
    label: 'Business Intelligence',
    href: '/analytics',
    icon: <BarChart className="w-4 h-4" />,
    roles: ['directrice', 'admin'],
  },
  {
    label: 'Agenda',
    href: '/agenda',
    icon: <Calendar className="w-4 h-4" />,
  },
  {
    label: 'Patients',
    href: '/patients',
    icon: <Users className="w-4 h-4" />,
  },
  {
    label: 'Dossier médical',
    href: '/patients',
    icon: <FileText className="w-4 h-4" />,
    roles: ['directrice', 'medecin', 'estheticienne', 'admin'],
  },
  {
    label: 'Gestion Stocks',
    href: '/stock',
    icon: <Pill className="w-4 h-4" />,
  },
  {
    label: 'Factures & Dépenses',
    href: '/invoices',
    icon: <DollarSign className="w-4 h-4" />,
  },
  {
    label: 'Commissions',
    href: '/commissions',
    icon: <DollarSign className="w-4 h-4" />,
    roles: ['directrice', 'admin', 'commercial'],
  },
  {
    label: 'Fidélité & Parrainage',
    href: '/loyalty',
    icon: <Heart className="w-4 h-4" />,
  },
  {
    label: 'Recrutement',
    href: '/recruitment',
    icon: <Briefcase className="w-4 h-4" />,
    roles: ['directrice', 'assistante', 'admin'],
  },
  {
    label: 'Social CRM',
    href: '/social',
    icon: <MessageSquare className="w-4 h-4" />,
  },
  {
    label: 'Messagerie Équipe',
    href: '/equipe',
    icon: <Mail className="w-4 h-4" />,
  },
  {
    label: 'Paramètres',
    href: '/settings',
    icon: <Settings className="w-4 h-4" />,
    roles: ['directrice', 'admin'],
  },
];

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { user, logout } = useAuth();
  const { branding } = useBranding();
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  const [open, setOpen] = useState(false);

  const translatedNavItems = [
    { label: t('nav.dashboard'), href: '/dashboard', icon: <Menu className="w-4 h-4" /> },
    { label: t('nav.odontogramme', 'Odontogramme'), href: '/patients', icon: <Activity className="w-4 h-4" />, roles: ['directrice', 'medecin', 'admin'] },
    { label: t('nav.radiologie', 'Radiologie'), href: '/patients', icon: <Camera className="w-4 h-4" />, roles: ['directrice', 'medecin', 'admin'] },
    { label: t('nav.protheses', 'Prothèses & Labo'), href: '/protheses', icon: <Zap className="w-4 h-4" />, roles: ['directrice', 'medecin', 'admin', 'assistante'] },
    { label: t('nav.devis', 'Devis Dentaires'), href: '/devis-dentaires', icon: <FileText className="w-4 h-4" />, roles: ['directrice', 'medecin', 'admin', 'assistante'] },
    { label: t('nav.delegues', 'Délégués médicaux'), href: '/delegues', icon: <Building2 className="w-4 h-4" />, roles: ['directrice', 'medecin', 'assistante', 'admin'] },
    { label: t('nav.cephalometrie', 'Céphalométrie'), href: '/cephalometries', icon: <ScanLine className="w-4 h-4" />, roles: ['orthodontiste', 'directrice', 'admin'] },
    { label: t('nav.dashboard_ia', 'Dashboard IA'), href: '/dashboard-ia', icon: <Zap className="w-4 h-4" /> },
    { label: t('nav.workflows', 'Automatisations IA'), href: '/workflows', icon: <Activity className="w-4 h-4" />, roles: ['directrice', 'admin'] },
    { label: t('nav.crm', 'Copilote CRM'), href: '/copilote-crm', icon: <Headphones className="w-4 h-4" />, roles: ['directrice', 'medecin', 'estheticienne', 'admin'] },
    { label: t('nav.bi', 'Business Intelligence'), href: '/analytics', icon: <BarChart className="w-4 h-4" />, roles: ['directrice', 'admin'] },
    { label: t('nav.agenda'), href: '/agenda', icon: <Calendar className="w-4 h-4" /> },
    { label: t('nav.patients'), href: '/patients', icon: <Users className="w-4 h-4" /> },
    { label: t('nav.stock'), href: '/stock', icon: <Pill className="w-4 h-4" /> },
    { label: t('nav.invoices'), href: '/invoices', icon: <DollarSign className="w-4 h-4" /> },
    { label: t('nav.commissions', 'Commissions'), href: '/commissions', icon: <DollarSign className="w-4 h-4" />, roles: ['directrice', 'admin', 'commercial'] },
    { label: t('nav.loyalty', 'Fidélité'), href: '/loyalty', icon: <Heart className="w-4 h-4" /> },
    { label: t('nav.recruitment', 'Recrutement'), href: '/recruitment', icon: <Briefcase className="w-4 h-4" />, roles: ['directrice', 'assistante', 'admin'] },
    { label: t('nav.social'), href: '/social', icon: <MessageSquare className="w-4 h-4" />, roles: ['directrice', 'assistante', 'commercial', 'admin'] },
    { label: t('nav.equipe', 'Messagerie Équipe'), href: '/equipe', icon: <Mail className="w-4 h-4" /> },
    { label: 'Pointage & RH', href: '/rh/pointage', icon: <Clock3 className="w-4 h-4" />, roles: ['directrice', 'admin'] },
    { label: 'Fiches personnel', href: '/personnel', icon: <Briefcase className="w-4 h-4" />, roles: ['directrice', 'admin'] },
    { label: t('nav.settings'), href: '/settings', icon: <Settings className="w-4 h-4" />, roles: ['directrice', 'admin'] },
    { label: 'Super Admin', href: '/super-admin', icon: <Building2 className="w-4 h-4" />, roles: ['superadmin'] },
  ];

  // Filter nav items based on user role
  const visibleItems = translatedNavItems.filter(
    (item) => !item.roles || (user && item.roles.includes(user.role))
  );

  const isActive = (href: string) => location === href;

  return (
    <SidebarProvider>
    <div className="premium-shell flex h-screen bg-background">
      <Sidebar>
        <SidebarHeader className="border-b border-sidebar-border px-5 py-5">
          <div className="flex items-center gap-3">
            {branding?.logo_url && (
              <img
                src={branding.logo_url}
                alt="Logo"
                className="sidebar-brand-mark h-10 w-10 rounded-2xl object-contain bg-sidebar-primary/15 p-1.5"
              />
            )}
            <div className="flex-1 min-w-0">
              <div className="mb-1 flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-[0.18em] text-sidebar-primary"><Sparkles className="h-3 w-3" /> Care suite</div>
              <h1 className="text-sm font-bold truncate tracking-tight">
                {branding?.nom_clinique || 'Clinique'}
              </h1>
              <p className="text-xs text-muted-foreground truncate">
                {user?.prenom} {user?.nom}
              </p>
            </div>
          </div>
        </SidebarHeader>

        <SidebarContent>
          <SidebarMenu>
            {visibleItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={isActive(item.href)}
                  onClick={() => setLocation(item.href)}
                >
                  <div className="flex items-center gap-2 cursor-pointer">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>

        <SidebarFooter className="border-t p-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="w-full justify-between">
                <span className="text-xs text-muted-foreground truncate">
                  {user?.email}
                </span>
                <ChevronDown className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem onClick={logout}>
                <LogOut className="w-4 h-4 mr-2" />
                {t('nav.logout')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </SidebarFooter>
      </Sidebar>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="flex items-center justify-between border-b border-border/70 bg-card/75 px-5 py-4 backdrop-blur-xl lg:px-8">
          <div className="flex items-center gap-4"><SidebarTrigger /><div className="hidden h-9 w-px bg-border md:block" /><div className="hidden items-center gap-2 rounded-full border border-border/70 bg-background/60 px-3 py-2 text-xs text-muted-foreground md:flex"><Search className="h-3.5 w-3.5" /> Rechercher dans le cabinet <span className="ml-3 rounded-md bg-muted px-1.5 py-0.5 font-mono text-[10px]">⌘ K</span></div></div>
          <div className="flex items-center gap-3"><div className="hidden items-center gap-2 rounded-full bg-emerald-500/10 px-3 py-1.5 text-xs font-semibold text-emerald-700 sm:flex"><span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> Système opérationnel</div><button aria-label="Notifications" className="rounded-full p-2 text-muted-foreground transition hover:bg-muted hover:text-foreground"><Bell className="h-4 w-4" /></button><LanguageSwitcher /><div className="hidden items-center gap-2 border-l border-border pl-3 text-right sm:flex"><div className="text-xs font-semibold text-foreground">{user?.prenom} {user?.nom}</div><div className="flex items-center justify-end gap-1 text-[10px] uppercase tracking-wider text-muted-foreground"><ShieldCheck className="h-3 w-3 text-sidebar-primary" /> {user?.role}</div></div></div>
        </header>

        <main className="flex-1 overflow-auto">
          <div className="p-5 lg:p-8">
            {children}
          </div>
        </main>
      </div>
    </div>
    </SidebarProvider>
  );
};
