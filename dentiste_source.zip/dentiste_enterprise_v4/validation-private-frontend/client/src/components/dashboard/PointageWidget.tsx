import { useCallback, useEffect, useState } from 'react';
import { Clock3, LogIn, LogOut } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Spinner } from '@/components/ui/spinner';

interface Pointage {
  id: number;
  debut: string;
  fin?: string | null;
  duree_minutes?: number | null;
}

interface PointageStatus {
  is_clocked_in: boolean;
  current_pointage?: Pointage | null;
}

function formatElapsed(start?: string | null): string {
  if (!start) return '—';
  const elapsed = Math.max(0, Date.now() - new Date(start).getTime());
  const minutes = Math.floor(elapsed / 60000);
  return `${Math.floor(minutes / 60)} h ${String(minutes % 60).padStart(2, '0')} min`;
}

export function PointageWidget() {
  const [status, setStatus] = useState<PointageStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  const loadStatus = useCallback(async () => {
    try {
      const response = await api.get('/pointage/statut');
      setStatus(response.data);
    } catch {
      setStatus(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStatus();
    const timer = window.setInterval(loadStatus, 60000);
    return () => window.clearInterval(timer);
  }, [loadStatus]);

  const handleClock = async () => {
    setIsSaving(true);
    try {
      await api.post(status?.is_clocked_in ? '/pointage/sortie' : '/pointage/entree');
      toast.success(status?.is_clocked_in ? 'Départ enregistré' : 'Arrivée enregistrée');
      await loadStatus();
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Impossible de mettre à jour le pointage');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">Présence du jour</CardTitle>
        <Clock3 className="h-4 w-4 text-primary" />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center gap-2 text-sm text-muted-foreground"><Spinner className="h-4 w-4" /> Chargement…</div>
        ) : (
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-lg font-semibold">{status?.is_clocked_in ? 'En service' : 'Hors service'}</div>
              <p className="text-xs text-muted-foreground">
                {status?.is_clocked_in ? `Présence en cours : ${formatElapsed(status.current_pointage?.debut)}` : 'Aucun pointage ouvert'}
              </p>
            </div>
            <Button onClick={handleClock} disabled={isSaving} size="sm" variant={status?.is_clocked_in ? 'outline' : 'default'}>
              {isSaving ? <Spinner className="h-4 w-4" /> : status?.is_clocked_in ? <><LogOut className="h-4 w-4 mr-2" /> Pointer le départ</> : <><LogIn className="h-4 w-4 mr-2" /> Pointer l’arrivée</>}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
