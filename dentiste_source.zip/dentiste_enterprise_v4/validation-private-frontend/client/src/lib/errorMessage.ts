export function getApiErrorMessage(error: any, fallback = 'Une erreur est survenue.'): string {
  const status = error?.response?.status;
  if (status === 429) return 'Trop de tentatives. Réessayez dans une minute.';

  const detail = error?.response?.data?.detail;
  if (typeof detail === 'string' && detail.trim()) return detail;
  if (Array.isArray(detail)) {
    const messages = detail
      .map((item) => {
        if (typeof item === 'string') return item;
        if (item && typeof item.msg === 'string') return item.msg;
        return '';
      })
      .filter(Boolean);
    if (messages.length) return messages.join(' — ');
  }
  if (typeof error?.message === 'string' && error.message.trim()) return error.message;
  return fallback;
}
