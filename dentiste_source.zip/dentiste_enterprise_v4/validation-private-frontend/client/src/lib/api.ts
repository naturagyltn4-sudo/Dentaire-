import axios, { AxiosInstance, AxiosError } from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '/api/v1';
const API_ORIGIN = API_BASE.replace(/\/api\/v1\/?$/, '');

export const resolveApiUrl = (url?: string | null) => {
  if (!url) return undefined;
  if (/^https?:\/\//i.test(url)) return url;
  return `${API_ORIGIN}${url.startsWith('/') ? '' : '/'}${url}`;
};

export const normalizeBrandingResponse = (branding: BrandingResponse): BrandingResponse => ({
  ...branding,
  logo_url: resolveApiUrl(branding.logo_url),
  contenu_landing: branding.contenu_landing ? { ...branding.contenu_landing, photo_hero_url: resolveApiUrl(branding.contenu_landing.photo_hero_url) } : branding.contenu_landing,
});

export interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

export interface UserOut {
  id: number;
  email: string;
  nom: string;
  prenom: string;
  role: string;
  telephone?: string;
  specialite?: string;
}

export interface BrandingResponse {
  nom_clinique: string;
  couleur_primaire: string;
  couleur_secondaire: string;
  logo_url?: string;
  contenu_landing?: {
    titre?: string;
    sous_titre?: string;
    services_mis_en_avant?: string[];
    adresse?: string;
    ville?: string;
    telephone?: string;
    whatsapp?: string;
    email?: string;
    instagram?: string;
    facebook?: string;
    tiktok?: string;
    photo_hero_url?: string;
    description_longue?: string;
    horaires?: string;
  };
}

export interface PublicPraticien {
  id: number;
  nom: string;
  prenom: string;
  nom_complet: string;
  specialite?: string | null;
  agenda_color?: string | null;
}

export interface TeamMember {
  id: number;
  email: string;
  nom: string;
  prenom: string;
  role: string;
  telephone?: string | null;
  specialite?: string | null;
  agenda_color?: string | null;
  taux_commission: string;
  is_active: boolean;
  mfa_enabled: boolean;
  created_at?: string | null;
  last_login?: string | null;
}

export interface AuditEvent {
  id: number;
  created_at?: string | null;
  action: string;
  resource_type: string;
  resource_id?: number | null;
  patient_id?: number | null;
  utilisateur_id: number;
  utilisateur_nom: string;
  utilisateur_role: string;
  details: Record<string, unknown>;
  ip_address?: string | null;
}

export interface TeamMemberCreateInput {
  email: string;
  nom: string;
  prenom: string;
  role: string;
  mot_de_passe: string;
  telephone?: string;
  specialite?: string;
  agenda_color?: string;
  taux_commission?: number;
}

export interface TeamMemberUpdateInput {
  nom?: string;
  prenom?: string;
  role?: string;
  telephone?: string | null;
  specialite?: string | null;
  agenda_color?: string | null;
  taux_commission?: number;
  is_active?: boolean;
}

export interface PublicActe {
  id: number;
  nom: string;
  categorie: string;
  duree_minutes: number;
  description?: string | null;
  prix_base?: number | null;
}

export interface PublicDisponibilite {
  heure: string;
  datetime: string;
}

export interface PublicDisponibilitesResponse {
  praticien_id: number;
  date: string;
  duree_minutes: number;
  creneaux: PublicDisponibilite[];
}

export interface BookingRequest {
  id: number;
  clinic_id: number;
  nom: string;
  prenom: string;
  telephone: string;
  praticien_id: number;
  praticien_nom: string;
  acte_id: number;
  acte_nom: string;
  date_heure: string;
  statut: 'pending' | 'accepted' | 'rejected';
  patient_id?: number | null;
  rendez_vous_id?: number | null;
  created_at?: string | null;
  validated_at?: string | null;
  rejected_at?: string | null;
}

export interface SuperAdminOverview {
  generated_at: string;
  clinics_count: number;
  users_count: number;
  active_users_count: number;
  patients_count: number;
  appointments_count: number;
  invoices_count: number;
  revenue_total: string;
  security_alerts_open: number;
  tenants_without_registry: number;
}

export interface SuperAdminClinic {
  id: number;
  nom: string;
  slug: string;
  statut: string;
  email_contact?: string | null;
  telephone_contact?: string | null;
  fuseau_horaire: string;
  users_count: number;
  active_users_count: number;
  patients_count: number;
  appointments_count: number;
  invoices_count: number;
  subscription: {
    id?: number;
    plan: string;
    statut: string;
    expires_at?: string | null;
    user_limit?: number | null;
    storage_limit_gb?: number | null;
    notes?: string | null;
  };
}

export interface SuperAdminUser {
  id: number;
  clinic_id: number;
  email: string;
  nom: string;
  prenom: string;
  role: string;
  is_active: boolean;
  mfa_enabled: boolean;
  last_login?: string | null;
}

export interface SuperAdminHealth {
  generated_at: string;
  environment: string;
  status: string;
  checks: { api: string; database: string; redis: string };
}

let accessToken: string | null = null;
let refreshPromise: Promise<string> | null = null;

const refreshAccessToken = async (): Promise<string> => {
  if (!refreshPromise) {
    refreshPromise = axios
      .post<TokenResponse>(`${API_BASE}/auth/refresh`, undefined, { withCredentials: true })
      .then(({ data }) => {
        accessToken = data.access_token;
        return data.access_token;
      })
      .finally(() => {
        refreshPromise = null;
      });
  }
  return refreshPromise;
};

export const createApiClient = (): AxiosInstance => {
  const client = axios.create({
    baseURL: API_BASE,
    headers: {
      'Content-Type': 'application/json',
    },
    withCredentials: true,
  });

  // Request interceptor: add access token
  client.interceptors.request.use(
    (config) => {
      if (accessToken) {
        config.headers.Authorization = `Bearer ${accessToken}`;
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  // Response interceptor: refresh the HttpOnly-cookie session once for concurrent 401s.
  client.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
      const originalRequest = error.config as (typeof error.config & { _retry?: boolean }) | undefined;
      const isRefreshRequest = originalRequest?.url?.includes('/auth/refresh');

      if (error.response?.status === 401 && originalRequest && !originalRequest._retry && !isRefreshRequest) {
        originalRequest._retry = true;
        try {
          const token = await refreshAccessToken();
          originalRequest.headers = originalRequest.headers ?? {};
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return client(originalRequest);
        } catch (refreshError) {
          accessToken = null;
          return Promise.reject(refreshError);
        }
      }

      return Promise.reject(error);
    }
  );

  return client;
};

export const api = createApiClient();

// Auth utilities
export const setTokens = (access: string) => {
  accessToken = access;
};

export const getAccessToken = () => accessToken;

export const clearTokens = () => {
  accessToken = null;
};

export const isAuthenticated = () => !!accessToken;

// Jeton de challenge MFA (5 min) : gardé en mémoire uniquement, comme les
// tokens d'accès/refresh — jamais en sessionStorage. Il est perdu si la
// page est rechargée pendant la saisie de l'OTP, ce qui est volontaire :
// l'utilisateur recommence simplement le login, exactement comme pour un
// access_token perdu au refresh.
let mfaChallengeToken: string | null = null;
export const setMfaChallengeToken = (token: string) => { mfaChallengeToken = token; };
export const getMfaChallengeToken = () => mfaChallengeToken;
export const clearMfaChallengeToken = () => { mfaChallengeToken = null; };

export interface MfaStatusResponse {
  enabled: boolean;
  setup_at?: string | null;
}

export interface MfaSetupResponse {
  secret: string;
  qr_uri: string;
  qr_code_b64: string;
  backup_codes: string[];
}

export interface MfaChallengeResponse {
  mfa_required: true;
  challenge_token: string;
}

// Auth endpoints
export const authApi = {
  // Le login retourne soit TokenResponse (pas de MFA), soit
  // MfaChallengeResponse (MFA activé) — à distinguer via `mfa_required`.
  login: (email: string, password: string) =>
    api.post<TokenResponse | MfaChallengeResponse>('/auth/login', { email, password }),

  refresh: () =>
    api.post<TokenResponse>('/auth/refresh', undefined, { withCredentials: true }),

  me: () => api.get<UserOut>('/auth/me'),

  // challenge_token vient de la réponse de login ci-dessus — il n'y a
  // plus de lookup par email ni de user_id envoyé en clair.
  verifyMfa: (challengeToken: string, otp: string) =>
    api.post<TokenResponse>('/auth/mfa/verify', { challenge_token: challengeToken, otp }),

  mfaSetup: () =>
    api.post<MfaSetupResponse>('/auth/mfa/setup'),

  mfaConfirm: (otp: string) =>
    api.post('/auth/mfa/confirm', { otp }),

  mfaDisable: (password: string) =>
    api.post('/auth/mfa/disable', { password }),

  logout: () => api.post('/auth/logout', undefined, { withCredentials: true }),

  mfaStatus: () =>
    api.get<MfaStatusResponse>('/auth/mfa/status'),
};

// Settings endpoints
export const settingsApi = {
  getBranding: () =>
    api.get<BrandingResponse>('/settings/branding').then((response) => ({
      ...response,
      data: normalizeBrandingResponse(response.data),
    })),

  updateBranding: (data: Partial<BrandingResponse>) =>
    api.patch<BrandingResponse>('/settings/branding', data).then((response) => ({
      ...response,
      data: normalizeBrandingResponse(response.data),
    })),

  uploadLogo: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post<{ logo_url: string }>('/settings/branding/logo', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  uploadHero: (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post<{ photo_hero_url: string }>('/settings/branding/hero', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export const bookingRequestsApi = {
  list: (statut: 'pending' | 'accepted' | 'rejected' = 'pending') =>
    api.get<BookingRequest[]>('/booking-requests', { params: { statut } }),
  approve: (id: number) => api.post(`/booking-requests/${id}/approve`),
  reject: (id: number, motif?: string) => api.post(`/booking-requests/${id}/reject`, { motif }),
};

export const adminTeamApi = {
  list: () => api.get<TeamMember[]>('/admin/team'),
  create: (data: TeamMemberCreateInput) => api.post<TeamMember>('/admin/team', data),
  update: (id: number, data: TeamMemberUpdateInput) => api.patch<TeamMember>(`/admin/team/${id}`, data),
  resetPassword: (id: number, mot_de_passe: string) =>
    api.post<{ status: string; message: string }>(`/admin/team/${id}/reset-password`, { mot_de_passe }),
  audit: (params?: { patient_id?: number; utilisateur_id?: number; resource_type?: string; limit?: number }) =>
    api.get<AuditEvent[]>('/admin/audit', { params }),
  patientAudit: (patientId: number, limit = 100) =>
    api.get<AuditEvent[]>(`/admin/audit/patients/${patientId}`, { params: { limit } }),
};

// Public endpoints
export const superAdminApi = {
  overview: () => api.get<SuperAdminOverview>('/super-admin/overview'),
  clinics: () => api.get<SuperAdminClinic[]>('/super-admin/clinics'),
  users: (clinicId?: number) => api.get<SuperAdminUser[]>('/super-admin/users', { params: clinicId ? { clinic_id: clinicId } : undefined }),
  health: () => api.get<SuperAdminHealth>('/super-admin/health'),
  updateClinic: (id: number, data: Partial<Pick<SuperAdminClinic, 'nom' | 'statut' | 'email_contact' | 'telephone_contact' | 'fuseau_horaire'>>) => api.patch(`/super-admin/clinics/${id}`, data),
  updateSubscription: (id: number, data: { plan?: string; statut?: string; expires_at?: string; user_limit?: number; storage_limit_gb?: number; notes?: string }) => api.patch(`/super-admin/clinics/${id}/subscription`, data),
  updateUser: (id: number, data: { is_active?: boolean; role?: string }) => api.patch(`/super-admin/users/${id}`, data),
  resetPassword: (id: number, mot_de_passe: string) => api.post(`/super-admin/users/${id}/reset-password`, { mot_de_passe }),
  audit: () => api.get('/super-admin/audit'),
};

export const publicApi = {
  getPraticiens: () => api.get<PublicPraticien[]>('/public/praticiens'),

  getActes: () => api.get<PublicActe[]>('/public/actes'),

  getDisponibilites: (praticienId: number, params?: { date?: string; acte_id?: number; duree?: number }) =>
    api.get<PublicDisponibilitesResponse>(`/public/disponibilites/${praticienId}`, { params }),

  submitCallback: (data: { nom: string; telephone: string; email?: string; message?: string }) =>
    api.post<{ lead_id: number; statut: string; message: string }>('/public/rappel', data),

  reserveRdv: (data: {
    nom: string;
    prenom: string;
    telephone: string;
    praticien_id: number;
    acte_id: number;
    date_heure: string;
  }) => api.post<{ booking_request_id: number; rdv_id: number | null; patient_id: number | null; praticien_id: number; statut: string; message?: string }>('/public/reservation', data),
};

export const photosApi = {
  /** Récupère une photo médicale déchiffrée et retourne une object URL
   * affichable dans une balise <img>. Un <img src="..."> classique ne
   * peut pas porter le header Authorization, d'où ce fetch en blob. */
  getPhotoUrl: async (patientId: number, photoId: number, thumbnail = false): Promise<string> => {
    const res = await api.get(`/patients/${patientId}/photos/${photoId}/view`, {
      params: thumbnail ? { thumbnail: true } : undefined,
      responseType: 'blob',
    });
    return URL.createObjectURL(res.data);
  },

  upload: (patientId: number, file: File, params: { type_photo: string; zone?: string; angle?: string; dossier_id?: number }) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post(`/patients/${patientId}/photos`, formData, {
      params,
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },

  delete: (patientId: number, photoId: number) =>
    api.delete(`/patients/${patientId}/photos/${photoId}`),

  /** Récupère les photos avant/après pour comparaison côte-à-côte.
   *  Utilise l'endpoint backend dédié qui retourne { avant: [...], apres: [...] }.
   */
  getComparaisonAvantApres: (patientId: number, zone?: string) =>
    api.get<{ avant: { id: number; url: string; date: string }[]; apres: { id: number; url: string; date: string }[] }>(
      `/patients/${patientId}/photos/avant-apres`,
      { params: zone ? { zone } : undefined },
    ),
};

export const simulationApi = {
  list: (patientId: number) => api.get(`/simulation-ia/patients/${patientId}/simulations`),
  getSimulationUrl: async (patientId: number, simulationId: number): Promise<string> => {
    const res = await api.get(`/simulation-ia/patients/${patientId}/simulations/${simulationId}/view`, {
      responseType: 'blob',
    });
    return URL.createObjectURL(res.data);
  },
  simuler: (patientId: number, photoId: number, data: { zone_anatomique: string; intensite: number; instructions?: string; masque_base64?: string }) =>
    api.post(`/simulation-ia/patients/${patientId}/photos/${photoId}/simuler`, data),
};

export const orthodontieApi = {
  listSuivis: (patientId: number) => api.get(`/orthodontie/patients/${patientId}/suivis`),
  createSuivi: (patientId: number, data: { photo_reelle_id: number; phase: string; type_appareil: string; observations?: string }) =>
    api.post(`/orthodontie/patients/${patientId}/suivi`, data),
};

export const dentalApi = {
  getProtheses: () => api.get('/protheses/'),
  getProthesesPatient: (patientId: number) => api.get(`/protheses/patient/${patientId}`),
  getDevis: () => api.get('/factures/devis'),
  getDevisPatient: (patientId: number) => api.get(`/factures/devis?patient_id=${patientId}`),
  createDevis: (data: { patient_id: number; prix: number; acte_id?: number; dent?: string; date_validite?: string; lignes?: { nom: string; prix: number; quantite: number }[] }) =>
    api.post('/factures/devis', data),
  accepterDevis: (devisId: number) => api.post(`/factures/devis/${devisId}/accepter`),
  // La PEC est rattachée à une facture dans le backend, pas directement au devis.
  creerPriseEnCharge: (factureId: number, data: { organisme: string; numero_dossier?: string; montant_pris_en_charge: string }) =>
    api.post(`/factures/${factureId}/mutuelle`, data),
  getPriseEnCharge: (factureId: number) => api.get(`/factures/${factureId}/reste-patient`),
};

export const suiviPostOpApi = {
  listPatient: (patientId: number) => api.get(`/patients/${patientId}/suivi-post-op`),
  getDetail: (suiviId: number) => api.get(`/suivis-post-op/${suiviId}`),
  marquerEffectue: (suiviId: number, data: { observations?: string; complication?: string | null }) =>
    api.patch(`/suivis-post-op/${suiviId}`, data),
  cloturer: (suiviId: number, data: { statut: 'effectue' | 'manque' }) =>
    api.post(`/suivis-post-op/${suiviId}/cloturer`, data),
};

export const iaDentaireApi = {
  detecter: (radioId: number) => api.post('/ia-dentaire/caries/analyser', { radio_id: radioId }),
  valider: (analyseId: number, praticienId: number) =>
    api.post(`/ia-dentaire/caries/${analyseId}/valider`, { praticien_id: praticienId }),
};

export const dossierMedicalApi = {
  getTimeline: (patientId: number) => api.get(`/patients/${patientId}/dossiers`),

  create: (patientId: number, data: {
    praticien_id: number;
    rdv_id?: number;
    acte_id?: number;
    date_acte: string;
    observations?: string;
    effets_secondaires?: string;
    satisfaction_patient?: number;
    suivi_requis?: boolean;
    date_suivi_recommandee?: string;
  }) => api.post(`/patients/${patientId}/dossiers`, data),

  listConsentements: (patientId: number) => api.get(`/patients/${patientId}/consentements`),

  signConsentement: (patientId: number, data: { acte_id?: number; signature_base64: string; methode_signature?: string }) =>
    api.post(`/patients/${patientId}/consentements`, data),

  listPhotos: (patientId: number) => api.get(`/patients/${patientId}/photos`),

  /** Déclenche le téléchargement du PDF complet du dossier patient. */
  downloadExportPdf: async (patientId: number) => {
    const res = await api.get(`/patients/${patientId}/export-pdf`, { responseType: 'blob' });
    const url = URL.createObjectURL(res.data);
    const link = document.createElement('a');
    link.href = url;
    link.download = `dossier_patient_${patientId}.pdf`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  },
};

// ── Equipe Messages (Messagerie interne) ───────────────────

export interface EquipeMessage {
  id: number;
  clinic_id: number;
  expediteur_id: number;
  destinataire_id: number;
  expediteur_nom: string;
  expediteur_prenom: string;
  destinataire_nom: string;
  destinataire_prenom: string;
  sujet: string;
  contenu: string;
  lu: boolean;
  lu_a: string | null;
  cree_a: string;
}

export interface EquipeMessageCreate {
  destinataire_id: number;
  sujet: string;
  contenu: string;
}

export interface EquipeMember {
  id: number;
  email: string;
  nom: string;
  prenom: string;
  role: string;
  telephone?: string | null;
  specialite?: string | null;
  is_active: boolean;
}

export const equipeApi = {
  listMembers: () => api.get<EquipeMember[]>('/equipe/membres'),
  // Envoyer un message
  send: (data: EquipeMessageCreate) =>
    api.post<EquipeMessage>('/equipe/messages', data),

  // Boîte de réception
  getInbox: (page = 1, page_size = 20) =>
    api.get<EquipeMessage[]>('/equipe/messages', { params: { page, page_size } }),

  // Messages envoyés
  getSent: (page = 1, page_size = 20) =>
    api.get<EquipeMessage[]>('/equipe/messages/sent', { params: { page, page_size } }),

  // Détail d'un message
  getOne: (id: number) =>
    api.get<EquipeMessage>(`/equipe/messages/${id}`),

  // Marquer comme lu
  markRead: (id: number) =>
    api.put(`/equipe/messages/${id}/lu`),

  // Supprimer
  delete: (id: number) =>
    api.delete(`/equipe/messages/${id}`),

  // Nombre de non-lus
  getUnreadCount: () =>
    api.get<{ unread_count: number }>('/equipe/messages/unread-count'),
};

export interface Delegue {
  id: number;
  nom: string;
  prenom: string;
  laboratoire_ou_societe: string;
  telephone: string;
  email?: string | null;
  specialite_produits?: string | null;
  notes?: string | null;
  is_active: boolean;
  created_at: string;
}

export interface Cephalometrie {
  id: number;
  patient_id: number;
  praticien_id?: number | null;
  titre: string;
  image_url: string;
  analyse_data?: Record<string, unknown> | null;
  conclusions?: string | null;
  created_at: string;
}

export const deleguesApi = {
  list: () => api.get<Delegue[]>('/delegues'),
  create: (data: Omit<Delegue, 'id' | 'is_active' | 'created_at'>) =>
    api.post<{ id: number; message: string }>('/delegues', data),
  update: (id: number, data: Partial<Omit<Delegue, 'id' | 'created_at'>>) =>
    api.patch<{ message: string }>(`/delegues/${id}`, data),
  remove: (id: number) => api.delete<{ message: string }>(`/delegues/${id}`),
};

export const cephalometriesApi = {
  list: (patientId?: number) =>
    api.get<Cephalometrie[]>('/cephalometries', { params: patientId ? { patient_id: patientId } : undefined }),
  upload: (data: { patient_id: number; titre: string; conclusions?: string; file: File }) => {
    const formData = new FormData();
    formData.append('patient_id', String(data.patient_id));
    formData.append('titre', data.titre);
    if (data.conclusions) formData.append('conclusions', data.conclusions);
    formData.append('file', data.file);
    return api.post<{ id: number; message: string; image_url: string }>('/cephalometries', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
};

export default api;
