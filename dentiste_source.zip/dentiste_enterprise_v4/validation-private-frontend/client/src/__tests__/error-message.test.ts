import { describe, expect, it } from 'vitest';
import { getApiErrorMessage } from '@/lib/errorMessage';

describe('getApiErrorMessage', () => {
  it('transforme un détail FastAPI structuré en texte affichable', () => {
    const error = {
      response: {
        data: {
          detail: [
            {
              type: 'missing',
              loc: ['body', 'password'],
              msg: 'Champ requis',
              input: {},
            },
          ],
        },
      },
    };

    expect(getApiErrorMessage(error, 'Connexion impossible')).toBe('Champ requis');
  });

  it('conserve le message de secours si le détail ne peut pas être affiché', () => {
    expect(getApiErrorMessage({ response: { data: { detail: [{ input: {} }] } } }, 'Connexion impossible')).toBe(
      'Connexion impossible'
    );
  });
});
