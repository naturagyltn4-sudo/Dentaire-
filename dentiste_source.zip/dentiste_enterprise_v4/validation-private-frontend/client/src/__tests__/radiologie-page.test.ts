import { describe, expect, it } from 'vitest';
import { normalizeRadioList } from '@/pages/patients/RadiologiePage';

describe('normalizeRadioList', () => {
  it('préserve une liste vide comme état fonctionnel normal', () => {
    expect(normalizeRadioList([])).toEqual([]);
  });

  it('évite un rendu incohérent si le contrat de réponse est invalide', () => {
    expect(normalizeRadioList({ detail: 'Réponse inattendue' })).toEqual([]);
  });
});
