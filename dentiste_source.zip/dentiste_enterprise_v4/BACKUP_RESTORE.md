# Backup et restauration Dentiste RC Enterprise

## Objectif

Une sauvegarde n’est exploitable que si elle peut être déchiffrée, vérifiée et restaurée. La stratégie doit protéger PostgreSQL, les volumes applicatifs chiffrés, les sauvegardes et les clés nécessaires au déchiffrement par des canaux séparés.

## Politique recommandée

| Élément | Fréquence | Conservation | Emplacement |
|---|---:|---:|---|
| PostgreSQL | Quotidienne et avant upgrade | Selon contrat clinique | Hors VPS chiffré |
| `clinic_data` | Quotidienne selon criticité photo/radio | Politique médicale | Stockage hors hôte |
| `clinic_backups` | Temporaire local | Court terme | Volume Docker dédié |
| Clés | À chaque rotation | Gestionnaire de secrets | Canal séparé des données |
| Test de restauration | Mensuel et avant version majeure | Rapport d’exploitation | Environnement isolé |

`BACKUP_RETENTION_DAYS` ne remplace pas la politique documentaire du responsable de traitement.

## Sauvegarde Compose

Vérifier PostgreSQL et l’environnement protégé, puis lancer :

```bash
docker compose -f docker-compose.production.yml ps postgres
docker compose -f docker-compose.production.yml --profile backup run --rm backup
```

Le profil exécute `backup_init` avant `backup` pour préparer les permissions du volume avec un conteneur éphémère root, tandis que l’outil de backup lui-même reste sous l’utilisateur applicatif. `pg_dump` produit un format custom, puis le script chiffre le fichier avec GPG AES256 et lance immédiatement `verify`.

## Vérification et restauration

Sur une base de validation ou un environnement isolé :

```bash
docker compose -f docker-compose.production.yml --profile backup run --rm backup /bin/bash -lc '\
  file=$(ls -1t /app/backups/*.dump.gpg | head -1); \
  ./scripts/backup_restore.sh verify "$file"; \
  ./scripts/backup_restore.sh restore "$file"'
```

La restauration génère le SQL depuis `pg_restore`, retire uniquement `SET transaction_timeout = 0;` lorsque le client PostgreSQL 17 vise un serveur PostgreSQL 16, puis l’exécute avec `psql -v ON_ERROR_STOP=1`. Une requête de cohérence sur la table `patients` termine la procédure. Toute autre erreur SQL arrête la restauration.

En production, arrêter d’abord les APIs et workers, sauvegarder l’état courant, restaurer la base et les volumes dans un environnement approuvé, rejouer les migrations si nécessaire, puis redémarrer les services et exécuter la recette fonctionnelle. Ne jamais utiliser `down -v` sur la clinique réelle pendant une restauration.

## Hors site et disaster recovery

Copier le fichier `.dump.gpg` vers un stockage hors VPS chiffré. Conserver la clé `BACKUP_ENCRYPTION_KEY` dans un gestionnaire de secrets distinct. Tester périodiquement la perte d’un VPS, la restauration d’une base vierge, la récupération des volumes de fichiers et la remise en service du reverse proxy public et du réseau clinique privé.

## Preuve actuelle

La campagne Docker du 17 août 2026 a exécuté : backup PostgreSQL, vérification GPG et table des matières, restauration sur PostgreSQL 16 et requête de cohérence. Le résultat est `PASS` dans `RELEASE_EVIDENCE_FINAL.md`. La restauration complète d’une clinique réelle, avec fichiers médicaux réels et stockage hors VPS client, reste une recette à réaliser chez le client et ne doit pas être confondue avec cette validation synthétique.
