# Dentiste RC Enterprise — Déploiement production

## Principe

Le déploiement est **mono-clinique par instance**. La clinique est déterminée par la configuration serveur, jamais par un paramètre HTTP choisi par le navigateur. La surface Internet est limitée au `public_gateway`; le cœur clinique et les données restent sur `clinic_private`.

## Topologie livrée

| Surface | Services | Accès attendu |
|---|---|---|
| Public Gateway | `public_gateway` → `public_api` | Internet via reverse proxy TLS |
| Private Clinical Core | `private_frontend` → `private_api` | Réseau clinique ou VPN |
| Données et traitements | PostgreSQL, Redis, worker, beat | `clinic_private`, aucun port public |

`public_api` ne monte que les routes branding, praticiens, actes, disponibilités et réservation. `private_api` monte l’application métier complète. Le fichier `public-gateway/nginx.conf` renvoie `404` pour les chemins privés.

## Variables de production

| Variable | Règle |
|---|---|
| `ENV` | `production` |
| `INSTANCE_CLINIC_ID` | Fixe pendant la vie de l’instance |
| `DATABASE_URL` / `REDIS_URL` | Réseau privé uniquement |
| `CORS_ORIGINS` | Origines HTTPS explicites, jamais `*` |
| `PRIVATE_FRONTEND_BIND` / `PRIVATE_FRONTEND_PORT` | Interface privée/VPN ou loopback, jamais exposition Internet directe |
| `PUBLIC_GATEWAY_BIND` / `PUBLIC_GATEWAY_PORT` | Port local du reverse proxy public |
| `SECRET_KEY`, `FERNET_KEY`, `PHOTO_ENCRYPTION_KEY`, `BACKUP_ENCRYPTION_KEY` | Secrets distincts, injectés hors dépôt |
| `COPILOTE_IA_ENABLED` | `false` par défaut |

## Déploiement initial

Depuis la racine de la release :

```bash
docker compose -f docker-compose.production.yml config --quiet
docker compose -f docker-compose.production.yml build --pull
docker compose -f docker-compose.production.yml up -d postgres redis
docker compose -f docker-compose.production.yml run --rm migrate
docker compose -f docker-compose.production.yml up -d private_api public_api private_frontend public_gateway worker beat
```

Le service `migrate` doit terminer avec succès avant les APIs. Une migration échouée est un **NO-GO**. Les services attendus en `healthy` sont PostgreSQL, Redis, `private_api`, `public_api`, les deux frontends, worker et beat.

Pour activer et tester un backup :

```bash
docker compose --profile backup run --rm backup
docker compose --profile backup run --rm backup /bin/bash -lc '\
  file=$(ls -1t /app/backups/*.dump.gpg | head -1); \
  ./scripts/backup_restore.sh verify "$file"; \
  ./scripts/backup_restore.sh restore "$file"'
```

## Reverse proxy et TLS

Le reverse proxy Internet doit pointer uniquement vers `PUBLIC_GATEWAY_PORT`. Il doit rediriger HTTP vers HTTPS, appliquer les limites de débit et conserver les journaux d’accès sans données médicales. Il ne doit publier ni `private_frontend`, ni `private_api`, ni PostgreSQL, ni Redis.

Le frontend privé doit être lié à une interface privée ou à un tunnel VPN. Le binding par défaut est `127.0.0.1:8080`; une modification vers une interface VPN doit être accompagnée d’une règle firewall et d’une recette depuis le réseau clinique.

## Vérification réseau

Depuis Internet ou le reverse proxy public :

```bash
curl -fsS https://public.example.tld/healthz
curl -fsS https://public.example.tld/api/v1/settings/branding
curl -fsS https://public.example.tld/api/v1/public/praticiens
curl -i https://public.example.tld/api/v1/patients   # attendu : 404
```

Depuis le réseau clinique/VPN :

```bash
curl -fsS http://private_frontend/healthz
curl -fsS http://private_api:8000/ready
```

Le script `scripts/test_public_private.sh` automatise cette recette dans Docker. La recette navigateur publique est dans `autocommerce-app/tests/e2e/public-gateway.spec.ts` et s’exécute avec `E2E_BASE_URL`.

## Déploiement d’une nouvelle version

Chaque upgrade suit le cycle : sauvegarde PostgreSQL et volumes, validation du release gate, construction des images, migration contrôlée, redémarrage des services et vérification des healthchecks. Le paquet livré ne contient jamais `.env.clinic`, secrets, patients réels, `node_modules`, `dist`, caches, virtualenv ou logs sensibles.

## Arrêt et incident

Pour arrêter sans supprimer les volumes :

```bash
docker compose -f docker-compose.production.yml stop
```

Ne jamais utiliser `down -v` sur une clinique réelle sans sauvegarde restaurable et autorisation de changement. En cas d’échec de migration, de backup, de healthcheck ou de séparation réseau, appliquer `ROLLBACK.md` et classer la release `NO-GO`.
