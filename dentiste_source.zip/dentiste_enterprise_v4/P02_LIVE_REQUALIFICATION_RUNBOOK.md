# P02 — Runbook de requalification live

## Objet

Ce document décrit les contrôles à exécuter sur le mono-VPS après déploiement. Il complète le code et ne remplace pas les obligations du fournisseur WhatsApp, les contrôles de sécurité, la politique de consentement ou les procédures cliniques.

## 1. Préparer sans exposer de secret

Copier `.env.example` vers un emplacement privé, remplacer tous les placeholders et limiter les permissions à l’utilisateur de déploiement. Les valeurs réelles ne doivent jamais être ajoutées au dépôt, aux logs, à une capture d’écran ou à l’archive de livraison.

Les quatre flags de sécurité sont à examiner séparément : `TELECONSULTATION_ENABLED`, `DAILY_REQUIRED_IN_PRODUCTION`, `DAILY_ENABLE_RECORDING` et `PRACTITIONER_AGENT_ENABLED`. L’état recommandé pour une première mise en ligne est `false` pour la téléconsultation et l’agent médecin, avec l’enregistrement désactivé.

## 2. Activer Daily.co seulement après validation opérateur

Renseigner `DAILY_API_KEY` et une `DAILY_API_BASE` HTTPS réelle, puis activer `TELECONSULTATION_ENABLED=true`. Ne pas déduire d’une clé présente que le fournisseur est contractuellement ou réglementairement adapté aux données de santé : conserver la preuve contractuelle, la région d’hébergement, les sous-traitants, la rétention et la politique d’enregistrement dans le dossier opérateur.

Le préflight doit passer. Un test contrôlé doit ensuite vérifier qu’un consentement HTTPS est obligatoire, que le lien généré est privé et que le tenant du JWT ne peut pas accéder à la téléconsultation d’une autre clinique. Avec Daily.co indisponible en production, la création doit échouer et ne doit pas basculer vers une salle vidéo publique.

## 3. Activer la ligne WhatsApp praticien

La ligne praticien doit utiliser un `Phone Number ID` distinct de la ligne cabinet. Renseigner ensemble `WA_BUSINESS_TOKEN_PRATICIEN`, `WA_PHONE_ID_PRATICIEN` et `WA_WEBHOOK_VERIFY_TOKEN_PRATICIEN`, vérifier la signature et le webhook Meta côté opérateur, puis mettre `PRACTITIONER_AGENT_ENABLED=true` seulement après validation de la téléconsultation et du consentement.

La whitelist doit être créée pour le bon `utilisateur_id`, le bon `clinic_id`, avec un statut actif et une date d’expiration. Un numéro révoqué, expiré, inconnu ou enregistré dans une autre clinique doit être refusé. La route praticien ne doit jamais être confondue avec la ligne cabinet ni avec le canal patient.

## 4. Scénarios de requalification

| Scénario | Résultat attendu |
|---|---|
| Agent médecin désactivé | Le webhook ne route pas vers l’agent médecin. |
| Numéro praticien whitelisté mais sans téléconsultation consentie | Refus contrôlé ; aucun appel LLM. |
| Whitelist expirée ou révoquée | Refus contrôlé ; aucune donnée médicale divulguée. |
| Téléconsultation d’une autre clinique | Refus tenant-scoped. |
| Consentement absent ou URL non HTTPS | Création et agent médecin refusés. |
| Question d’un praticien autorisé sur une téléconsultation active | Réponse pseudonymisée ou mode dégradé contrôlé, avec journal d’audit. |
| Daily.co indisponible en production | Erreur contrôlée ; aucun fallback Jitsi/public. |
| Médecin listant les conversations | Seulement les conversations qui lui sont assignées. |
| Administrateur listant les conversations | Accès selon RBAC et tenant, sans élargissement inter-clinique. |

## 5. Contrôles de fin de changement

Exécuter le préflight, consulter les logs d’audit, vérifier les limites de débit et confirmer qu’aucun token, consentement ou dossier médical n’est écrit en clair dans les logs. Réaliser un test de révocation et un test de rollback avant l’ouverture publique.

Désactiver immédiatement `PRACTITIONER_AGENT_ENABLED` et `TELECONSULTATION_ENABLED` en cas de doute sur le fournisseur, le consentement, la signature Meta, la whitelist ou l’isolation tenant. La désactivation n’efface pas les données existantes ; appliquer la politique de conservation et d’incident de l’opérateur.

## 6. Preuves à conserver

Le dossier de requalification doit contenir la sortie horodatée du préflight, la sortie de `docker compose config`, le résultat de la migration PostgreSQL, les smoke tests HTTPS, le test de restauration, les vérifications de rôles, la preuve de configuration webhook et la preuve contractuelle du fournisseur vidéo. Cette archive de code ne prétend pas contenir ces preuves live.
