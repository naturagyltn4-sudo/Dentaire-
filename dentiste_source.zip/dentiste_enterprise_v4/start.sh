#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

ENV_FILE="${DEPLOY_ENV_FILE:-$ROOT_DIR/.env}"
if [ ! -f "$ENV_FILE" ]; then
  echo "[start.sh] Fichier env absent : $ENV_FILE" >&2
  echo "[start.sh] Copiez .env.example vers .env puis renseignez les secrets réels." >&2
  exit 1
fi
export DEPLOY_ENV_FILE="$ENV_FILE"

docker compose --env-file "$ENV_FILE" \
  -f docker-compose.production.yml up -d private_api worker beat

echo "[start.sh] Statut des conteneurs :"
docker compose --env-file "$ENV_FILE" \
  -f docker-compose.production.yml ps
