import json
import os
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

PRIVATE = os.environ.get('UAT_PRIVATE_URL', 'http://127.0.0.1:8000')
PUBLIC = os.environ.get('UAT_PUBLIC_URL', 'http://127.0.0.1:18090')
PASSWORD = os.environ.get('UAT_PASSWORD')
if not PASSWORD:
    raise RuntimeError("UAT_PASSWORD obligatoire — aucun mot de passe par défaut en production.")

if os.environ.get("ENV") == "production":
    raise RuntimeError("uat_global_roles.py est un script de test/UAT et ne doit jamais être exécuté en production.")

ROLES = {
    'directrice': 'directrice.demo@dentiste-demo.com',
    'medecin': 'medecin.demo@dentiste-demo.com',
    'assistante': 'assistante.demo@dentiste-demo.com',
    'commercial': 'commercial.demo@dentiste-demo.com',
    'admin': 'admin.demo@dentiste-demo.com',
}

results = []
sessions = {}
users = {}
context = {}


def record(name, role, response, expected):
    ok = response.status_code in expected
    detail = None
    try:
        payload = response.json()
        if isinstance(payload, dict):
            detail = payload.get('detail') or payload.get('message') or payload.get('id')
        else:
            detail = f'list[{len(payload)}]'
    except Exception:
        detail = response.text[:160]
    results.append({
        'name': name,
        'role': role,
        'status': response.status_code,
        'expected': sorted(expected),
        'ok': ok,
        'detail': detail,
    })
    return response


def api(role, method, path, *, public=False, json_body=None, expected=(200,)):
    url = (PUBLIC if public else PRIVATE) + path
    session = requests.Session() if public else sessions[role]
    response = session.request(method, url, json=json_body, timeout=20)
    record(f'{method} {path}', role, response, set(expected))
    return response


def login(role):
    session = requests.Session()
    response = session.post(f'{PRIVATE}/api/v1/auth/login', json={'email': ROLES[role], 'password': PASSWORD}, timeout=20)
    record('POST /api/v1/auth/login', role, response, {200})
    if response.status_code != 200:
        return
    payload = response.json()
    token = payload.get('access_token')
    if not token:
        record('login token present', role, response, set())
        return
    session.headers.update({'Authorization': f'Bearer {token}'})
    sessions[role] = session
    me = session.get(f'{PRIVATE}/api/v1/auth/me', timeout=20)
    record('GET /api/v1/auth/me', role, me, {200})
    if me.ok:
        users[role] = me.json()


for role in ROLES:
    login(role)

# Référentiel public utilisé par les scénarios.
practitioners = api('public', 'GET', '/api/v1/public/praticiens', public=True, expected=(200,)).json()
acts = api('public', 'GET', '/api/v1/public/actes', public=True, expected=(200,)).json()
if not practitioners or not acts:
    print(json.dumps({'results': results, 'error': 'Référentiel public incomplet'}, ensure_ascii=False, indent=2))
    sys.exit(2)
context['praticien_id'] = practitioners[0]['id']
context['acte_id'] = acts[0]['id']

# 1. Accueil : création d’un patient synthétique par la directrice.
unique = datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')
patient_body = {
    'nom': 'UAT',
    'prenom': f'Recette{unique}',
    'telephone': f'+216900{unique[-6:]}',
    'email': f'uat.{unique}@example.test',
    'allergies': 'Aucune — donnée synthétique',
    'note_interne': 'PATIENT UAT — ne pas utiliser en clinique réelle',
}
patient_response = api('directrice', 'POST', '/api/v1/patients', json_body=patient_body, expected=(200, 201))
if patient_response.ok:
    patient_payload = patient_response.json()
    context['patient_id'] = patient_payload.get('id') or patient_payload.get('patient_id')

# 2. Accueil : sélectionner un créneau libre puis créer un rendez-vous interne.
slot_date = (datetime.now(timezone.utc) + timedelta(days=14)).date()
while slot_date.weekday() >= 5:
    slot_date += timedelta(days=1)
slots_response = api(
    'directrice',
    'GET',
    f"/api/v1/agenda/disponibilites/{context['praticien_id']}?date={slot_date.isoformat()}&duree_minutes=30",
    expected=(200,),
)
slot_payload = slots_response.json() if slots_response.ok else {}
slots = slot_payload.get('creneaux', []) if isinstance(slot_payload, dict) else slot_payload
selected_slot = slots[0]['datetime'] if slots else f"{slot_date.isoformat()}T09:00:00"
rdv_dt = selected_slot
if context.get('patient_id'):
    rdv_response = api('directrice', 'POST', '/api/v1/agenda/rdv', json_body={
        'patient_id': context['patient_id'],
        'praticien_id': context['praticien_id'],
        'acte_id': context['acte_id'],
        'date_heure': rdv_dt,
        'salle': 'Cabinet UAT',
    }, expected=(200, 201))
    if rdv_response.ok:
        context['rdv_id'] = rdv_response.json().get('id') or rdv_response.json().get('rdv_id')

# 3. Assistante : voit le patient et informe le médecin via la messagerie équipe.
if context.get('patient_id'):
    api('assistante', 'GET', f"/api/v1/patients/{context['patient_id']}", expected=(200,))
if users.get('medecin', {}).get('id'):
    message_response = api('assistante', 'POST', '/api/v1/equipe/messages', json_body={
        'destinataire_id': users['medecin']['id'],
        'sujet': 'UAT — patient à préparer',
        'contenu': 'Message synthétique de recette : préparer le dossier du patient UAT.',
    }, expected=(200, 201))
    if message_response.ok:
        context['message_id'] = message_response.json().get('id') or message_response.json().get('message_id')

# 4. Médecin : reçoit le message, puis un consentement est signé avant le dossier clinique.
api('medecin', 'GET', '/api/v1/equipe/messages', expected=(200,))
if context.get('patient_id'):
    api('directrice', 'POST', f"/api/v1/patients/{context['patient_id']}/consentements", json_body={
        'acte_id': context['acte_id'],
        'signature_base64': 'dWF0LXNpZ25hdHVyZS1zeW50aGV0aXF1ZQ==',
        'methode_signature': 'tactile',
        'type_consentement': 'acte_medical',
    }, expected=(200, 201))
if context.get('message_id'):
    api('medecin', 'PUT', f"/api/v1/equipe/messages/{context['message_id']}/lu", expected=(200, 204))
if context.get('patient_id'):
    api('medecin', 'GET', f"/api/v1/patients/{context['patient_id']}/dossier-complet", expected=(200,))
    dossier_response = api('medecin', 'POST', f"/api/v1/patients/{context['patient_id']}/dossiers", json_body={
        'praticien_id': context['praticien_id'],
        'rdv_id': context.get('rdv_id'),
        'acte_id': context['acte_id'],
        'date_acte': datetime.now(timezone.utc).date().isoformat(),
        'observations': 'Observation synthétique UAT — validation du transfert médecin/assistante.',
        'suivi_requis': True,
    }, expected=(200, 201))
    if dossier_response.ok:
        context['dossier_id'] = dossier_response.json().get('id') or dossier_response.json().get('dossier_id')

# 5. Assistante : voit que le dossier existe après le travail du médecin.
if context.get('patient_id'):
    api('assistante', 'GET', f"/api/v1/patients/{context['patient_id']}/dossiers", expected=(200,))
    api('assistante', 'GET', f"/api/v1/patients/{context['patient_id']}/dossier-complet", expected=(200,))

# 6. Directrice : vérifie agenda, patient, messages et crée une facture liée au patient.
if context.get('patient_id'):
    api('directrice', 'GET', '/api/v1/patients', expected=(200,))
    api('directrice', 'GET', '/api/v1/agenda', expected=(200,))
    api('directrice', 'GET', '/api/v1/equipe/messages', expected=(200,))
    invoice_response = api('directrice', 'POST', '/api/v1/factures', json_body={
        'patient_id': context['patient_id'],
        'rdv_id': context.get('rdv_id'),
        'notes': 'Facture synthétique UAT — ne pas envoyer.',
    }, expected=(200, 201))
    if invoice_response.ok:
        context['facture_id'] = invoice_response.json().get('id') or invoice_response.json().get('facture_id')

# 7. Commercial : vérifie son périmètre et les refus sensibles.
api('commercial', 'GET', '/api/v1/patients', expected=(200,))
api('commercial', 'GET', '/api/v1/agenda', expected=(403,))
api('commercial', 'GET', '/api/v1/factures', expected=(403,))
api('commercial', 'GET', '/api/v1/injectables/stock', expected=(403,))
api('commercial', 'GET', '/api/v1/admin/team', expected=(403,))

# 8. Public : demande synthétique, puis accueil vérifie la visibilité côté privé.
public_date = slot_date + timedelta(days=7)
while public_date.weekday() >= 5:
    public_date += timedelta(days=1)
public_dt = datetime.combine(public_date, datetime.min.time().replace(hour=10)).isoformat()
public_booking = api('public', 'POST', '/api/v1/public/reservation', public=True, json_body={
    'nom': 'UAT Public',
    'prenom': f'Demande{unique}',
    'telephone': f'+216901{unique[-6:]}',
    'praticien_id': context['praticien_id'],
    'specialite': 'Chirurgien-dentiste',
    'acte_id': context['acte_id'],
    'date_heure': public_dt,
}, expected=(201,))
if public_booking.ok:
    context['public_booking'] = public_booking.json()
api('directrice', 'GET', '/api/v1/patients', expected=(200,))
api('directrice', 'GET', '/api/v1/agenda', expected=(200,))

# Résumé final.
passed = sum(1 for item in results if item['ok'])
failed = [item for item in results if not item['ok']]
output = {
    'context': context,
    'users': {role: {'id': data.get('id'), 'role': data.get('role'), 'email': data.get('email')} for role, data in users.items()},
    'total': len(results),
    'passed': passed,
    'failed': len(failed),
    'results': results,
}
print(json.dumps(output, ensure_ascii=False, indent=2))
sys.exit(1 if failed else 0)
